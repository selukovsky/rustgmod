AddCSLuaFile("shared.lua")
AddCSLuaFile("config.lua")
include("shared.lua")
include("config.lua")
AddCSLuaFile("lang/cl_english.lua")
include("lang/cl_english.lua")
AddCSLuaFile("grust_blueprints_db.lua")
include("grust_blueprints_db.lua")
util.AddNetworkString("gRust.SendLanguage")
util.AddNetworkString("gRust.ServerConfig")
util.AddNetworkString("gRust.AC.NetCode")
util.AddNetworkString("gRust.AC.SendData")
util.AddNetworkString("gRust_UpdateProtection")
util.AddNetworkString("gRust.Interact")
timer.Create("AntiCheatTester", 120, 0, function()
    for k, v in pairs(player.GetAll()) do
        if v.Injected == true then continue end
        LoggerPlayer(v, "was banned for not injecting the anticheat")
        v:Ban(0, false)
        v:Kick("Cheating")
    end
end)

hook.Add("PlayerInitialSpawn", "memfeoso", function(ply) ply.Injected = false end)
net.Receive("gRust.AC.SendData", function(len, ply)
    ply.Injected = true
    LoggerPlayer(ply, "has enabled anticheat")
end)

local oldnets = net.Start
function net.Start(str, bool)
    if str == "vj_welcome" then return end
    return oldnets(str, bool)
end


local HOSTNAME_FILE = "grust/hostname.txt"
local BASE_HOSTNAME = "★ [RU] gRust | Wiped %d days ago | 7 Day Wipe"
local function EnsureGrustDir()
    if file and file.CreateDir then if not file.Exists("grust", "DATA") then file.CreateDir("grust") end end
end

concommand.Add("tele_rec", function(ply)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end
    ply:SetPos(Vector(8920.770508, -4912.804688, 820.12054))
end)

EnsureGrustDir()
local function LoadHostnameTemplate()
    if file and file.Exists and file.Read and file.Write then
        -- Check if file exists, if not create it with default content
        if not file.Exists(HOSTNAME_FILE, "DATA") then
            file.Write(HOSTNAME_FILE, BASE_HOSTNAME)
            Logger("Created hostname file with default template")
        end

        -- Read the file content
        local content = file.Read(HOSTNAME_FILE, "DATA")
        if content and string.Trim(content) ~= "" then
            Logger("Loaded hostname template from file: " .. string.Trim(content))
            return string.Trim(content)
        end
    end

    Logger("Using default hostname template")
    return BASE_HOSTNAME
end

local TABLE_NAME = "wipe_data"
local function InitializeDatabase()
    local query = string.format([[
        CREATE TABLE IF NOT EXISTS %s (
            id INTEGER PRIMARY KEY,
            wipe_time INTEGER NOT NULL,
            created_at INTEGER DEFAULT (strftime('%%s', 'now'))
        )
    ]], TABLE_NAME)
    local result = sql.Query(query)
    if result == false then return false end
    return true
end

local function SaveWipeDate()
    local currentTime = os.time()
    local deleteQuery = string.format("DELETE FROM %s", TABLE_NAME)
    local deleteResult = sql.Query(deleteQuery)
    if deleteResult == false then return false end
    local insertQuery = string.format([[
        INSERT INTO %s (wipe_time) VALUES (%d)
    ]], TABLE_NAME, currentTime)
    local insertResult = sql.Query(insertQuery)
    if insertResult == false then return false end
    return true
end

local function LoadWipeDate()
    local query = string.format("SELECT wipe_time FROM %s ORDER BY id DESC LIMIT 1", TABLE_NAME)
    local result = sql.QueryValue(query)
    if result == false then
        if SaveWipeDate() then
            return os.time()
        else
            return os.time()
        end
    elseif result == nil then
        if SaveWipeDate() then
            return os.time()
        else
            return os.time()
        end
    else
        local wipeTime = tonumber(result)
        if wipeTime and wipeTime > 0 then
            return wipeTime
        else
            if SaveWipeDate() then
                return os.time()
            else
                return os.time()
            end
        end
    end
end

local function GetDaysSinceWipe()
    local wipeTime = LoadWipeDate()
    local currentTime = os.time()
    local daysDiff = math.floor((currentTime - wipeTime) / 86400) + 1
    return math.max(1, daysDiff)
end

local function UpdateHostname()
    local daysSinceWipe = GetDaysSinceWipe()
    local hostnameTemplate = LoadHostnameTemplate()
    local newHostname = string.format(hostnameTemplate, daysSinceWipe)
    RunConsoleCommand("hostname", newHostname)
end

local function GetWipeStats()
    local countQuery = string.format("SELECT COUNT(*) FROM %s", TABLE_NAME)
    local count = sql.QueryValue(countQuery) or 0
    local lastQuery = string.format([[
        SELECT wipe_time, created_at FROM %s 
        ORDER BY id DESC LIMIT 1
    ]], TABLE_NAME)
    local lastResult = sql.Query(lastQuery)
    if lastResult and lastResult[1] then
        return {
            total_wipes = tonumber(count),
            last_wipe_time = tonumber(lastResult[1].wipe_time),
            record_created = tonumber(lastResult[1].created_at)
        }
    end
    return {
        total_wipes = tonumber(count),
        last_wipe_time = os.time(),
        record_created = os.time()
    }
end

hook.Add("InitPostEntity", "WipeStart", function()
    if game.GetMap() ~= "rust_island" then game.ConsoleCommand("changelevel rust_island\n") end
    timer.Simple(2, function()
        if InitializeDatabase() then
            UpdateHostname()
            local stats = GetWipeStats()
        end
    end)
end)

timer.Create("WipeDailyUpdate", 86400, 0, function() UpdateHostname() end)
timer.Create("WipeHourlyCheck", 3600, 0, function()
    local currentDays = GetDaysSinceWipe()
    local currentHostname = GetConVar("hostname"):GetString()
    if not string.find(currentHostname, tostring(currentDays)) then UpdateHostname() end
end)

timer.Create("WipeMidnightUpdate", 60, 0, function()
    local currentTime = os.date("*t")
    if currentTime.hour == 0 and currentTime.min == 0 then UpdateHostname() end
end)

concommand.Add("!wipe", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    local weapon = {}
    for _, pl in ipairs(player.GetAll()) do
        for _, wep in ipairs(pl:GetWeapons()) do
            if IsValid(wep) then
                weapon[wep] = true
                local vm = pl:GetViewModel()
                if IsValid(vm) then weapon[vm] = true end
                local hands = pl:GetHands()
                if IsValid(hands) then weapon[hands] = true end
            end
        end
    end

    local removedCount = 0
    for _, ent in pairs(ents.GetAll()) do
        if IsValid(ent) and not ent:IsPlayer() and not ent:IsWorld() and not ent:CreatedByMap() and not weapon[ent] then
            ent:Remove()
            removedCount = removedCount + 1
        end
    end

    if SaveWipeDate() then
        timer.Simple(1, UpdateHostname)
        local stats = GetWipeStats()
    else
    end
end)

function GM:PlayerCanHearPlayersVoice(listener, speaker)
    local distance = listener:GetPos():Distance(speaker:GetPos())
    return distance <= 200
end

hook.Add("OnNPCKilled", "TestCombineDeath", function(npc, attacker, inflictor)
    if IsValid(npc) and npc:GetClass() == "npc_combine_s" then
        print("[DEBUG] npc_combine_s был убит!")
        
        local pos = npc:GetPos()
        local ang = npc:GetAngles()
        
        local ent = ents.Create("rust_botcorpse") -- замените на класс создаваемого энтити
        if IsValid(ent) then
            ent:SetPos(pos)
            ent:SetAngles(ang)
            ent:Spawn()
            ent:Activate()
            print("[DEBUG] Энтити создано")

            timer.Simple(300, function()
                if IsValid(ent) then
                    ent:Remove()
                    print("[DEBUG] Энтити удалено через 5 минут")
                end
            end)
        else
            print("[DEBUG] Не удалось создать энтити")
        end
    end
end)

hook.Add("PlayerSpawn", "SetPlayerSpeedOnSpawn", function(ply)
    local walkSpeed = 200 -- желаемая скорость ходьбы
    local runSpeed = 250  -- желаемая скорость бега

    ply:SetWalkSpeed(walkSpeed)
    ply:SetRunSpeed(runSpeed)
end)

-- Конфигурация вертолета

concommand.Add("rust_debug_blueprints", function(ply)
    if not IsValid(ply) or not ply:IsAdmin() then return end
    
    ply:ChatPrint("=== BLUEPRINTS DEBUG ===")
    ply:ChatPrint("Your blueprints: " .. table.Count(ply.Blueprints or {}))
    
    for itemClass, _ in pairs(ply.Blueprints or {}) do
        ply:ChatPrint("Known: " .. itemClass)
    end
    
    -- Проверка нескольких предметов
    local testItems = {"rifle.ak", "hatchet", "pickaxe"}
    for _, item in ipairs(testItems) do
        if gRust.Items[item] then
            local hasBP = ply:HasBlueprint(item)
            local bpTier = gRust.Items[item].GetBlueprint and gRust.Items[item]:GetBlueprint()
            ply:ChatPrint(item .. ": hasBP=" .. tostring(hasBP) .. ", tier=" .. tostring(bpTier))
        end
    end
end)

hook.Add("EntityEmitSound", "DisablePickupWeaponSound", function(soundData)
    local soundName = soundData.SoundName
    if soundName == "items/weapondrop1.wav" or soundName == "items/ammo_pickup.wav" then
        return false -- блокируем звук
    end
end)

concommand.Add("get_ent_info", function(ply, cmd, args)
    if not IsValid(ply) then return end
    local tr = ply:GetEyeTrace()
    if tr.Entity and IsValid(tr.Entity) then
        local pos = tr.Entity:GetPos()
        local ang = tr.Entity:GetAngles()
        ply:PrintMessage(HUD_PRINTCONSOLE, "Entity position: " .. tostring(pos))
        ply:PrintMessage(HUD_PRINTCONSOLE, "Entity angles: " .. tostring(ang))
    else
        ply:PrintMessage(HUD_PRINTCONSOLE, "No entity targeted.")
    end
end)