gRust.Testing = true
gRust.InDev = true
--
-- Player Movement
--  
gRust.Config.WalkSpeed = 140
gRust.Config.RunSpeed = 160
gRust.Config.CrouchSpeed = 50
gRust.Config.JumpPower = 190
gRust.Config.Language = "English"
--
-- Chat
--
gRust.Config.CmdPrefix = "/"
--
-- Farming
--
gRust.Config.EntRespawnTime = 120
gRust.Config.WaterLevel = -62
--
-- Interact
--
gRust.Config.InteractRange = 12500
gRust.Config.MeleeRange = 3000
--
-- Building
--
gRust.Config.TCRadius = 450
gRust.Config.Scale = 63 -- Rust units to gmod units
--
-- Vending Machines
--
gRust.Config.MaxSellOrders = 6
--
-- Chat Messages
--
gRust.Config.ChatMessages = {
    {
        Text = "Be sure to join our discord: https://discord.gg/GkgTz6Ydkh",
        Time = 315
    },
    {
        Text = "Welcome to gRust!",
        Time = 425
    },
}

--
-- Electrical
--
gRust.Config.MaxWires = 5
gRust.Config.MaxWireLength = 10
--
-- Modded
--
gRust.Config.Blueprints = true
gRust.Config.ProcessSpeed = 4 -- Multiplier for furnaces and recyclers
gRust.Stacks = {
    ItemStack = 1,
    ResourceStack = 1,
    ClothingStack = 1,
    ToolStack = 1,
    MedicalStack = 1,
    WeaponStack = 1,
    AttachmentStack = 1,
    AmmoStack = 1,
    ExplosivesStack = 1,
}

gRust.Gather = {
    TreeGather = 1,
    StoneGather = 1,
    MetalGather = 1,
    SulfurGather = 1,
    HQGather = 1,
    HempGather = 1,
}

hook.Add("gRust.Loaded", "gRust.LoadKits", function()

    gRust.RegisterKit("hunter", {
        name = "Охотник",
        order = 0,
        icon = "materials/items/weapons/bow.png",
        redemptions = 1,
        items = {
            {id = "bow.hunting", amount = 1},
            {id = "arrow.wooden", amount = 30},
            {id = "bandage", amount = 5},
            {id = "stonehatchet", amount = 1},
            {id = "horse.cook", amount = 3},
            {id = "burlap.pants", amount = 1},
            {id = "burlap.shirt", amount = 1}
        }
    })

    gRust.RegisterKit("resio", {
        name = "Ресурсы (Обрывки чертежей 150x)",
        order = 0,
        icon = "materials/items/resources/metal_fragments.png",
        redemptions = 1,
        price = {
        {id = "bluefrag", amount = 150}
    },
        items = {
            {id = "metal.fragments", amount = 5500},
            {id = "wood", amount = 5000},
            {id = "scrap", amount = 500},
            {id = "metal.refined", amount = 100},
            {id = "gunpowder", amount = 1000}
        }
    })

    gRust.RegisterKit("vip1res", {
        name = "VIP Ресурсы",
        order = 0,
        icon = "materials/items/resources/metal_fragments.png",
        redemptions = 1,
        items = {
            {id = "metal.fragments", amount = 5000},
            {id = "wood", amount = 5000},
            {id = "scrap", amount = 500},
            {id = "metal.refined", amount = 100},
            {id = "gunpowder", amount = 1000}
        }
    })

    gRust.RegisterKit("vip1wep", {
        name = "VIP Оружие",
        order = 0,
        icon = "materials/items/resources/metal_fragments.png",
        redemptions = 1,
        items = {
            {id = "coffee.mask", amount = 1},
            {id = "roadchest", amount = 1},
            {id = "kilt", amount = 1},
            {id = "hoodieblue", amount = 1},
            {id = "pantsg", amount = 1},
            {id = "shoes", amount = 1},
            {id = "sar.m39", amount = 1},
            {id = "ammo.rifle", amount = 128},
            {id = "syringe.medical", amount = 5},
            {id = "f1.grenade", amount = 3}
        }
    })

    gRust.RegisterKit("vip1dom", {
        name = "VIP Дом",
        order = 0,
        icon = "materials/items/resources/metal_fragments.png",
        redemptions = 1,
        items = {
            {id = "cupboard.tool", amount = 1},
            {id = "sleepingbag", amount = 1},
            {id = "workbench1", amount = 1},
            {id = "box.wooden.large", amount = 2},
            {id = "wall.frame.doubledoor", amount = 2},
            {id = "building.planner", amount = 1},
            {id = "hammer", amount = 1},
            {id = "protaxe", amount = 1},
            {id = "protpick", amount = 1}
        }
    })

    gRust.RegisterKit("combat", {
        name = "Комбат (Обрывки чертежей 500x)",
        order = 0,
        icon = "materials/icons2/metalfacemask.png",
        redemptions = 1,
        price = {
        {id = "bluefrag", amount = 500}
    },
        items = {
            {id = "hqm.mask", amount = 1},
            {id = "hqm.chest", amount = 1},
            {id = "kilt", amount = 1},
            {id = "hoodieblue", amount = 1},
            {id = "pantsg", amount = 1},
            {id = "shoes", amount = 1},
            {id = "rifle.ak", amount = 1},
            {id = "ammo.rifle", amount = 256},
            {id = "syringe.medical", amount = 8},
            {id = "grenade.beancan", amount = 5},
            {id = "rifle.bolt", amount = 1}
        }
    })


    --[[gRust.RegisterKit("starter", {

        name = "Starter",

        order = 0,hazmatsuit_scientist

        redemptions = 1,

        items = {

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "stone",

                amount = 1000,

            },

            {

                id = "stone",

                amount = 500,

            },

            {

                id = "metal.fragments",

                amount = 500,

            },

            {

                id = "hq_metal",

                amount = 20,

            },

            {

                id = "furnace",

                amount = 1,

            },

            {

                id = "large_wood_box",

                amount = 1,

            },

            {

                id = "revolver",

                amount = 1,

            },

            {

                id = "hunting_bow",

                amount = 1,

            },

            {

                id = "arrow",

                amount = 25,

            }

        }

    })



    gRust.RegisterKit("vip", {

        name = "VIP",

        order = 1,

        redemptions = 1,

        icon = "kits/vip.png",

        items = {

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "stone",

                amount = 1000,

            },

            {

                id = "stone",

                amount = 500,

            },

            {

                id = "metal.fragments",

                amount = 500,

            },

            {

                id = "hq_metal",

                amount = 20,

            },

            {

                id = "furnace",

                amount = 1,

            },

            {

                id = "large_wood_box",

                amount = 1,

            },

            {

                id = "revolver",

                amount = 1,

            },

            {

                id = "hunting_bow",

                amount = 1,

            },

            {

                id = "arrow",

                amount = 25,

            }

        }

    })



    gRust.RegisterKit("gold_vip", {

        name = "Gold VIP",

        redemptions = 1,

        order = 2,

        icon = "kits/gold_vip.png",

        items = {

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "stone",

                amount = 1000,

            },

            {

                id = "stone",

                amount = 1000,

            },

            {

                id = "stone",

                amount = 1000,

            },

            {

                id = "stone",

                amount = 500,

            },

            {

                id = "metal.fragments",

                amount = 1000,

            },

            {

                id = "metal.fragments",

                amount = 500,

            },

            {

                id = "hq_metal",

                amount = 75,

            },

            {

                id = "tier1",

                amount = 1,

            },

            {

                id = "large_wood_box",

                amount = 2,

            },

            {

                id = "scientist_suit",

                amount = 1,

            },

            {

                id = "sap",

                amount = 1,

            },

            {

                id = "dbarrel",

                amount = 1,

            },

            {

                id = "shotgun_ammo",

                amount = 6,

            },

            {

                id = "pistol_ammo",

                amount = 12,

            },

            {

                id = "crossbow",

                amount = 1,

            },

            {

                id = "arrow",

                amount = 25,

            },

            {

                id = "gunpowder",

                amount = 120,

            },

            {

                id = "doormetal",

                amount = 1,

            },

        }

    })



    gRust.RegisterKit("platinum_vip", {

        name = "Platinum VIP",

        redemptions = 1,

        order = 3,

        icon = "kits/platinum_vip.png",

        items = {

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "wood",

                amount = 1000,

            },

            {

                id = "stone",

                amount = 1000,

            },

            {

                id = "stone",

                amount = 1000,

            },

            {

                id = "stone",

                amount = 1000,

            },

            {

                id = "stone",

                amount = 1000,

            },

            {

                id = "stone",

                amount = 1000,

            },

            {

                id = "metal.fragments",

                amount = 1000,

            },

            {

                id = "metal.fragments",

                amount = 1000,

            },

            {

                id = "metal.fragments",

                amount = 1000,

            },

            {

                id = "hq_metal",

                amount = 150,

            },

            {

                id = "furnace",

                amount = 1,

            },

            {

                id = "large_wood_box",

                amount = 3,

            },

            {

                id = "pickaxe",

                amount = 1,

            },

            {

                id = "hatchet",

                amount = 1,

            },

            {

                id = "medical_syringe",

                amount = 1,

            },

            {

                id = "custom_smg",

                amount = 1,

            },

            {

                id = "thompson",

                amount = 1,

            },

            {

                id = "pistol_ammo",

                amount = 80,

            },

            {

                id = "satchel",

                amount = 1,

            }

        }

    })]]
end)