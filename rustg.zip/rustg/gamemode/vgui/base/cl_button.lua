local PANEL = {}

local function invalidateLayout(pnl) pnl:InvalidateLayout() end

zlib.func.accessor(PANEL, 'm_iTextSpacing', 'TextSpacing', invalidateLayout)

zlib.func.accessor(PANEL, 'm_sFont', 'Font', invalidateLayout)
zlib.func.accessor(PANEL, 'm_sText', 'Text', invalidateLayout)
zlib.func.accessor(PANEL, 'm_iTextAlign', 'TextAlign', invalidateLayout)

zlib.func.accessor(PANEL, 'm_tTextStyle', 'TextStyle')
function PANEL:SetTextStyle(style)
	self.m_tTextStyle = style
	self:LerpColor('textColor', style, true)
end

zlib.func.accessor(PANEL, 'm_MIcon', 'Icon', invalidateLayout)
zlib.func.accessor(PANEL, 'm_iIconSize', 'IconSize', invalidateLayout)
zlib.func.accessor(PANEL, 'm_iIconAlign', 'IconAlign', invalidateLayout)

zlib.func.accessor(PANEL, 'm_tIconStyle', 'IconStyle')
function PANEL:SetIconStyle(style)
	self.m_tIconStyle = style
	self:LerpColor('iconColor', style or self:GetTextStyle(), true)
end

function PANEL:Init()
	self:SetFont(fonts['RobotoBold'][17])
	self:SetContentSpacing(ss(8))

	self:SetStyles({})

	self:SetText('')
	self:SetFontColor(colors.white220)
	self:SetIconColor(colors.white120)

	self:SetIconSize(ss(24))

	self.textX, self.textY = 0, 0
	self.iconX, self.iconY = 0, 0
end

zlib.func.accessor(PANEL, 'm_tStyles', 'Styles')
zlib.func.accessor(PANEL, 'm_aStyle', 'Style', function(self, style)
	if self:GetStyle() == style then return end

	local styleTable = self:GetStyles()[style]
	if not styleTable then return end

	self:SetMainStyle(styleTable.main)
	self:SetTextStyle(styleTable.text)
	self:SetIconStyle(styleTable.icon)
end)

function PANEL:PerformLayout(w, h)
	local spacing = self:GetContentSpacing()

	local text, font = self:GetText(), self:GetFont()
	local textAlign = self:GetTextAlign() or TEXT_ALIGN_LEFT

	surface.SetFont(font)
	local textW, textH = surface.GetTextSize(text or '')

	local icon = self:GetIcon()
	local iconS, iconAlign = self:GetIconSize(), self:GetIconAlign() or TEXT_ALIGN_LEFT

	local fullIconW = iconS + spacing
	if not icon then
		fullIconW = 0
		iconS = 0
	end

	local fullTextW = w - fullIconW
	local textSpacing = (icon and textAlign == iconAlign) and self:GetTextSpacing() or spacing

	local textX, textY = fullIconW + textSpacing, (h - textH) / 2
	if textAlign == TEXT_ALIGN_CENTER then
		textX = fullIconW + fullTextW / 2
	elseif textAlign == TEXT_ALIGN_RIGHT then
		textX = fullIconW + fullTextW - textSpacing
	end

	local iconX, iconY = spacing, (h - iconS) / 2
	if iconAlign == TEXT_ALIGN_CENTER then
		if textAlign == TEXT_ALIGN_CENTER then
			local fullW = iconS + textSpacing + textW

			iconX = (w - fullW) / 2
			textX = iconX + iconS + textSpacing + textW / 2
		else
			iconX = (w - iconS) / 2
		end
	elseif iconAlign == TEXT_ALIGN_RIGHT then
		iconX = w - fullIconW
		textX = textX - fullIconW
	end

	self.textX, self.textY = textX, textY
	self.iconX, self.iconY = iconX, iconY
end

function PANEL:PaintOver(w, h)
	local icon = self:GetIcon()
	if icon then
		local iconS = self:GetIconSize()
		local iconColor = self:LerpColor('iconColor', self:GetIconStyle() or self:GetTextStyle())

		surface.SetDrawColor(iconColor)
		surface.SetMaterial(icon)
		surface.DrawTexturedRect(self.iconX, self.iconY, iconS, iconS)
	end

	local text = self:GetText()
	if text and text ~= '' then
		local textColor = self:LerpColor('textColor', self:GetTextStyle())

		draw.DrawText(text, self:GetFont(), self.textX, self.textY, textColor, self:GetTextAlign())
	end
end

function PANEL:SetFontColor(clr)
	self:SetTextStyle({
		default = clr,
	})
end

function PANEL:SetIconColor(clr)
	self:SetIconStyle({
		default = clr,
	})
end

vgui.Register('Rust::Button', PANEL, 'Rust::ButtonBase')