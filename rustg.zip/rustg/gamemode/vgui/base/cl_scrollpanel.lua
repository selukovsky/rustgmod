local PANEL = {}

function PANEL:Init()
	hook.Add('VGUIMousePressed', self, function(_, pnl, key)
		if not pnl:HasParent(self) or pnl:GetPreventScroll() then return end
		self:OnMousePressed(key)
	end)
end

function PANEL:OnMousePressed(key)
	self:GetParent():OnMousePressed(key)
end

function PANEL:OnMouseReleased(key)
	self:GetParent():OnMouseReleased(key)
end

local function getArrangementPos(arrangement, canvasSize, scrollSize)
	local pos

	if arrangement == SCROLLARRANGEMENT_TOP then
		pos = 0
	elseif arrangement == SCROLLARRANGEMENT_CENTER then
		pos = (scrollSize - canvasSize) / 2
	else
		pos = scrollSize - canvasSize
	end

	return pos
end

function PANEL:SizeToChildren(width, height)
	local maxX, maxY = 0, 0

	for _, child in ipairs(self:GetChildren()) do
		if child:GetPreventScrollCanvasLayout() then continue end

		local x, y, w, h = child:GetBounds()
		maxX = math.max(x + w, maxX)
		maxY = math.max(y + h, maxY)
	end

	if width then
		self:SetWide(maxX)
	end

	if height then
		self:SetTall(maxY)
	end
end

function PANEL:PerformLayout()
	if self.m_bPreventLayout then return end

	local parent = self:GetParent()

	local axis = parent:GetScrollAxis()
	if axis == SCROLLAXIS_VERTICAL then
		self:SizeToChildren(false, true)
		self:SetWide(parent:GetWide())
	elseif axis == SCROLLAXIS_HORIZONTAL then
		self:SizeToChildren(true, false)
		self:SetTall(parent:GetTall())
	elseif axis == SCROLLAXIS_BOTH then
		self:SizeToChildren(true, true)
	end

	local arrangement = parent:GetScrollArrangement()
	local w, h = self:GetSize()

	if axis == SCROLLAXIS_VERTICAL then
		self:SetY(getArrangementPos(arrangement, h, parent:GetTall()))
	elseif axis == SCROLLAXIS_HORIZONTAL then
		self:SetX(getArrangementPos(arrangement, w, parent:GetWide()))
	else
		self:SetX(getArrangementPos(arrangement, w, parent:GetWide()))
		self:SetY(getArrangementPos(arrangement, h, parent:GetTall()))
	end

	parent.velX = 0
	parent.velY = 0
end

vgui.Register('Rust::ScrollPanel_Internal', PANEL, 'EditablePanel')

--

local PANEL = {}

SCROLLAXIS_VERTICAL = 1
SCROLLAXIS_HORIZONTAL = 2
SCROLLAXIS_BOTH = 3

zlib.func.accessor(PANEL, 'm_iScrollAxis', 'ScrollAxis')

SCROLLARRANGEMENT_TOP = 1
SCROLLARRANGEMENT_LEFT = 1
SCROLLARRANGEMENT_CENTER = 2
SCROLLARRANGEMENT_BOTTOM = 3
SCROLLARRANGEMENT_RIGHT = 3

zlib.func.accessor(PANEL, 'm_iScrollArrangement', 'ScrollArrangement')
zlib.func.accessor(PANEL, 'm_bStrictBorders', 'StrictBorders')

function PANEL:Init()
	self:SetScrollAxis(SCROLLAXIS_VERTICAL)
	self:SetScrollArrangement(SCROLLARRANGEMENT_TOP)
	self:SetNoiseColor(colors.white0)

	local canvas = vgui.Create('Rust::ScrollPanel_Internal', self)
	canvas:SetSize(0, 0)

	self.canvas = canvas

	self.mouseMoves = {}
	self.velX, self.velY = 0, 0
end

function PANEL:OnMousePressed(keyCode)
	self.isMouseDown = true

	self.startX, self.startY = input.GetCursorPos()

	vgui.GetControlTable('Rust::Panel').OnMousePressed(self, keyCode)
end

function PANEL:OnMouseReleased(keyCode)
	local canvas = self.canvas

	canvas:SetMouseInputEnabled(true)

	self.isMouseDown, self.isMouseCaptured = nil

	local moves = self.mouseMoves
	local movesCount = #moves

	if movesCount > 2 then
		local velX, velY = 0, 0
		local startIndex = math.max(movesCount - 5, 1)

		for i = startIndex + 1, movesCount do
			local move = moves[i]
			local prevMove = moves[i - 1]

			local delta = move.time - prevMove.time
			if delta > 0 and delta < 0.5 then
				velX = velX + (move.x - prevMove.x) / delta
				velY = velY + (move.y - prevMove.y) / delta
			end
		end

		local canvasW, canvasH = canvas:GetSize()
		canvasW = canvasW * 10
		canvasH = canvasH * 10

		local count = movesCount - startIndex
		self.velX = math.Clamp(velX * 0.75 / count, -canvasW, canvasW)
		self.velY = math.Clamp(velY * 0.75 / count, -canvasH, canvasH)
	else
		self.velX, self.velY = 0, 0
	end

	self.mouseMoves = {}

	vgui.GetControlTable('Rust::Panel').OnMouseReleased(self, keyCode)
end

local scrollSensitivity = ss(45)
function PANEL:OnMouseWheeled(delta)
	local canvas = self.canvas
	local deltaMove = zlib.math.sign(delta) * scrollSensitivity

	local scrollAxis = self:GetScrollAxis()

	if scrollAxis == SCROLLAXIS_VERTICAL then
		canvas:SetY(canvas:GetY() + deltaMove)
	elseif scrollAxis == SCROLLAXIS_HORIZONTAL then
		canvas:SetX(canvas:GetX() + deltaMove)
	end
end

local function applyElastic(strict, value, min, max, resistance)
	if not min or not max then return value end

	if strict then
		return math.Clamp(value, min, max)
	end

	if value < min then
		return min - (min - value) / (1 + math.abs(min - value) / resistance)
	elseif value > max then
		return max + (value - max) / (1 + math.abs(value - max) / resistance)
	end

	return value
end

local function applyVelocity(value, drag)
	return math.Round(value * (1 - FrameTime()) * drag)
end

local function approachPosition(strict, pos, minPos, maxPos, scrollSize)
	if not minPos or not maxPos then return pos end

	if strict then
		return math.Clamp(pos, minPos, maxPos)
	end

	if pos < minPos then
		return math.Approach(pos, minPos, 6 * math.max(math.abs(pos - minPos) / scrollSize, 1))
	elseif pos > maxPos then
		return math.Approach(pos, maxPos, 6 * math.max(math.abs(maxPos - pos) / scrollSize, 1))
	end

	return pos
end

PANEL.OnCanvasMoved = zlib.func.zero

local scrollResistance = 250
local scrollDrag = 0.99
function PANEL:Think()
	local ft = FrameTime()
	local canvas = self.canvas

	if self.isMouseDown then
		if not input.IsMouseDown(MOUSE_LEFT) then
			self:OnMouseReleased(MOUSE_LEFT)
			return
		end

		local mouseX, mouseY = input.GetCursorPos()

		local deltaX = self.startX - mouseX
		local deltaY = self.startY - mouseY

		if self.isMouseCaptured then
			local moves = self.mouseMoves

			local newIndex = #moves + 1
			if newIndex > 10 then
				table.remove(moves, 1)
				newIndex = 10
			end

			moves[newIndex] = {
				x = mouseX,
				y = mouseY,
				time = CurTime(),
			}

			local posX, posY
			local axis = self:GetScrollAxis()

			if axis == SCROLLAXIS_VERTICAL then
				posY = self.offsetY - deltaY
			elseif axis == SCROLLAXIS_HORIZONTAL then
				posX = self.offsetX - deltaX
			elseif axis == SCROLLAXIS_BOTH then
				posX = self.offsetX - deltaX
				posY = self.offsetY - deltaY
			end

			if posX then
				canvas:SetX(applyElastic(self:GetStrictBorders(), posX, self.minPosX, self.maxPosX, scrollResistance))
			end

			if posY then
				canvas:SetY(applyElastic(self:GetStrictBorders(), posY, self.minPosY, self.maxPosY, scrollResistance))
			end

			self:OnCanvasMoved(canvas:GetPos())
		elseif math.abs(deltaX) > 5 or math.abs(deltaY) > 5 then
			canvas:SetMouseInputEnabled(false)
			self.isMouseCaptured = true

			self.startX, self.startY = mouseX, mouseY
			self.offsetX, self.offsetY = canvas:GetPos()
		end
	else
		ft = ft * 0.5
		local canvasX, canvasY = canvas:GetPos()

		local posX, posY
		local axis = self:GetScrollAxis()

		if axis == SCROLLAXIS_VERTICAL then
			posY = canvasY + math.Round(self.velY * ft * 0.5)
		elseif axis == SCROLLAXIS_HORIZONTAL then
			posX = canvasX + math.Round(self.velX * ft * 0.5)
		elseif axis == SCROLLAXIS_BOTH then
			posX = canvasX + math.Round(self.velX * ft * 0.5)
			posY = canvasY + math.Round(self.velY * ft * 0.5)
		end

		if posX then
			canvas:SetX(approachPosition(self:GetStrictBorders(), posX, self.minPosX, self.maxPosX, self:GetWide() * 0.125))
		end

		if posY then
			canvas:SetY(approachPosition(self:GetStrictBorders(), posY, self.minPosY, self.maxPosY, self:GetTall() * 0.125))
		end
	end

	self.velX = applyVelocity(self.velX, scrollDrag)
	self.velY = applyVelocity(self.velY, scrollDrag)
end

function PANEL:OnChildAdded(pnl)
	local canvas = self.canvas
	if IsValid(canvas) then
		pnl:SetParent(canvas)

		timer.Create(self, 0, 1, function()
			self:InvalidateLayout()
		end, 'Rust::ScrollPanel')
	end
end

local function calcMinsMaxs(arrangement, canvasSize, scrollSize, axis)
	local minPos, maxPos

	if arrangement == SCROLLARRANGEMENT_TOP then
		minPos = 0
		maxPos = canvasSize <= scrollSize and 0 or (scrollSize - canvasSize)
	elseif arrangement == SCROLLARRANGEMENT_BOTTOM then
		maxPos = scrollSize - canvasSize
		minPos = canvasSize <= scrollSize and maxPos or 0
	else
		if axis == SCROLLAXIS_BOTH then
			maxPos = scrollSize / 2
			minPos = maxPos - canvasSize
		else
			if canvasSize <= scrollSize then
				minPos = (scrollSize - canvasSize) / 2
				maxPos = minPos
			else
				minPos = 0
				maxPos = scrollSize - canvasSize
			end
		end
	end

	if maxPos < minPos then
		minPos, maxPos = maxPos, minPos
	end

	return minPos, maxPos
end

function PANEL:PerformLayout(w, h)
	local canvas = self.canvas

	local arrangement = self:GetScrollArrangement()
	local axis = self:GetScrollAxis()

	self.minPosX, self.maxPosX = calcMinsMaxs(arrangement, canvas:GetWide(), w, axis)
	self.minPosY, self.maxPosY = calcMinsMaxs(arrangement, canvas:GetTall(), h, axis)
end

function PANEL:Clear()
	self.canvas:Clear()
end

vgui.Register('Rust::ScrollPanel', PANEL, 'Rust::Panel')

--

local PANEL = {}

local function zoomPanel(target, zoom)
	if target:GetDisableZoom() then return end

	local x, y = target:GetUnmodifiedPos()
	local w, h = target:GetUnmodifiedSize()

	if target:GetZoomStatic() then
		local pivotX, pivotY = target:GetZoomPivotX() or 0, target:GetZoomPivotY() or 0

		w, h = w * pivotX, h * pivotY

		local originX, originY = x + w, y + h
		target:SetPos(originX * zoom - w, originY * zoom - h)
	else
		target:SetPos(x * zoom, y * zoom)
		target:SetSize(w * zoom, h * zoom)
	end
end

function PANEL:ClampZoom(val)
	return math.Clamp(val, 0.75, 5)
end

PANEL.OnZoom = zlib.func.zero
function PANEL:GetZoom() return self.zoom end
function PANEL:SetZoom(zoom)
	local canvas = self.canvas
	if not IsValid(canvas) then return end

	zoom = self:ClampZoom(zoom)

	local oldZoom = self:GetZoom()
	self.zoom = zoom

	if not oldZoom or oldZoom == zoom then return end

	self:InvalidateLayout(true)

	local canvasX, canvasY = canvas:GetUnmodifiedPos()
	local canvasW, canvasH = canvas:GetUnmodifiedSize()

	local mouseX, mouseY = self:ScreenToLocal(input.GetCursorPos())
	local deltaX, deltaY = canvasX - mouseX, canvasY - mouseY

	canvas.m_bPreventLayout = true

	local mult = zoom / oldZoom

	canvas:SetPos(mouseX + deltaX * mult, mouseY + deltaY * mult)
	canvas:SetSize(canvasW * mult, canvasH * mult)

	for _, child in ipairs(canvas:GetChildren()) do
		zoomPanel(child, mult)
	end

	self:OnZoom(zoom)
end

function PANEL:Init()
	self:SetScrollAxis(SCROLLAXIS_BOTH)
	self:SetScrollArrangement(SCROLLARRANGEMENT_CENTER)
	self:SetStrictBorders(true)

	self:SetZoom(1)
end

-- TODO: Remove this shit with canvas.m_bPreventLayout
function PANEL:OnMouseWheeled(delta)
	local deltaMove = zlib.math.sign(delta) * 0.1

	local oldZoom = self:GetZoom()
	local newZoom = self:ClampZoom(oldZoom + deltaMove)

	self:SetZoom(newZoom)
end

function PANEL:OnCanvasMoved()
	self.canvas.m_bPreventLayout = true
end

function PANEL:OnChildAdded(pnl)
	local canvas = self.canvas
	if not IsValid(canvas) then return end

	pnl:SetParent(canvas)

	timer.Create(self, 0, 1, function()
		self:InvalidateLayout()
	end, 'Rust::ZoomablePanel')

	zoomPanel(pnl, self:GetZoom())
end

vgui.Register('Rust::ZoomablePanel', PANEL, 'Rust::ScrollPanel')

--

local PANEL = FindMetaTable('Panel')

zlib.func.accessor(PANEL, 'm_bPreventScroll', 'PreventScroll')
zlib.func.accessor(PANEL, 'm_bPreventScrollCanvasLayout', 'PreventScrollCanvasLayout')
zlib.func.accessor(PANEL, 'm_bDisableZoom', 'DisableZoom')
zlib.func.accessor(PANEL, 'm_bZoomStatic', 'ZoomStatic')
zlib.func.accessor(PANEL, 'm_iZoomPivotX', 'ZoomPivotX')
zlib.func.accessor(PANEL, 'm_iZoomPivotY', 'ZoomPivotY')

PANEL.SetPos = zlib.func.detour(PANEL.SetPos, 'PANEL.SetPos', function(orig, pnl, x, y)
	pnl.___realPosX = x
	pnl.___realPosY = y

	orig(pnl, x, y)
end)

function PANEL:GetUnmodifiedPos()
	return self.___realPosX or self:GetX(), self.___realPosY or self:GetY()
end

PANEL.SetSize = zlib.func.detour(PANEL.SetSize, 'PANEL.SetSize', function(orig, pnl, w, h)
	pnl.___realSizeW = w
	pnl.___realSizeH = h

	orig(pnl, w, h)
end)

PANEL.SetWide = zlib.func.detour(PANEL.SetWide, 'PANEL.SetWide', function(orig, pnl, w)
	pnl.___realSizeW = w

	orig(pnl, w)
end)

PANEL.SetTall = zlib.func.detour(PANEL.SetTall, 'PANEL.SetTall', function(orig, pnl, h)
	pnl.___realSizeH = h

	orig(pnl, h)
end)

PANEL.SizeToChildren = zlib.func.detour(PANEL.SizeToChildren, 'PANEL.SizeToChildren', function(orig, pnl, ...)
	orig(pnl, ...)

	local w, h = pnl:GetSize()
	pnl.___realSizeW = w
	pnl.___realSizeH = h
end)

function PANEL:GetUnmodifiedSize()
	return self.___realSizeW or self:GetWide(), self.___realSizeH or self:GetTall()
end