local PANEL = {}

local function invalidateLayout(pnl) pnl:InvalidateLayout() end

zlib.func.accessor(PANEL, 'm_iLerpSpeed', 'LerpSpeed')
zlib.func.accessor(PANEL, 'm_iContentSpacing', 'ContentSpacing', invalidateLayout)
zlib.func.accessor(PANEL, 'm_bSelected', 'Selected', invalidateLayout)

zlib.func.accessor(PANEL, 'm_tMainStyle', 'MainStyle')
function PANEL:SetMainStyle(style)
	self.m_tMainStyle = style
	self.m_cNoiseColor = self:LerpColor('noiseColor', style, true)
end

function PANEL:Init()
	self:SetCursor('hand')
	self:SetContentSpacing(0)

	self:SetLerpSpeed(25)

	self:SetMainStyle({
		default = colors.white30,
		hovered = colors.white20,
		down = colors.white10,
		disabled = colors.black75,
	})
end

function PANEL:LerpColor(colorKey, style, reset)
	if not style then
		return colors.white0
	end

	local clr
	if self:IsEnabled() or not style.disabled then
		if self:IsDown() then
			clr = style.down
		elseif self:GetSelected() then
			clr = style.selected or style.down
		elseif self:IsHovered() then
			clr = style.hovered
		end
	else
		clr = style.disabled
	end

	colorKey = '__' .. colorKey

	if reset then
		self[colorKey] = nil
	end

	clr = clr or style.default or colors.white0

	local speed = self:GetLerpSpeed()
	if speed <= 0 then
		speed = 1
	else
		speed = FrameTime() * speed
	end

	local final = zlib.math.lerpColor(speed, self[colorKey] or Color(clr:Unpack()), clr, true)
	self[colorKey] = final

	return final
end

function PANEL:Think()
	self:LerpColor('noiseColor', self:GetMainStyle())
end

function PANEL:SetMainColor(clr)
	self:SetMainStyle({
		default = clr,
	})
end

vgui.Register('Rust::ButtonBase', PANEL, 'Rust::Panel')