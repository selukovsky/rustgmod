local mat_noise = Material('ui/zohart/overlays/noise.png', 'noclamp')

local PANEL = {}

AccessorFunc(PANEL, 'm_cNoiseColor', 'NoiseColor', FORCE_COLOR)
AccessorFunc(PANEL, 'm_iNoiseTiling', 'NoiseTiling', FORCE_NUMBER)
AccessorFunc(PANEL, 'm_bNoiseEnabled', 'NoiseEnabled', FORCE_BOOL)
AccessorFunc(PANEL, 'm_iNoiseX', 'NoiseX', FORCE_NUMBER)
AccessorFunc(PANEL, 'm_iNoiseY', 'NoiseY', FORCE_NUMBER)

function PANEL:Init()
	self:SetNoiseColor(color_white)
	self:SetNoiseTiling(250)
	self:SetNoiseEnabled(true)

	self:SetNoiseX(0)
	self:SetNoiseY(0)
end

function PANEL:Paint(w, h)
	if self:IsDown() and not input.IsMouseDown(self.m_iMouseButton) then
		self.m_bIsDown = nil
	end

	surface.SetDrawColor(self:GetNoiseColor())

	local x, y = self.m_iNoiseX or 0, self.m_iNoiseY or 0

	if self:GetNoiseEnabled() then
		local tiling = ss(self:GetNoiseTiling())
		surface.SetMaterial(mat_noise)
		surface.DrawTexturedRectUV(x, y, w, h, 0, 0, w / tiling, h / tiling)
	else
		surface.DrawRect(x, y, w, h)
	end
end

function PANEL:IsDown()
	return self.m_bIsDown == true
end

function PANEL:OnMousePressed(key)
	if self:IsDraggable() then
		self:MouseCapture(true)
		self:DragMousePress(key)
	end

	self.m_bIsDown = true
	self.m_iMouseButton = key
end

function PANEL:OnMouseReleased(key)
	self:MouseCapture(false)

	if self:DragMouseRelease(key) then
		self.m_bIsDown = nil
		self.m_iMouseButton = nil
		return
	end

	if self.m_bIsDown and self.m_iMouseButton == key then
		self.m_bIsDown = nil
		self.m_iMouseButton = nil

		if self:IsHovered() or self:IsChildHovered(true) then
			if key == MOUSE_LEFT then
				local curTime = CurTime()

				local doDoubleClick = self.DoDoubleClick
				if doDoubleClick and (curTime - (self._lastPressed or 0)) <= 0.33 then
					self:DoDoubleClick()
				else
					self:DoClick()
				end

				self._lastPressed = curTime
			elseif key == MOUSE_RIGHT then
				self:DoRightClick()
			else
				self:DoMiddleClick()
			end
		end
	end
end

PANEL.DoClick = zlib.func.zero
PANEL.DoRightClick = zlib.func.zero
PANEL.DoMiddleClick = zlib.func.zero

vgui.Register('Rust::Panel', PANEL, 'EditablePanel')