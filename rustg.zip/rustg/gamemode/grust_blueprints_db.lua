print("[gRust] Blueprints database module loading...")

gRust_BPDB = gRust_BPDB or {}

function gRust_BPDB.Initialize()
    if not sql then
        ErrorNoHalt("[gRust] SQLite not available! Blueprints will not be saved.")
        return false
    end
    
    local query = [[
        CREATE TABLE IF NOT EXISTS rust_blueprints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            steamid64 TEXT NOT NULL,
            item_class TEXT NOT NULL,
            learned_date INTEGER DEFAULT (strftime('%s', 'now')),
            UNIQUE(steamid64, item_class)
        )
    ]]
    
    local result = sql.Query(query)
    if not result then
        local err = sql.LastError()
        ErrorNoHalt("[gRust] Error creating blueprints table: " .. (err or "Unknown error"))
        return false
    end
    
    print("[gRust] Blueprints database initialized successfully")
    return true
end

function gRust_BPDB.GetAll(steamid64)
    if not steamid64 or not sql then 
        print("[gRust] GetAll failed: no steamid64 or SQL")
        return {} 
    end
    
    local query = string.format("SELECT item_class FROM rust_blueprints WHERE steamid64 = %s", sql.SQLStr(steamid64))
    local results = sql.Query(query)
    local blueprints = {}
    
    if results then
        print("[gRust] Loaded " .. #results .. " blueprints for " .. steamid64)
        for _, row in ipairs(results) do
            blueprints[row.item_class] = true
        end
    else
        print("[gRust] No blueprints found for " .. steamid64)
    end
    
    return blueprints
end

function gRust_BPDB.Add(steamid64, item_class)
    if not steamid64 or not item_class or not sql then 
        print("[gRust] Add failed: invalid parameters")
        return false 
    end
    
    local query = string.format(
        "INSERT OR IGNORE INTO rust_blueprints (steamid64, item_class) VALUES (%s, %s)",
        sql.SQLStr(steamid64), sql.SQLStr(item_class)
    )
    
    local success = sql.Query(query) ~= false
    if success then
        print("[gRust] Added blueprint: " .. item_class .. " for " .. steamid64)
    else
        print("[gRust] Failed to add blueprint: " .. item_class)
    end
    
    return success
end

function gRust_BPDB.Remove(steamid64, item_class)
    if not steamid64 or not item_class or not sql then return false end
    
    local query = string.format(
        "DELETE FROM rust_blueprints WHERE steamid64 = %s AND item_class = %s",
        sql.SQLStr(steamid64), sql.SQLStr(item_class)
    )
    
    return sql.Query(query) ~= false
end

function gRust_BPDB.WipeAll()
    if not sql then return false end
    return sql.Query("DELETE FROM rust_blueprints") ~= false
end

function gRust_BPDB.WipePlayer(steamid64)
    if not steamid64 or not sql then return false end
    return sql.Query(string.format("DELETE FROM rust_blueprints WHERE steamid64 = %s", sql.SQLStr(steamid64))) ~= false
end

-- Автоматическая инициализация при загрузке
hook.Add("Initialize", "gRust.BlueprintsDBInit", function()
    timer.Simple(1, function() -- Небольшая задержка для инициализации SQL
        gRust_BPDB.Initialize()
    end)
end)

-- Сообщаем что файл загружен
print("[gRust] Blueprints database module loaded")

concommand.Add("grust_wipeblueprints", function(ply, cmd, args)
    -- Только серверная консоль или админ
    if IsValid(ply) then
        if not ply:IsAdmin() then
            ply:ChatPrint("У вас нет прав для выполнения этой команды!")
            return
        end
    end

    local success = gRust_BPDB.WipeAll()
    if success then
        print("[gRust] Все чертежи успешно удалены из базы данных!")
        if IsValid(ply) then
            ply:ChatPrint("Все чертежи были удалены!")
        end
    else
        print("[gRust] Ошибка при попытке очистить базу данных чертежей!")
        if IsValid(ply) then
            ply:ChatPrint("Ошибка при очистке базы данных!")
        end
    end
end)