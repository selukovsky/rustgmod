local Draw = {}

local surface = surface

return Draw