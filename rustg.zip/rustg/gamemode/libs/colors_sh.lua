gRust.Colors = {}

gRust.Colors.Primary    = Color(205, 65, 43)

gRust.Colors.Secondary  = Color(115, 141, 69)

gRust.Colors.Accent     = Color(83, 166, 249)

gRust.Colors.Background = Color(17, 17, 17)

gRust.Colors.Surface    = Color(74, 74, 74)

gRust.Colors.White      = Color(255, 255, 255)

gRust.Colors.Blue       = Color(0, 76, 152)

gRust.Colors.Panel      = Color(42, 42, 34)

gRust.Colors.Text       = Color(255, 255, 255)

gRust.Colors.Text2      = Color(255, 255, 255)
