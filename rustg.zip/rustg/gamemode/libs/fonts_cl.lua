
local function CreateFonts()
    local scaling = (ScrH() / 1440) * 0 + (1 - 0) * ScrW() / 2560
    for i = 16, 128, 2 do
        surface.CreateFont(string.format("gRust.%ipx", i), {
            font = "Roboto Condensed Bold",
            size = i * scaling,
            weight = 2000,
            antialias = true,
            shadow = false,
        })
    end
end

timer.Simple(0, function()
    CreateFonts()
end)

hook.Add("OnScreenSizeChanged", "gRust.CreateFonts", function()
    timer.Simple(0, function()
        CreateFonts()
    end)
end)

local function CreateNewFonts()
    local scaling = gRust.Hud.Scaling

    -- Шрифты для слайдера как в старом UI
    surface.CreateFont("gRust.32px", {
        font = "Roboto Condensed Bold",
        size = 32 * scaling,
        weight = 2000,
        antialias = true,
        shadow = false,
    })

    surface.CreateFont("gRust.28px", {
        font = "Roboto Condensed",
        size = 28 * scaling,
        weight = 500,
        antialias = true
    })

    surface.CreateFont("gRust.26px", {
        font = "Roboto Condensed",
        size = 26 * scaling,
        weight = 500,
        antialias = true
    })
end