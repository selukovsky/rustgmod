function GM:AllowPlayerPickup(ply, ent)
    return false -- block +use prop pickup
end