-- Spawning System for gRust
-- Handles spawning of all entities on the map

local SpawningSystem = {}

-- Configuration
local SPAWN_DELAY = 5 -- Seconds to wait after map load
local RANDOM_SPAWNS = 150 -- Number of random positions to find

CreateConVar("gr_spawnsystem_creatures", "90", {FCVAR_ARCHIVE}, "Chickens that spawn")
CreateConVar("gr_spawnsystem_ores", "150", {FCVAR_ARCHIVE}, "Ores that spawn")
CreateConVar("gr_spawnsystem_hemp", "90", {FCVAR_ARCHIVE}, "Hemp that spawn")
CreateConVar("gr_spawnsystem_ore_pickups", "80", {FCVAR_ARCHIVE}, "Ore pickups that spawn")
CreateConVar("gr_spawnsystem_junkpiles", "15", {FCVAR_ARCHIVE}, "Junk piles that spawn")

local creatureSpawns = GetConVar("gr_spawnsystem_creatures"):GetInt()
local oreSpawns = GetConVar("gr_spawnsystem_ores"):GetInt()
local hempSpawns = GetConVar("gr_spawnsystem_hemp"):GetInt()
local orePickupSpawns = GetConVar("gr_spawnsystem_ore_pickups"):GetInt()
local junkPileSpawns = GetConVar("gr_spawnsystem_junkpiles"):GetInt()

-- Predefined spawn positions
local RoadSignSpawns = {
    {pos = Vector(7876.923828, 4310.765137, 636.311584), ang = Angle(-2.679643, 164.679718, 0.000000)},
    {pos = Vector(3373.470459, -3902.622803, -5373.084961), ang = Angle(-1.165943, -150.627182, 0.000000)},
    {pos = Vector(8537.921875, -908.605530, 640.918396), ang = Angle(10.740351, -72.780304, 0.000000)},
    {pos = Vector(10860.347656, -1018.629578, 640.031250), ang = Angle(10.300351, -0.620302, 0.000000)},
    {pos = Vector(13555.104492, -946.081726, 634.023682), ang = Angle(6.780344, -10.520297, 0.000000)},
    {pos = Vector(8694.571289, -4823.195801, 652.140930), ang = Angle(0.400345, -93.459991, 0.000000)},
    {pos = Vector(8510.013672, -9049.104492, 642.908264), ang = Angle(11.180354, -143.839966, 0.000000)},
    {pos = Vector(1117.237671, -7396.788086, 641.518311), ang = Angle(-2.899647, -174.199936, 0.000000)},
    {pos = Vector(-3560.072998, -6392.807617, 640.015930), ang = Angle(2.160353, 150.819962, 0.000000)},
    {pos = Vector(-8209.355469, -2536.942383, 646.270020), ang = Angle(3.920354, 102.639862, 0.000000)},
    {pos = Vector(-7312.624512, 4939.358398, 667.799438), ang = Angle(3.040354, 79.759804, 0.000000)},
    {pos = Vector(-6870.493164, 11190.271484, 406.339844), ang = Angle(5.900353, 93.399872, 0.000000)},
    {pos = Vector(-6139.575684, 14378.451172, 456.877289), ang = Angle(2.820352, 86.799835, 0.000000)}
}

local MilitarySpawns = {
    {pos = Vector(2410.355957, -5026.132812, -5378.520508), ang = Angle(1.299129, -1.260388, 0.000000)},-- Тунели
    {pos = Vector(3373.470459, -3902.622803, -5373.084961), ang = Angle(-1.165943, -150.627182, 0.000000)},
    {pos = Vector(2972.497559, -3475.992920, -5376.239746), ang = Angle(-1.713740, 60.466679, 0.000000)},
    {pos = Vector(3403.800293, -3135.768555, -5380.413086), ang = Angle(1.664348, -179.561020, 0.000000)},
    {pos = Vector(4348.346191, -3751.194824, -5376.361816), ang = Angle(-1.074633, 179.799911, 0.000000)}, -- конец милитари
    {pos = Vector(996.462769, -106.048515, -4123.708496), ang = Angle(-2.809325, 2.673773, 0.000000)}, -- супер
    {pos = Vector(1178.507568, 420.568512, -4060.944092), ang = Angle(1.481762, 141.636795, 0.000000)}, -- конец супера
    {pos = Vector(-3798.949219, 2309.775635, -3995.214355), ang = Angle(1.846973, -88.169395, 0.000000)}, -- заправка 1
    {pos = Vector(-3252.231689, 10883.860352, -5652.993164), ang = Angle(0.477437, 178.609146, 0.000000)}, -- порт
    {pos = Vector(13390.202148, 13539.795898, -5002.306152), ang = Angle(2.759920, -88.443192, 0.000000)},---риг
    {pos = Vector(13620.821289, 12799.512695, -5000.757812), ang = Angle(3.125145, -89.721428, 0.000000)},---rig
    {pos = Vector(13638.722656, 13686.409180, -5117.698730), ang = Angle(0.842678, 89.043961, 0.000000)},---rig
    {pos = Vector(13689.093750, 13810.730469, -5346.834473), ang = Angle(4.951209, -0.616815, 0.000000)}---rig
}

local EliteSpawns = {
    {pos = Vector(2337.263916, -3946.899658, -5340.083496), ang = Angle(4.403401, 0.939352, 0.000000)},-- military
    {pos = Vector(2453.767090, -4166.280762, -5374.552734), ang = Angle(1.116614, 105.386490, 0.000000)},
    {pos = Vector(3311.520996, -4026.095215, -5339.282715), ang = Angle(-0.161562, 92.148018, 0.000000)},
    {pos = Vector(3893.871582, -3157.061035, -5344.854492), ang = Angle(-0.252800, -89.356659, 0.000000)}, -- конец милитари
    {pos = Vector(14015.013672, 13552.027344, -4964.362793), ang = Angle(2.303584, -88.626266, 0.000000)}, -- Base
    {pos = Vector(13812.492188, 13835.695312, -5000.190918), ang = Angle(2.394892, -90.817528, 0.000000)}
}

local ArmorySpawns = {
    {pos = Vector(-1516.730591, -1233.829834, 388.834229), ang = Angle(-1.826011, 179.346542, 0.000000)}
}

local Armory2Spawns = {
    {pos = Vector(-8324.431641, 9978.888672, 321.852417), ang = Angle(-0.730391, -178.553665, 0.000000)}
}

local BradleySpawns = {
    {pos = Vector(3163.466309, -3991.791016, -5376.959961), ang = Angle(-1.257201, 31.163904, 0.000000)},
    {pos = Vector(3166.601562, -3995.112793, -5324.376953), ang = Angle(2.394814, 31.616213, 0.000000)}
}

local WoodenSpawns = {
    {pos = Vector(1063.255859, 154.864639, -4120.383789), ang = Angle(-0.498360, 90.103043, 0.000000)},
    {pos = Vector(1044.092163, -65.023811, -3970.175293), ang = Angle(2.930861, 178.229507, 0.000000)},
    {pos = Vector(1425.364258, 39.994415, -3948.043213), ang = Angle(1.859229, -0.021403, 0.000000)},
    {pos = Vector(1673.194458, -2559.366943, -4370.374512), ang = Angle(-1.462793, 179.660995, 0.000000)},
    {pos = Vector(2235.531494, -2339.395020, -4370.813477), ang = Angle(-0.605504, -90.138084, 0.000000)},
    {pos = Vector(1625.219849, -2342.312012, -4363.636230), ang = Angle(1.001911, -178.654831, 0.000000)},
    {pos = Vector(-4511.738770, 1057.755859, -4015.871582), ang = Angle(0.037441, -0.013624, 0.000000)}, -- заправка
    {pos = Vector(-3891.432617, 1914.655884, -3844.357910), ang = Angle(1.859190, -89.066383, 0.000000)},
    {pos = Vector(-4383.036621, 2396.957275, -4004.718506), ang = Angle(1.109033, 90.363609, 0.000000)},-- конец заправки
    {pos = Vector(3173.547119, -5078.356934, -5376.229492), ang = Angle(-5.535103, 177.594681, 0.000000)}, -- милитари тунели
    {pos = Vector(4635.730469, -4487.063477, -5377.976074), ang = Angle(1.323418, -118.176140, 0.000000)},
    {pos = Vector(-4384.273926, 10274.697266, -5653.550293), ang = Angle(-2.261494, 91.604362, 0.000000)},-- порт
    {pos = Vector(-2725.152100, 11209.568359, -5659.082520), ang = Angle(-0.161597, -178.921585, 0.000000)},-- 
    {pos = Vector(-3466.540283, 12238.156250, -5656.809570), ang = Angle(1.207919, -178.830505, 0.000000)}-- 
}

local HorseSpawns = {
    {pos = Vector(9597.709961, -5977.870605, 636.279541), ang = Angle(7.925698, 13.860143, 0.000000)},
    {pos = Vector(11494.255859, 2188.282471, 267.167053), ang = Angle(18.333883, 48.462841, 0.000000)},
    {pos = Vector(-1871.864868, 4422.202637, 593.178406), ang = Angle(10.116879, -92.691238, 0.000000)},
    {pos = Vector(-12389.288086, 9733.316406, 169.668701), ang = Angle(13.860166, -2.204549, 0.000000)}
}

local FoodSpawns = {
    {pos = Vector(1264.179199, -173.476379, -4116.105469), ang = Angle(3.125422, 2.864650, 0.000000)},
    {pos = Vector(1369.593506, 169.298111, -4117.926758), ang = Angle(3.855839, -0.330861, 0.000000)},
    {pos = Vector(1498.621582, 394.872986, -4114.061035), ang = Angle(2.303742, -90.352623, 0.000000)},
    {pos = Vector(-4384.437988, 1914.079590, -3956.885986), ang = Angle(0.021240, -50.910954, 0.000000)},
    {pos = Vector(-3806.807129, 1892.261353, -3992.378662), ang = Angle(0.569045, 178.799957, 0.000000)},
    {pos = Vector(-4279.242676, 2108.620117, -3995.842041), ang = Angle(-0.617838, -89.352303, 0.000000)}
}


local ApcSpawns = {
    {pos = Vector(7551.35009, 11775.405273, 136.031250), ang = Angle(4.929768, 1.907047, 0.000000)}
}

local KarSpawns = {
    {pos = Vector(11879.833008, -10135.820312, -37.028694), ang = Angle(-8.205420, 71.166908, 0.000000)}
}

local MedSpawns = {
    {
        pos = Vector(-2642.448975, 10835.826172, -5658.556641),
        ang = Angle(4.038322, -91.269829, 0.000000)
    }, -- recycler
    {
        pos = Vector(939.569946, 130.663498, -4137.889160),
        ang = Angle(0.000000, -89.813000, 0.000000)
    },
    {
        pos = Vector(-3734.301025, 2076.569336, -3998.527588),
        ang = Angle(0.842926, 1.578490, 0.000000)
    }
}

local VendSpawns = {
    {pos = Vector(-2254.464844, -12034.299805, -5709.524902), ang = Angle(3.469426, -1.087391, 0.000000)}
}

local RedSpawns = {
    {pos = Vector(4087.000000, 862.000000, 497.132996), ang = Angle(0.000, 90.000, 0.000)}
}

local RedReadSpawns = {
    {pos = Vector(4012.000000, 864.000000, 551.310974), ang = Angle(0.000, 90.000, 0.000)}
}

local BlueSpawns = {
    {pos = Vector(-8348.379883, 9813.030273, 295.132996), ang = Angle(0.000, 270.000, 0.000)}
}

local BlueReadSpawns = {
    {pos = Vector(-8273.379883, 9811.030273, 349.311005), ang = Angle(0.000, -90.000, 0.000)}
}

local GreenSpawns = {
    {pos = Vector(-1742.000000, -1204.239990, 385.132996), ang = Angle(0.000, 180.000, 0.000)}
}

local BarrelSpawns = {
    {pos = Vector(2629.214111, -866.966614, -4329.756348), ang = Angle(-2.991678, 88.503784, 0.000)},
    {pos = Vector(2721.024170, 684.922180, -4272.392090), ang = Angle(-4.635059, 147.027100, 0.000)},
    {pos = Vector(2767.508057, 735.249329, -4279.021973), ang = Angle(9.151232, -38.768444, 0.000)},
    {pos = Vector(3934.004395, 794.167664, -4411.845703), ang = Angle(14.446648, 25.506742, 0.000)},
    {pos = Vector(4518.745605, 1618.598389, -4690.822266), ang = Angle(7.690446, 54.540142, 0.000)},
    {pos = Vector(5406.260254, 2015.370239, -4889.498535), ang = Angle(10.703353, 21.033064, 0.000)},
    {pos = Vector(1314.386108, 1982.925415, -4138.630371), ang = Angle(-4.635037, 132.514786, 0.000)}, -- ДОБАВЛЕНА ЗАПЯТАЯ ЗДЕСЬ
    {pos = Vector(789.708679, 2905.721436, -4127.183105), ang = Angle(2.851576, 146.940063, 0.000)},
    {pos = Vector(-768.818848, 3255.653564, -3946.276367), ang = Angle(-4.817625, 171.043213, 0.000)},
    {pos = Vector(-1281.752563, 3305.053711, -3910.156250), ang = Angle(-2.535116, -179.552887, 0.000)},
    {pos = Vector(-2876.943604, 2326.346191, -4002.100342), ang = Angle(-1.530802, -100.122025, 0.000)},
    {pos = Vector(-2589.758545, 665.999084, -3875.281982), ang = Angle(-3.265493, -76.931816, 0.000)}
}


-- Find random valid positions on the map
-- Find random valid positions on the map
local function FindRandomPlacesOnMap(count)
    local positions = {}
    local attempts = 0
    local maxAttempts = count * 20

    local center = Vector(0, 0, 0)
    local minRadius = 5000
    local maxRadius = 15000

    while #positions < count and attempts < maxAttempts do
        attempts = attempts + 1

        -- Генерация точки в кольце между minRadius и maxRadius
        local angle = math.Rand(0, 2 * math.pi)
        local radius = math.Rand(minRadius, maxRadius)
        local x = center.x + math.cos(angle) * radius
        local y = center.y + math.sin(angle) * radius
        local z = 100 -- стартовая высота

        local pos = Vector(x, y, z)

        local tr = util.TraceLine({
            start = pos,
            endpos = pos - Vector(0, 0, 8000),  -- глубина спуска
            mask = MASK_SOLID
        })

        if tr.Hit then
            local spawnPos = tr.HitPos + Vector(0, 0, 2)
            table.insert(positions, spawnPos)
        end
    end

    print("Total valid positions found: " .. #positions)
    return positions
end


-- Вызов с меньшим числом камней
SpawningSystem.SpawnRocks = function()
    local oreSpawns = 165 -- уменьшено количество камней
    local positions = FindRandomPlacesOnMap(oreSpawns)
    local spawnedCount = 0
    
    for _, spawnPos in pairs(positions) do
        if not isvector(spawnPos) then continue end
        
        local ent = ents.Create("rust_ore")
        if IsValid(ent) then
            local groundTrace = util.TraceLine({
                start = spawnPos,
                endpos = spawnPos - Vector(0, 0, 50),
                mask = MASK_SOLID
            })
            
            if groundTrace.Hit then
                ent:SetPos(groundTrace.HitPos)
            else
                ent:SetPos(spawnPos)
            end
            
            ent:SetSkin(math.random(1, 3))
            ent:Spawn()
            ent:Activate()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " rocks")
end

-- Spawn chickens
function SpawningSystem.SpawnChickens()
    local positions = FindRandomPlacesOnMap(creatureSpawns)
    local spawnedCount = 0
    
    for _, pos in pairs(positions) do
        local ent = ents.Create("npc_vj_f_killerchicken")
        if IsValid(ent) then
            ent:SetPos(pos)
            ent:Spawn()
            ent:Activate()
            ent:SetModelScale(1.75, 0)
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " chickens")
end

-- Spawn hemp plants
function SpawningSystem.SpawnHemp()
    local positions = FindRandomPlacesOnMap(hempSpawns)
    local spawnedCount = 0
    local pairCount = 0
    for _, pos in ipairs(positions) do
        
        local lowerPos = pos - Vector(0, 0, 10)
        
        local ent = ents.Create("rust_map_hemp")
        if IsValid(ent) then
            ent:SetPos(lowerPos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
            
            if math.random(1, 100) <= 30 then
                local offset = Vector(math.random(-80, 80), math.random(-80, 80), 0)
                local nearbyPos = lowerPos + offset
                
                local ent2 = ents.Create("rust_map_hemp")
                if IsValid(ent2) then
                    ent2:SetPos(nearbyPos)
                    ent2:Spawn()
                    ent2:Activate()
                    ent2:DropToFloor()
                    spawnedCount = spawnedCount + 1
                    pairCount = pairCount + 1
                end
            end
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " hemp plants (" .. pairCount .. " pairs)")
end

function SpawningSystem.SpawnOrePickups()
    local positions = FindRandomPlacesOnMap(orePickupSpawns)
    local spawnedCount = 0
    for _, pos in pairs(positions) do
        if not isvector(pos) then continue end

        local lowerPos = pos - Vector(0, 0, 15)

        local ent = ents.Create("rust_orepickup")
        if IsValid(ent) then
            ent:SetPos(lowerPos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " ore pickups")
end

function SpawningSystem.SpawnJunkPiles()
    local positions = FindRandomPlacesOnMap(junkPileSpawns)
    local spawnedCount = 0

    for _, pos in pairs(positions) do
        local ent = ents.Create("rust_junkpile")
        if IsValid(ent) then
            ent:SetPos(pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end

    Logger("[Spawning] Spawned " .. spawnedCount .. " junk piles")
end

-- Spawn roadsigns

-- spawns apc
function SpawningSystem.SpawnBradley()
    local spawnedCount = 0
    
    for i, spawn in ipairs(BradleySpawns) do
        local ent = ents.Create("rust_bradleycrate")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " Bradleycrates")
end

function SpawningSystem.SpawnMedic()
    local spawnedCount = 0
    
    for i, spawn in ipairs(MedSpawns) do
        local ent = ents.Create("rust_reyclr")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " MEDICC!!")
end

function SpawningSystem.SpawnHorse()
    local spawnedCount = 0
    
    for i, spawn in ipairs(HorseSpawns) do
        local ent = ents.Create("npc_horse")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " Horses")
end

function SpawningSystem.SpawnVend()
    local spawnedCount = 0
    
    for i, spawn in ipairs(VendSpawns) do
        local ent = ents.Create("rust_vendingmachine")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " Vendings")
end

function SpawningSystem.SpawnFood()
    local spawnedCount = 0
    
    for i, spawn in ipairs(FoodSpawns) do
        local ent = ents.Create("rust_food")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. "Foodcrate")
end

function SpawningSystem.SpawnMilitary()
    local spawnedCount = 0
    
    for i, spawn in ipairs(MilitarySpawns) do
        local ent = ents.Create("rust_militarycrate")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " militarycrates")
end

function SpawningSystem.SpawnElite()
    local spawnedCount = 0
    
    for i, spawn in ipairs(EliteSpawns) do
        local ent = ents.Create("rust_elitecrate")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " Elitecrates")
end

function SpawningSystem.SpawnWooden()
    local spawnedCount = 0
    
    for i, spawn in ipairs(WoodenSpawns) do
        local ent = ents.Create("rust_woodencrate")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " Woodencrates")
end


function SpawningSystem.SpawnRed()
    local spawnedCount = 0
    
    for i, spawn in ipairs(RedSpawns) do
        local ent = ents.Create("rust_puzzledoorred")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " armorycrates")
end

function SpawningSystem.SpawnBlue()
    local spawnedCount = 0
    
    for i, spawn in ipairs(BlueSpawns) do
        local ent = ents.Create("rust_puzzledoorblue")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " armorycrates")
end

function SpawningSystem.SpawnGreen()
    local spawnedCount = 0
    
    for i, spawn in ipairs(GreenSpawns) do
        local ent = ents.Create("rust_puzzledoorgreen")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " armorycrates")
end

function SpawningSystem.SpawnRedRead()
    local spawnedCount = 0
    
    for i, spawn in ipairs(RedReadSpawns) do
        local ent = ents.Create("rust_cardreaderred")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " armorycrates")
end

function SpawningSystem.SpawnBlueRead()
    local spawnedCount = 0
    
    for i, spawn in ipairs(BlueReadSpawns) do
        local ent = ents.Create("rust_cardreaderblue")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " armorycrates")
end

function SpawningSystem.BarrelSpawns()
    local spawnedCount = 0
    
    for i, spawn in ipairs(BarrelSpawns) do
        local ent = ents.Create("rust_barrel")
        if IsValid(ent) then
            ent:SetPos(spawn.pos)
            ent:Spawn()
            ent:Activate()
            ent:DropToFloor()
            spawnedCount = spawnedCount + 1
        end
    end
    
    Logger("[Spawning] Spawned " .. spawnedCount .. " armorycrates")
end


-- Main spawning function
function SpawningSystem.SpawnAll()
    Logger("[Spawning] Starting entity spawning on map: " .. game.GetMap())
    
    SpawningSystem.SpawnRocks()
    
    timer.Simple(1, function()
        SpawningSystem.SpawnChickens()
    end)
    
    timer.Simple(2, function()
        SpawningSystem.SpawnHemp()
    end)
    
    timer.Simple(3, function()
        SpawningSystem.SpawnOrePickups()
    end)

    timer.Simple(4, function()
        SpawningSystem.SpawnJunkPiles()
    end)

    timer.Simple(5, function()
        SpawningSystem.SpawnBradley()
    end)

    timer.Simple(6, function()
        SpawningSystem.SpawnWooden()
    end)

    timer.Simple(7, function()
        SpawningSystem.SpawnMilitary()
    end)

    timer.Simple(8, function()
        SpawningSystem.SpawnElite()
    end)

    timer.Simple(9, function()
        SpawningSystem.SpawnArmory()
    end)

    timer.Simple(10, function()
        SpawningSystem.SpawnHorse()
    end)

    timer.Simple(11, function()
        SpawningSystem.SpawnFood()
    end)

    timer.Simple(12, function()
        SpawningSystem.SpawnVend()
    end)

    timer.Simple(13, function()
        SpawningSystem.SpawnMedic()
    end)

    timer.Simple(14, function()
        SpawningSystem.SpawnRed()
    end)

    timer.Simple(15, function()
        SpawningSystem.SpawnRedRead()
    end)

    timer.Simple(16, function()
        SpawningSystem.SpawnBlue()
    end)

    timer.Simple(17, function()
        SpawningSystem.SpawnBlueRead()
    end)

    timer.Simple(18, function()
        SpawningSystem.SpawnGreen()
    end)

    timer.Simple(19, function()
        SpawningSystem.BarrelSpawns()
    end)


    timer.Simple(20, function()
        Logger("[Spawning] All entity spawning completed!")
    end)
end

-- Initialize spawning system
hook.Add("InitPostEntity", "gRust.SpawningSystem", function()
    timer.Simple(SPAWN_DELAY, function()
        SpawningSystem.SpawnAll()
    end)
end)

gRust.SpawningSystem = SpawningSystem

-- Add console command for manual spawning (admin only)
concommand.Add("grust_spawn_all", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    SpawningSystem.SpawnAll()
end)

Logger("Spawning system loaded")


concommand.Add("grust_debug_spawn", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    
    local mapMin, mapMax = game.GetWorld():GetModelBounds()
    print("Map bounds:")
    print("Min: ", mapMin)
    print("Max: ", mapMax)
    
    local testPositions = FindRandomPlacesOnMap(5)
    print("Test positions found: ", #testPositions)
    for i, pos in ipairs(testPositions) do
        print(i .. ": " .. tostring(pos))
        
        -- Создаем маркер для визуализации
        local marker = ents.Create("prop_physics")
        if IsValid(marker) then
            marker:SetModel("models/hunter/blocks/cube05x05x05.mdl")
            marker:SetPos(pos)
            marker:SetColor(Color(255, 0, 0))
            marker:SetMaterial("models/debug/debugwhite")
            marker:Spawn()
            timer.Simple(30, function() if IsValid(marker) then marker:Remove() end end)
        end
    end
end)


concommand.Add("grust_test_rocks", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    
    print("=== TESTING ROCK SPAWN ===")
    
    -- Спавним тестовый камень рядом с игроком
    local pos = ply:GetPos() + Vector(100, 0, 50)
    
    local testRock = ents.Create("rust_ore")
    if IsValid(testRock) then
        testRock:SetPos(pos)
        testRock:SetSkin(1)
        testRock:SetResourceType("stones")
        testRock:Spawn()
        testRock:Activate()
        
        print("TEST: Spawned rock at: " .. tostring(pos))
        
        -- Проверяем через секунду
        timer.Simple(1, function()
            if IsValid(testRock) then
                print("TEST: Rock still exists at: " .. tostring(testRock:GetPos()))
                print("TEST: Rock model: " .. testRock:GetModel())
            else
                print("TEST: Rock was removed!")
            end
        end)
    else
        print("TEST: Failed to create rock entity!")
    end
    
    -- Проверяем существующие камни
    local existing = ents.FindByClass("rust_ore")
    print("Existing rocks: " .. #existing)
end)

concommand.Add("grust_check_ground", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    
    print("=== CHECKING GROUND LEVELS ===")
    
    local testPositions = {
        Vector(0, 0, 0),
        Vector(1000, 1000, 0),
        Vector(-1000, -1000, 0),
        Vector(2000, 0, 0),
        Vector(0, 2000, 0)
    }
    
    for i, pos in ipairs(testPositions) do
        local trace = util.TraceLine({
            start = pos + Vector(0, 0, 1000),
            endpos = pos - Vector(0, 0, 1000),
            mask = MASK_SOLID
        })
        
        if trace.Hit then
            print("Position " .. i .. ": " .. tostring(pos) .. " -> Ground at Z: " .. trace.HitPos.z)
        else
            print("Position " .. i .. ": " .. tostring(pos) .. " -> NO GROUND FOUND")
        end
    end
    
    -- Проверяем высоту существующих камней
    local rocks = ents.FindByClass("rust_ore")
    print("Existing rocks: " .. #rocks)
    for i, rock in ipairs(rocks) do
        if IsValid(rock) then
            print("Rock " .. i .. " Z: " .. rock:GetPos().z)
        end
    end
end)

concommand.Add("grust_test_simple", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    
    print("=== SIMPLE SPAWN TEST ===")
    
    -- Спавним 5 тестовых камней вокруг игрока
    for i = 1, 5 do
        local offset = Vector(
            math.random(-300, 300),
            math.random(-300, 300),
            50  -- На 50 единиц выше текущей позиции игрока
        )
        
        local spawnPos = ply:GetPos() + offset
        
        local ent = ents.Create("rust_ore")
        if IsValid(ent) then
            ent:SetPos(spawnPos)
            ent:SetSkin(1)
            ent:Spawn()
            ent:Activate()
            
            -- Ставим на землю
            ent:DropToFloor()
            
            print("Test rock " .. i .. " spawned at: " .. tostring(spawnPos))
            
            -- Проверяем конечную позицию
            timer.Simple(1, function()
                if IsValid(ent) then
                    local finalPos = ent:GetPos()
                    print("Test rock " .. i .. " final position: " .. tostring(finalPos))
                end
            end)
        end
    end
end)