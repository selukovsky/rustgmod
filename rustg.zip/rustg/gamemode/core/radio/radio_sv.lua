net.Receive("gRust.ChangeRadioStation", function(len, ply)
    local radio = net.ReadEntity()
    local stationName = net.ReadString()
    
    if not IsValid(radio) or not IsValid(ply) then return end
    if radio:GetClass() ~= "rust_radio" then return end
    
    -- Проверяем расстояние
    if radio:GetPos():Distance(ply:GetPos()) > 200 then
        ply:ChatPrint("You are too far from the radio!")
        return
    end
    
    -- Запускаем станцию
    if radio.StartStation and radio:StartStation(stationName) then
        local stationData = radio.RadioStations and radio.RadioStations[stationName]
        local stationDisplayName = stationData and stationData.name or stationName
        ply:ChatPrint("Radio tuned to: " .. stationDisplayName)
        
        print("[RADIO] " .. ply:Nick() .. " changed station to: " .. stationName)
    else
        ply:ChatPrint("Failed to change radio station!")
        print("[RADIO] Failed to change station: " .. stationName)
    end
end)