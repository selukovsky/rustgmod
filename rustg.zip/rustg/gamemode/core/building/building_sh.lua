local PLAYER = FindMetaTable("Player")

function PLAYER:HasBuildPrivilege(pos, rad)
    if self:IsInNoBuildZone() then
        return false
    end

    local radius = 450
    pos = pos or self:GetPos()

    for k, v in ipairs(ents.FindByClass("rust_toolcupboard")) do
        local dist = v:GetPos():Distance(pos)
        if dist <= radius then
            if SERVER and not v:IsAuthorized(self) then
                return false
            end
        end
    end
    return true
end

function PLAYER:GetWorkbenchTier()
    if not self:HasBuildPrivilege() then return 0 end
    return 0
end

if CLIENT then
    function PLAYER:IsInNoBuildZone()
        return IsInNoBuildZone and IsInNoBuildZone() or false
    end
else
    function PLAYER:IsInNoBuildZone()
        return self.InNoBuildZone or false
    end
end