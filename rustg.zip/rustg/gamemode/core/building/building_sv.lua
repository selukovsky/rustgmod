util.AddNetworkString("gRust.BuildingStatus")
util.AddNetworkString("gRust.RequestBuildingStatus")

if not gRust then gRust = {} end

if not gRust.Building then gRust.Building = {} end

function gRust.Building.UpdatePlayer(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end

    local newStatus = "none"

    if ply:IsInNoBuildZone() then
        newStatus = "nobuild"
    else

        local radius = 450
        for _, tc in pairs(ents.FindByClass("rust_toolcupboard")) do
            if IsValid(tc) then
                local dist = ply:GetPos():Distance(tc:GetPos())
                if dist <= radius then
                    if tc:IsAuthorized(ply) then
                        newStatus = "privilege"
                        break
                    else
                        newStatus = "blocked"
                    end
                end
            end
        end
    end

    -- Кэширование для оптимизации
    local oldStatus = gRust.Building.PlayerCache[ply] or "none"
    if oldStatus ~= newStatus then
        gRust.Building.PlayerCache[ply] = newStatus

        -- Отправка статуса клиенту
        net.Start("gRust.BuildingStatus")
        net.WriteString(newStatus)
        net.Send(ply)
    end
end

gRust.Building.PlayerCache = {}

timer.Create("gRust.Building.UpdateAll", 0.5, 0, function()
    for _, ply in pairs(player.GetAll()) do
        if ply:Alive() then
            gRust.Building.UpdatePlayer(ply)
        end
    end
end)

local ENT = {}

ENT.Type = "brush"
ENT.Base = "base_brush"


function ENT:Initialize()
    self:SetSolid(SOLID_BSP)
    self:SetMoveType(MOVETYPE_PUSH)
    self:SetTrigger(true)
    self:SetNoDraw(true)
end

function ENT:StartTouch(ent)
    if not IsValid(ent) or not ent:IsPlayer() then return end

    ent.InNoBuildZone = true
    ent.InNoBuildZoneEntity = self

    if gRust.Building and gRust.Building.UpdatePlayer then
        gRust.Building.UpdatePlayer(ent)
    end

    hook.Call("gRust.NoBuildZoneEnter", nil, ent, self)
end

function ENT:EndTouch(ent)
    if not IsValid(ent) or not ent:IsPlayer() then return end

    ent.InNoBuildZone = false
    ent.InNoBuildZoneEntity = nil

    if gRust.Building and gRust.Building.UpdatePlayer then
        gRust.Building.UpdatePlayer(ent)
    end

    hook.Call("gRust.NoBuildZoneExit", nil, ent, self)
end

function ENT:Touch(ent)
    if not IsValid(ent) or not ent:IsPlayer() then return end

    ent.InNoBuildZone = true
    ent.InNoBuildZoneEntity = self
end

scripted_ents.Register(ENT, "rust_nobuildzone")

local PLAYER = FindMetaTable("Player")

function PLAYER:IsInNoBuildZone()
    return self.InNoBuildZone or false
end

function PLAYER:GetNoBuildZoneEntity()
    return self.InNoBuildZoneEntity
end

hook.Add("PlayerDisconnected", "gRust.Building.Cleanup", function(ply)
    if gRust.Building and gRust.Building.PlayerCache then
        gRust.Building.PlayerCache[ply] = nil
    end
    ply.InNoBuildZone = nil
    ply.InNoBuildZoneEntity = nil
end)


net.Receive("gRust.RequestBuildingStatus", function(len, ply)
    -- Здесь должна быть логика определения текущего статуса билдинга для игрока
    local status = "none" -- По умолчанию
    
    -- Ваша логика определения статуса (пример):
    if IsInNoBuildZone(ply) then
        status = "nobuild"
    elseif HasBuildingPrivilege(ply) then
        status = "privilege"
    elseif IsBuildingBlocked(ply) then
        status = "blocked"
    end
    
    net.Start("gRust.BuildingStatus")
    net.WriteString(status)
    net.Send(ply)
    
    print("[BUILDING] Sent building status to " .. ply:Nick() .. ": " .. status)
end)