ATTACHMENT_SYSTEM = ATTACHMENT_SYSTEM or {}

ATTACHMENT_SYSTEM.TYPES = {
    Barrel = 1,
    Sight = 2, 
    Magazine = 3,
    Stock = 4,
    Underbarrel = 5,
    Other = 6
}

-- Для обратной совместимости
ATTACHMENT_TYPE = ATTACHMENT_SYSTEM.TYPES

-- Базовая таблица аттачментов
ATTACHMENT_SYSTEM.ATTACHMENTS = {
    ["weapon.mod.holosight"] = {
        Type = ATTACHMENT_SYSTEM.TYPES.Sight,
        Model = "models/weapons/darky_m/rust/attachments/holosight.mdl",
        Bone = "ValveBiped.Bip01_R_Hand",
        Position = Vector(0, 0, 0),
        Angle = Angle(0, 0, 0),
        IronSightsPos = Vector(-6.115, -8, 3.68),
        IronSightsAng = Vector(-0.25, 0.03, 0)
    },
    ["weapon.mod.silencer"] = {
        Type = ATTACHMENT_SYSTEM.TYPES.Barrel,
        Model = "models/weapons/darky_m/rust/attachments/silencer.mdl",
        Bone = "ValveBiped.Bip01_R_Hand",
        Position = Vector(2, 0, 0),
        Angle = Angle(0, 0, 0)
    },
    ["weapon.mod.8x.scope"] = {
        Type = ATTACHMENT_SYSTEM.TYPES.Sight,
        Model = "models/weapons/darky_m/rust/attachments/8xscope.mdl",
        Bone = "ValveBiped.Bip01_R_Hand",
        Position = Vector(0, 0, 0),
        Angle = Angle(0, 0, 0),
        IronSightsPos = Vector(-6.115, -10, 3.68),
        IronSightsAng = Vector(-0.3, 0.05, 0)
    },
    ["weapon.mod.16x.scope"] = {
        Type = ATTACHMENT_SYSTEM.TYPES.Sight,
        Model = "models/weapons/darky_m/rust/attachments/16xscope.mdl",
        Bone = "ValveBiped.Bip01_R_Hand",
        Position = Vector(0, 0, 0),
        Angle = Angle(0, 0, 0),
        IronSightsPos = Vector(-6.115, -12, 3.68),
        IronSightsAng = Vector(-0.35, 0.06, 0)
    },
    ["weapon.mod.muzzlebrake"] = {
        Type = ATTACHMENT_SYSTEM.TYPES.Barrel,
        Model = "models/weapons/darky_m/rust/attachments/muzzle_brake.mdl",
        Bone = "ValveBiped.Bip01_R_Hand",
        Position = Vector(2, 0, 0),
        Angle = Angle(0, 0, 0)
    }
}

function ATTACHMENT_SYSTEM.GetAttachmentData(attachmentClass)
    return ATTACHMENT_SYSTEM.ATTACHMENTS[attachmentClass]
end

function ATTACHMENT_SYSTEM.IsAttachment(itemClass)
    return ATTACHMENT_SYSTEM.ATTACHMENTS[itemClass] ~= nil
end