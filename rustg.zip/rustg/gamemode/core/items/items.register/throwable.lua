local Item
--
-- Beancan Grenade
--
Item = gRust.ItemRegister("grenade.beancan")
Item:SetName("Beancan Grenade")
Item:SetDescription("The Beancan Grenade is an early-game tool. They're used to craft Satchel Charges, but can be used by themselves in raiding")
Item:SetCategory("Weapons")
Item:SetStack(10)
Item:SetIcon("materials/items/throwable/beancan.png")
Item:SetWeapon("rust_beancan")
Item:SetDurability(false)
Item:SetClip(false)
Item:SetSound("can")
Item:SetBlueprint(75)
Item:SetTier(1)
Item:SetCraft({
    {
        item = "gunpowder",
        amount = 60
    },
    {
        item = "metal.fragments",
        amount = 20
    }
})

gRust.RegisterItem(Item)

Item = gRust.ItemRegister("f1.grenade")
Item:SetName("F1 Grenade")
Item:SetDescription("End game grenade often used in combat. Unlike the Beancan Grenade, the F1 Grenade is much more reliable as it does not dud or randomly explode.")
Item:SetCategory("Weapons")
Item:SetStack(5)
Item:SetIcon("materials/icons2/grenade.f1.png")
Item:SetWeapon("rust_f1grenade")
Item:SetDurability(false)
Item:SetClip(false)
Item:SetSound("gun")
Item:SetTier(2)
Item:SetCraft({
    {
        item = "gunpowder",
        amount = 30
    },
    {
        item = "metal.fragments",
        amount = 25
    }
})

gRust.RegisterItem(Item)
--
-- Supply Signal
--
Item = gRust.ItemRegister("supply.signal")
Item:SetName("Supply Signal")
Item:SetDescription("A purple smoke grenade that calls in an airdrop somewhere in a small radius around it. Can be found rarely in Military and Elite Crates.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/items/throwable/supply_signal.png")
Item:SetSound("gun")
Item:SetWeapon("rust_supplysignal")
Item:SetDurability(false)
Item:SetClip(false)
gRust.RegisterItem(Item)
--
-- Satchel Charge
--
Item = gRust.ItemRegister("explosive.satchel")
Item:SetName("Satchel Charge")
Item:SetDescription("The Satchel Charge is a midgame raiding tool that can be used to destroy player-made buildings for the purpose of entering and looting another player's base.")
Item:SetCategory("Tools")
Item:SetStack(10)
Item:SetIcon("materials/items/throwable/satchel.png")
Item:SetWeapon("rust_satchel")
Item:SetDurability(false)
Item:SetSound("leather")
Item:SetClip(false)
Item:SetTier(1)
Item:SetBlueprint(125)
Item:SetCraft({
    {
        item = "grenade.beancan",
        amount = 4
    },
    {
        item = "rope",
        amount = 1
    }
})

gRust.RegisterItem(Item)
--
-- Timed Explosive CHarge
--
Item = gRust.ItemRegister("explosive.timed")
Item:SetName("Timed Explosive Charge")
Item:SetDescription("The Timed Explosive Charge, mostly known as C4, is an item often used when raiding other players. Once thrown, the charge will stick to walls, floors, doors and deployable items.")
Item:SetCategory("Tools")
Item:SetStack(10)
Item:SetIcon("materials/items/throwable/c4.png")
Item:SetWeapon("rust_c4")
Item:SetDurability(false)
Item:SetSound("leather")
Item:SetBlueprint(500)
Item:SetClip(false)
Item:SetTier(3)
Item:SetCraft({
    {
        item = "explosives",
        amount = 20
    },
    {
        item = "cloth",
        amount = 5
    },
    {
        item = "techparts",
        amount = 2
    }
})

gRust.RegisterItem(Item)