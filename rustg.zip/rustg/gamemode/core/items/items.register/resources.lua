
local Item



Item = gRust.ItemRegister("wood")
Item:SetName("Wood")
Item:SetDescription("Wood. Harvested from trees, used in many recipes. Necessary for cooking food.")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/items/resources/wood.png")
Item:SetModel("models/items/wood.mdl")
Item:SetSound("wood")
gRust.RegisterItem(Item)

--
Item = gRust.ItemRegister("stone")
Item:SetName("Stone")
Item:SetDescription("Mined from rock nodes using tools. A primary building material.")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/items/resources/stone.png")
Item:SetModel("models/items/stone.mdl")
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("fertilizer")
Item:SetName("Fertilizer")
Item:SetDescription("Fresh and fertile")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/icons2/fertilizer.png")
Item:SetSound("meat")
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("navoz")
Item:SetName("Horse Manure")
Item:SetDescription("Don't eat it! Fertilizer is needed for fertilizing plants.")
Item:SetCategory("Resources")
Item:SetStack(100)
Item:SetIcon("materials/icons2/horsedung.png")
Item:SetSound("meat")
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("leather")
Item:SetName("Leather")
Item:SetDescription("Leather harvested from an animal. Used in the creation of many types of clothing and more.")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetSound("leather")
Item:SetIcon("materials/icons2/leather.png")
gRust.RegisterItem(Item)

--
-- Metal Ore
--

Item = gRust.ItemRegister("bluefrag")
Item:SetName("Blueprint Fragments")
Item:SetDescription("Needed to create blueprints. Collect 65 pieces to assemble into a sheet.")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/icons2/bpr.png")
Item:SetModel("models/items/stone.mdl")
Item:SetSound("paper")
Item:SetCraft({

    {

        item = "metal.refined",

        amount = 2

    }

})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("bluelist")
Item:SetName("Blueprint Sheet")
Item:SetDescription("Used for creating more complex items.")
Item:SetCategory("Resources")
Item:SetStack(100)
Item:SetIcon("materials/icons2/researchpaper.png")
Item:SetSound("paper")
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("book")
Item:SetName("Blueprint Book")
Item:SetDescription("An old book with various blueprint parts. You can't assemble anything complete, but you can disassemble it into pieces.")
Item:SetCategory("Resources")
Item:SetStack(5)
Item:SetIcon("materials/icons2/book.png")
Item:SetSound("paper")
gRust.RegisterItem(Item)

-- Bone Fragments
--
Item = gRust.ItemRegister("bone.fragments")
Item:SetName("Bone Fragments")
Item:SetDescription("Bone Fragments are a resource obtained from harvesting animal corpses. They can be used in various crafting recipes, including the creation of bone tools and armor.")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/items/resources/bone_fragments.png")
Item:SetModel("models/items/bone_fragments.mdl")
Item:SetSound("seeds")
gRust.RegisterItem(Item)
--

Item = gRust.ItemRegister("metal.ore")
Item:SetName("Metal Ore")
Item:SetDescription("A natural mineral containing metal and metal compounds. You can smelt this metal using a furnace.")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/items/resources/metal_ore.png")
Item:SetModel("models/items/metal_ore.mdl")

gRust.RegisterItem(Item)
--
-- HQ Metal Ore
--
Item = gRust.ItemRegister("hq.metal.ore")
Item:SetName("High Quality Metal Ore")
Item:SetDescription("Ore containing high-quality metal. Can be smelted in a furnace.")
Item:SetCategory("Resources")
Item:SetStack(100)
Item:SetIcon("materials/items/resources/hqmetal_ore.png")
gRust.RegisterItem(Item)
--
-- Sulfur Ore
--
Item = gRust.ItemRegister("sulfur.ore")
Item:SetName("Sulfur Ore")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/items/resources/sulfur_ore.png")
Item:SetModel("models/items/sulfur_ore.mdl")
gRust.RegisterItem(Item)
--
-- Sulfur
--
Item = gRust.ItemRegister("sulfur")
Item:SetName("Sulfur")
Item:SetDescription("Sulfur is commonly used in gunpowder, medicine, and matches. Burning matches release sulfur dioxide, which gives them their smell. Sulfur is an essential component of living cells. Most proteins contain sulfur. It is also used as a pesticide in fields.")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/items/resources/sulfur.png")
Item:SetModel("models/items/sulphur.mdl")
gRust.RegisterItem(Item)
--
-- Metal Fragments
--
Item = gRust.ItemRegister("metal.fragments")
Item:SetName("Metal Fragments")
Item:SetDescription("Metal fragments. Smelted from metal ore and used in many recipes.")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/items/resources/metal_fragments.png")
Item:SetSound("metal")
Item:SetModel("models/items/metalfragments.mdl")
gRust.RegisterItem(Item)
--
-- High Quality Metal
--
Item = gRust.ItemRegister("metal.refined")
Item:SetName("High Quality Metal")
Item:SetDescription("High-quality metal used for crafting armor and weapons.")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/items/resources/hqmetal.png")
Item:SetModel("models/items/hqmetal.mdl")
Item:SetSound("metal")
gRust.RegisterItem(Item)
--
-- Charcoal
--
Item = gRust.ItemRegister("charcoal")
Item:SetName("Charcoal")
Item:SetDescription("A byproduct of burning wood, used in the manufacture of gunpowder.")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/items/resources/charcoal.png")
Item:SetModel("models/items/charcoal.mdl")
Item:SetSound("charcoal")
gRust.RegisterItem(Item)
--
-- Cloth
--
Item = gRust.ItemRegister("cloth")
Item:SetName("Cloth")
Item:SetDescription("Cloth obtained from animals or hemp. Used in the creation of much clothing, weapons, and more.")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/items/resources/cloth.png")
Item:SetModel("models/items/cloth.mdl")
Item:SetSound("cloth")
gRust.RegisterItem(Item)
--
-- Scrap
--
Item = gRust.ItemRegister("scrap")
Item:SetName("Scrap")
Item:SetDescription("Scrap is the main currency for learning blueprints.")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/items/resources/scrap.png")
Item:SetModel("models/items/scrappile.mdl")
Item:SetSound("scrap")
gRust.RegisterItem(Item)
--
-- Gears
--

--
-- Tarp
--
Item = gRust.ItemRegister("fat.animal")
Item:SetName("Animal Fat")
Item:SetDescription("For making fuel.")
Item:SetCategory("Resources")
Item:SetStack(100)
Item:SetIcon("materials/items/resources/animal_fat.png")
--Item:SetModel("models/items/animal_fat.mdl")
gRust.RegisterItem(Item)
--
-- Low Grade Fuel
--
Item = gRust.ItemRegister("lowgradefuel")
Item:SetName("Low Grade Fuel")
Item:SetDescription("Low-grade fuel used to power light sources.")
Item:SetCategory("Resources")
Item:SetStack(500)
Item:SetIcon("materials/items/resources/low_grade_fuel.png")
Item:SetSound("oil")
Item:SetCraftTime(5)
Item:SetCraftAmount(4)
Item:SetCraft({
    {
        item = "fat.animal",
        amount = 3
    },
    {
        item = "cloth",
        amount = 1
    }
})

gRust.RegisterItem(Item)


Item = gRust.ItemRegister("crude.oil")
Item:SetName("Crude Oil")
Item:SetDescription("Crude oil from the earth's depths, must be refined for further use.")
Item:SetCategory("Resources")
Item:SetStack(500)
Item:SetIcon("materials/icons2/crudeoil.png")
Item:SetSound("leather")
gRust.RegisterItem(Item)


--
-- Metal Blade
--

--
-- Gunpowder
--
Item = gRust.ItemRegister("gunpowder")
Item:SetName("Gunpowder")
Item:SetDescription("Made from sulfur and charcoal, it is a key ingredient for everything that explodes!")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetIcon("materials/items/resources/gunpowder.png")
Item:SetModel("models/items/gunpowder.mdl")
Item:SetSound("leather")
Item:SetCraftAmount(10)
Item:SetCraftTime(3)
Item:SetCraft({
    {
        item = "charcoal",
        amount = 30
    },
    {
        item = "sulfur",
        amount = 20
    }
})

gRust.RegisterItem(Item)
--
-- Explosives
--
Item = gRust.ItemRegister("explosives")
Item:SetName("Explosives")
Item:SetDescription("A primary component used in the creation of rockets and explosives.")
Item:SetCategory("Resources")
Item:SetStack(100)
Item:SetIcon("materials/items/resources/explosives.png")
Item:SetSound("leather")
Item:SetTier(3)
Item:SetModel("models/items/explosives.mdl")
Item:SetCraft({
    {
        item = "gunpowder",
        amount = 50
    },
    {
        item = "sulfur",
        amount = 10
    },
    {
        item = "metal.fragments",
        amount = 20
    }
})

gRust.RegisterItem(Item)

---
--- Coal :(
---

Item = gRust.ItemRegister("coal")
Item:SetName("Coal :(")
Item:SetDescription("Merry shitty holidays!")
Item:SetCategory("Resources")
Item:SetStack(100)
Item:SetIcon("materials/icons2/coal.png")
Item:SetModel("models/items/charcoal.mdl")
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("cum")
Item:SetName("Cum")
Item:SetDescription("An interesting sticky liquid, smells sharp and not very pleasant, slightly transparent. Tastes slightly salty. Hmm, what kind of liquid is this?")
Item:SetCategory("Resources")
Item:SetStack(100)
Item:SetIcon("materials/icons2/glue.png")
Item:SetSound("oil")
Item:SetModel("models/items/charcoal.mdl")
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("computer")
Item:SetName("Targeting Computer")
Item:SetDescription("A computer with loaded software for video analysis and object tracking.")
Item:SetCategory("Resources")
Item:SetStack(64)
Item:SetIcon("materials/icons2/computer.png")
Item:SetSound("plastic")
Item:SetModel("models/items/charcoal.mdl")
Item:SetBlueprint(125)
Item:SetCraft({
    {
        item = "techparts",
        amount = 6
    },
    {
        item = "metal.refined",
        amount = 2
    },
    {
        item = "metal.fragments",
        amount = 120
    }
})

gRust.RegisterItem(Item)

Item = gRust.ItemRegister("camera")
Item:SetName("CCTV Camera")
Item:SetDescription("A surveillance camera system can be used for real-time monitoring and base protection if it receives power and can be connected to a computer station.")
Item:SetCategory("Resources")
Item:SetStack(32)
Item:SetIcon("materials/icons2/camera.png")
Item:SetSound("plastic")
Item:SetModel("models/items/charcoal.mdl")
Item:SetBlueprint(125)
Item:SetCraft({
    {
        item = "techparts",
        amount = 2
    },
    {
        item = "metal.refined",
        amount = 2
    }
})

gRust.RegisterItem(Item)