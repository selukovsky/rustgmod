

local Item


Item = gRust.ItemRegister("metalblade")
Item:SetName("Metal Blade")
Item:SetDescription("A metal blade for creating melee weapons.")
Item:SetCategory("Components")
Item:SetStack(50)
Item:SetIcon("materials/items/resources/metal_blade.png")
Item:SetModel("models/items/metalblade.mdl")
Item:SetSound("refined")
Item:SetBlueprint(125)
Item:SetCraft({

    {

        item = "scrap",

        amount = 4

    },

    {

        item = "metal.fragments",

        amount = 36

    }

})

gRust.RegisterItem(Item)


--
-- Propane Tank
--
Item = gRust.ItemRegister("propanetank")
Item:SetName("Propane Tank")
Item:SetDescription("A durable metal item.")
Item:SetCategory("Components")
Item:SetStack(5)
Item:SetIcon("materials/items/resources/propane_tank.png")
Item:SetModel("models/items/propanetank.mdl")
Item:SetSound("refined")
Item:SetBlueprint(125)
Item:SetCraft({

    {

        item = "scrap",

        amount = 2

    },

    {

        item = "metal.fragments",

        amount = 100

    }

})
gRust.RegisterItem(Item)
--
-- Electric Fuse
--
Item = gRust.ItemRegister("fuse")
Item:SetName("Electric Fuse")
Item:SetDescription("An unreliable electric fuse. Will allow power to be supplied for a certain period of time.")
Item:SetCategory("Components")
Item:SetStack(10)
Item:SetIcon("materials/items/resources/fuse.png")
Item:SetDurability(true)
Item:SetSound("refined")
Item:SetBlueprint(125)
Item:SetCraft({

    {

        item = "scrap",

        amount = 48

    }

})
gRust.RegisterItem(Item)


Item = gRust.ItemRegister("gears")
Item:SetName("Gears")
Item:SetDescription("Some are functional, some are not.")
Item:SetCategory("Components")
Item:SetStack(20)
Item:SetIcon("materials/items/resources/gears.png")
Item:SetModel("models/items/gears.mdl")
Item:SetSound("refined")
Item:SetBlueprint(125)
Item:SetCraft({

    {

        item = "metal.fragments",

        amount = 30

    },

    {

        item = "scrap",

        amount = 24

    }

})

gRust.RegisterItem(Item)
--
-- Road Signs
--
Item = gRust.ItemRegister("roadsigns")
Item:SetName("Road Signs")
Item:SetDescription("Needed for crafting armor.")
Item:SetCategory("Components")
Item:SetStack(20)
Item:SetIcon("materials/items/resources/road_signs.png")
Item:SetModel("models/items/roadsigns.mdl")
Item:SetSound("road")
Item:SetBlueprint(125)
Item:SetCraft({

    {

        item = "scrap",

        amount = 5

    },

    {

        item = "metal.refined",

        amount = 2

    }


})

gRust.RegisterItem(Item)
--
-- Metal Pipe
--
Item = gRust.ItemRegister("metalpipe")
Item:SetName("Metal Pipe")
Item:SetDescription("Metal pipe.")
Item:SetCategory("Components")
Item:SetStack(20)
Item:SetIcon("materials/items/resources/metal_pipe.png")
Item:SetModel("models/items/metalpipe.mdl")
Item:SetSound("refined")
Item:SetBlueprint(125)
Item:SetCraft({

    {

        item = "scrap",

        amount = 5

    },

    {

        item = "metal.refined",

        amount = 2

    }


})
gRust.RegisterItem(Item)
--
-- Metal Spring
--
Item = gRust.ItemRegister("metalspring")
Item:SetName("Metal Spring")
Item:SetDescription("A metal spring. Used to provide motion or resistance in objects.")
Item:SetCategory("Components")
Item:SetStack(20)
Item:SetIcon("materials/items/resources/metal_spring.png")
Item:SetModel("models/items/spring.mdl")
Item:SetSound("spring")
Item:SetBlueprint(125)
Item:SetCraft({

    {

        item = "scrap",

        amount = 24

    },

    {

        item = "metal.refined",

        amount = 4

    }


})
gRust.RegisterItem(Item)
--
-- Sheet Metal
--
Item = gRust.ItemRegister("sheetmetal")
Item:SetName("Sheet Metal")
Item:SetDescription("Scraps of sheet metal.")
Item:SetCategory("Components")
Item:SetStack(1000)
Item:SetIcon("materials/items/resources/sheet_metal.png")
Item:SetModel("models/items/sheetmetal.mdl")
Item:SetSound("road")
Item:SetBlueprint(125)
Item:SetCraft({

    {

        item = "scrap",

        amount = 20

    },

    {

        item = "metal.fragments",

        amount = 240

    },

    {

        item = "metal.refined",

        amount = 2

    }


})
gRust.RegisterItem(Item)
--
-- Semi Auto Body
--
Item = gRust.ItemRegister("semibody")
Item:SetName("Semi-Automatic Body")
Item:SetDescription("The trigger mechanism of a semi-automatic weapon.")
Item:SetCategory("Components")
Item:SetStack(10)
Item:SetIcon("materials/items/resources/semi_auto_body.png")
Item:SetModel("models/items/semibody.mdl")
Item:SetSound("gun")
Item:SetBlueprint(125)
Item:SetCraft({

    {

        item = "scrap",

        amount = 36

    },

    {

        item = "metal.fragments",

        amount = 180

    },

    {

        item = "metal.refined",

        amount = 4

    }


})
gRust.RegisterItem(Item)
--
-- Rifle Body
--
Item = gRust.ItemRegister("riflebody")
Item:SetName("Rifle Body")
Item:SetDescription("A rifle's trigger mechanism. Used in the construction of automatic weapons that fire 5.56 rounds.")
Item:SetCategory("Components")
Item:SetStack(10)
Item:SetIcon("materials/items/resources/rifle_body.png")
Item:SetModel("models/items/rifle_body.mdl")
Item:SetSound("gun")
Item:SetBlueprint(125)
Item:SetCraft({

    {

        item = "scrap",

        amount = 60

    },

    {

        item = "metal.refined",

        amount = 4

    }

})
gRust.RegisterItem(Item)
--
-- SMG Body
--
Item = gRust.ItemRegister("smgbody")
Item:SetName("SMG Body")
Item:SetDescription("A submachine gun's trigger mechanism. Used in creating weapons that fire pistol rounds fully automatically.")
Item:SetCategory("Components")
Item:SetStack(10)
Item:SetIcon("materials/items/resources/smg_body.png")
Item:SetModel("models/items/smgbody.mdl")
Item:SetSound("gun")
Item:SetBlueprint(125)
Item:SetCraft({

    {

        item = "scrap",

        amount = 36

    },

    {

        item = "metal.refined",

        amount = 4

    }

})
gRust.RegisterItem(Item)
--
-- Tech Trash
--
Item = gRust.ItemRegister("techparts")
Item:SetName("Old Microchips")
Item:SetDescription("A pile of random microchips.")
Item:SetCategory("Components")
Item:SetStack(50)
Item:SetIcon("materials/items/resources/tech_trash.png")
Item:SetModel("models/items/techtrash.mdl")
Item:SetSound("plastic")
Item:SetBlueprint(125)
Item:SetCraft({

    {

        item = "bluefrag",

        amount = 1

    },

    {

        item = "scrap",

        amount = 48

    },

    {

        item = "metal.refined",

        amount = 2

    }

})
gRust.RegisterItem(Item)
--
-- Sewing Kit
--
Item = gRust.ItemRegister("sewingkit")
Item:SetName("Sewing Kit")
Item:SetDescription("A sewing kit. Used for crafting complex clothing.")
Item:SetCategory("Components")
Item:SetStack(50)
Item:SetIcon("materials/items/resources/sewing_kit.png")
Item:SetModel("models/items/sewingkit.mdl")
Item:SetSound("cloth")
Item:SetBlueprint(125)
Item:SetCraft({

    {

        item = "rope",

        amount = 6

    },

    {

        item = "cloth",

        amount = 40

    }

})

gRust.RegisterItem(Item)
--
-- Rope
--
Item = gRust.ItemRegister("rope")
Item:SetName("Rope")
Item:SetDescription("A long rope.")
Item:SetCategory("Components")
Item:SetStack(50)
Item:SetIcon("materials/items/resources/rope.png")
Item:SetModel("models/items/rope.mdl")
Item:SetSound("cloth")
Item:SetBlueprint(125)
Item:SetCraft({
    {
        item = "cloth",
        amount = 60
    }
})
gRust.RegisterItem(Item)
--
-- Tarp
--
Item = gRust.ItemRegister("tarp")
Item:SetName("Tarp")
Item:SetDescription("Waterproof tarp.")
Item:SetCategory("Components")
Item:SetStack(50)
Item:SetIcon("materials/items/resources/tarp.png")
Item:SetModel("models/items/tarp.mdl")
Item:SetBlueprint(125)
Item:SetCraft({
    {
        item = "cloth",
        amount = 120
    }
})
gRust.RegisterItem(Item)