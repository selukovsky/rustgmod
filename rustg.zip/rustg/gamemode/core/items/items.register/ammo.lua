local Item
--
-- Pistol Ammo
--
Item = gRust.ItemRegister("ammo.pistol")
Item:SetName("Pistol Bullet")
Item:SetDescription("Standard ammunition for pistols and submachine guns.")
Item:SetCategory("Ammo")
Item:SetStack(128)
Item:SetIcon("materials/items/ammo/pistol_ammo.png")
Item:SetCraftTime(3)
Item:SetTier(1)
Item:SetCraftAmount(4)
Item:SetBlueprint(75)
Item:SetSound("metal")
Item:SetCraft({
    {
        item = "metal.fragments",
        amount = 10
    },
    {
        item = "gunpowder",
        amount = 5
    }
})

gRust.RegisterItem(Item)
--
-- Rifle Ammo
--
Item = gRust.ItemRegister("ammo.rifle")
Item:SetName("5.56 Rifle Ammo")
Item:SetDescription("Standard high powered ammunition, used by any rifle in the game currently. Offers superior damage, range, accuracy, damage drop off and air resistance from the Pistol Bullet.")
Item:SetCategory("Ammo")
Item:SetStack(128)
Item:SetIcon("materials/items/ammo/rifle_ammo.png")
Item:SetCraftTime(3)
Item:SetTier(2)
Item:SetCraftAmount(3)
Item:SetBlueprint(125)
Item:SetSound("metal")
Item:SetCraft({
    {
        item = "metal.fragments",
        amount = 10
    },
    {
        item = "gunpowder",
        amount = 5
    }
})

gRust.RegisterItem(Item)

Item = gRust.ItemRegister("ammo.rifle.incendiary")
Item:SetName("Incendiary 5.56 Rifle Ammo")
Item:SetDescription("A variant of the standard 5.56 rifle ammunition. The 5.56 Incendiary round will ignite on impact dealing both bullet and fire damage to a player. The round is however subject to increased bullet drop and lower velocity. This bullet is an especially effective counter to helicopters and vehicles for its cost.")
Item:SetCategory("Ammo")
Item:SetStack(128)
Item:SetIcon("materials/icons2/ammo.rifle.incendiary.png")
Item:SetCraftTime(3)
Item:SetTier(3)
Item:SetCraftAmount(3)
Item:SetSound("metal")
Item:SetCraft({
    {
        item = "metal.fragments",
        amount = 10
    },
    {
        item = "gunpowder",
        amount = 5
    }
})

gRust.RegisterItem(Item)

Item = gRust.ItemRegister("ammo.rifle.ap")
Item:SetName("Explosive 5.56 Rifle Ammo")
Item:SetDescription("A variant of the standard 5.56 rifle ammunition. The Explosive 5.56 round deals a small amount of additional explosion damage to a player upon direct impact as well as damaging nearby structures or players.")
Item:SetCategory("Ammo")
Item:SetStack(128)
Item:SetIcon("materials/icons2/ammo.rifle.explosive.png")
Item:SetCraftTime(3)
Item:SetTier(3)
Item:SetCraftAmount(2)
Item:SetSound("metal")
Item:SetCraft({
    {
        item = "metal.fragments",
        amount = 10
    },
    {
        item = "gunpowder",
        amount = 20
    },
    {
        item = "sulfur",
        amount = 10
    }
})

gRust.RegisterItem(Item)

--
-- Shotgun Ammo
--
Item = gRust.ItemRegister("ammo.shotgun")
Item:SetName("12 Gauge Buckshot")
Item:SetDescription("12 Gauge buckshot has fewer pellets than the Handmade Shell, but makes up for it by doing much more damage with each pellet.")
Item:SetCategory("Ammo")
Item:SetStack(128)
Item:SetIcon("materials/items/ammo/shotgun_ammo.png")
Item:SetTier(2)
Item:SetCraftTime(3)
Item:SetSound("leather")
Item:SetBlueprint(75)
Item:SetCraftAmount(2)
Item:SetCraft({
    {
        item = "metal.fragments",
        amount = 5
    },
    {
        item = "gunpowder",
        amount = 10
    }
})

gRust.RegisterItem(Item)

Item = gRust.ItemRegister("ammo.shotgun.slug")
Item:SetName("12 Gauge Slug")
Item:SetDescription("12 Gauge Slug is a type of shotgun ammunition that fires a single, high-damage projectile. 12 Gauge Slug is most useful for when the user seeks to significantly extend the range of their shotgun at the cost of decreased lethality in close-quarters and requiring more precise aim to land a hit.")
Item:SetCategory("Ammo")
Item:SetStack(128)
Item:SetIcon("materials/icons2/ammo.shotgun.slug.png")
Item:SetTier(2)
Item:SetCraftTime(3)
Item:SetSound("leather")
Item:SetBlueprint(75)
Item:SetCraftAmount(2)
Item:SetCraft({
    {
        item = "metal.fragments",
        amount = 5
    },
    {
        item = "gunpowder",
        amount = 10
    }
})

gRust.RegisterItem(Item)
--
-- Arrow
--
Item = gRust.ItemRegister("arrow.wooden")
Item:SetName("Wooden Arrow")
Item:SetDescription("The Wooden Arrow is one of four ammo types for the crossbow and the bow. It has lower range and velocity than the High Velocity Arrow, but it does more damage compared to it.")
Item:SetCategory("Ammo")
Item:SetStack(64)
Item:SetIcon("materials/items/ammo/arrow.png")
Item:SetCraftTime(3)
Item:SetCraftAmount(2)
Item:SetCraft({
    {
        item = "wood",
        amount = 25
    },
    {
        item = "stone",
        amount = 10
    }
})

gRust.RegisterItem(Item)
--
-- Nailgun Nails
--
Item = gRust.ItemRegister("ammo.nailgun.nails")
Item:SetName("Nailgun Nails")
Item:SetDescription("Early game cheap and easy to acquire ammo for the Nailgun. Has a unique trajectory and velocity that is worse than regular arrows shot from a Hunting Bow, thus giving it a really small effective range. Work best up close and not beyond 10 meters.")
Item:SetCategory("Ammo")
Item:SetStack(64)
Item:SetIcon("materials/items/ammo/nailgun_nails.png")
Item:SetCraftTime(3)
Item:SetCraftAmount(5)
Item:SetCraft({
    {
        item = "metal.fragments",
        amount = 8
    }
})

Item = gRust.ItemRegister("ammo.mgl.basic")
Item:SetName("40mm HE Grenade")
Item:SetDescription("Ammunition for a 40mm Grenade Launcher.")
Item:SetCategory("Ammo")
Item:SetStack(32)
Item:SetSound("refined")
Item:SetIcon("materials/icons2/ammogrenadelauncherhe.png")

gRust.RegisterItem(Item)
--
-- Handmade Shells
--
Item = gRust.ItemRegister("ammo.handmade.shell")
Item:SetName("Handmade Shell")
Item:SetDescription("The handmade shell is an early-game shotgun ammunition that fires a spread of 20 low-damage pellets. It's highly damaging in close quarters, but its lethality quickly drops off as range increases. In comparison to 12 gauge buckshot, the handmade shell has significantly more pellets, but less damage overall.")
Item:SetCategory("Ammo")
Item:SetStack(64)
Item:SetIcon("materials/items/ammo/handmade_shell.png")
Item:SetCraftTime(3)
Item:SetSound("leather")
Item:SetCraftAmount(2)
Item:SetCraft({
    {
        item = "stone",
        amount = 5
    },
    {
        item = "gunpowder",
        amount = 5
    }
})

gRust.RegisterItem(Item)


--
-- Rocket
--

Item = gRust.ItemRegister("ammo.rocket.basic")
Item:SetName("Rocket")
Item:SetDescription("Rockets are currently one of the best tools for raiding and destroying buildings. Rockets are also deadly against players due to its high damage and range of splash damage.")
Item:SetCategory("Ammo")
Item:SetStack(3)
Item:SetIcon("materials/items/ammo/rocket.png")
Item:SetCraftTime(3)
Item:SetTier(2)
Item:SetBlueprint(125)
Item:SetSound("refined")
Item:SetCraftAmount(1)
Item:SetCraft({
    {
        item = "metalpipe",
        amount = 2
    },
    {
        item = "explosives",
        amount = 10
    },
    {
        item = "gunpowder",
        amount = 150
    }
})

gRust.RegisterItem(Item)


Item = gRust.ItemRegister("ammo.rocket.highvelocity")
Item:SetName("High Velocity Rocket")
Item:SetDescription("The High-Velocity Rocket trades damage for a much higher speed and far less drop. The High-Velocity rocket is best used against placeables (mainly turrets), vehicles such as cars and helicopters, and enemy players. It is essentially intended for cases where a rocket would be overkill, or you would need the extra speed. The high-velocity rocket has poor damage against buildables and doors, but is a valuable tool for raiding in the other ways described.")
Item:SetCategory("Ammo")
Item:SetStack(3)
Item:SetIcon("materials/icons2/ammo.rocket.hv.png")
Item:SetCraftTime(3)
Item:SetTier(2)
Item:SetBlueprint(125)
Item:SetSound("refined")
Item:SetCraftAmount(1)
Item:SetCraft({
    {
        item = "metalpipe",
        amount = 1
    },
    {
        item = "gunpowder",
        amount = 100
    }
})

gRust.RegisterItem(Item)

Item = gRust.ItemRegister("ammo.rocket.incendiary")
Item:SetName("Incendiary Rocket")
Item:SetDescription("Incendiary rockets spread flames over the area of impact, dealing fire damage to its surroundings. It deals heavy damage to wooden structures and turrets. They can also be used effectively to trap and kill players in an enclosed space.")
Item:SetCategory("Ammo")
Item:SetStack(3)
Item:SetIcon("materials/icons2/ammo.rocket.fire.png")
Item:SetCraftTime(3)
Item:SetTier(2)
Item:SetBlueprint(125)
Item:SetSound("refined")
Item:SetCraftAmount(1)
Item:SetCraft({
    {
        item = "metalpipe",
        amount = 2
    },
    {
        item = "gunpowder",
        amount = 150
    }
})

gRust.RegisterItem(Item)