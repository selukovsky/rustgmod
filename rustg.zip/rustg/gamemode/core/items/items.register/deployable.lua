local Item

Item = gRust.ItemRegister("minicopter")
Item:SetName("Minicopter")
Item:SetStack(1)
Item:SetEntity("rust_minicopter")
Item:SetIcon("materials/icons2/mymini.png")
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("recycler")
Item:SetName("Recycler")
Item:SetStack(10)
Item:SetEntity("rust_recycler")
Item:SetIcon("materials/items/deployable/recycler.png")
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("milicrate")
Item:SetName("Military Crate")
Item:SetCategory("Resources")
Item:SetStack(1)
Item:SetEntity("rust_militarycrate")
Item:SetIcon("materials/icons2/cratem.png")
gRust.RegisterItem(Item)


Item = gRust.ItemRegister("ore")
Item:SetName("Ore")
Item:SetCategory("Resources")
Item:SetStack(1000)
Item:SetEntity("rust_ore")
Item:SetIcon("materials/icons2/stone-node.png")
gRust.RegisterItem(Item)
---
---
---

Item = gRust.ItemRegister("woodcrate")
Item:SetName("Wooden Crate")
Item:SetCategory("Resources")
Item:SetStack(1)
Item:SetEntity("rust_woodencrate")
Item:SetIcon("materials/icons2/cratew.png")
gRust.RegisterItem(Item)

---

Item = gRust.ItemRegister("lockcrate")
Item:SetName("Locked Crate")
Item:SetCategory("Resources")
Item:SetStack(1)
Item:SetEntity("rust_lockedcrate")
Item:SetIcon("materials/icons2/locked.png")
gRust.RegisterItem(Item)

---

Item = gRust.ItemRegister("elitcrate")
Item:SetName("Elite Crate")
Item:SetCategory("Resources")
Item:SetStack(1)
Item:SetEntity("rust_elitecrate")
Item:SetIcon("materials/icons2/cratee.png")
gRust.RegisterItem(Item)

---

Item = gRust.ItemRegister("bradleycrate")
Item:SetName("Bradley Crate")
Item:SetCategory("Resources")
Item:SetStack(1)
Item:SetEntity("rust_bradleycrate")
Item:SetIcon("materials/icons2/cratee.png")
Item:SetCraft({
    { item = "scrap", amount = 10000 },
    { item = "metal.fragments", amount = 5000 },
})
gRust.RegisterItem(Item)

---
-- Large Wood Box
---

Item = gRust.ItemRegister("box.wooden.large")
Item:SetName("Large Wooden Box")
Item:SetDescription("Store your belongings in this wooden box. Holds up to 48 items.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_largewoodbox")
Item:SetIcon("materials/items/deployable/large_wood_box.png")
Item:SetSound("wood")
Item:SetCraft({
    { item = "wood", amount = 250 },
    { item = "metal.fragments", amount = 50 },
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("auto.turret")
Item:SetName("Auto Turret")
Item:SetDescription("Store your belongings in this wooden box. Holds up to 48 items.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_turrel")
Item:SetIcon("materials/icons2/autoturret.png")
Item:SetSound("road")
Item:SetCraft({
    { item = "wood", amount = 250 },
    { item = "metal.fragments", amount = 50 },
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("radio")
Item:SetName("Radio")
Item:SetDescription("Radio! Dance Time")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_rust")
Item:SetIcon("materials/icons2/fun.boomboxportable.png")
Item:SetSound("plastic")
Item:SetCraft({
    { item = "metal.fragments", amount = 50 },
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("rustybarrel")
Item:SetName("Rusty Storage Barrel")
Item:SetDescription("Store your belongings in this old rusty barrel. Holds up to 48 items.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_barrelbox")
Item:SetIcon("materials/icons2/oildrum001.png")
Item:SetSound("wood")
Item:SetCraft({
    { item = "wood", amount = 250 },
    { item = "metal.fragments", amount = 50 },
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("comost")
Item:SetName("Composter")
Item:SetDescription("Turn poop into fertilizer.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_compost")
Item:SetIcon("materials/icons2/composter.png")
Item:SetSound("wood")
Item:SetCraft({
    { item = "wood", amount = 250 },
    { item = "tarp", amount = 1 },
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("locker")
Item:SetName("Locker")
Item:SetDescription("A locker to keep your clothes and armor safe!")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_locker")
Item:SetSound("wood")
Item:SetIcon("materials/icons2/locker.png")
Item:SetCraft({
    { item = "wood", amount = 50 },
    { item = "metal.fragments", amount = 100 },
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("barikada")
Item:SetName("Stone Barricade")
Item:SetDescription("A strong stone barricade to block enemies and protect your base.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_baricada")
Item:SetIcon("materials/icons2/barricadeconcrete.png")
Item:SetCraft({
    { item = "stones", amount = 150 },
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("ukritie")
Item:SetName("Wooden Cover")
Item:SetDescription("Perfect for cover during shootouts. Quickly decays if placed outside a building privilege area.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_ukritie")
Item:SetIcon("materials/icons2/barricadewoodcover.png")
Item:SetCraft({
    { item = "stones", amount = 150 },
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("bbq")
Item:SetName("Campfire")
Item:SetDescription("Used for cooking food.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_bbq")
Item:SetIcon("materials/icons2/campfire.png")
Item:SetSound("wood")
Item:SetCraft({
    { item = "wood", amount = 100 },
})
gRust.RegisterItem(Item)

---
-- Wood Box
---

Item = gRust.ItemRegister("box.wooden")
Item:SetName("Wooden Box")
Item:SetDescription("Store your belongings in this wooden box. Holds up to 18 items.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_woodbox")
Item:SetIcon("materials/items/deployable/wood_box.png")
Item:SetSound("wood")
Item:SetCraft({
    { item = "wood", amount = 100 },
})
gRust.RegisterItem(Item)

---
-- Wooden Door
---

---
-- Furnace
---

Item = gRust.ItemRegister("furnace")
Item:SetName("Furnace")
Item:SetDescription("Used for smelting ore.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_furnace")
Item:SetIcon("materials/items/deployable/furnace.png")
Item:SetCraft({
    { item = "stone", amount = 200 },
    { item = "wood", amount = 100 },
    { item = "lowgradefuel", amount = 50 },
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("oilfactory")
Item:SetName("Small Oil Refinery")
Item:SetDescription("A small refinery that can produce low-grade fuel from crude oil.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_npz")
Item:SetIcon("materials/icons2/smalloilrefinery.png")
Item:SetSound("refined")
Item:SetCraft({
    { item = "metal.fragments", amount = 500 },
    { item = "wood", amount = 200 },
    { item = "lowgradefuel", amount = 10 },
})
gRust.RegisterItem(Item)

---
-- Tool Cupboard
---

---
-- Sleeping Bag
---

Item = gRust.ItemRegister("sleepingbag")
Item:SetName("Sleeping Bag")
Item:SetDescription("A sleeping bag that sets a respawn point for you or another player with a long cooldown.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_sleepingbag")
Item:SetIcon("materials/items/deployable/sleeping_bag.png")
Item:SetSound("cloth")
Item:SetCraft({
    { item = "cloth", amount = 30 },
})
gRust.RegisterItem(Item)

---
-- Garage Door
---

Item = gRust.ItemRegister("largefurnace")
Item:SetName("Large Furnace")
Item:SetDescription("The Large Furnace is used for smelting larger quantities of ore, faster than a regular furnace.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_largefurnace")
Item:SetIcon("materials/icons2/furnace.large.png")
Item:SetCraft({
    { item = "stone", amount = 500 },
    { item = "wood", amount = 600 },
    { item = "lowgradefuel", amount = 75 },
})
gRust.RegisterItem(Item)

---
-- Research Table
---

Item = gRust.ItemRegister("research.table")
Item:SetName("Research Table")
Item:SetDescription("Used to research obtained items for scrap, granting blueprints for crafting.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_researchtable")
Item:SetIcon("materials/items/deployable/research_table.png")
Item:SetTier(1)
Item:SetCraft({
    { item = "metal.fragments", amount = 200 },
    { item = "scrap", amount = 20 },
})
gRust.RegisterItem(Item)

---
-- Repair Bench
---

Item = gRust.ItemRegister("box.repair.bench")
Item:SetName("Repair Bench")
Item:SetDescription("Used to repair broken items back to a usable state. Repairs cost half of the original resources.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_repairbench")
Item:SetIcon("materials/items/deployable/repair_bench.png")
Item:SetTier(1)
Item:SetCraft({
    { item = "metal.fragments", amount = 125 },
})
gRust.RegisterItem(Item)

---
-- Workbench Level 1
---

Item = gRust.ItemRegister("workbench1")
Item:SetName("Workbench Level 1")
Item:SetDescription("Allows crafting and unlocking items that require Workbench Level 1.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_tier1")
Item:SetIcon("materials/items/deployable/tier1.png")
Item:SetSound("wood")
Item:SetCraft({
    { item = "wood", amount = 500 },
    { item = "metal.fragments", amount = 100 },
    { item = "scrap", amount = 50 },
})
gRust.RegisterItem(Item)

---
-- Workbench Level 2
---

Item = gRust.ItemRegister("workbench2")
Item:SetName("Workbench Level 2")
Item:SetDescription("Allows crafting and unlocking items that require Workbench Level 2.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_tier2")
Item:SetIcon("materials/items/deployable/tier2.png")
Item:SetTier(1)
Item:SetSound("large")
Item:SetCraft({
    { item = "bluefrag", amount = 100 },
    { item = "metal.fragments", amount = 500 },
    { item = "metal.refined", amount = 20 },
    { item = "scrap", amount = 500 },
})
gRust.RegisterItem(Item)

---
-- Workbench Level 3
---

Item = gRust.ItemRegister("workbench3")
Item:SetName("Workbench Level 3")
Item:SetDescription("Allows crafting and unlocking items that require Workbench Level 3.")
Item:SetCategory("Items")
Item:SetStack(1)
Item:SetEntity("rust_tier3")
Item:SetIcon("materials/items/deployable/tier3.png")
Item:SetTier(2)
Item:SetSound("large")
Item:SetCraft({
    { item = "bluelist", amount = 3 },
    { item = "metal.fragments", amount = 1000 },
    { item = "metal.refined", amount = 100 },
    { item = "scrap", amount = 1250 },
})
gRust.RegisterItem(Item)

---
-- Hemp Seed
---

Item = gRust.ItemRegister("seed.hemp")
Item:SetName("Hemp Seed")
Item:SetDescription("Hemp seeds can be planted to grow more hemp and produce cloth. Growing in planters with water increases yield and growth speed.")
Item:SetCategory("Items")
Item:SetStack(50)
Item:SetEntity("rust_hemp")
Item:SetIcon("materials/items/deployable/hemp_seed.png")
gRust.RegisterItem(Item)

---
-- Metal Shop Front
---





Item = gRust.ItemRegister("barricade.stone")

Item:SetName("Stone Barricade")

Item:SetCategory("Items")

Item:SetStack(10)

Item:SetEntity("rust_stonebarricade")

Item:SetIcon("materials/items/deployable/stone_barricade.png")

Item:SetBlueprint(125)

Item:SetCraft({

    {

        item = "stone",

        amount = 100

    }

})

gRust.RegisterItem(Item)




--

-- Metal Shop Front

--



Item = gRust.ItemRegister("wall.frame.shopfront.metal")

Item:SetName("Metal Shop Front")

Item:SetDescription("The metal shop front is quite useful for trading. The vendor can stand safely behind it without worrying about getting shot, as the glass is bulletproof. When the player on the inside and the player on the outside have put in items to make the desired trade, they both have to accept the deal for the items to be transferred.")

Item:SetCategory("Items")

Item:SetStack(1)

Item:SetEntity("rust_frontshop")

Item:SetIcon("materials/items/deployable/metal_shop_front.png")

Item:SetTier(1)

Item:SetCraft({

    {

        item = "metal.fragments",

        amount = 250

    }

})

gRust.RegisterItem(Item)



--

-- Wooden Window Bars

--



Item = gRust.ItemRegister("wall.window.bars.wood")

Item:SetName("Wooden Window Bars")

Item:SetDescription("The Wooden Window Bars are the lowest-tier window bars, provide little cover and deny entrance through windows. They are weaker over its reinforced and metal counterparts. Due to its weakness to fire damage and low health higher tier window bars are recommended.")

Item:SetCategory("Items")

Item:SetStack(1)

Item:SetEntity("rust_woodbars")

Item:SetIcon("materials/items/deployable/wood_window_bars.png")

Item:SetTier(1)

Item:SetCraft({

    {

        item = "wood",

        amount = 200

    }

})

gRust.RegisterItem(Item)


Item = gRust.ItemRegister("embrasure")

Item:SetName("Metal Vertical embrasure")

Item:SetDescription("Placed over a window it is used to reduce the size and grants the player more cover than the window.")

Item:SetCategory("Items")

Item:SetStack(1)

Item:SetEntity("rust_boinica")

Item:SetIcon("materials/icons2/shutter.metal.embrasure.b.png")

Item:SetTier(2)

Item:SetBlueprint(125)

Item:SetCraft({

    {

        item = "metal.fragments",

        amount = 100

    }

})

gRust.RegisterItem(Item)



--

-- Reinforced Glass Window

--



Item = gRust.ItemRegister("wall.window.glass.reinforced")

Item:SetName("Усиленное окно")

Item:SetDescription("Не повезло с лутом да? Ну не унывай следующий крейт тебя точно удивит")

Item:SetCategory("Items")

Item:SetStack(1)

Item:SetEntity("rust_reinforcedwindow")

Item:SetIcon("materials/items/deployable/reinforced_glass_window.png")

Item:SetTier(3)

Item:SetBlueprint(125)

Item:SetCraft({

    {

        item = "metal.refined",

        amount = 20

    }

})

gRust.RegisterItem(Item)


--

-- Table

--



Item = gRust.ItemRegister("table")

Item:SetName("Стол")

Item:SetDescription("Every home needs a table. A decorative item which provides comfort when in close proximity.")

Item:SetCategory("Items")

Item:SetStack(1)

Item:SetEntity("rust_table")

Item:SetIcon("materials/items/deployable/table.png")

Item:SetBlueprint(75)

Item:SetCraft({

    {

        item = "wood",

        amount = 300

    }

})

gRust.RegisterItem(Item)



--

-- Shelves

--



Item = gRust.ItemRegister("shelves")

Item:SetName("Полки")

Item:SetDescription("Shelves for item stacking")

Item:SetCategory("Items")

Item:SetStack(1)

Item:SetEntity("rust_shelves")

Item:SetIcon("materials/items/deployable/shelves.png")

Item:SetBlueprint(75)

Item:SetCraft({

    {

        item = "metal.fragments",

        amount = 400

    }

})

gRust.RegisterItem(Item)





--

-- Vending Machine

--



Item = gRust.ItemRegister("vending.machine")

Item:SetName("Vending Machine")

Item:SetDescription("The Vending Machine provides a safe way to make indirect trade with other players.")

Item:SetCategory("Items")

Item:SetStack(1)

Item:SetEntity("rust_vendingmachine")

Item:SetIcon("materials/items/deployable/vending_machine.png")

Item:SetCraft({

    {

        item = "gears",

        amount = 50,

    }

})

gRust.RegisterItem(Item)