local Item



--

-- Bandages

--



Item = gRust.ItemRegister("bandage")

Item:SetName("Bandage")

Item:SetDescription("Bandages are crafted medical supplies that stop bleeding and heal a small amount of health.")

Item:SetCategory("Medical")

Item:SetStack(3)

Item:SetIcon("materials/items/medical/bandages.png")

Item:SetWeapon("rust_bandages")

Item:SetSound("cloth")

Item:SetDurability(false)

Item:SetCraftTime(3)

Item:SetCraft({

    {

        item = "cloth",

        amount = 5

    },

})

gRust.RegisterItem(Item)



--

-- Medical Syringe

--



Item = gRust.ItemRegister("syringe.medical")

Item:SetName("Medical Syringe")

Item:SetDescription("The Medical Syringe is the best medical supply used for combat situations. It instant heals you a portion of your health and slowly heals the rest. It also reduces your radiation poisoning which is very useful while navigating the red puzzle building with high levels of radiation.")

Item:SetCategory("Medical")

Item:SetStack(2)


Item:SetIcon("materials/items/medical/syringe.png")

Item:SetWeapon("rust_medicalsyringe")

Item:SetTier(2)

Item:SetDurability(false)

Item:SetBlueprint(75)

Item:SetSound("leather")

Item:SetCraft({

    {

        item = "cloth",

        amount = 15

    },

    {

        item = "metal.fragments",

        amount = 10

    },

    {

        item = "lowgradefuel",

        amount = 10

    }

})

gRust.RegisterItem(Item)