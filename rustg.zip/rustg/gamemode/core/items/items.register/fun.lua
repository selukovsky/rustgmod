Item = gRust.ItemRegister("smalllootbag")

Item:SetName("Маленький мешок с добычей")

Item:SetDescription("Откройте, чтобы получить маленький сюрприз")

Item:SetCategory("Fun")

Item:SetStack(1)

Item:SetIcon("materials/icons2/halloweenlootbagsmall.png")

Item:SetSound("paper")

gRust.RegisterItem(Item)



--

-- Medical Syringe

--



Item = gRust.ItemRegister("medlootbag")

Item:SetName("Средний мешок с добычей")

Item:SetDescription("Содержит добычу среднего уровня. Соберите 10 штук, чтобы улучшить до большого мешка с лучшим лутом")

Item:SetCategory("Fun")

Item:SetStack(1)

Item:SetIcon("materials/icons2/halloweelootbagmedium.png")

Item:SetSound("paper")

gRust.RegisterItem(Item)



Item = gRust.ItemRegister("largelootbag")

Item:SetName("Большой мешок с добычей")

Item:SetDescription("Акустическая гитара, подходит для ночных посиделок возле костра.")

Item:SetCategory("Fun")

Item:SetStack(1)

Item:SetIcon("materials/icons2/halloweenlootbaglarge.png")

Item:SetSound("paper")

gRust.RegisterItem(Item)



Item = gRust.ItemRegister("guitar")

Item:SetName("Акустическая гитара")

Item:SetDescription("Акустическая гитара, подходит для ночных посиделок возле костра.")

Item:SetCategory("Fun")

Item:SetStack(1)

Item:SetIcon("materials/icons2/funguitar.png")

Item:SetSound("tool")

Item:SetWeapon("velkon_guitar")

Item:SetCraft({

    {

        item = "wood",

        amount = 150

    },

    {

        item = "metal.fragments",

        amount = 25

    }

})

gRust.RegisterItem(Item)



Item = gRust.ItemRegister("piano")

Item:SetName("Пианино на тачке")

Item:SetDescription("Храните свои вещи в этой старой ржавой бочке. Вмещает до 48 предметов.")

Item:SetCategory("Fun")

Item:SetStack(1)

Item:SetEntity("rust_piano")

Item:SetIcon("materials/icons2/oildrum001.png")

Item:SetSound("wood")

Item:SetCraft({

    {

        item = "wood",

        amount = 250,

    },

    {

        item = "metal.fragments",

        amount = 50,

    }

})

gRust.RegisterItem(Item)