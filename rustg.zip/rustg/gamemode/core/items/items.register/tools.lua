local Item
--
-- Rock
--
Item = gRust.ItemRegister("rock")
Item:SetName("Rock")
Item:SetDescription("The Rock. Main and primitive gathering tool.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/items/tools/rock.png")
Item:SetWeapon("rust_rock")
Item:SetCraft({
    {
        item = "stone",
        amount = 10
    }
})

gRust.RegisterItem(Item)
--
-- Stone hatchet
--
Item = gRust.ItemRegister("stonehatchet")
Item:SetName("Stone Hatchet")
Item:SetDescription("A primitive tool for chopping wood.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/items/tools/stone_hatchet.png")
Item:SetSound("tool")
Item:SetWeapon("rust_stonehatchet")
Item:SetCraft({
    {
        item = "wood",
        amount = 200,
    },
    {
        item = "stone",
        amount = 100
    }
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("betonhatchet")
Item:SetName("Concrete Hatchet")
Item:SetDescription("A primitive tool for chopping wood.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/icons2/concretehatchet.png")
Item:SetSound("tool")
Item:SetWeapon("rust_betonhatchet")
Item:SetCraft({
    {
        item = "wood",
        amount = 200,
    },
    {
        item = "stone",
        amount = 100
    }
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("betonpick")
Item:SetName("Concrete Pickaxe")
Item:SetDescription("A primitive tool for gathering resources.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/icons2/concretepickaxe.png")
Item:SetSound("tool")
Item:SetWeapon("rust_betonpickaxe")
Item:SetCraft({
    {
        item = "wood",
        amount = 200,
    },
    {
        item = "stone",
        amount = 100
    }
})
gRust.RegisterItem(Item)
--
-- Stone pickaxe
--
Item = gRust.ItemRegister("stone.pickaxe")
Item:SetName("Stone Pickaxe")
Item:SetDescription("A primitive tool for gathering stone, as well as metal and sulfur ore.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/items/tools/stone_pickaxe.png")
Item:SetSound("tool")
Item:SetWeapon("rust_stonepickaxe")
Item:SetCraft({
    {
        item = "wood",
        amount = 200,
    },
    {
        item = "stone",
        amount = 100
    }
})
gRust.RegisterItem(Item)
--
-- Building Plan
--
Item = gRust.ItemRegister("building.planner")
Item:SetName("Building Plan")
Item:SetDescription("Building plan. Used for creating structures - take it in your hands and press the right mouse button to view options.")
Item:SetCategory("Construction")
Item:SetStack(1)
Item:SetIcon("materials/items/tools/building_plan.png")
Item:SetWeapon("rust_buildingplan")
Item:SetSound("paper")
Item:SetDurability(false)
Item:SetCraft({
    {
        item = "wood",
        amount = 20
    }
})
gRust.RegisterItem(Item)
--
-- Hammer
--
Item = gRust.ItemRegister("hammer")
Item:SetName("Hammer")
Item:SetDescription("The hammer is used to upgrade structures. Right click to view options. You can also pick up objects when holding the hammer.")
Item:SetCategory("Construction")
Item:SetStack(1)
Item:SetIcon("materials/items/tools/hammer.png")
Item:SetWeapon("rust_hammer")
Item:SetDurability(false)
Item:SetModel("models/weapons/darky_m/rust/w_hammer.mdl")
Item:SetSound("tool")
Item:SetCraft({
    {
        item = "wood",
        amount = 200,
    },
})
gRust.RegisterItem(Item)
--
-- Hatchet
--
Item = gRust.ItemRegister("hatchet")
Item:SetName("Hatchet")
Item:SetDescription("The hatchet is useful for chopping trees and dismembering corpses.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/items/tools/hatchet.png")
Item:SetWeapon("rust_hatchet")
Item:SetSound("tool")
Item:SetBlueprint(125)
Item:SetTier(1)
Item:SetCraft({
    {
        item = "wood",
        amount = 200,
    },
    {
        item = "metal.fragments",
        amount = 100
    }
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("protaxe")
Item:SetName("Prototype Hatchet")
Item:SetDescription("The hatchet is useful for chopping trees and dismembering corpses.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/icons2/lumberjackhatchet.png")
Item:SetWeapon("rust_prothatchet")
Item:SetSound("tool")
Item:SetTier(1)
Item:SetCraft({
    {
        item = "wood",
        amount = 200,
    },
    {
        item = "metal.fragments",
        amount = 100
    }
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("frontaxe")
Item:SetName("Frontier Hatchet")
Item:SetDescription("The hatchet is useful for chopping trees and dismembering corpses.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/icons2/frontierhatchet.png")
Item:SetWeapon("rust_fronthatchet")
Item:SetSound("tool")
Item:SetTier(1)
Item:SetCraft({
    {
        item = "wood",
        amount = 200,
    },
    {
        item = "metal.fragments",
        amount = 100
    }
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("protpick")
Item:SetName("Prototype Pickaxe")
Item:SetDescription("Prototype pickaxe")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/icons2/lumberjackpickaxe.png")
Item:SetWeapon("rust_protpickaxe")
Item:SetSound("tool")
Item:SetTier(1)
Item:SetCraft({
    {
        item = "wood",
        amount = 200,
    },
    {
        item = "metal.fragments",
        amount = 100
    }
})
gRust.RegisterItem(Item)
--
-- Pickaxe
--
Item = gRust.ItemRegister("pickaxe")
Item:SetName("Pickaxe")
Item:SetDescription("A pickaxe, useful for gathering ore from stones.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/items/tools/pickaxe.png")
Item:SetWeapon("rust_pickaxe")
Item:SetSound("tool")
Item:SetBlueprint(125)
Item:SetTier(1)
Item:SetCraft({
    {
        item = "wood",
        amount = 200,
    },
    {
        item = "metal.fragments",
        amount = 100
    }
})
gRust.RegisterItem(Item)
--
-- Jackhammer
--
Item = gRust.ItemRegister("jackhammer")
Item:SetName("Jackhammer")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/items/tools/jackhammer.png")
Item:SetWeapon("rust_jackhammer")
gRust.RegisterItem(Item)
--
-- Green Keycard
--

Item = gRust.ItemRegister("keycard_red")
Item:SetName("Red Keycard")
Item:SetDescription("An access keycard for a locked crate. It is consumed after use.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/icons2/keycard_red.png")
Item:SetWeapon("rust_card")
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("keycard_blue")
Item:SetName("Blue Keycard")
Item:SetDescription("An access keycard for a locked crate. It is consumed after use.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/icons2/keycard_blue.png")
Item:SetWeapon("rust_card")
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("keycard_green")
Item:SetName("Green Keycard")
Item:SetDescription("An access keycard for a locked crate. It is consumed after use.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/icons2/keycard_green.png")
Item:SetWeapon("rust_card")
gRust.RegisterItem(Item)

---
---
---
Item = gRust.ItemRegister("torch12")
Item:SetName("Torch")
Item:SetDescription("A torch. Illuminates the path at night and can be used as a weapon.")
Item:SetCategory("Tools")
Item:SetStack(1)
Item:SetIcon("materials/icons2/torch.png")
Item:SetSound("tool")
Item:SetWeapon("tfa_rustalpha_torch")
gRust.RegisterItem(Item)