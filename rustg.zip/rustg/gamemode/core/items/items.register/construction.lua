local Item

Item = gRust.ItemRegister("wall.frame.garagedoor")
Item:SetName("Garage Door")
Item:SetDescription("The garage door is a lockable door that slides upward when opened. It fits in a wall frame and is more durable than sheet metal double doors but opens slower.")
Item:SetCategory("Construction")
Item:SetStack(1)
Item:SetEntity("rust_garagedoor")
Item:SetIcon("materials/items/deployable/garage_door.png")
Item:SetTier(2)
Item:SetSound("road")
Item:SetCraft({
    { item = "metal.fragments", amount = 300 },
    { item = "gears", amount = 2 },
})
gRust.RegisterItem(Item)


Item = gRust.ItemRegister("wall.frame.doubledoor")
Item:SetName("Sheet Metal Double Door")
Item:SetDescription("The garage door is a lockable door that slides upward when opened. It fits in a wall frame and is more durable than sheet metal double doors but opens slower.")
Item:SetCategory("Construction")
Item:SetStack(1)
Item:SetEntity("rust_doubledoormetal")
Item:SetIcon("materials/icons2/door.double.hinged.metal.png")
Item:SetSound("large")
Item:SetCraft({
    { item = "metal.fragments", amount = 150 }
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("armor.double.door")
Item:SetName("Armored Double Door")
Item:SetDescription("The armored double door is the highest tier double door and is the best for base defense. Because of its high durability, if the door is placed in a weak wall frame, raiders may target the wall frame instead of the door itself. The door has working hatches and these hatches allow you to see outside of the door and can be shot through in both directions.")
Item:SetCategory("Construction")
Item:SetStack(1)
Item:SetEntity("rust_doubledoorarmor")
Item:SetIcon("materials/icons2/door.double.hinged.toptier.png")
Item:SetSound("large")
Item:SetTier(3)
Item:SetCraft({
    { item = "metal.refined", amount = 25 },
    { item = "gears", amount = 5 }
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("wooden.double.door")
Item:SetName("Wood Double Door")
Item:SetDescription("A Cheap door to secure your base. Its vulnerability to fire and weak explosive resistance makes the door a temporary solution to securing your base.")
Item:SetCategory("Construction")
Item:SetStack(1)
Item:SetEntity("rust_doubledoorwooden")
Item:SetIcon("materials/icons2/door.double.hinged.wood.png")
Item:SetSound("wood")
Item:SetCraft({
    { item = "wood", amount = 350 }
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("door.hinged.wood")
Item:SetName("Wooden Door")
Item:SetDescription("A cheap door for protecting your base. Vulnerable to fire and explosives, making it only a temporary solution. Consider upgrading to a stronger door, like sheet metal.")
Item:SetCategory("Construction")
Item:SetStack(1)
Item:SetEntity("rust_doorwood")
Item:SetIcon("materials/items/deployable/wooden_door.png")
Item:SetSound("wood")
Item:SetCraft({
    { item = "wood", amount = 300 },
})
gRust.RegisterItem(Item)

---
-- Sheet Metal Door
---

Item = gRust.ItemRegister("door.hinged.metal")
Item:SetName("Sheet Metal Door")
Item:SetDescription("A medium-strength door, vulnerable to explosives.")
Item:SetCategory("Construction")
Item:SetStack(1)
Item:SetEntity("rust_doormetal")
Item:SetIcon("materials/items/deployable/metal_door.png")
Item:SetSound("refined")
Item:SetCraft({
    { item = "metal.fragments", amount = 150 },
})
gRust.RegisterItem(Item)

---
-- Armored Door
---

Item = gRust.ItemRegister("door.hinged.toptier")
Item:SetName("Armored Door")
Item:SetDescription("A very durable door with a viewing slit to look and shoot through.")
Item:SetCategory("Construction")
Item:SetStack(1)
Item:SetEntity("rust_doorarmored")
Item:SetIcon("materials/items/deployable/armored_door.png")
Item:SetTier(3)
Item:SetBlueprint(500)
Item:SetCraft({
    { item = "metal.refined", amount = 20 },
    { item = "gears", amount = 5 },
})
gRust.RegisterItem(Item)

---
-- Key Lock
---

Item = gRust.ItemRegister("lock.key")
Item:SetName("Code Lock")
Item:SetDescription("An electronic lock secured by a four-digit code.")
Item:SetCategory("Construction")
Item:SetStack(1)
Item:SetEntity("rust_keylock")
Item:SetIcon("materials/items/deployable/keylock.png")
Item:SetCraft({
    { item = "wood", amount = 75 },
})
gRust.RegisterItem(Item)

---
-- Keypad
---

Item = gRust.ItemRegister("lock.code")
Item:SetName("Door Lock")
Item:SetDescription("Place on a door to prevent unwanted guests. You can create a key to let friends in, but don't let it fall into the wrong hands!")
Item:SetCategory("Construction")
Item:SetStack(1)
Item:SetEntity("rust_keypad")
Item:SetIcon("materials/items/deployable/keypad.png")
Item:SetCraft({
    { item = "metal.fragments", amount = 100 },
})
gRust.RegisterItem(Item)

Item = gRust.ItemRegister("cupboard.tool")
Item:SetName("Tool Cupboard")
Item:SetDescription("Placing and authorizing in the cupboard allows only you to build within a 50-meter radius. Friends must also authorize to gain access. Protect this cupboard!")
Item:SetCategory("Construction")
Item:SetStack(1)
Item:SetEntity("rust_toolcupboard")
Item:SetIcon("materials/items/deployable/tool_cupboard.png")
Item:SetSound("wood")
Item:SetCraft({
    { item = "wood", amount = 1000 },
})
gRust.RegisterItem(Item)