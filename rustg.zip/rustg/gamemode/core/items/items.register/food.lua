local Item



--

-- Bandages

--



Item = gRust.ItemRegister("can.tuna")

Item:SetName("Can of Tuna")

Item:SetDescription("Chunked tuna found as loot. Eating it provides a small boost to health, hunger, and thirst.")

Item:SetCategory("Food")

Item:SetStack(10)

Item:SetDurability(false)

Item:SetIcon("materials/icons2/can.tuna.png")

Item:SetSound("can")

gRust.RegisterItem(Item)



Item = gRust.ItemRegister("horse.raw")

Item:SetName("Raw Horse Meat")

Item:SetDescription("Raw Horse Meat. Eating it will damage your health, try cooking it first.")

Item:SetCategory("Food")

Item:SetStack(20)

Item:SetDurability(false)

Item:SetIcon("materials/icons2/horsemeatraw.png")

Item:SetSound("meat")

gRust.RegisterItem(Item)



Item = gRust.ItemRegister("horse.cook")

Item:SetName("Cooked Horse Meat")

Item:SetDescription("Cooked Horse Meat. Eating it will restore some health, hunger, and thirst.")

Item:SetCategory("Food")

Item:SetStack(20)

Item:SetDurability(false)

Item:SetIcon("materials/icons2/horsemeatcooked.png")

Item:SetSound("meat")

gRust.RegisterItem(Item)


Item = gRust.ItemRegister("large.medkit")

Item:SetName("Large Medkit")

Item:SetDescription("The Large Medkit is medical supplies that stops bleeding")

Item:SetCategory("Food")

Item:SetStack(5)

Item:SetDurability(false)

Item:SetIcon("materials/icons2/largemedkit.png")

Item:SetSound("leather")

gRust.RegisterItem(Item)
--

-- Medical Syringe

--



Item = gRust.ItemRegister("can.beans")

Item:SetName("Can of Beans")

Item:SetDescription("Beans found as loot. Eating it provides a small boost to health, hunger, and thirst.")

Item:SetCategory("Food")

Item:SetStack(10)

Item:SetDurability(false)

Item:SetIcon("materials/icons2/can.beans.png")

Item:SetSound("can")

gRust.RegisterItem(Item)


Item = gRust.ItemRegister("breed")

Item:SetName("Bread")

Item:SetDescription("A loaf of bread, eating it provides a boost to health, hunger and hydration. Feeding to a horse will provide a boost to its digestion and dung production for a short time.")

Item:SetCategory("Food")

Item:SetStack(10)

Item:SetDurability(false)

Item:SetIcon("materials/icons2/bread.loaf.png")

Item:SetSound("leather")

gRust.RegisterItem(Item)



Item = gRust.ItemRegister("apple")

Item:SetName("Apple")

Item:SetDescription("The apple is a food that gives the player food and water.")

Item:SetCategory("Food")

Item:SetStack(5)

Item:SetDurability(false)

Item:SetIcon("materials/icons2/apple.png")

Item:SetSound("leather")

gRust.RegisterItem(Item)


Item = gRust.ItemRegister("granolabar")

Item:SetName("Granola Bar")

Item:SetDescription("Granola Bar")

Item:SetCategory("Food")

Item:SetStack(5)

Item:SetDurability(false)

Item:SetIcon("materials/icons2/granolabar.png")

Item:SetSound("paper")

gRust.RegisterItem(Item)


Item = gRust.ItemRegister("blueberries")

Item:SetName("Blueberries")

Item:SetDescription("A rare food item acquired from food crates (not to be confused with ration boxes) found in monuments randomly")

Item:SetCategory("Food")

Item:SetStack(5)

Item:SetDurability(false)

Item:SetIcon("materials/icons2/blueberries.png")

Item:SetSound("leather")

gRust.RegisterItem(Item)


Item = gRust.ItemRegister("water.item")
Item:SetName("Вода")
Item:SetDescription("Водичка, ммм вкусненькая, выпей её она такая холодненькая. ДЛЯ ДЕБАГА БЛЯТЬ")
Item:SetCategory("Food")
Item:SetStack(10000)
Item:SetIcon("materials/icons2/water.png")
Item:SetSound("water")
gRust.RegisterItem(Item)



Item = gRust.ItemRegister("water")

Item:SetName("Small Water Bottle")

Item:SetDescription("The Water Bottle found in trash piles, and is used for the collection and transportation of drinkable water.")

Item:SetCategory("Food")

Item:SetStack(1)

Item:SetDurability(false)

Item:SetWeapon("rust_water")

Item:SetIcon("materials/icons2/smallwaterbottle.png")

Item:SetSound("plastic")

gRust.RegisterItem(Item)