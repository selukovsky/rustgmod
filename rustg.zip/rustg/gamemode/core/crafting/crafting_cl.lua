gRust.CraftQueue = gRust.CraftQueue or {}
LocalPlayer().Blueprints = LocalPlayer().Blueprints or {}

-- Обработчик синхронизации чертежей
net.Receive("gRust.SyncBlueprints", function()
    local count = net.ReadUInt(16)
    LocalPlayer().Blueprints = {}
    
    for i = 1, count do
        local class = net.ReadString()
        LocalPlayer().Blueprints[class] = true
        print("[BLUEPRINT SYNC] Added: ", class)
    end
    
    print("[BLUEPRINT SYNC] Total blueprints: ", table.Count(LocalPlayer().Blueprints))
    gRust.PrintBlueprints() -- Вывод всех чертежей в консоль
    
    -- Принудительное обновление интерфейса крафта
    gRust.ForceUpdateCraftingMenu()
end)

-- Обработчик добавления одного чертежа
net.Receive("gRust.AddBlueprint", function()
    local class = net.ReadString()
    LocalPlayer().Blueprints[class] = true
    
    print("[BLUEPRINT ADD] Single blueprint added: ", class)
    gRust.PrintBlueprints()
    
    -- Немедленное обновление интерфейса
    gRust.ForceUpdateCraftingMenu()
end)

function gRust.RequestCraft(item, amount, skin)
    net.Start("gRust.Craft")
    net.WriteString(item)
    net.WriteUInt(amount, 7)
    net.WriteString(skin)
    net.SendToServer()
end

-- Функция проверки доступности крафта
function gRust.CanCraftItem(itemClass)
    if not LocalPlayer().Blueprints then
        print("[CAN CRAFT ERROR] Blueprints table is nil")
        return false
    end
    
    local canCraft = LocalPlayer().Blueprints[itemClass] == true
    print("[CAN CRAFT] ", itemClass, ": ", canCraft)
    return canCraft
end

-- Принудительное обновление интерфейса крафта
function gRust.ForceUpdateCraftingMenu()
    print("[FORCE UPDATE] Attempting to update crafting menu")
    
    if IsValid(gRust.CraftingMenu) then
        print("[FORCE UPDATE] Crafting menu is valid, removing...")
        
        -- Сохраняем информацию о текущем меню
        local oldX, oldY = gRust.CraftingMenu:GetPos()
        local wasVisible = gRust.CraftingMenu:IsVisible()
        
        gRust.CraftingMenu:Remove()
        print("[FORCE UPDATE] Menu removed")
        
        -- Небольшая задержка для гарантии очистки
        timer.Simple(0.2, function()
            if wasVisible and IsValid(LocalPlayer()) then
                print("[FORCE UPDATE] Reopening crafting menu")
                gRust.OpenCraftingMenu()
                if IsValid(gRust.CraftingMenu) then
                    gRust.CraftingMenu:SetPos(oldX, oldY)
                    print("[FORCE UPDATE] Crafting menu reopened")
                end
            end
        end)
    else
        print("[FORCE UPDATE] No crafting menu open")
    end
end

-- Отладочная функция для проверки чертежей
function gRust.PrintBlueprints()
    print("=== CURRENT BLUEPRINTS ===")
    if not LocalPlayer().Blueprints then
        print("Blueprints table is nil!")
        return
    end
    
    local count = 0
    for class, known in pairs(LocalPlayer().Blueprints) do
        if known then
            print(class)
            count = count + 1
        end
    end
    print("Total known blueprints: ", count)
    print("==========================")
end

-- Консольная команда для отладки
concommand.Add("print_blueprints", gRust.PrintBlueprints)

-- Команда для принудительной синхронизации
concommand.Add("sync_blueprints", function()
    print("[SYNC] Requesting blueprint sync from server")
    net.Start("gRust.RequestBlueprintSync")
    net.SendToServer()
end)