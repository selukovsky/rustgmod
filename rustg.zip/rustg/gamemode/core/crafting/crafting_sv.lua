local PLAYER = FindMetaTable("Player")
local CRAFT_CONFIG = {
    MAX_CRAFT_AMOUNT = 100,
    MAX_QUEUE_SIZE = 32,
    PROCESS_INTERVAL = 0.5,
    MAX_INDEX_BITS = 6
}

-- Сетевые сообщения
util.AddNetworkString("gRust.Craft")
util.AddNetworkString("gRust.Crafting")
util.AddNetworkString("gRust.CraftRemove")
util.AddNetworkString("gRust.CraftComplete")
util.AddNetworkString("gRust.CraftProgress")
util.AddNetworkString("gRust.CraftStarted")
util.AddNetworkString("gRust.CraftCompleted")
util.AddNetworkString("gRust.UpdateCrafts")

-------------------------------------------------------------------
-- Проверка, изучен ли чертеж
-------------------------------------------------------------------
function PLAYER:HasBlueprint(itemClass)
    if not gRust.Items[itemClass] then return false end
    local blueprintTier = gRust.Items[itemClass]:GetBlueprint()
    if not blueprintTier then return true end -- если предмет не требует чертежа
    return self.Blueprints and self.Blueprints[itemClass] == true
end

-------------------------------------------------------------------
-- Главная проверка перед началом крафта
-------------------------------------------------------------------
function PLAYER:CanCraft(itemdata, amount)
    -- Проверяем изучен ли чертеж
    if not self:HasBlueprint(itemdata:GetClass()) then
        if self.SendNotification then
            self:SendNotification("Вы не изучили этот чертеж!", NOTIFICATION_ERROR, "materials/icons/close.png", "")
        end
        print("[DEBUG] Чертеж не изучен:", itemdata:GetClass())
        return false
    end

    -- Проверяем количество
    if amount <= 0 or amount > CRAFT_CONFIG.MAX_CRAFT_AMOUNT then
        return false
    end

    return true
end

-------------------------------------------------------------------
-- Проверка на верстак
-------------------------------------------------------------------
function PLAYER:IsLookingAtValidWorkbench(itemClass)
    local itemdata = gRust.Items[itemClass]
    if not itemdata then return false end
    local requiredTier = itemdata:GetTier() or 0
    if requiredTier == 0 then return true end
    local playerPos = self:GetPos()
    local playerAngle = self:GetAngles()
    local forwardVec = playerAngle:Forward()
    local nearbyEnts = ents.FindInSphere(playerPos, 200)
    for _, ent in ipairs(nearbyEnts) do
        if IsValid(ent) and ent:GetClass() == "rust_tier" .. requiredTier then
            local entPos = ent:GetPos()
            local dirToEnt = (entPos - playerPos):GetNormalized()
            local dot = forwardVec:Dot(dirToEnt)
            if dot > 0.3 then return true end
        end
    end
    return false
end

-------------------------------------------------------------------
-- Получение активных крафтов
-------------------------------------------------------------------
function PLAYER:GetActiveCrafts()
    self:InitCraftQueue()
    return self.CraftQueue or {}
end

-------------------------------------------------------------------
-- Обработка начала крафта
-------------------------------------------------------------------
net.Receive("gRust.Craft", function(len, ply)
    if not IsValid(ply) then return end
    local item = net.ReadString()
    local amount = net.ReadUInt(7)
    local skin = net.ReadString()

    if not item or item == "" then return end
    local itemdata = gRust.Items[item]
    if not itemdata then return end

    -- Проверка на изученный чертеж
    if not ply:CanCraft(itemdata, amount) then return end

    -- Проверка на верстак
    if not ply:IsLookingAtValidWorkbench(item) then
        if ply.SendNotification then
            ply:SendNotification("Вы не находитесь рядом с нужным верстаком!", NOTIFICATION_ERROR, "materials/icons/close.png", "")
        end
        return
    end

    -- Проверка на очередь
    if table.Count(ply:GetActiveCrafts()) >= CRAFT_CONFIG.MAX_QUEUE_SIZE then
        if ply.SendNotification then
            ply:SendNotification("Очередь крафта заполнена!", NOTIFICATION_ERROR, "materials/icons/close.png", "")
        end
        return
    end

    ply:AddToCraftQueue(item, amount, skin)
end)

-------------------------------------------------------------------
-- Удаление крафта из очереди
-------------------------------------------------------------------
net.Receive("gRust.CraftRemove", function(len, ply)
    if not IsValid(ply) then return end
    local index = net.ReadUInt(CRAFT_CONFIG.MAX_INDEX_BITS)
    ply:CancelCraft(index)
end)

-------------------------------------------------------------------
-- Инициализация очереди крафта
-------------------------------------------------------------------
function PLAYER:InitCraftQueue()
    if not self.CraftQueue then
        self.CraftQueue = {}
        self.CraftQueueIndex = 0
        self.LastCraftProcess = 0
    end
end

-------------------------------------------------------------------
-- Получение индекса для крафта
-------------------------------------------------------------------
function PLAYER:GetNextCraftIndex()
    self.CraftQueueIndex = (self.CraftQueueIndex or 0) + 1
    if self.CraftQueueIndex > (2 ^ CRAFT_CONFIG.MAX_INDEX_BITS - 1) then self.CraftQueueIndex = 1 end
    while self.CraftQueue[self.CraftQueueIndex] do
        self.CraftQueueIndex = self.CraftQueueIndex + 1
        if self.CraftQueueIndex > (2 ^ CRAFT_CONFIG.MAX_INDEX_BITS - 1) then self.CraftQueueIndex = 1 end
    end
    return self.CraftQueueIndex
end

-------------------------------------------------------------------
-- Добавление предмета в очередь крафта
-------------------------------------------------------------------
function PLAYER:AddToCraftQueue(item, amount, skin)
    self:InitCraftQueue()
    local itemdata = gRust.Items[item]
    if not itemdata then return false end
    local craftRecipe = itemdata:GetCraft()
    if not craftRecipe or #craftRecipe == 0 then return false end

    -- Проверяем ресурсы
    for _, recipe in ipairs(craftRecipe) do
        if not self:HasItem(recipe.item, recipe.amount * amount) then
            if self.SendNotification then
                self:SendNotification("Недостаточно ресурсов!", NOTIFICATION_REMOVE, "resources", "")
            end
            return false
        end
    end

    -- Удаляем ресурсы
    for _, recipe in ipairs(craftRecipe) do
        self:RemoveItem(recipe.item, recipe.amount * amount)
    end

    local index = self:GetNextCraftIndex()
    local currentTime = CurTime()
    local craftTime = itemdata:GetCraftTime() or 5
    self.CraftQueue[index] = {
        item = item,
        amount = amount,
        skin = skin or "",
        startTime = currentTime,
        craftTime = craftTime,
        endTime = currentTime + craftTime,
        completed = false,
        index = index,
        progress = 0
    }

    -- Отправляем клиенту информацию о начале крафта
    net.Start("gRust.Crafting")
    net.WriteString(item)
    net.WriteUInt(index, CRAFT_CONFIG.MAX_INDEX_BITS)
    net.WriteFloat(craftTime)
    net.Send(self)

    -- Отправляем уведомление для HUD
    net.Start("gRust.CraftStarted")
    net.WriteString(item)
    net.WriteFloat(craftTime)
    net.Send(self)

    return true
end

-------------------------------------------------------------------
-- Обработка крафта
-------------------------------------------------------------------
function PLAYER:ProcessCraftQueue()
    if not self.CraftQueue or table.IsEmpty(self.CraftQueue) then return end
    local currentTime = CurTime()
    local completedIndex = nil
    for index, craft in pairs(self.CraftQueue) do
        if not craft.completed then
            local progress = math.min((currentTime - craft.startTime) / craft.craftTime, 1)
            craft.progress = progress
            if currentTime >= craft.endTime then
                completedIndex = index
                break
            end
        end
    end

    if completedIndex then
        local craft = self.CraftQueue[completedIndex]
        local itemdata = gRust.Items[craft.item]
        if itemdata then
            local craftAmount = itemdata:GetCraftAmount() or 1
            for i = 1, craft.amount * craftAmount do
                self:GiveItem(craft.item, 1, craft.skin ~= "" and craft.skin or nil)
            end
        end

        net.Start("gRust.CraftComplete")
        net.WriteUInt(completedIndex, CRAFT_CONFIG.MAX_INDEX_BITS)
        net.WriteString(craft.item)
        net.WriteUInt(craft.amount, 7)
        net.Send(self)

        -- Отправляем уведомление о завершении крафта
        net.Start("gRust.CraftCompleted")
        net.WriteString(craft.item)
        net.Send(self)

        self.CraftQueue[completedIndex] = nil
    end
end

-------------------------------------------------------------------
-- Отмена крафта
-------------------------------------------------------------------
function PLAYER:CancelCraft(index)
    if not self.CraftQueue or not self.CraftQueue[index] then return false end
    
    local craft = self.CraftQueue[index]
    local itemdata = gRust.Items[craft.item]
    
    if itemdata then
        -- Возвращаем ресурсы
        local craftRecipe = itemdata:GetCraft()
        for _, recipe in ipairs(craftRecipe) do
            self:GiveItem(recipe.item, recipe.amount * craft.amount)
        end
    end
    
    -- Отправляем уведомление о отмене крафта клиенту
    net.Start("gRust.CraftCompleted")
    net.WriteString(craft.item)
    net.Send(self)
    
    self.CraftQueue[index] = nil
    return true
end

-------------------------------------------------------------------
-- Хуки и таймеры
-------------------------------------------------------------------
hook.Add("PlayerInitialSpawn", "gRust.InitCraftQueue", function(ply)
    timer.Simple(1, function()
        if IsValid(ply) then ply:InitCraftQueue() end
    end)
end)

hook.Add("PlayerInitialSpawn", "gRust.SendActiveCrafts", function(ply)
    timer.Simple(3, function()
        if IsValid(ply) and ply.CraftQueue then
            local activeCount = 0
            for _, craft in pairs(ply.CraftQueue) do
                if not craft.completed then
                    activeCount = activeCount + 1
                end
            end
            
            net.Start("gRust.UpdateCrafts")
            net.WriteUInt(activeCount, 8)
            for _, craft in pairs(ply.CraftQueue) do
                if not craft.completed then
                    local timeLeft = math.max(0, craft.endTime - CurTime())
                    net.WriteString(craft.item)
                    net.WriteFloat(timeLeft)
                end
            end
            net.Send(ply)
        end
    end)
end)

hook.Add("PlayerDisconnected", "gRust.ClearCraftQueue", function(ply)
    if ply.CraftQueue then ply.CraftQueue = nil end
end)

timer.Create("gRust.ProcessCrafts", CRAFT_CONFIG.PROCESS_INTERVAL, 0, function()
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and ply:IsConnected() then
            ply:ProcessCraftQueue()
        end
    end
end)