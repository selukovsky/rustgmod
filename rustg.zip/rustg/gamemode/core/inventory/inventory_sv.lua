util.AddNetworkString("gRust.Inventory.Move")
util.AddNetworkString("gRust.Inventory.Request")
util.AddNetworkString("gRust.Inventory.SyncSlot")
util.AddNetworkString("gRust.Inventory.Remove")
util.AddNetworkString("gRust.Inventory.SyncAll")
util.AddNetworkString("gRust.Inventory.Create")
util.AddNetworkString("gRust.Inventory.Clos")
util.AddNetworkString("gRust.Inventory.Close")
util.AddNetworkString("gRust_UpdateBodygroups")
util.AddNetworkString("gRust_RequestBodygroups")
util.AddNetworkString("gRust.EatFood")
util.AddNetworkString("gRust.Inventory.EatItem")
util.AddNetworkString("gRust.RequestAddItem")
util.AddNetworkString("gRust.QuickSwap")
util.AddNetworkString("gRust.Inventory.UpgradeScrap")
util.AddNetworkString("gRust.SplitItem")
util.AddNetworkString("gRust.PickupNotification")
util.AddNetworkString("gRust.SleepingPlayer.SyncAttire")
util.AddNetworkString("gRust.SleepingPlayer.SyncBelt")
util.AddNetworkString("Rust_AttachToWeapon")
util.AddNetworkString("gRust.SleepingPlayer.RequestFullSync")
util.AddNetworkString("gRust.Drop")
local ENTITY = FindMetaTable("Entity")
local PLAYER = FindMetaTable("Player")
local DEFAULT_HANDS_MODEL = "models/player/darky_m/rust/c_arms_human.mdl" -- Модель рук по умолчанию
function ENTITY:SetSlotsLocked(locked, startSlot, endSlot)
    self.SlotsLocked = locked or false
    self.LockedStartSlot = startSlot or 7
    self.LockedEndSlot = endSlot or 12
end

function ENTITY:GetSlotsLocked()
    return self.SlotsLocked or false
end

function ENTITY:IsSlotLocked(slot)
    if not self:GetSlotsLocked() then return false end
    local startSlot = self.LockedStartSlot or 7
    local endSlot = self.LockedEndSlot or 12
    return slot >= startSlot and slot <= endSlot
end

function ENTITY:CanPlaceInSlot(slot, item)
    return not self:IsSlotLocked(slot)
end

function PLAYER:MoveSlot(fromEnt, toEnt, fromSlot, toSlot, amount, isQuickLoot)
    net.Start("gRust.Inventory.Move")
    net.WriteEntity(fromEnt)
    net.WriteEntity(toEnt)
    net.WriteUInt(fromSlot, 6)
    net.WriteUInt(toSlot, 6)
    net.WriteUInt(amount or 0, 20)
    net.WriteBool(isQuickLoot or false) -- Передаем тип перемещения
    net.SendToServer()
end

function ENTITY:SetSlot(item, slot)
    if not self.Inventory or not slot then return false end
    if slot > self.InventorySlots or slot < 1 then return false end
    self.Inventory[slot] = item
    self:SyncSlot(slot)
    if slot >= 31 and slot <= 36 and item and self:IsPlayer() and self:IsClothingItem(item) then self:ApplyClothing(item, slot) end
    return true
end

local FoodEffectTable = {
    ["can.tuna"] = { hunger = 50, thirst = 15, health = 2 },
    ["horse.cook"] = { hunger = 45, thirst = 5, health = 1 },
    ["can.beans"] = { hunger = 100, thirst = 25, health = 2 },
    ["breed"] = { hunger = 150, thirst = 10, health = 5 },
    ["apple"] = { hunger = 30, thirst = 15, health = 3 },
    ["granolabar"] = { hunger = 60, thirst = 0, health = 1 },
    ["blueberries"] = { hunger = 30, thirst = 20, health = 10 },
    ["water.item"] = { hunger = 0, thirst = 30, health = 1 },
    ["large.medkit"] = { hunger = 0, thirst = 0, health = 15 },
    -- Добавьте ваши предметы с эффектамиwater.item
}

local EatCooldownTimes = {}

local function HandleEatItem(len, pl)
    local ent = net.ReadEntity()
    local slot = net.ReadUInt(6)

    if not IsValid(pl) or not pl:Alive() then return end
    if not IsValid(ent) then return end
    if ent ~= pl then return end
    if not ent.Inventory then return end
    if slot < 1 or slot > ent.InventorySlots then return end

    local now = CurTime()
    if EatCooldownTimes[pl] and now - EatCooldownTimes[pl] < 1 then
        pl:ChatPrint("Подождите 2 секунды перед следующим приемом пищи.")
        return
    end

    local item = ent.Inventory[slot]
    if not item then return end

    local itemClass = item:GetItem()
    if not itemClass then return end

    local effect = FoodEffectTable[itemClass]
    if not effect then
        pl:ChatPrint("Этот предмет нельзя съесть.")
        return
    end

    local quantity = item:GetQuantity()
    if quantity > 1 then
        item:RemoveQuantity(1)
        ent:SyncSlot(slot)
    else
        ent:RemoveSlot(slot)
    end

    if effect.hunger and effect.hunger > 0 then
        pl:AddHunger(effect.hunger)
    end

    if effect.thirst and effect.thirst > 0 then
        pl:AddThirst(effect.thirst)
    end

    if effect.health and effect.health > 0 then
        local newHealth = math.min(pl:Health() + effect.health, pl:GetMaxHealth())
        pl:SetHealth(newHealth)
    end

    pl:ChatPrint("Вы съели " .. gRust.Items[itemClass]:GetName() .. ".")
    pl:EmitSound("rust/eat-2.wav")

    EatCooldownTimes[pl] = now
end

function PLAYER:GetAttireType(item)
    if not item then return nil end
    local itemClass = item:GetItem()
    local itemData = gRust.Items[itemClass]
    if not itemData then return nil end
    local attireId = itemData:GetAttire()
    if not attireId then return nil end
    local attireData = gRust.Attire[attireId]
    if not attireData then return nil end
    return attireData.type
end

function PLAYER:HasConflictingClothing(item, targetSlot)
    if not item then return false end
    local newItemType = self:GetAttireType(item)
    if newItemType == nil then return false end
    for slot = 31, 36 do
        if slot ~= targetSlot and self.Inventory[slot] then
            local existingType = self:GetAttireType(self.Inventory[slot])
            if existingType == newItemType then return true end
        end
    end
    return false
end

function PLAYER:CanPlaceInSlot(slot, item)
    if self:IsSlotLocked(slot) then return false end
    if slot >= 31 and slot <= 36 then
        if not self:IsClothingItem(item) then return false end
        if self:HasConflictingClothing(item, slot) then return false end
    end
    return true
end

function FindSlotForStacking(ent, itemClass, excludeSlot)
    if not ent or not ent.Inventory then return nil end
    
    for slot = 1, ent.InventorySlots do
        if slot ~= excludeSlot and ent.Inventory[slot] then
            local item = ent.Inventory[slot]
            if item:GetItem() == itemClass then
                local maxStack = gRust.Items[itemClass] and gRust.Items[itemClass]:GetStack() or 1
                if item:GetQuantity() < maxStack then
                    return slot
                end
            end
        end
    end
    
    return nil
end

function FindEmptySlot(ent)
    if not ent or not ent.Inventory then return nil end
    
    for slot = 1, ent.InventorySlots do
        if not ent.Inventory[slot] then
            return slot
        end
    end
    
    return nil
end

function MoveItemWithStacking(fromEnt, toEnt, fromSlot, toSlot, amount)
    local fromItem = fromEnt.Inventory[fromSlot]
    local toItem = toEnt.Inventory[toSlot]
    
    if not fromItem or not toItem then return false end
    
    local maxStack = gRust.Items[fromItem:GetItem()]:GetStack()
    local availableSpace = maxStack - toItem:GetQuantity()
    local transferAmount = math.min(amount, availableSpace)
    
    toItem:AddQuantity(transferAmount)
    fromItem:RemoveQuantity(transferAmount)
    
    if fromItem:GetQuantity() <= 0 then
        fromEnt:RemoveSlot(fromSlot)
    else
        fromEnt:SyncSlot(fromSlot)
    end
    
    toEnt:SyncSlot(toSlot)
    return true
end

function MoveItemToSlot(fromEnt, toEnt, fromSlot, toSlot, amount)
    local fromItem = fromEnt.Inventory[fromSlot]
    
    if not fromItem then return false end
    
    amount = math.min(amount, fromItem:GetQuantity())
    
    -- Сохраняем дополнительные данные (wear и clip)
    local wear = fromItem.GetWear and fromItem:GetWear() or nil
    local clip = fromItem.GetClip and fromItem:GetClip() or nil
    
    if amount >= fromItem:GetQuantity() then
        -- Перемещаем весь предмет
        toEnt.Inventory[toSlot] = fromItem
        fromEnt:RemoveSlot(fromSlot)
        toEnt:SyncSlot(toSlot)
    else
        -- Разделяем стак
        local newItem = fromItem:Split(amount)
        if newItem then
            -- Сохраняем дополнительные данные для разделенного предмета
            if wear and newItem.SetWear then newItem:SetWear(wear) end
            if clip and newItem.SetClip then newItem:SetClip(clip) end
            
            toEnt.Inventory[toSlot] = newItem
            fromEnt:SyncSlot(fromSlot)
            toEnt:SyncSlot(toSlot)
        end
    end
    
    return true
end


function PLAYER:SetupHands()
    local hands = self:GetHands()
    if not IsValid(hands) then
        hands = ents.Create("gmod_hands")
        if IsValid(hands) then
            self:SetHands(hands)
            hands:SetOwner(self)
            hands:Spawn()
        end
    end
    
    -- Принудительно устанавливаем модель рук
    local handsModel = self.CurrentHandsModel or DEFAULT_HANDS_MODEL
    if IsValid(hands) then
        hands:SetModel(handsModel)
    end
    
    return hands
end

function PLAYER:ApplyClothing(item, slot)
    if not self.OriginalModel then self.OriginalModel = self:GetModel() end
    local itemClass = item:GetItem()
    local itemData = gRust.Items[itemClass]
    if not itemData then return end
    local attireId = itemData:GetAttire()
    if not attireId then return end
    local attireData = gRust.Attire[attireId]
    if not attireData then return end
    
    if attireData.model then 
        self:SetModel(attireData.model) 
    end
    
    -- Устанавливаем модель рук из одежды или используем дефолтную
    if attireData.hands then
        self.CurrentHandsModel = attireData.hands
    else
        self.CurrentHandsModel = DEFAULT_HANDS_MODEL
    end
    
    -- Принудительно обновляем руки
    self:SetupHands()
    
    if attireData.head then self.ArmorHead = attireData.head end
    if attireData.body then self.ArmorBody = attireData.body end
    if attireData.arms then self.ArmorArms = attireData.arms end
    if attireData.legs then self.ArmorLegs = attireData.legs end
    
    self.EquippedAttire = self.EquippedAttire or {}
    self.EquippedAttire[slot] = attireId
end

-- Добавьте эту функцию для принудительной установки рук
function PLAYER:ForceHandsModel(modelPath)
    self.CurrentHandsModel = modelPath or DEFAULT_HANDS_MODEL
    self:SetupHands()
end

-- Измените функцию RemoveClothing
function PLAYER:RemoveClothing(slot)
    if not self.EquippedAttire or not self.EquippedAttire[slot] then return end
    self.EquippedAttire[slot] = nil
    
    local hasOtherAttire = false
    local newModel = self.OriginalModel
    
    for slotNum, equippedAttire in pairs(self.EquippedAttire) do
        if equippedAttire and gRust.Attire[equippedAttire] then
            local attireData = gRust.Attire[equippedAttire]
            if attireData.model then
                newModel = attireData.model
                hasOtherAttire = true
                break
            end
        end
    end

    self:SetModel(newModel)
    
    -- Если нет другой одежды, возвращаем дефолтные руки
    if not hasOtherAttire then
        self.CurrentHandsModel = DEFAULT_HANDS_MODEL
        self:SetupHands()
        
        self.ArmorHead = nil
        self.ArmorBody = nil
        self.ArmorArms = nil
        self.ArmorLegs = nil
    else
        -- Иначе находим первую доступную модель рук из оставшейся одежды
        for slotNum, equippedAttire in pairs(self.EquippedAttire) do
            if equippedAttire and gRust.Attire[equippedAttire] then
                local attireData = gRust.Attire[equippedAttire]
                if attireData.hands then
                    self.CurrentHandsModel = attireData.hands
                    self:SetupHands()
                    break
                end
            end
        end
    end
end

function PLAYER:DropItem(slot, amount)
    if not self.Inventory or not slot then return false end
    if slot > self.InventorySlots or slot < 1 then return false end
    local item = self.Inventory[slot]
    if not item then return false end
    amount = amount or item:GetQuantity()
    amount = math.min(amount, item:GetQuantity())
    if amount <= 0 then return false end
    local dropItem
    if amount >= item:GetQuantity() then
        dropItem = item
        self:RemoveSlot(slot)
        if slot >= 31 and slot <= 36 then self:RemoveClothing(slot) end
    else
        dropItem = item:Split(amount)
        if dropItem then
            self:SyncSlot(slot)
        else
            return false
        end
    end

    -- Сохраняем тип боеприпасов если выкидываем оружие
    local itemData = gRust.Items[dropItem:GetItem()]
    if itemData and itemData:GetWeapon() then
        local weaponClass = itemData:GetWeapon()
        local weaponTable = weapons.Get(weaponClass)
        if weaponTable then
            -- Получаем текущий тип боеприпасов из оружия в руках
            local activeWeapon = self:GetActiveWeapon()
            if IsValid(activeWeapon) and activeWeapon:GetClass() == weaponClass then
                local currentAmmoType = activeWeapon:GetCurrentAmmoType()
                if currentAmmoType and currentAmmoType ~= "" and currentAmmoType ~= weaponTable.Ammo then
                    dropItem.AmmoType = currentAmmoType
                    print(string.format("[DROP WEAPON] Saved ammo type: %s", currentAmmoType))
                end
            -- Или из сохраненного типа в предмете
            elseif item.AmmoType then
                dropItem.AmmoType = item.AmmoType
                print(string.format("[DROP WEAPON] Saved ammo type from item: %s", item.AmmoType))
            end
        end
    end

    local itemEnt = ents.Create("rust_droppeditem")
    if not IsValid(itemEnt) then
        if amount >= item:GetQuantity() then
            self:SetSlot(dropItem, slot)
        else
            item:AddQuantity(amount)
            self:SyncSlot(slot)
        end
        return false
    end

    itemEnt:SetItem(dropItem)
    itemEnt:SetPos(self:GetPos() + self:GetForward() * 50 + Vector(0, 0, 30))
    itemEnt:SetAngles(Angle(0, math.random(0, 360), 0))
    itemEnt:Spawn()
    local phys = itemEnt:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        local force = self:GetAimVector() * 300 + Vector(0, 0, 100)
        force = force + VectorRand() * 50
        phys:ApplyForceCenter(force)
        phys:AddAngleVelocity(VectorRand() * 100)
    end

    if itemData and itemData:GetSound() then 
        self:EmitSound(gRust.RandomGroupedSound(string.format("drop.%s", itemData:GetSound()))) 
    end
    
    hook.Call("gRust.ItemDropped", nil, self, dropItem, itemEnt, slot)
    return true
end

net.Receive("gRust.Inventory.SyncSlot", function()
    local ent = net.ReadEntity()
    local slot = net.ReadUInt(6)
    local item = net.ReadItem()
    -- Update your local representation
    ent.Inventory[slot] = item
    -- Refresh the UI if it's open
    if gRust.Inventory.Container then gRust.Inventory.UpdateContainer() end
end)

function PLAYER:IsClothingItem(item)
    if not item then return false end
    local itemClass = item:GetItem()
    local itemData = gRust.Items[itemClass]
    if not itemData then return false end
    return itemData:GetCategory() == "Clothing"
end

-- ИСПРАВЛЕННАЯ ФУНКЦИЯ СИНХРОНИЗАЦИИ
function ENTITY:SyncSlot(slot)
    if not self.Inventory or not slot then return end
    local item = self.Inventory[slot]
    -- Для игроков
    if self:IsPlayer() then
        if item then
            net.Start("gRust.Inventory.SyncSlot")
            net.WriteEntity(self)
            net.WriteUInt(slot, 6)
            net.WriteItem(item)
            net.Send(self)
        else
            net.Start("gRust.Inventory.Remove")
            net.WriteEntity(self)
            net.WriteUInt(slot, 6)
            net.Send(self)
        end
        return
    end

    -- Для контейнеров - находим всех ближайших игроков
    local recipients = {}
    for _, pl in pairs(player.GetAll()) do
        if IsValid(pl) and pl:GetPos():Distance(self:GetPos()) <= 200 then table.insert(recipients, pl) end
    end

    if #recipients > 0 then
        if item then
            net.Start("gRust.Inventory.SyncSlot")
            net.WriteEntity(self)
            net.WriteUInt(slot, 6)
            net.WriteItem(item)
            net.Send(recipients)
        else
            net.Start("gRust.Inventory.Remove")
            net.WriteEntity(self)
            net.WriteUInt(slot, 6)
            net.Send(recipients)
        end
    end
end

function ENTITY:RemoveSlot(slot)
    if not self.Inventory or not slot then return end
    self.Inventory[slot] = nil
    self:SyncSlot(slot)
end

function PLAYER:RemoveSlot(slot)
    if not self.Inventory or not slot then return end
    if slot >= 31 and slot <= 36 then self:RemoveClothing(slot) end
    self.Inventory[slot] = nil
    self:SyncSlot(slot)
end

function PLAYER:CreateInventory(slots)
    slots = slots or 30
    self.Inventory = {}
    self.InventorySlots = slots
    self.EquippedAttire = {}
    net.Start("gRust.Inventory.Create")
    net.WriteUInt(slots, 6)
    net.Send(self)
end

function PLAYER:SyncInventory()
    if not self.Inventory then return end
    for i = 31, 36 do
        local item = self.Inventory[i]
        if item and self:IsClothingItem(item) then self:ApplyClothing(item, i) end
    end

    net.Start("gRust.Inventory.SyncAll")
    local validItems = {}
    for i = 1, self.InventorySlots do
        if self.Inventory[i] then
            table.insert(validItems, {
                slot = i,
                item = self.Inventory[i]
            })
        end
    end

    net.WriteUInt(#validItems, 6)
    for _, data in pairs(validItems) do
        net.WriteUInt(data.slot, 6)
        net.WriteItem(data.item)
    end

    net.WriteUInt(self.InventorySlots, 6)
    net.Send(self)
end

function PLAYER:FindEmptySlot(startSlot, endSlot, item)
    startSlot = startSlot or 1
    endSlot = endSlot or self.InventorySlots
    if item and item:IsStackable() then
        for i = startSlot, endSlot do
            local existingItem = self.Inventory[i]
            if existingItem and existingItem:CanStack(item) then return i end
        end
    end

    for i = startSlot, endSlot do
        if not self.Inventory[i] then return i end
    end
end

function PLAYER:RequestInventory(entity)
    if not IsValid(entity) or not entity.Inventory then return end
    if entity:GetPos():Distance(self:GetPos()) > 200 then return end
    net.Start("gRust.Inventory.Request")
    net.WriteEntity(entity)
    local validItems = {}
    for i = 1, entity.InventorySlots do
        if entity.Inventory[i] then
            table.insert(validItems, {
                slot = i,
                item = entity.Inventory[i]
            })
        end
    end

    net.WriteUInt(#validItems, 6)
    for _, data in pairs(validItems) do
        net.WriteUInt(data.slot, 6)
        net.WriteItem(data.item)
    end

    net.WriteUInt(entity.InventorySlots, 6)
    net.Send(self)
end

function PLAYER:GiveItem(itemOrClass, amount, slot, wear, clip)
    print("[DEBUG] GiveItem called for", itemOrClass, "amount:", amount, "player:", self:Nick())
    if not self.Inventory or not itemOrClass then return false end
    
    -- Проверка: отправлять ли уведомление (можно отключить через флаг _skipPickupNotification)
    local shouldSendNotification = not self._skipPickupNotification
    local notificationItemClass = nil
    local notificationQuantity = 0
    local originalAmount = amount or 1

    -- Если в функцию передан готовый объект предмета
    if type(itemOrClass) == "table" and itemOrClass.GetItem then
        local item = itemOrClass
        local originalWear = item.GetWear and item:GetWear() or wear
        local originalClip = item.GetClip and item:GetClip() or clip
        local itemQuantity = item:GetQuantity()
        
        notificationItemClass = item:GetItem()
        notificationQuantity = itemQuantity
        
        local targetSlot = slot
        if targetSlot then
            -- Проверка корректности слота
            if targetSlot < 1 or targetSlot > self.InventorySlots then return false end
            local existingItem = self.Inventory[targetSlot]
            
            -- Если в слоте уже есть предмет
            if existingItem then
                if existingItem:CanStack(item) then
                    local success = existingItem:Merge(item)
                    if success then
                        self:SyncSlot(targetSlot)
                        return true
                    end
                end
                return false
            else
                -- Если слот пустой — копируем предмет в него
                local newItem = item:Copy()
                if originalWear and newItem.SetWear then newItem:SetWear(originalWear) end
                if originalClip and newItem.SetClip then newItem:SetClip(originalClip) end
                
                self:SetSlot(newItem, targetSlot)
                return true
            end
        else
            -- Автоматический поиск слота для стака
            for i = 1, self.InventorySlots do
                local existingItem = self.Inventory[i]
                if existingItem and existingItem:CanStack(item) then
                    local success = existingItem:Merge(item)
                    if success then
                        self:SyncSlot(i)
                        return true
                    end
                end
            end

            -- Ищем пустой слот
            targetSlot = self:FindEmptySlot(1, self.InventorySlots, item)
            if targetSlot then
                local newItem = item:Copy()
                if originalWear and newItem.SetWear then newItem:SetWear(originalWear) end
                if originalClip and newItem.SetClip then newItem:SetClip(originalClip) end

                self:SetSlot(newItem, targetSlot)
                return true
            end
        end
        return false
    end

    -- Если передано имя предмета (строка)
    local itemClass = itemOrClass
    if not gRust.Items[itemClass] then return false end
    amount = amount or 1
    local remaining = amount
    local ItemData = gRust.Items[itemClass]
    local maxStack = ItemData:GetStack()

    notificationItemClass = itemClass
    notificationQuantity = amount

    -- Если указан конкретный слот
    if slot then
        if slot < 1 or slot > self.InventorySlots then return false end
        local existingItem = self.Inventory[slot]

        if existingItem then
            if existingItem:GetItem() == itemClass and existingItem:CanAddQuantity(remaining) then
                existingItem:AddQuantity(remaining)
                if wear and existingItem.SetWear then existingItem:SetWear(wear) end
                if clip and existingItem.SetClip then existingItem:SetClip(clip) end
                self:SyncSlot(slot)
                return true
            end
            return false
        else
            local newItem = gRust.CreateItem(itemClass, remaining, wear)
            if clip and newItem.SetClip then newItem:SetClip(clip) end
            self:SetSlot(newItem, slot)
            return true
        end
    end

    -- Автоматическая вставка предметов в стаки
    local success = false
    while remaining > 0 do
        local targetSlot = nil

        -- Ищем стак для увеличения количества
        for i = 1, self.InventorySlots do
            local existingItem = self.Inventory[i]
            if existingItem and existingItem:GetItem() == itemClass and existingItem:CanAddQuantity(1) then
                targetSlot = i
                break
            end
        end

        if not targetSlot then
            targetSlot = self:FindEmptySlot(1, self.InventorySlots, gRust.CreateItem(itemClass, 1))
        end
        if not targetSlot then break end

        local existingItem = self.Inventory[targetSlot]
        if existingItem then
            local maxAddable = existingItem:GetMaxAddable()
            local toAdd = math.min(remaining, maxAddable)
            existingItem:AddQuantity(toAdd)
            remaining = remaining - toAdd
            self:SyncSlot(targetSlot)
            success = true
        else
            local toAdd = math.min(remaining, maxStack)
            local newItem = gRust.CreateItem(itemClass, toAdd, wear)
            if clip and newItem.SetClip then newItem:SetClip(clip) end
            self:SetSlot(newItem, targetSlot)
            remaining = remaining - toAdd
            success = true
        end
    end

    -- Отправляем ОДНО уведомление после полного добавления (если успешно и нужно)
    if success and shouldSendNotification and notificationItemClass then
        local totalAmount = self:GetItemCount(notificationItemClass)
        local givenAmount = originalAmount - remaining
        
        timer.Simple(0.1, function()
            if IsValid(self) then
                net.Start("gRust.PickupNotification")
                net.WriteString(notificationItemClass)
                net.WriteUInt(givenAmount, 16)
                net.WriteUInt(totalAmount, 16)
                net.Send(self)
                print("[DEBUG] Final PickupNotification for", notificationItemClass, "amount:", givenAmount, "total:", totalAmount)
            end
        end)
    end

    return remaining == 0
end

function PLAYER:RemoveItem(itemClass, amount)
    if not self.Inventory or not itemClass then 
        print("RemoveItem: Invalid parameters")
        return false 
    end
    
    amount = amount or 1
    local availableAmount = self:GetItemCount(itemClass)
    
    print(string.format("RemoveItem: Trying to remove %d of %s (available: %d)", amount, itemClass, availableAmount))
    
    if availableAmount < amount then
        print(string.format("RemoveItem failed: not enough %s (need %d, have %d)", itemClass, amount, availableAmount))
        return false 
    end
    
    local remaining = amount
    for i = 1, self.InventorySlots do
        if remaining <= 0 then break end
        local invItem = self.Inventory[i]
        
        if invItem and invItem:GetItem() == itemClass then
            local currentQty = invItem:GetQuantity()
            local takeAmount = math.min(remaining, currentQty)
            
            print(string.format("RemoveItem: Removing %d from slot %d (had %d)", takeAmount, i, currentQty))
            
            invItem:RemoveQuantity(takeAmount)
            remaining = remaining - takeAmount
            
            if invItem:GetQuantity() <= 0 then
                print(string.format("RemoveItem: Slot %d is now empty", i))
                self:RemoveSlot(i)
            else
                print(string.format("RemoveItem: Slot %d now has %d", i, invItem:GetQuantity()))
                self:SyncSlot(i)
            end
            
            print(string.format("RemoveItem: Remaining to remove: %d", remaining))
        end
    end
    
    local success = (remaining == 0)
    if success then
        print(string.format("RemoveItem: Successfully removed %d of %s", amount, itemClass))
    else
        print(string.format("RemoveItem failed: could not remove all items. Remaining: %d", remaining))
    end
    
    return success
end

function PLAYER:HasItem(itemClass, amount)
    if not self.Inventory or not itemClass then 
        print("HasItem failed: no inventory or itemClass")
        return false 
    end
    amount = amount or 1
    local totalAmount = 0
    for i = 1, self.InventorySlots do
        local invItem = self.Inventory[i]
        if invItem and invItem:GetItem() == itemClass then 
            totalAmount = totalAmount + invItem:GetQuantity() 
        end
    end
    
    local result = totalAmount >= amount
    if not result then
        print(string.format("HasItem: need %d %s, but have %d", amount, itemClass, totalAmount))
    end
    
    return result
end

function PLAYER:ItemCount(itemType)
    local count = 0
    if not self.Inventory then return 0 end
    for i = 1, self.InventorySlots do
        local item = self.Inventory[i]
        if item and item:GetItem() == itemType then
            count = count + item:GetQuantity()
        end
    end
    return count
end

function PLAYER:GetItemCount(itemClass)
    if not self.Inventory then 
        print("GetItemCount: No inventory!")
        return 0 
    end
    if not itemClass then 
        print("GetItemCount: No itemClass provided!")
        return 0 
    end
    
    local total = 0
    print(string.format("GetItemCount: Searching for %s", tostring(itemClass)))
    
    for i = 1, self.InventorySlots do
        local invItem = self.Inventory[i]
        if invItem then
            local itemName = invItem:GetItem()
            local quantity = invItem:GetQuantity()
            
            print(string.format("Slot %d: %s x%d (looking for: %s)", i, tostring(itemName), quantity, tostring(itemClass)))
            
            if itemName == itemClass then 
                total = total + quantity
                print(string.format("MATCH: Adding %d from slot %d", quantity, i))
            end
        end
    end
    
    print(string.format("GetItemCount: Total %s = %d", itemClass, total))
    return total
end

-- ФУНКЦИЯ ДЛЯ КОПИРОВАНИЯ АТТАЧМЕНТОВ ПРИ ПЕРЕМЕЩЕНИИ
function CopyAttachments(fromItem, toItem)
    if not fromItem or not toItem then return end
    
    -- Копируем таблицу аттачментов
    if fromItem.Attachments then
        toItem.Attachments = table.Copy(fromItem.Attachments)
    else
        toItem.Attachments = nil
    end
end

function HandleMoveSlot(_, pl)
    local fromEnt = net.ReadEntity()
    local toEnt = net.ReadEntity()
    local oldSlot = net.ReadUInt(6)
    local newSlot = net.ReadUInt(6)
    local amount = net.ReadUInt(20)
    
    if not (IsValid(pl) and pl:Alive()) then return end
    if not (IsValid(fromEnt) and IsValid(toEnt)) then return end
    if not (fromEnt.Inventory and toEnt.Inventory) then return end
    if oldSlot < 1 or newSlot < 1 or oldSlot > fromEnt.InventorySlots or newSlot > toEnt.InventorySlots then return end
    if amount == 0 then return end
    
    local fromItem = fromEnt.Inventory[oldSlot]
    if not fromItem then return end
    if not toEnt:CanPlaceInSlot(newSlot, fromItem) then return end
    
    amount = math.min(amount, fromItem:GetQuantity())
    local toItem = toEnt.Inventory[newSlot]
    local itemClass = fromItem:GetItem()
    local maxStack = gRust.Items[itemClass] and gRust.Items[itemClass]:GetStack() or 1
    
    -- Сохраняем дополнительные данные перед перемещением
    local wear = fromItem.GetWear and fromItem:GetWear() or nil
    local clip = fromItem.GetClip and fromItem:GetClip() or nil
    local ammoType = fromItem.AmmoType -- Сохраняем тип боеприпасов
    
    -- ФУНКЦИЯ ДЛЯ КОПИРОВАНИЯ МОДОВ И ТИПА БОЕПРИПАСОВ
    local function CopyItemData(fromItem, toItem)
        if not fromItem or not toItem then return end
        
        -- Копируем таблицу модов (аттачментов)
        if fromItem.Mods then
            toItem.Mods = {}
            for i = 1, 4 do
                if fromItem.Mods[i] then
                    toItem.Mods[i] = fromItem.Mods[i]:Copy()
                    print(string.format("[Mods] Copied mod %d: %s", i, toItem.Mods[i]:GetItem()))
                end
            end
            print(string.format("[Mods] Copied %d mods total", table.Count(fromItem.Mods)))
        else
            toItem.Mods = nil
        end
        
        -- Копируем тип боеприпасов
        if fromItem.AmmoType then
            toItem.AmmoType = fromItem.AmmoType
            print(string.format("[AmmoType] Copied ammo type: %s", fromItem.AmmoType))
        else
            toItem.AmmoType = nil
        end
    end
    
    -- ЛОГИКА БЫСТРОГО СБОРА: если toEnt - игрок, а fromEnt - контейнер
    if toEnt:IsPlayer() and fromEnt ~= toEnt then
        print(string.format("[QuickMove] Container -> Player: %s x%d", itemClass, amount))
        
        local remainingAmount = amount
        
        -- Сначала пытаемся суммировать с существующими стаками у игрока
        for slot = 1, toEnt.InventorySlots do
            if remainingAmount <= 0 then break end
            
            local targetItem = toEnt.Inventory[slot]
            if targetItem and targetItem:GetItem() == itemClass then
                local availableSpace = maxStack - targetItem:GetQuantity()
                
                if availableSpace > 0 then
                    local transferAmount = math.min(remainingAmount, availableSpace)
                    
                    print(string.format("[Stacking] Slot %d: %d + %d", slot, targetItem:GetQuantity(), transferAmount))
                    
                    -- Суммируем в целевом слоте
                    targetItem:SetQuantity(targetItem:GetQuantity() + transferAmount)
                    toEnt:SyncSlot(slot)
                    
                    remainingAmount = remainingAmount - transferAmount
                end
            end
        end
        
        -- Если осталось количество после суммирования, ищем свободные слоты
        if remainingAmount > 0 then
            for slot = 1, toEnt.InventorySlots do
                if remainingAmount <= 0 then break end
                
                if not toEnt.Inventory[slot] then
                    local transferAmount = math.min(remainingAmount, maxStack)
                    
                    -- Создаем новый предмет с сохранением данных
                    local newItem = gRust.CreateItem(itemClass, transferAmount, wear)
                    if clip and newItem.SetClip then newItem:SetClip(clip) end
                    
                    -- КОПИРУЕМ МОДЫ И ТИП БОЕПРИПАСОВ ПРИ ПЕРЕМЕЩЕНИИ ОРУЖИЯ
                    CopyItemData(fromItem, newItem)
                    
                    toEnt.Inventory[slot] = newItem
                    toEnt:SyncSlot(slot)
                    
                    remainingAmount = remainingAmount - transferAmount
                    print(string.format("[New Stack] Slot %d: %d", slot, transferAmount))
                end
            end
        end
        
        -- Обновляем источник
        if remainingAmount < amount then
            if remainingAmount > 0 then
                -- Часть предметов осталась в источнике
                fromItem:SetQuantity(fromItem:GetQuantity() - (amount - remainingAmount))
                fromEnt:SyncSlot(oldSlot)
                print(string.format("[Source] %d remaining", fromItem:GetQuantity()))
            else
                -- Все предметы перемещены
                fromEnt:RemoveSlot(oldSlot)
                print("[Source] Slot cleared")
            end
        else
            -- Не удалось переместить
            pl:ChatPrint("Нет места в инвентаре!")
            print("[QuickMove] Failed - no space")
        end
        
        return -- Завершаем обработку быстрого перемещения
    end
    
    -- ЛОГИКА ПЕРЕМЕЩЕНИЯ ИЗ ИГРОКА В КОНТЕЙНЕР
    if fromEnt:IsPlayer() and toEnt ~= fromEnt then
        print(string.format("[QuickMove] Player -> Container: %s x%d", itemClass, amount))
        
        local remainingAmount = amount
        
        -- Сначала пытаемся суммировать с существующими стаками в контейнере
        for slot = 1, toEnt.InventorySlots do
            if remainingAmount <= 0 then break end
            
            local targetItem = toEnt.Inventory[slot]
            if targetItem and targetItem:GetItem() == itemClass then
                local availableSpace = maxStack - targetItem:GetQuantity()
                
                if availableSpace > 0 then
                    local transferAmount = math.min(remainingAmount, availableSpace)
                    
                    print(string.format("[Stacking] Container Slot %d: %d + %d", slot, targetItem:GetQuantity(), transferAmount))
                    
                    -- Суммируем в целевом слоте контейнера
                    targetItem:SetQuantity(targetItem:GetQuantity() + transferAmount)
                    toEnt:SyncSlot(slot)
                    
                    remainingAmount = remainingAmount - transferAmount
                end
            end
        end
        
        -- Если осталось количество после суммирования, ищем свободные слоты в контейнере
        if remainingAmount > 0 then
            for slot = 1, toEnt.InventorySlots do
                if remainingAmount <= 0 then break end
                
                if not toEnt.Inventory[slot] then
                    local transferAmount = math.min(remainingAmount, maxStack)
                    
                    -- Создаем новый предмет в контейнере с сохранением данных
                    local newItem = gRust.CreateItem(itemClass, transferAmount, wear)
                    if clip and newItem.SetClip then newItem:SetClip(clip) end
                    
                    -- КОПИРУЕМ МОДЫ И ТИП БОЕПРИПАСОВ ПРИ ПЕРЕМЕЩЕНИИ ОРУЖИЯ
                    CopyItemData(fromItem, newItem)
                    
                    toEnt.Inventory[slot] = newItem
                    toEnt:SyncSlot(slot)
                    
                    remainingAmount = remainingAmount - transferAmount
                    print(string.format("[New Stack] Container Slot %d: %d", slot, transferAmount))
                end
            end
        end
        
        -- Обновляем источник (инвентарь игрока)
        if remainingAmount < amount then
            if remainingAmount > 0 then
                -- Часть предметов осталась у игрока
                fromItem:SetQuantity(fromItem:GetQuantity() - (amount - remainingAmount))
                fromEnt:SyncSlot(oldSlot)
                print(string.format("[Player Source] %d remaining", fromItem:GetQuantity()))
            else
                -- Все предметы перемещены
                fromEnt:RemoveSlot(oldSlot)
                print("[Player Source] Slot cleared")
            end
        else
            -- Не удалось переместить
            pl:ChatPrint("Нет места в контейнере!")
            print("[QuickMove] Failed - no space in container")
        end
        
        return -- Завершаем обработку перемещения в контейнер
    end
    
    -- ОБЫЧНАЯ ЛОГИКА ПЕРЕМЕЩЕНИЯ (для drag&drop между одинаковыми типами)
    if toItem then
        if toItem:CanStack(fromItem) and toItem:CanAddQuantity(amount) then
            -- СУММИРОВАНИЕ: Добавляем количество к существующему предмету
            toItem:AddQuantity(amount)
            fromItem:RemoveQuantity(amount)
            
            if fromItem:GetQuantity() <= 0 then
                fromEnt:RemoveSlot(oldSlot)
            else
                fromEnt:SyncSlot(oldSlot)
            end
            
            toEnt:SyncSlot(newSlot)
        else
            -- Если нельзя суммировать, меняем предметы местами
            -- СОЗДАЕМ КОПИИ ПРЕДМЕТОВ С МОДАМИ И ТИПОМ БОЕПРИПАСОВ
            local fromItemCopy = fromItem:Copy()
            local toItemCopy = toItem:Copy()
            
            -- КОПИРУЕМ МОДЫ И ТИП БОЕПРИПАСОВ
            CopyItemData(fromItem, fromItemCopy)
            CopyItemData(toItem, toItemCopy)
            
            fromEnt.Inventory[oldSlot] = toItemCopy
            toEnt.Inventory[newSlot] = fromItemCopy
            
            fromEnt:SyncSlot(oldSlot)
            toEnt:SyncSlot(newSlot)
        end
    else
        -- Перемещаем в пустой слот
        if amount >= fromItem:GetQuantity() then
            -- Полное перемещение предмета - создаем копию с модами и типом боеприпасов
            local itemCopy = fromItem:Copy()
            
            -- КОПИРУЕМ МОДЫ И ТИП БОЕПРИПАСОВ
            CopyItemData(fromItem, itemCopy)
            
            toEnt.Inventory[newSlot] = itemCopy
            fromEnt:RemoveSlot(oldSlot)
            toEnt:SyncSlot(newSlot)
        else
            -- Разделение предмета
            local split = fromItem:Split(amount)
            if not split then return end
            
            -- Сохраняем дополнительные данные для разделенного предмета
            if wear and split.SetWear then split:SetWear(wear) end
            if clip and split.SetClip then split:SetClip(clip) end
            
            -- КОПИРУЕМ МОДЫ И ТИП БОЕПРИПАСОВ ПРИ РАЗДЕЛЕНИИ ОРУЖИЯ
            CopyItemData(fromItem, split)
            
            toEnt.Inventory[newSlot] = split
            fromEnt:SyncSlot(oldSlot)
            toEnt:SyncSlot(newSlot)
        end
    end

    -- Обработка одежды
    if fromEnt:IsPlayer() and oldSlot >= 31 and oldSlot <= 36 then
        if fromEnt.Inventory[oldSlot] and fromEnt:IsClothingItem(fromEnt.Inventory[oldSlot]) then
            fromEnt:ApplyClothing(fromEnt.Inventory[oldSlot], oldSlot)
        else
            fromEnt:RemoveClothing(oldSlot)
        end
    end

    if toEnt:IsPlayer() and newSlot >= 31 and newSlot <= 36 then 
        if toEnt:IsClothingItem(toEnt.Inventory[newSlot]) then 
            toEnt:ApplyClothing(toEnt.Inventory[newSlot], newSlot) 
        end 
    end
    
    hook.Run("gRust.ItemMoved", pl, fromEnt, toEnt, oldSlot, newSlot)
end

function HandleItemDrop(len, pl)
    local ent = net.ReadEntity()
    local slot = net.ReadUInt(6)
    local amount = net.ReadUInt(20)
    if not IsValid(pl) or not pl:Alive() then return end
    if not IsValid(ent) then return end
    if ent ~= pl and ent:GetPos():Distance(pl:GetPos()) > 200 then return end
    if not ent.Inventory then return end
    if ent:IsPlayer() and ent ~= pl then
        pl:ChatPrint("ИДИ НАХУЙ ПИДОР Я ВСЁ ПОФИКСИЛ")
        return
    end

    if ent:IsPlayer() then
        ent:DropItem(slot, amount)
    else
        if slot < 1 or slot > ent.InventorySlots then return end
        local item = ent.Inventory[slot]
        if not item then return end
        amount = math.min(amount, item:GetQuantity())
        if amount <= 0 then return end
        local dropItem
        if amount >= item:GetQuantity() then
            dropItem = item
            ent.Inventory[slot] = nil
            ent:SyncSlot(slot)
        else
            dropItem = item:Split(amount)
            if dropItem then
                ent:SyncSlot(slot)
            else
                return
            end
        end

        -- Сохраняем тип боеприпасов если выкидываем оружие
        local itemData = gRust.Items[dropItem:GetItem()]
        if itemData and itemData:GetWeapon() then
            local weaponClass = itemData:GetWeapon()
            local weaponTable = weapons.Get(weaponClass)
            if weaponTable then
                -- Получаем текущий тип боеприпасов из оружия в руках
                local activeWeapon = pl:GetActiveWeapon()
                if IsValid(activeWeapon) and activeWeapon:GetClass() == weaponClass then
                    local currentAmmoType = activeWeapon:GetCurrentAmmoType()
                    if currentAmmoType and currentAmmoType ~= "" and currentAmmoType ~= weaponTable.Ammo then
                        dropItem.AmmoType = currentAmmoType
                        print(string.format("[DROP WEAPON] Saved ammo type: %s", currentAmmoType))
                    end
                -- Или из сохраненного типа в предмете
                elseif item.AmmoType then
                    dropItem.AmmoType = item.AmmoType
                    print(string.format("[DROP WEAPON] Saved ammo type from item: %s", item.AmmoType))
                end
            end
        end

        local itemEnt = ents.Create("rust_droppeditem")
        if IsValid(itemEnt) then
            itemEnt:SetItem(dropItem)
            itemEnt:SetPos(ent:GetPos() + Vector(0, 0, 30) + VectorRand() * 20)
            itemEnt:SetAngles(Angle(0, math.random(0, 360), 0))
            itemEnt:Spawn()
            local phys = itemEnt:GetPhysicsObject()
            if IsValid(phys) then
                phys:Wake()
                phys:ApplyForceCenter(VectorRand() * 200 + Vector(0, 0, 100))
            end
        end
    end
end

function HandleInventoryRequest(len, pl)
    local ent = net.ReadEntity()
    if not IsValid(ent) then return end
    if not ent.Inventory then return end
    if ent ~= pl and ent:GetPos():Distance(pl:GetPos()) > 200 then return end
    net.Start("gRust.Inventory.Request")
    net.WriteEntity(ent)
    local validItems = {}
    for i = 1, ent.InventorySlots do
        if ent.Inventory[i] then
            table.insert(validItems, {
                slot = i,
                item = ent.Inventory[i]
            })
        end
    end

    net.WriteUInt(#validItems, 6)
    for _, data in pairs(validItems) do
        net.WriteUInt(data.slot, 6)
        net.WriteItem(data.item)
    end

    net.WriteUInt(ent.InventorySlots, 6)
    net.Send(pl)
end

-- HOOKS
hook.Add("PlayerDisconnected", "gRust.Inventory.PlayerDisconnect", function(pl)
    if pl.Inventory then
        local hasItems = false
        for i = 1, 36 do
            if pl.Inventory[i] then
                hasItems = true
                break
            end
        end

        if hasItems then
            local playerData = {
                steamID = pl:SteamID(),
                name = pl:Nick(),
                pos = pl:GetPos(),
                inventory = {}
            }

            for i = 1, 36 do
                if pl.Inventory[i] then playerData.inventory[i] = pl.Inventory[i] end
            end

            local lootEnt = ents.Create("rust_sleepingplayer")
            if IsValid(lootEnt) then
                lootEnt:SetPos(playerData.pos + Vector(0, 0, 10))
                lootEnt:SetAngles(Angle(0, math.random(0, 360), 0))
                lootEnt:Spawn()
                lootEnt.OwnerSteamID = playerData.steamID
                lootEnt.OwnerName = playerData.name
                lootEnt:SetNWString("OwnerSteamID", lootEnt.OwnerSteamID)
                lootEnt:SetNWString("OwnerName", lootEnt.OwnerName)
                local itemCount = 0
                for i = 1, 36 do
                    if playerData.inventory[i] then
                        lootEnt:SetSlot(playerData.inventory[i], i)
                        itemCount = itemCount + 1
                    end
                end
            end
        end

        pl.Inventory = {}
    end
end)

hook.Add("PlayerSpawn", "gRust_BodygroupsTracker", function(ply)
    ply.gRust_LastBodygroups = {}
    for i = 0, ply:GetNumBodyGroups() - 1 do
        ply.gRust_LastBodygroups[i] = ply:GetBodygroup(i)
    end
end)

hook.Add("PlayerSpawn", "gRust_ForceHandsOnSpawn", function(ply)
    timer.Simple(0.1, function()
        if IsValid(ply) then
            ply.CurrentHandsModel = DEFAULT_HANDS_MODEL
            ply:SetupHands()
        end
    end)
end)



-- Добавьте консольную команду для принудительной смены рук
concommand.Add("rust_forcehands", function(ply, cmd, args)
    if not ply:IsAdmin() then return end
    
    local model = args[1] or DEFAULT_HANDS_MODEL
    ply:ForceHandsModel(model)
    ply:ChatPrint("Модель рук установлена: " .. model)
end)


hook.Add("Think", "gRust_BodygroupsTracker", function()
    for _, ply in ipairs(player.GetAll()) do
        if not ply.gRust_LastBodygroups then continue end
        
        local changed = false
        local bodygroups = {}
        
        for i = 0, ply:GetNumBodyGroups() - 1 do
            local current = ply:GetBodygroup(i)
            bodygroups[i] = current
            
            if ply.gRust_LastBodygroups[i] ~= current then
                changed = true
            end
        end
        
        if changed then
            ply.gRust_LastBodygroups = bodygroups
            net.Start("gRust_UpdateBodygroups")
            net.WriteEntity(ply)
            for i = 0, ply:GetNumBodyGroups() - 1 do
                net.WriteUInt(ply:GetBodygroup(i), 8)
            end
            net.Broadcast()
        end
    end
end)

hook.Add("PlayerDeath", "gRust.Inventory.PlayerDeath", function(pl)
    if pl.Inventory then
        local hasItems = false
        for i = 1, 36 do
            if pl.Inventory[i] then
                hasItems = true
                break
            end
        end

        if hasItems then
            local playerData = {
                steamID = pl:SteamID(),
                name = pl:Nick(),
                pos = pl:GetPos(),
                inventory = {}
            }

            for i = 1, 36 do
                if pl.Inventory[i] then playerData.inventory[i] = pl.Inventory[i] end
            end

            local lootEnt = ents.Create("rust_sleepingplayer")
            if IsValid(lootEnt) then
                lootEnt:SetPos(playerData.pos + Vector(0, 0, 10))
                lootEnt:SetAngles(Angle(0, math.random(0, 360), 0))
                lootEnt:Spawn()
                lootEnt.OwnerSteamID = playerData.steamID
                lootEnt.OwnerName = playerData.name
                lootEnt:SetNWString("OwnerSteamID", lootEnt.OwnerSteamID)
                lootEnt:SetNWString("OwnerName", lootEnt.OwnerName)
                local itemCount = 0
                for i = 1, 36 do
                    if playerData.inventory[i] then
                        lootEnt:SetSlot(playerData.inventory[i], i)
                        itemCount = itemCount + 1
                    end
                end
            end
        end

        pl.Inventory = {}
        pl.EquippedAttire = {}
        pl:SetModel("models/player/Group01/Male_01.mdl")
        pl.ArmorHead = nil
        pl.ArmorBody = nil
        pl.ArmorArms = nil
        pl.ArmorLegs = nil
        timer.Simple(0, function()
            if IsValid(pl) then
                pl:SyncInventory()
                pl:GiveItem("rock", 1)
                pl:GiveItem("torch12", 1)
                pl:GiveItem("horse.cook", 1)
                pl:GiveItem("bandage", 1)
            end
        end)
    end
end)

function FindPlayerSleepingBag(player)
    local steamID = player:SteamID()
    for _, ent in pairs(ents.FindByClass("rust_sleepingplayer")) do
        if IsValid(ent) and ent.OwnerSteamID == steamID then return ent end
    end
    return nil
end

function TransferSleepingBagToPlayer(player, sleepingBag)
    if not IsValid(player) or not IsValid(sleepingBag) then return false end
    local transferred = false
    local transferredItems = 0
    for i = 1, sleepingBag.InventorySlots do
        local item = sleepingBag.Inventory[i]
        if item then
            local success = player:GiveItem(item)
            if success then
                transferred = true
                transferredItems = transferredItems + 1
                sleepingBag:RemoveSlot(i)
            end
        end
    end

    if transferred then
        sleepingBag:Remove()
        return true
    end
    return false
end

function PLAYER:GetWeaponFromSlot(slotID)
    if not self.Inventory or not self.Inventory[slotID] then return nil end
    
    local weaponItem = self.Inventory[slotID]
    local weaponClass = "rust_" .. string.lower(weaponItem:GetItem())
    
    -- Ищем оружие среди энтитей
    for _, ent in pairs(ents.FindByClass(weaponClass)) do
        if ent:GetOwner() == self then
            local entSlot = ent:GetInventorySlot()
            if entSlot and entSlot:GetID() == slotID then
                return ent
            end
        end
    end
    
    return nil
end

-- NET RECEIVERS
net.Receive("gRust.Inventory.Move", HandleMoveSlot)
net.Receive("gRust.Inventory.Request", HandleInventoryRequest)
net.Receive("gRust.Inventory.EatItem", HandleEatItem)
net.Receive("gRust.Drop", HandleItemDrop)
net.Receive("gRust_RequestBodygroups", function(len, ply)
    net.Start("gRust_UpdateBodygroups")
    net.WriteEntity(ply)
    for i = 0, ply:GetNumBodyGroups() - 1 do
        net.WriteUInt(ply:GetBodygroup(i), 8)
    end
    net.Send(ply)
end)

net.Receive("gRust.SplitItem", function(len, ply)
    local ent = net.ReadEntity()
    local slot = net.ReadUInt(6)
    local amount = net.ReadUInt(20)
    
    if not IsValid(ply) or not ply:Alive() then return end
    if not IsValid(ent) then return end
    
    -- Проверяем расстояние до контейнера (если это не инвентарь игрока)
    if ent ~= ply and ent:GetPos():Distance(ply:GetPos()) > 200 then
        ply:ChatPrint("Слишком далеко!")
        return
    end
    
    if not ent.Inventory then return end
    if slot < 1 or slot > ent.InventorySlots then return end
    
    local item = ent.Inventory[slot]
    if not item then 
        ply:ChatPrint("Предмет не найден")
        return
    end
    
    -- Проверяем, можно ли разделить предмет
    if item:GetQuantity() <= 1 then
        ply:ChatPrint("Нельзя разделить предмет с количеством 1")
        return
    end
    
    amount = math.Clamp(math.Round(amount), 1, item:GetQuantity() - 1)
    
    if amount <= 0 or amount >= item:GetQuantity() then
        ply:ChatPrint("Некорректное количество для разделения")
        return
    end
    
    print(string.format("[Split] %s разделяет стак %s: %d -> %d и %d", 
          ply:Nick(), item:GetItem(), item:GetQuantity(), amount, item:GetQuantity() - amount))
    
    -- Сохраняем дополнительные данные предмета
    local wear = item.GetWear and item:GetWear() or nil
    local clip = item.GetClip and item:GetClip() or nil
    
    -- Создаем разделенный предмет
    local splitItem = item:Split(amount)
    if not splitItem then
        ply:ChatPrint("Ошибка при разделении стака")
        return
    end
    
    -- Сохраняем данные для разделенного предмета
    if wear and splitItem.SetWear then splitItem:SetWear(wear) end
    if clip and splitItem.SetClip then splitItem:SetClip(clip) end
    
    -- КОПИРУЕМ МОДЫ ПРИ РАЗДЕЛЕНИИ ОРУЖИЯ
    if item.Mods then
        splitItem.Mods = {}
        for i = 1, 4 do
            if item.Mods[i] then
                splitItem.Mods[i] = item.Mods[i]:Copy()
                print(string.format("[Split Mods] Copied mod %d: %s", i, splitItem.Mods[i]:GetItem()))
            end
        end
    end
    
    -- Ищем свободный слот для разделенного предмета
    local emptySlot = nil
    for i = 1, ent.InventorySlots do
        if not ent.Inventory[i] then
            emptySlot = i
            break
        end
    end
    
    if emptySlot then
        -- Помещаем разделенный предмет в свободный слот
        ent:SetSlot(splitItem, emptySlot)
        ply:ChatPrint(string.format("Разделено: %d из %d", amount, item:GetQuantity()))
        
        -- Синхронизируем оба слота
        ent:SyncSlot(slot)
        ent:SyncSlot(emptySlot)
    else
        -- Если нет места, возвращаем предмет обратно в стак
        item:AddQuantity(amount)
        ply:ChatPrint("Нет места в инвентаре для разделенного предмета")
        ent:SyncSlot(slot)
    end
end)

net.Receive("Rust_AttachToWeapon", function(len, ply)
    if not IsValid(ply) or not ply:Alive() then return end
    
    local weaponSlot = net.ReadUInt(6)
    local attachmentClass = net.ReadString()
    
    print(string.format("[SV] %s attaching %s to weapon in slot %d", ply:Nick(), attachmentClass, weaponSlot))
    
    -- Проверяем наличие аттачмента
    if not ply:HasItem(attachmentClass, 1) then
        ply:ChatPrint("❌ Нет аттачмента в инвентаре")
        return
    end
    
    -- Проверяем слот с оружием
    if not ply.Inventory or not ply.Inventory[weaponSlot] then
        ply:ChatPrint("❌ Слот с оружием не найден")
        return
    end
    
    local weaponItem = ply.Inventory[weaponSlot]
    local weaponData = gRust.Items[weaponItem:GetItem()]
    
    if not weaponData or not weaponData:GetWeapon() then
        ply:ChatPrint("❌ Это не оружие!")
        return
    end
    
    -- Создаем таблицу для аттачментов если ее нет
    if not weaponItem.Attachments then
        weaponItem.Attachments = {}
    end
    
    -- Проверяем лимит
    local attachmentCount = 0
    for k, v in pairs(weaponItem.Attachments) do
        attachmentCount = attachmentCount + 1
    end
    
    if attachmentCount >= 4 then
        ply:ChatPrint("❌ Максимум 4 аттачмента на оружии")
        return
    end
    
    -- Проверяем не установлен ли уже
    if weaponItem.Attachments[attachmentClass] then
        ply:ChatPrint("❌ Этот аттачмент уже установлен")
        return
    end
    
    -- Добавляем аттачмент
    weaponItem.Attachments[attachmentClass] = true
    
    -- Убираем из инвентаря
    ply:RemoveItem(attachmentClass, 1)
    
    -- Синхронизируем
    ply:SyncSlot(weaponSlot)
    
    -- Обновляем оружие в руках
    timer.Simple(0.5, function()
        if IsValid(ply) then
            local activeWeapon = ply:GetActiveWeapon()
            if IsValid(activeWeapon) and activeWeapon.LoadAttachments then
                activeWeapon:LoadAttachments()
                activeWeapon:SendAttachmentsUpdate()
            end
            ply:ChatPrint("✅ Аттачмент установлен!")
        end
    end)
end)


net.Receive("gRust.Inventory.UpgradeScrap", function(len, ply)
    -- Таблица настроек улучшений
    local upgrades = {
        {
            scrapItemClass = "bluefrag", -- обрывки 1-го типа
            sheetItemClass = "bluelist", -- лист 1-го типа
            requiredAmount = 65,
            giveAmount = 1
        },
        {
            scrapItemClass = "book", -- обрывки 2-го типа
            sheetItemClass = "bluefrag", -- лист 2-го типа
            requiredAmount = 1,
            giveAmount = 45
        }
    }

    local foundUpgrade = nil

    -- Проверяем для какого типа у игрока хватает обрывков
    for _, upgrade in pairs(upgrades) do
        if ply:HasItem(upgrade.scrapItemClass, upgrade.requiredAmount) then
            foundUpgrade = upgrade
            break
        end
    end

    if not foundUpgrade then
        ply:ChatPrint("У вас недостаточно обрывков для улучшения.")
        return
    end

    -- Удаляем обрывки нужного типа
    ply:RemoveItem(foundUpgrade.scrapItemClass, foundUpgrade.requiredAmount)

    -- Выдаём конечный предмет нужным количеством
    local success = ply:GiveItem(foundUpgrade.sheetItemClass, foundUpgrade.giveAmount)

    if success then
        ply:ChatPrint("Вы успешно улучшили обрывки в лист.")
    else
        ply:ChatPrint("Недостаточно места в инвентаре для листа.")
        -- возвращаем обрывки обратно при неудаче
        ply:GiveItem(foundUpgrade.scrapItemClass, foundUpgrade.requiredAmount)
    end
end)

net.Receive("gRust.SleepingPlayer.RequestFullSync", function(len, ply)
    local ent = net.ReadEntity()
    if not IsValid(ent) or not ent.AttireInventory or not ent.BeltInventory then return end
    if ent:GetPos():Distance(ply:GetPos()) > 200 then return end
    
    -- Синхронизируем Attire
    for i = 1, 6 do
        net.Start("gRust.SleepingPlayer.SyncAttire")
        net.WriteEntity(ent)
        net.WriteUInt(i, 6)
        net.WriteItem(ent.AttireInventory[i])
        net.Send(ply)
    end
    
    -- Синхронизируем Belt
    for i = 1, 6 do
        net.Start("gRust.SleepingPlayer.SyncBelt")
        net.WriteEntity(ent)
        net.WriteUInt(i, 6)
        net.WriteItem(ent.BeltInventory[i])
        net.Send(ply)
    end
end)

net.Receive("gRust.Inventory.Clos", function(len, ply)
    local ent = net.ReadEntity()
    if IsValid(ent) then
        ent:PlayCloseSound()
    end
end)

net.Receive("gRust.SplitItem", function(len, ply)
    local ent = net.ReadEntity()
    local slot = net.ReadUInt(6)
    local amount = net.ReadUInt(20)
    
    if not IsValid(ply) or not ply:Alive() then return end
    if not IsValid(ent) then return end
    if ent ~= ply then return end
    if not ent.Inventory then return end
    if slot < 1 or slot > ent.InventorySlots then return end
    
    local item = ent.Inventory[slot]
    if not item then return end
    
    -- Проверяем, можно ли разделить предмет
    if item:GetQuantity() <= 1 then
        ply:ChatPrint("Cannot split item with quantity 1")
        return
    end
    
    amount = math.Clamp(math.Round(amount), 1, item:GetQuantity() - 1)
    
    if amount <= 0 or amount >= item:GetQuantity() then
        ply:ChatPrint("Invalid split amount")
        return
    end
    
    -- Сохраняем дополнительные данные предмета
    local wear = item.GetWear and item:GetWear() or nil
    local clip = item.GetClip and item:GetClip() or nil
    
    -- Создаем разделенный предмет
    local splitItem = item:Split(amount)
    if not splitItem then
        ply:ChatPrint("Failed to split item")
        return
    end
    
    -- Сохраняем данные для разделенного предмета
    if wear and splitItem.SetWear then splitItem:SetWear(wear) end
    if clip and splitItem.SetClip then splitItem:SetClip(clip) end
    
    -- КОПИРУЕМ АТТАЧМЕНТЫ ПРИ РАЗДЕЛЕНИИ ОРУЖИЯ
    if item.Attachments then
        splitItem.Attachments = table.Copy(item.Attachments)
    end
    
    -- Ищем свободный слот для разделенного предмета
    local emptySlot = nil
    for i = 1, ent.InventorySlots do
        if not ent.Inventory[i] then
            emptySlot = i
            break
        end
    end
    
    if emptySlot then
        -- Помещаем разделенный предмет в свободный слот
        ent:SetSlot(splitItem, emptySlot)
        ply:ChatPrint(string.format("Split %d items from stack", amount))
        
        -- Синхронизируем оба слота
        ent:SyncSlot(slot)
        ent:SyncSlot(emptySlot)
    else
        -- Если нет места, возвращаем предмет обратно в стак
        item:AddQuantity(amount)
        ply:ChatPrint("No space in inventory for split item")
        ent:SyncSlot(slot)
    end
end)

net.Receive("Rust_SimpleAttach", function(len, ply)
    if not IsValid(ply) or not ply:Alive() then return end
    
    local weaponSlot = net.ReadUInt(6)
    local attachmentClass = net.ReadString()
    
    print(string.format("[Attach] %s добавляет %s на оружие в слоте %d", 
          ply:Nick(), attachmentClass, weaponSlot))
    
    -- Проверяем наличие аттачмента
    if not ply:HasItem(attachmentClass, 1) then
        ply:ChatPrint("❌ Нет аттачмента в инвентаре")
        return
    end
    
    -- Проверяем слот с оружием
    if not ply.Inventory or not ply.Inventory[weaponSlot] then
        ply:ChatPrint("❌ Слот с оружием не найден")
        return
    end
    
    local weaponItem = ply.Inventory[weaponSlot]
    local weaponData = gRust.Items[weaponItem:GetItem()]
    
    if not weaponData or not weaponData:GetWeapon() then
        ply:ChatPrint("❌ Это не оружие!")
        return
    end
    
    -- Создаем таблицу для аттачментов если ее нет
    if not weaponItem.Attachments then
        weaponItem.Attachments = {}
    end
    
    -- Проверяем лимит (макс 4 аттачмента)
    local attachmentCount = 0
    for k, v in pairs(weaponItem.Attachments) do
        attachmentCount = attachmentCount + 1
    end
    
    if attachmentCount >= 4 then
        ply:ChatPrint("❌ Максимум 4 аттачмента на оружии")
        return
    end
    
    -- Проверяем не установлен ли уже этот аттачмент
    if weaponItem.Attachments[attachmentClass] then
        ply:ChatPrint("❌ Этот аттачмент уже установлен")
        return
    end
    
    -- Добавляем аттачмент
    weaponItem.Attachments[attachmentClass] = true
    
    -- Убираем аттачмент из инвентаря
    ply:RemoveItem(attachmentClass, 1)
    
    -- Синхронизируем слот
    ply:SyncSlot(weaponSlot)
    
    -- Обновляем оружие в руках
    timer.Simple(0.3, function()
        if IsValid(ply) then
            local activeWeapon = ply:GetActiveWeapon()
            if IsValid(activeWeapon) and activeWeapon.LoadAttachments then
                activeWeapon:LoadAttachments()
            end
            ply:ChatPrint("✅ Аттачмент установлен!")
        end
    end)
    
    print("✅ Аттачмент успешно добавлен")
end)
-- CONSOLE COMMANDS
concommand.Add("giveitem", function(pl, cmd, args)
    if not pl:IsSuperAdmin() then return end
    local item = args[1]
    local amount = tonumber(args[2]) or 1
    local slot = tonumber(args[3])
    if pl:GiveItem(item, amount, slot) then
        pl:ChatPrint("Gave " .. amount .. "x " .. item)
    else
        pl:ChatPrint("Failed to give item - inventory full or invalid slot")
    end
end)