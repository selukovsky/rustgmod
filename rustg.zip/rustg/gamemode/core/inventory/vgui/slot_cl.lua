local PANEL = {}

local BaseClass = baseclass.Get("Panel") or {}

local Dragging = false
local DraggingPanel
local MouseCode

-- Добавляем глобальную переменную для хранения выбранного слота
gRust.SelectedInventorySlot = nil

AccessorFunc(PANEL, "Selected", "Selected", FORCE_BOOL)
AccessorFunc(PANEL, "Preview", "Preview", FORCE_BOOL)
AccessorFunc(PANEL, "ID", "ID", FORCE_NUMBER)
AccessorFunc(PANEL, "Entity", "Entity")
AccessorFunc(PANEL, "DrawBackground", "DrawBackground", FORCE_BOOL)

-- Инициализация глобальных переменных если их нет
gRust = gRust or {}
gRust.ActiveInventorySlot = gRust.ActiveInventorySlot or nil
gRust.QuickSwapQueue = gRust.QuickSwapQueue or 0
gRust.ScalingInfluence = gRust.ScalingInfluence or 0.0    
gRust.Scaling = gRust.Scaling or (ScrH() / 1440) * gRust.ScalingInfluence + (1 - gRust.ScalingInfluence) * ScrW() / 2560

QuickSwapTime = QuickSwapTime or 0.09

-- Материалы из oldslot
local BlueprintIcon = Material("items/misc/blueprint.png", "smooth")
local BROKEN_ICON = gRust.GetIcon and gRust.GetIcon("broken") or Material("icons/broken.png", "smooth")
local LOCK_OVERLAY = Material("ui/tile_grid.png", "noclamp")

local AnimTime = 0.3
local AnimIntensity = 0.1

-- Цвета из oldslot
local TextColor = Color(255, 255, 255, 100)
local HighlightedColor = gRust.Colors and gRust.Colors.Secondary or Color(0, 127, 211, 150)
local ClickColor = Color(0, 100, 200, 80) -- Синий цвет при клике

-- Убедимся что gRust.Items существует
gRust.Items = gRust.Items or {}

local function Distance(x1, x2, y1, y2)
    return (x2 - x1)^2 + (y2 - y1)^2
end

local function FormatNumberWithCommas(n)
    local str = tostring(n)
    local result = ""
    local len = #str
    local count = 0
    for i = len, 1, -1 do
        count = count + 1
        local char = str:sub(i,i)
        result = char .. result
        if count % 3 == 0 and i ~= 1 then
            result = "," .. result
        end
    end
    return result
end

local function IsMouseDown()
    return input.IsMouseDown(107) or input.IsMouseDown(108) or input.IsMouseDown(109)
end

-- Вспомогательные функции для совместимости со старой системой
local function GetItemCondition(item)
    -- Новая система: используем GetWear()
    if item.GetWear then 
        local wear = item:GetWear() or 0
        local maxWear = 1000 -- Максимальный износ в новой системе
        return 1 - (wear / maxWear)
    end
    -- Старая система: используем GetCondition()
    if item.GetCondition then return item:GetCondition() end
    return 1
end

local function GetItemDamage(item)
    -- В новой системе damage может быть nil или отсутствовать
    if item.GetDamage then 
        local damage = item:GetDamage() or 0
        return math.Clamp(damage, 0, 1)
    end
    return 0
end

local function GetItemClip(item)
    if item.GetClip then return item:GetClip() end
    return nil
end

local function HasClipSize(itemData)
    if itemData and itemData.GetClipSize then return itemData:GetClipSize() end
    if itemData and itemData.GetClip then return itemData:GetClip() end
    return false
end

local function IsBlueprint(itemData)
    if itemData and itemData.GetBlueprint then return itemData:GetBlueprint() == true end
    if itemData and itemData.IsInCategory and itemData:IsInCategory("Blueprints") then return true end
    return false
end

local function HasDurability(itemData)
    -- В новой системе оружие имеет прочность если есть свойство durability или wear
    if itemData and itemData.GetDurability then return itemData:GetDurability() end
    if itemData and itemData.GetWeapon then 
        -- Проверяем, есть ли у оружия система износа
        local weaponClass = itemData:GetWeapon()
        return weaponClass and true or false
    end
    return false
end

local function IsWeapon(itemData)
    if itemData and itemData.GetWeapon then return itemData:GetWeapon() end
    return false
end

-- Новая функция: проверяет, является ли предмет чертежом оружия
local function IsWeaponBlueprint(itemData)
    return IsBlueprint(itemData) and IsWeapon(itemData)
end

-- Новая функция: проверяет, является ли предмет обычным оружием (не чертежом)
local function IsRegularWeapon(itemData)
    return IsWeapon(itemData) and not IsBlueprint(itemData)
end

-- Функция для получения максимальной прочности оружия
local function GetMaxDurability(itemData)
    if itemData and itemData.GetMaxDurability then return itemData:GetMaxDurability() end
    return 1000 -- Значение по умолчанию для новой системы
end

function PANEL:OnQuickSwap()
    if not self.Item then return end
    LocalPlayer():MoveSlot(self:GetEntity(), LocalPlayer(), self:GetID(), 0, self.Item:GetQuantity())
end

function PANEL:Init()
    self:NoClipping(true)
    self:SetDrawBackground(true)
    
    -- Текст для количества предметов (адаптировано из oldslot)
    self.Text = self:Add("DLabel")
    self.Text:SetFont("gRust.34px")
    self.Text:SetText("")
    self.Text:SetContentAlignment(6)
    self.Text:SetTextColor(TextColor)
    
    self.ClickScale = 1.0
    self.BounceOffset = 0
    self.Matrix = Matrix()
    self.AnimScale = 1
    self.HoveredTime = 0
    self.bHovered = false
    self.LastHoverState = false
    self.LastItem = nil
    self.ClickAlpha = 0 -- Альфа для синего цвета при клике
    
    -- Инициализация переменных для предотвращения nil ошибок
    self.Item = nil
    self.Icon = nil
    self.Dragging = false
    self.DraggingLast = false
    self.LMBDown = false
    self.RMBDown = false
    self.QuickSwapStart = nil
    self.HadLastItem = false
    self.WasClicked = false
end

function PANEL:PerformLayout()
    local Margin = self:GetTall() * 0.04
    self.Text:SetSize(self:GetWide() * 0.9, self:GetTall() * 0.3)
    local textY = self:GetTall() - self.Text:GetTall() - Margin + 5 -- +5 пикселей вниз
    self.Text:SetPos(self:GetWide() - self.Text:GetWide() - Margin, textY)
end

function PANEL:DrawDrag(x, y, w, h)
    if (!self.Item) then return end
    if (self.Preview) then return end
    
    -- Безопасное получение иконки
    local itemData = gRust.Items[self.Item:GetItem()]
    if not itemData then return end
    
    local iconPath = itemData:GetIcon()
    if not iconPath then return end
    
    local iconMaterial = Material(iconPath, "smooth")
    if not iconMaterial then return end
    
    surface.SetMaterial(iconMaterial)
    surface.SetDrawColor(255, 255, 255, 150)
    surface.DrawTexturedRect(x, y, w, h)
end

function PANEL:CanDrag()
    return self.Item ~= nil
end

function PANEL:OnDrag()
    if self.Preview or not self.Item then return end
    
    -- Скрываем информацию о предмете при начале перетаскивания
    if IsValid(gRust.ItemInfoPanel) then
        gRust.ItemInfoPanel:Remove()
        gRust.ItemInfoPanel = nil
    end
    
    -- Снимаем выделение
    if IsValid(gRust.SelectedInventorySlot) then
        gRust.SelectedInventorySlot:SetSelected(false)
        gRust.SelectedInventorySlot = nil
    end
    
    local itemData = gRust.Items[self.Item:GetItem()]
    if not itemData then return end
    
    -- Безопасное воспроизведение звука
    local soundName = itemData:GetSound()
    if soundName then
        LocalPlayer():EmitSound(gRust.RandomGroupedSound(string.format("pickup.%s", soundName)))
    end
end

function PANEL:OnDropped(Other, mcode)
    if (self.Preview) then return end
    if (!Other.Item) then return end
    
    local itemName = Other.Item:GetItem()
    local targetItem = self.Item
    
    -- ПРОВЕРКА АТТАЧМЕНТОВ: если перетаскиваем аттачмент на оружие
    if ATTACHMENT_SYSTEM and ATTACHMENT_SYSTEM.IsAttachment and ATTACHMENT_SYSTEM.IsAttachment(itemName) and targetItem then
        local targetItemData = gRust.Items[targetItem:GetItem()]
        if targetItemData and targetItemData:GetWeapon() then
            print(string.format("[Attachment] Attempting to attach %s to weapon in slot %d", itemName, self:GetID()))
            
            -- Отправляем запрос на сервер для установки аттачмента
            net.Start("Rust_AttachToWeapon")
            net.WriteUInt(self:GetID(), 6) -- Слот оружия
            net.WriteString(itemName) -- Класс аттачмента
            net.SendToServer()
            
            LocalPlayer():EmitSound("ui/item_attachment.wav")
            return true
        else
            print("[Attachment] Target is not a weapon or weapon data not found")
        end
    end
    
    -- Стандартная логика перемещения предметов
    local Amount = Other.Item:GetQuantity()
    if (mcode == 1) then
        Amount = 1
    elseif (mcode == 2) then
        if (LocalPlayer():KeyDown(IN_SPEED)) then
            Amount = math.floor(Amount / 3)
        else
            Amount = math.floor(Amount * 0.5)
        end
    end
    
    Amount = math.max(1, math.min(Amount, Other.Item:GetQuantity()))
    
    -- Проверяем, можно ли поместить предмет в целевой слот
    if targetItem then
        -- Если в целевом слоте уже есть предмет
        if targetItem:GetItem() == Other.Item:GetItem() and targetItem:CanStack(Other.Item) then
            -- Предметы одинаковые - пытаемся сложить
            local maxStack = gRust.Items[targetItem:GetItem()] and gRust.Items[targetItem:GetItem()]:GetStack() or 1
            local availableSpace = maxStack - targetItem:GetQuantity()
            
            if availableSpace > 0 then
                local transferAmount = math.min(Amount, availableSpace)
                
                -- ИСПРАВЛЕНИЕ: правильные звуки при перемещении
                LocalPlayer():EmitSound(gRust.RandomGroupedSound(string.format("pickup.%s", gRust.Items[Other.Item:GetItem()]:GetSound())))
                LocalPlayer():MoveSlot(Other:GetEntity(), self:GetEntity(), Other:GetID(), self:GetID(), transferAmount)
                return true
            else
                -- Нельзя сложить - меняем местами
                LocalPlayer():EmitSound(gRust.RandomGroupedSound(string.format("drop.%s", gRust.Items[Other.Item:GetItem()]:GetSound())))
                LocalPlayer():MoveSlot(Other:GetEntity(), self:GetEntity(), Other:GetID(), self:GetID(), Amount)
                return true
            end
        else
            -- Предметы разные - меняем местами
            LocalPlayer():EmitSound(gRust.RandomGroupedSound(string.format("drop.%s", gRust.Items[Other.Item:GetItem()]:GetSound())))
            LocalPlayer():MoveSlot(Other:GetEntity(), self:GetEntity(), Other:GetID(), self:GetID(), Amount)
            return true
        end
    else
        -- Целевой слот пустой - перемещаем предмет
        LocalPlayer():EmitSound(gRust.RandomGroupedSound(string.format("drop.%s", gRust.Items[Other.Item:GetItem()]:GetSound())))
        LocalPlayer():MoveSlot(Other:GetEntity(), self:GetEntity(), Other:GetID(), self:GetID(), Amount)
        return true
    end
    
    return false
end

function PANEL:OnRelease(other)
    if (!other) then return end
    if (!self.Item) then return end
    if (other.DropPanel) then
        net.Start("gRust.Drop")
        net.WriteEntity(self:GetEntity())
        net.WriteUInt(self:GetID(), 6)
        net.WriteUInt(self.Item:GetQuantity(), 20)
        net.SendToServer()
    end
end

function PANEL:SetItem(item)
    self.Item = item
    if (!item) then
        self.Text:SetText("")
        self.Icon = nil
        self.LastItem = nil
        return
    end
    
    local ItemData = gRust.Items[item:GetItem()]
    if not ItemData then
        self.Text:SetText("")
        self.Icon = nil
        return
    end
    
    self.Icon = Material(ItemData:GetIcon(), "smooth")
    
    -- Форматирование текста как в oldslot (исправленная версия)
    local text = ""
    
    -- Проверка наличия обоймы через совместимую функцию
    if HasClipSize(ItemData) then
        local clip = GetItemClip(item)
        if clip then
            text = tostring(clip)
        end
    elseif item:GetQuantity() > 1 then
        text = "x" .. FormatNumberWithCommas(item:GetQuantity()) -- Добавлен "x" перед количеством
    end
    
    self.Text:SetText(text)
    self.LastItem = item
end

function PANEL:GetItem()
    return self.Item
end

function PANEL:DoClick()
    if (self.Preview) then return end
    
    -- Если кликаем на уже выбранный слот - скрываем информацию
    if (IsValid(gRust.SelectedInventorySlot) && gRust.SelectedInventorySlot == self) then
        self:SetSelected(false)
        gRust.SelectedInventorySlot = nil
        
        -- Скрываем панель информации о предмете
        if IsValid(gRust.ItemInfoPanel) then
            gRust.ItemInfoPanel:Remove()
            gRust.ItemInfoPanel = nil
        end
        return
    end
    
    -- Убираем выделение с предыдущего слота
    if (IsValid(gRust.SelectedInventorySlot)) then
        gRust.SelectedInventorySlot:SetSelected(false)
        
        -- Скрываем предыдущую панель информации
        if IsValid(gRust.ItemInfoPanel) then
            gRust.ItemInfoPanel:Remove()
            gRust.ItemInfoPanel = nil
        end
    end

    -- Устанавливаем новый выбранный слот
    gRust.SelectedInventorySlot = self
    self:SetSelected(true)
    self.ClickStart = SysTime()
    self.ClickAlpha = 255
    
    -- Показываем информацию о предмете только если есть предмет
    if self.Item then
        -- Создаем панель информации о предмете
        if IsValid(gRust.ItemInfoPanel) then
            gRust.ItemInfoPanel:Remove()
        end
        
        -- Безопасное создание панели информации
        if vgui.GetControlTable("gRust.ItemData") then
            gRust.ItemInfoPanel = vgui.Create("gRust.ItemData")
            if IsValid(gRust.ItemInfoPanel) then
                gRust.ItemInfoPanel:SetItemData(self:GetEntity(), self:GetID())
                
                -- Добавляем панель в родительский контейнер (инвентарь)
                local parent = self:GetParent()
                while parent and not parent.ClassName:find("Inventory") do
                    parent = parent:GetParent()
                end
                
                if parent then
                    parent:AddItem(gRust.ItemInfoPanel)
                end
            end
        end
    end
end

function PANEL:OnMousePressed(mouseCode)
    self.StartMouseX, self.StartMouseY = input.GetCursorPos()
    
    if (self.Preview) then return end
    
    if (mouseCode == MOUSE_LEFT) then
        self.ClickStartTime = SysTime()
        self.WasClicked = true
        -- НЕ показываем информацию здесь, только в DoClick
    elseif mouseCode == MOUSE_RIGHT then
        if input.IsShiftDown() and self.Item and self.Item:GetQuantity() > 1 then
            local currentQuantity = self.Item:GetQuantity()
            local halfQuantity = math.floor(currentQuantity / 2)
            if halfQuantity > 0 then
                net.Start("gRust.RequestSplitStack")
                net.WriteEntity(self:GetEntity())
                net.WriteUInt(self:GetID(), 6)
                net.WriteUInt(halfQuantity, 20)
                net.SendToServer()
            end
        end
    end
end

function PANEL:OnMouseReleased(mouseCode)
    self.StartMouseX, self.StartMouseY = nil, nil
    
    if (DraggingPanel) then
        self:OnDropped(DraggingPanel, MouseCode)
    end
    
    if (self.Preview) then return end
    
    if (mouseCode == MOUSE_LEFT and self.WasClicked) then
        local clickDuration = SysTime() - (self.ClickStartTime or 0)
        if (!self.Dragging and clickDuration < 0.2) then
            self:DoClick()
        end
        self.WasClicked = false
        self.ClickStartTime = nil
    end
end

function PANEL:PaintOver(w, h)
    if (self.Dragging) then
        local mx, my = input.GetCursorPos()
        local lx, ly = self:LocalToScreen()
        mx = mx - lx
        my = my - ly
        self:DrawDrag(mx - (w * 0.5), my - (h * 0.5), w, h)
    end
end

function PANEL:UpdateAnimation()
    local x, y = self:LocalToScreen(0, 0)
    local w, h = self:GetWide(), self:GetTall()
    
    x = x + w * 0.5
    y = y + h * 0.5
    
    if (vgui.GetHoveredPanel() == self) then
        if (!self.bHovered) then
            self.bHovered = true
            self.HoveredTime = SysTime()
            if (!self.Preview) then
                LocalPlayer():EmitSound("ui.blip")
            end
        end
    else
        if (self.bHovered) then
            self.bHovered = false
        end
    end
    
    local t = Lerp((SysTime() - self.HoveredTime) / AnimTime, 0, 1)
    
    if (gRust.Anim and gRust.Anim.Punch) then
        self.AnimScale = (gRust.Anim.Punch(t) * AnimIntensity) + 1
    else
        local bounce = math.sin(t * math.pi)
        self.AnimScale = (bounce * AnimIntensity) + 1
    end
    
    self.Matrix:Identity()
    self.Matrix:Translate(Vector(x, y))
    self.Matrix:SetScale(Vector(self.AnimScale, self.AnimScale, 1))
    self.Matrix:Translate(Vector(-x, -y))
end

function PANEL:CheckSelection()
    if (!self:GetEntity() or !self:GetEntity().Inventory) then return end
    
    if (IsValid(self.LastItem) and !IsValid(self:GetEntity().Inventory[self:GetID()])) then
        self:SetSelected(false)
        self.LastItem = nil
    end
end

function PANEL:Think()
    if (self.Preview) then return end

    if BaseClass.Think then
        BaseClass.Think(self)
    end

    self:CheckSelection()

    -- Анимация синего цвета при клике
    if self.ClickAlpha > 0 then
        self.ClickAlpha = math.max(0, self.ClickAlpha - FrameTime() * 500)
    end

    -- ЛКМ быстрое взаимодействие
    if (input.IsMouseDown(107) && vgui.GetHoveredPanel() == self) then
        if (!self.LMBDown) then
            self.LMBDown = true
            self:DoClick()
        end
    else
        self.LMBDown = false
    end

    if (self.DraggingLast and !IsMouseDown()) then
        self:OnRelease(vgui.GetHoveredPanel())
    end
    
    self.DraggingLast = self.Dragging
    
    if ((self.Dragging or DraggingPanel) && !IsMouseDown()) then
        self.Dragging = false
        Dragging = false
        DraggingPanel = nil
        self.LastHoverState = false
        self.bHovered = false
    end
    
    if (self.StartMouseX) then
        local mx, my = input.GetCursorPos()
        if (!Dragging && self:CanDrag() && Distance(self.StartMouseX, mx, self.StartMouseY, my) > 5^2) then
            self.StartMouseX, self.StartMouseY = nil, nil
            Dragging = true
            DraggingPanel = self
            self.Dragging = true
            self:OnDrag()
        end
    end
    
    self:UpdateAnimation()
    self:UpdateOtherAnimations()

    -- Быстрый сбор предметов
    if (!input.IsMouseDown(108)) then
        if (!self:IsHovered()) then return end
        if (!self:GetItem() or (!self.HadLastItem and !input.IsKeyDown(KEY_H))) then return end
        if ((self.RMBDown or input.IsKeyDown(KEY_H)) && !self.QuickSwapStart) then
            gRust.QuickSwapQueue = gRust.QuickSwapQueue + 1
            self.QuickSwapStart = SysTime() + ((gRust.QuickSwapQueue - 1) * QuickSwapTime)

            -- Безопасное воспроизведение звука
            local itemData = gRust.Items[self.Item:GetItem()]
            if itemData then
                local soundName = itemData:GetSound()
                if soundName then
                    LocalPlayer():EmitSound(gRust.RandomGroupedSound(string.format("pickup.%s", soundName)))
                end
            end

            timer.Simple(gRust.QuickSwapQueue * QuickSwapTime, function()
                if (!IsValid(self)) then return end
                if (!self.Item) then return end
                
                -- Безопасное воспроизведение звука
                local itemData = gRust.Items[self.Item:GetItem()]
                if itemData then
                    local soundName = itemData:GetSound()
                    if soundName then
                        LocalPlayer():EmitSound(gRust.RandomGroupedSound(string.format("drop.%s", soundName)))
                    end
                end
                
                self:OnQuickSwap()
                self.QuickSwapStart = nil
                gRust.QuickSwapQueue = gRust.QuickSwapQueue - 1
            end)

            self.RMBDown = false
            return
        end

        self.RMBDown = false
    elseif (self:IsHovered()) then
        self.RMBDown = true
    else
        self.RMBDown = false
    end

    self.HadLastItem = self.Item ~= nil
end

function PANEL:UpdateOtherAnimations()
    local dt = FrameTime()
    if self.ClickStart then
        local elapsed = SysTime() - self.ClickStart
        local duration = 0.12
        local progress = elapsed / duration
        if progress >= 1.0 then
            self.ClickStart = nil
            self.ClickScale = 1.0
        else
            local t = progress * 2
            if t <= 1 then
                self.ClickScale = 1.0 + t * 0.08
            else
                t = t - 1
                self.ClickScale = 1.08 - t * 0.08
            end
        end
    else
        if math.abs(self.ClickScale - 1.0) > 0.001 then
            self.ClickScale = Lerp(dt * 25, self.ClickScale, 1.0)
        else
            self.ClickScale = 1.0
        end
    end
end

function PANEL:GetSoundName()
    if not self.Item then return nil end
    local itemData = gRust.Items[self.Item:GetItem()]
    if not itemData then return nil end
    local soundName = itemData:GetSound()
    if not soundName then return nil end
    return gRust.RandomGroupedSound(string.format("pickup.%s", soundName))
end

function PANEL:Paint(w, h)
    if (!IsValid(LocalPlayer())) then return end
    
    if (!self.Preview) then
        cam.PushModelMatrix(self.Matrix)
    end
    
    local totalScale = self.ClickScale
    local scaledW = w * totalScale
    local scaledH = h * totalScale
    local offsetX = (w - scaledW) * 0.5
    local offsetY = (h - scaledH) * 0.5
    
    local backgroundMaterial = Material("ui/background.png", "noclamp smooth")
    local scale = 1 / 768
    local uScale = scaledW * scale
    local vScale = scaledH * scale
    
    surface.SetDrawColor(126, 126, 126, 39)
    surface.SetMaterial(backgroundMaterial)
    surface.DrawTexturedRectUV(offsetX, offsetY, scaledW, scaledH, 0, 0, uScale, vScale)
    
    if self:GetSelected() then
        surface.SetDrawColor(0, 127, 211, 150)
        surface.DrawRect(offsetX, offsetY, scaledW, scaledH)
    end
    
    if (!self.Item) then 
        if (!self.Preview) then
            cam.PopModelMatrix()
        end
        return 
    end
    
    local ID = gRust.Items[self.Item:GetItem()]
    if not ID then
        if (!self.Preview) then
            cam.PopModelMatrix()
        end
        return
    end
    
    -- ONLY DRAW WEAR BAR, NO BROKEN ICON
    if (ID:GetWeapon() && !self.Preview) then
        if (ID:GetDurability()) then
            surface.SetDrawColor(90, 206, 45, 20)
            surface.DrawRect(offsetX, offsetY, scaledW * 0.07, scaledH)
            
            local WearFrac = self.Item:GetWear() / 1000
            surface.SetDrawColor(137, 181, 55, 255)
            surface.DrawRect(offsetX, offsetY + scaledH - (scaledH * WearFrac), scaledW * 0.07, scaledH * WearFrac)
        end
        
        if (ID:GetClip()) then
            self.Text:SetText(self.Item:GetClip())
        end
    end
    
    if (!self.Icon) then 
        if (!self.Preview) then
            cam.PopModelMatrix()
        end
        return 
    end
    
    local iconSize = math.min(scaledW, scaledH) * 0.8
    local iconX = offsetX + (scaledW - iconSize) * 0.5
    local iconY = offsetY + (scaledH - iconSize) * 0.3
    
    if (ID:GetBlueprint() == true) then
        surface.SetDrawColor(200, 200, 200)
        surface.SetMaterial(BlueprintIcon)
        surface.DrawTexturedRect(iconX, iconY, iconSize, iconSize)
    end
    
    surface.SetDrawColor(200, 200, 200)
    surface.SetMaterial(self.Icon)
    surface.DrawTexturedRect(iconX, iconY, iconSize, iconSize)
    
    local mods = self:GetItem():GetMods()
    if (mods and !self.Preview) then
        local Padding = math.floor(scaledH * 0.0)
        local Spacing = math.floor(scaledH * 0.025)
        local Margin = scaledH * 0.05
        local ModSize = math.floor(scaledH * 0.09)
        
        for i = 1, 3 do
            local modAlpha = mods[i] and 255 or 50
            surface.SetDrawColor(255, 255, 255, modAlpha)
            surface.DrawRect(
                offsetX + Margin + Padding, 
                offsetY + Padding * 2 + ((i - 1) * (ModSize + Spacing)), 
                ModSize, 
                ModSize
            )
        end
    end
    
    if (!self.Preview) then
        cam.PopModelMatrix()
    end
end

function PANEL:SetSelected(selected)
    self.Selected = selected
end

function PANEL:GetSelected()
    return self.Selected
end

function PANEL:OnRemove()
    -- Если эта панель была выбрана, сбрасываем выбор
    if IsValid(gRust.SelectedInventorySlot) and gRust.SelectedInventorySlot == self then
        gRust.SelectedInventorySlot = nil
        
        -- Скрываем информацию
        if IsValid(gRust.ItemInfoPanel) then
            gRust.ItemInfoPanel:Remove()
            gRust.ItemInfoPanel = nil
        end
    end
end

-- Регистрируем панель с защитой от конфликтов
if not vgui.GetControlTable("gRust.Inventory.Slot") then
    vgui.Register("gRust.Inventory.Slot", PANEL, "Panel")
else
    print("[WARNING] gRust.Inventory.Slot already registered!")
end