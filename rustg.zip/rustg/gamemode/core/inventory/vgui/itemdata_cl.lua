local PANEL = {}

local ItemStatsConfig = {
    -- Оружие (показываем все стандартные статистики)
    weapon = {
        fields = {
            { key = "Damage", name = "Damage", max = 100 },
            { key = "AttackRate", name = "Attack Rate", max = 100 },
            { key = "AttackSize", name = "Attack Size", max = 1 },
            { key = "Range", name = "Range", max = 3 },
            { key = "Accuracy", name = "Accuracy", max = 8 },
            { key = "Recoil", name = "Recoil", max = 10 },
            { key = "FireRate", name = "Fire Rate", max = 600 },
            { key = "OreGather", name = "Ore Gather", max = 10 },
            { key = "TreeGather", name = "Tree Gather", max = 20 },
            { key = "FleshGather", name = "Flesh Gather", max = 20 }
        }
    },
    
    -- Кирки (только статистики добычи руды)
    pickaxe = {
        fields = {
            { key = "Damage", name = "Damage", max = 100 },
            { key = "AttackRate", name = "Attack Rate", max = 100 },
            { key = "OreGather", name = "Ore Gather", max = 10 }
        }
    },
    
    -- Топоры (только статистики добычи дерева)
    hatchet = {
        fields = {
            { key = "Damage", name = "Damage", max = 100 },
            { key = "AttackRate", name = "Attack Rate", max = 100 },
            { key = "TreeGather", name = "Tree Gather", max = 20 }
        }
    },
    
    -- Оружие ближнего боя (без статистик добычи)
    melee = {
        fields = {
            { key = "Damage", name = "Damage", max = 100 },
            { key = "AttackRate", name = "Attack Rate", max = 100 },
            { key = "AttackSize", name = "Attack Size", max = 1 },
            { key = "Range", name = "Range", max = 3 }
        }
    }
}

-- ТАБЛИЦА ПРИВЯЗКИ SHORTNAME К ТИПАМ СТАТИСТИК
local ItemTypeMapping = {
    -- Топоры
    ["hatchet"] = "hatchet",
    ["hatchet2"] = "hatchet",
    ["hatchet3"] = "hatchet",
    
    -- Кирки
    ["pickaxe"] = "pickaxe", 
    ["pickaxe2"] = "pickaxe",
    ["pickaxe3"] = "pickaxe",
    
    -- Оружие ближнего боя
    ["knife"] = "melee",
    ["sword"] = "melee",
    ["spear"] = "melee",
    ["mace"] = "melee",
    
    -- Огнестрельное оружие (обычные статистики)
    ["pistol"] = "weapon",
    ["rifle"] = "weapon",
    ["shotgun"] = "weapon"
}

-- ФУНКЦИЯ ДЛЯ ОПРЕДЕЛЕНИЯ ТИПА ПРЕДМЕТА ПО ЕГО SHORTNAME
function PANEL:GetItemType(itemClass, swep)
    if not itemClass then return "weapon" end
    
    -- Сначала проверяем прямую привязку по shortname
    if ItemTypeMapping[itemClass] then
        return ItemTypeMapping[itemClass]
    end
    
    -- Если нет прямой привязки, проверяем по названию класса
    local classLower = string.lower(itemClass)
    
    -- Кирки
    if string.find(classLower, "pickaxe") or string.find(classLower, "pick") then
        return "pickaxe"
    end
    
    -- Топоры
    if string.find(classLower, "hatchet") or string.find(classLower, "axe") then
        return "hatchet"
    end
    
    -- Оружие ближнего боя
    if string.find(classLower, "sword") or string.find(classLower, "knife") or 
       string.find(classLower, "spear") or string.find(classLower, "mace") then
        return "melee"
    end
    
    -- Дополнительная проверка по SWEP данным
    if swep then
        -- Если у оружия есть статистики добычи, определяем тип по ним
        if swep.OreGather and swep.OreGather > 0 then
            return "pickaxe"
        elseif swep.TreeGather and swep.TreeGather > 0 then
            return "hatchet"
        elseif not swep.FireRate or swep.FireRate == 0 then
            return "melee"
        end
    end
    
    -- По умолчанию - обычное оружие
    return "weapon"
end

-- ФУНКЦИЯ ДЛЯ ДОБАВЛЕНИЯ НОВЫХ ПРЕДМЕТОВ В СИСТЕМУ
function PANEL:AddItemTypeMapping(itemShortname, statsType)
    ItemTypeMapping[itemShortname] = statsType
end

-- ФУНКЦИЯ ДЛЯ СОЗДАНИЯ НОВОГО ТИПА СТАТИСТИК
function PANEL:CreateStatsType(typeName, fieldsTable)
    ItemStatsConfig[typeName] = {
        fields = fieldsTable
    }
end

surface.CreateFont("gRust.ItemDescription", {
    font = "Roboto Condensed",
    size = 28 * gRust.Scaling,
    weight = 500,
    antialias = true
})

AccessorFunc(PANEL, "Inventory", "Inventory")
AccessorFunc(PANEL, "Slot", "Slot")

function PANEL:Init()
    self:NoClipping(true)
	self:Dock(BOTTOM)
	self:SetTall(ScrH() * 0.365)
	self:DockMargin(0, 0, 0, ScrH() * 0.01)
end

function PANEL:SetItemData(ent, i)
    self:Clear()
    
	self.Entity = ent
	self.ItemIndex = i
    self:SetInventory(ent.Inventory)
    self:SetSlot(i)
	
	local Item = ent.Inventory[i]
	if (Item == nil) then return end
	local ItemData = gRust.Items[Item:GetItem()]
	
	local Text = self:Add("gRust.Label")
	Text:Dock(TOP)
	Text:SetText(ItemData:GetName())
	Text:SetTextSize(40)
	Text:SetTall(ScrH() * 0.03)
	
    local Container = self:Add("Panel")
    Container:Dock(BOTTOM)
    Container:SetTall(ScrH() * 0.250)

    -- ТОЧНАЯ КОПИЯ СПЛИТИНГА ИЗ СТАРОГО UI
    if (Item:GetQuantity() > 1) then
    local Splitting = Container:Add("Panel")
    Splitting:SetTall(100 * gRust.Scaling)
    Splitting:Dock(BOTTOM) -- теперь сплитинг всегда внизу
    Splitting:DockMargin(0, 8 * gRust.Scaling, 0, 0)

        local Container = Splitting:Add("Panel")
        Container:Dock(FILL)

        local TipColor1 = ColorAlpha(gRust.Colors.Text, 200)
        local TipColor2 = ColorAlpha(gRust.Colors.Text, 100)
        
        local TipPanel = Container:Add("Panel")
        TipPanel:Dock(TOP)
        TipPanel:SetTall(40 * gRust.Scaling)
        TipPanel.Paint = function(pnl, w, h)
            gRust.DrawPanel(0, 0, w, h)
            gRust.DrawPanel(0, 0, w, h)
            draw.SimpleText("SPLITTING", "gRust.28px", 8 * gRust.Scaling, h / 2, TipColor1, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText("SET AMOUNT & DRAG ICON", "gRust.26px", w - (8 * gRust.Scaling), h / 2, TipColor2, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        end

        local value = math.ceil(Item:GetQuantity() * 0.5)
        
        -- ИСПОЛЬЗУЕМ РЕАЛЬНЫЙ СЛАЙДЕР ИЗ СТАРОГО UI
        local Slider = Container:Add("gRust.Slider")
        Slider:Dock(FILL)
        Slider:DockMargin(0, 2 * gRust.Scaling, 0, 0)
        Slider:SetMinValue(1)
        Slider:SetMaxValue(Item:GetQuantity())
        Slider:SetValue(value)

        -- ПРОСТАЯ ИКОНКА ВМЕСТО gRust.Slot
        local DragItem = Splitting:Add("DButton")
        DragItem:Dock(RIGHT)
        DragItem:SetWide(100 * gRust.Scaling)
        DragItem:DockMargin(2 * gRust.Scaling, 0, 0, 0)
        DragItem:SetText("")
        DragItem.Quantity = value
        DragItem.ItemData = ItemData
        
        DragItem.Paint = function(me, w, h)
            -- Фон как у слота
            surface.SetDrawColor(126, 126, 126, 39)
            surface.DrawRect(0, 0, w, h)
            
            surface.SetDrawColor(126, 126, 126, 39)
            surface.DrawOutlinedRect(0, 0, w, h)
            
            -- Иконка предмета
            if me.ItemData and me.ItemData:GetIcon() then
                surface.SetMaterial(Material(me.ItemData:GetIcon()))
                surface.SetDrawColor(255, 255, 255, 255)
                surface.DrawTexturedRect(10, 10, w - 20, h - 20)
            end
            
            -- Отображение количества (как в старом UI)
            if me.Quantity and me.Quantity > 1 then
                draw.SimpleText(me.Quantity, "gRust.32px", w - 8, h - 8, Color(255, 255, 255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
            end
            
            -- Эффект при наведении
            if me:IsHovered() then
                surface.SetDrawColor(255, 255, 255, 30)
                surface.DrawRect(0, 0, w, h)
            end
        end
        
        Slider.OnValueChanged = function(slider, value)
            value = math.Round(value)
            DragItem.Quantity = value
            DragItem:SetTooltip("Split " .. value .. " items")
        end

        -- Обработка перетаскивания
        DragItem.DoClick = function()
            local splitAmount = math.Round(Slider:GetValue())
            if splitAmount >= 1 and splitAmount < Item:GetQuantity() then
                net.Start("gRust.SplitItem")
                    net.WriteEntity(ent)
                    net.WriteUInt(i, 6)
                    net.WriteUInt(splitAmount, 20)
                net.SendToServer()
                
                if gRust.Inventory.Container then
                    gRust.Inventory.Container:Close()
                end
            end
        end
        
        -- Устанавливаем подсказку
        DragItem:SetTooltip("Split " .. value .. " items")
    end

    -- ОСНОВНОЙ КОНТЕЙНЕР ДЛЯ ИНФОРМАЦИИ И ДЕЙСТВИЙ
    local MainContent = Container:Add("Panel")
    MainContent:Dock(FILL)
    
    -- Зазор только для оружия
    if (ItemData:GetWeapon()) then
        MainContent:DockMargin(0, 8 * gRust.Scaling, 0, 8 * gRust.Scaling) -- Зазор сверху и снизу только для оружия
    else
        MainContent:DockMargin(0, 0, 0, 0) -- Без зазора для обычных предметов
    end

    -- БЛОК ИНФОРМАЦИИ О ОРУЖИИ (слева) - ТОЛЬКО ДЛЯ ОРУЖИЯ
    if (ItemData:GetWeapon()) then
        local WeaponStats = MainContent:Add("Panel")
        WeaponStats:Dock(LEFT)
        WeaponStats:SetWide(ScrH() * 0.25) -- Компактный размер
        WeaponStats:DockMargin(0, 0, 8 * gRust.Scaling, 0) -- Зазор справа
        
        -- Фон для блока информации (слегка прозрачный)
        WeaponStats.Paint = function(me, w, h)
            surface.SetMaterial(Material("materials/ui/background.png"))
            surface.SetDrawColor(192, 192, 192, 20) -- Слегка прозрачный
            surface.DrawTexturedRect(0, 0, w, h)
        end

        local Title = WeaponStats:Add("Panel")
        Title:Dock(TOP)
        Title:SetTall(30 * gRust.Scaling)
        Title.Paint = function(me, w, h)
            surface.SetDrawColor(192, 192, 192, 180)
            surface.DrawRect(0, 0, w, h)
            draw.SimpleText("INFORMATION", "gRust.24px", 8 * gRust.Scaling, h / 2, gRust.Colors.Text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        local StatsContainer = WeaponStats:Add("DScrollPanel")
        StatsContainer:Dock(FILL)
        StatsContainer:DockMargin(4 * gRust.Scaling, 4 * gRust.Scaling, 4 * gRust.Scaling, 4 * gRust.Scaling)

        local swep = weapons.GetStored(ItemData:GetWeapon())
        if (swep) then
            local itemType = self:GetItemType(Item:GetItem(), swep)
            local statsConfig = ItemStatsConfig[itemType] or ItemStatsConfig["weapon"]
            
            local TextColor = Color(247, 238, 231)
            local BarColor = ColorAlpha(gRust.Colors.Text, 100)

            for k, v in pairs(statsConfig.fields) do
                local value = swep[v.key]

                if v.key == "Recoil" or v.key == "FireRate" then
                    value = 20
                end

                if value and (value ~= 0 or v.key == "Recoil" or v.key == "FireRate") then
                    local Row = StatsContainer:Add("Panel")
                    Row:Dock(TOP)
                    Row:SetTall(24 * gRust.Scaling) -- Более компактные строки
                    Row:DockMargin(5, 0, 0, 5 * gRust.Scaling)

                    local Left = Row:Add("DLabel")
                    Left:Dock(LEFT)
                    Left:SetWide(100 * gRust.Scaling) -- Уже для компактности
                    Left:SetFont("gRust.20px")
                    Left:SetText(v.name)
                    Left:SetTextColor(TextColor)

                    local Right = Row:Add("Panel")
                    Right:Dock(FILL)
                    Right:DockMargin(8 * gRust.Scaling, 0, 0, 0)
                    local BarMargin = 2 * gRust.Scaling
                    Right.Paint = function(me, w, h)
                        local frac = math.min(value / v.max, 1.0)
                        surface.SetFont("gRust.20px")
                        local tw, th = surface.GetTextSize(value .. "  ")
                        
                        -- Полоса прогресса
                        surface.SetDrawColor(BarColor)
                        surface.DrawRect(0, BarMargin, (w - BarMargin - tw) * frac, h - BarMargin * 2)
                        
                        -- Текст значения
                        draw.SimpleText(value, "gRust.20px", BarMargin + (w - BarMargin - tw) * frac, h / 2, BarColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                    end
                end
            end

            -- БЛОК АТТАЧМЕНТОВ БЕЗ ЗАГОЛОВКА - ПОД СТАТИСТИКАМИ
            -- Проверяем, поддерживает ли оружие аттачменты
            if (ItemData:GetAttachments() and ItemData:GetAttachments() > 0) then
                local AttachmentsContainer = WeaponStats:Add("Panel")
                AttachmentsContainer:Dock(BOTTOM)
                AttachmentsContainer:SetTall(ScrH() * 0.06)
                AttachmentsContainer:DockMargin(4 * gRust.Scaling, 8 * gRust.Scaling, 4 * gRust.Scaling, 4 * gRust.Scaling)
                AttachmentsContainer.Paint = function(me, w, h)
                    surface.SetDrawColor(255, 255, 255, 0)
                    surface.DrawRect(0, 0, w, h)
                end

                AttachmentsContainer.Slots = {}
                local count = ItemData:GetAttachments() or 4
                for j = 1, count do
                    local Slot = AttachmentsContainer:Add("gRust.Inventory.Slot")
                    Slot:Dock(LEFT)
                    Slot:SetEntity(ent)
                    Slot.Attachment = j
                    Slot.Weapon = i
                    if (Item.Mods and Item.Mods[j]) then
                        Slot:SetItem(Item.Mods[j])
                    end
                    
                    -- ИСПРАВЛЕННАЯ ЛОГИКА: Обработка дропа в слот аттачмента
                    Slot.OnDropped = function(me, other, mcode)
                        if not other or not other.Item then return false end
                        
                        local itemData = gRust.Items[other.Item:GetItem()]
                        if not itemData then return false end
                        
                        -- Проверяем, является ли предмет аттачментом
                        if not itemData.IsAttachment then return false end
                        
                        -- Получаем индекс предмета из слота
                        local itemIndex = other.ItemIndex
                        if not itemIndex then 
                            -- Пытаемся найти индекс в инвентаре
                            for idx, invItem in pairs(ent.Inventory) do
                                if invItem == other.Item then
                                    itemIndex = idx
                                    break
                                end
                            end
                        end
                        
                        if not itemIndex then return false end
                        
                        -- Отправляем запрос на сервер для добавления аттачмента
                        net.Start("gRust.AttachMod")
                            net.WriteEntity(ent)
                            net.WriteUInt(i, 8) -- индекс оружия
                            net.WriteUInt(j, 3) -- индекс слота аттачмента
                            net.WriteUInt(itemIndex, 8) -- индекс предмета в инвентаре
                        net.SendToServer()
                        
                        return true
                    end
                    
                    -- Добавляем возможность снять аттачмент
                    Slot.DoRightClick = function(me)
                        if not me.Item then return end
                        
                        net.Start("gRust.DetachMod")
                            net.WriteEntity(ent)
                            net.WriteUInt(i, 8) -- индекс оружия
                            net.WriteUInt(j, 3) -- индекс слота аттачмента
                        net.SendToServer()
                    end
                    
                    AttachmentsContainer.Slots[#AttachmentsContainer.Slots + 1] = Slot
                end

                AttachmentsContainer.PerformLayout = function(me)
                    local slotCount = #me.Slots
                    if slotCount > 0 then
                        local slotWidth = me:GetTall()
                        local totalMargin = me:GetWide() - (slotWidth * slotCount)
                        local marginBetween = totalMargin / (slotCount - 1)
                        
                        for k, v in ipairs(me.Slots) do
                            v:SetWide(slotWidth)
                            if k < slotCount then
                                v:DockMargin(0, 0, marginBetween, 0)
                            else
                                v:DockMargin(0, 0, 0, 0)
                            end
                        end
                    end
                end
            end
        end
    end

    -- БЛОК ДЕЙСТВИЙ (справа) - ДЛЯ ВСЕХ ПРЕДМЕТОВ
	local Actions = MainContent:Add("Panel")
	Actions:Dock(RIGHT)
	Actions:SetWide(ScrH() * 0.25)
	Actions.Paint = function(me, w, h)
		surface.SetMaterial(Material("materials/ui/background.png"))
		surface.SetDrawColor(192, 192, 192, 20) -- Слегка прозрачный
		surface.DrawTexturedRect(0, 0, w, h)
	end
	
	-- ЗАГОЛОВОК ACTIONS (растянут по ширине)
	local ActionsPanel = Actions:Add("Panel")
    ActionsPanel:SetTall(30 * gRust.Scaling)
    ActionsPanel:Dock(TOP)
    ActionsPanel:DockMargin(0, 0, 0, 0)
    ActionsPanel.Paint = function(me, w, h)
        ActionsPanel:SetWide(Actions:GetWide())
        ActionsPanel:SetPos(0, 0)
        surface.SetDrawColor(192, 192, 192, 180)
        surface.DrawRect(0, 0, w, h)
        draw.SimpleText("ACTIONS", "gRust.24px", w / 8, h / 2, gRust.Colors.Text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local ActionsContainer = Actions:Add("Panel")
    ActionsContainer:Dock(FILL)
    ActionsContainer:DockMargin(4 * gRust.Scaling, 6 * gRust.Scaling, 4 * gRust.Scaling, 4 * gRust.Scaling)

    -- Действия предмета ВЫШЕ кнопки Drop
	if (ItemData.Actions) then
		for k, v in ipairs(ItemData.Actions) do
			local Button = ActionsContainer:Add("gRust.Button")
			Button:SetText(v.Name)
			Button:Dock(BOTTOM) -- Все кнопки внизу
			Button:SetTall(ScrH() * 0.045)
			Button:DockMargin(0, 0, 0, 2 * gRust.Scaling)
			Button.DoClick = function()
				v.Func(ent, i)
			end
		end
	end

    -- Пустое пространство сверху (если нужно)
    local Spacer = ActionsContainer:Add("Panel")
    Spacer:Dock(FILL)
    Spacer.Paint = function() end

    -- ОСТАЛЬНАЯ ИНФОРМАЦИЯ О ПРЕДМЕТЕ
    local DescriptionMargin = 20 * gRust.Scaling
    local DescriptionText = self:Add("gRust.Label")
    DescriptionText:Dock(FILL)
    DescriptionText:SetFont("gRust.ItemDescription")
    DescriptionText:DockMargin(DescriptionMargin, DescriptionMargin, 110 * gRust.Scaling, DescriptionMargin)
    DescriptionText:SetText(ItemData:GetDescription())
    DescriptionText:SetContentAlignment(7)
    DescriptionText:SetTextColor(ColorAlpha(gRust.Colors.Text, 100))
    DescriptionText:SetWrap(true)

	local Info = self:Add("DPanel")
	Info:Dock(FILL)
	Info.Paint = function(me, w, h)
		surface.SetMaterial(Material("materials/ui/background.png"))
		surface.SetDrawColor(126, 126, 126, 39)
		surface.DrawTexturedRect(0, 0, w, h)
	end
	
	local Icon = Info:Add("DImage")
	Icon:Dock(RIGHT)
	Icon:SetImage(ItemData:GetIcon())
	Icon:SetWide(ScrH() * 0.08)
	local IconMargin = ScrH() * 0.005
	Icon:DockMargin(IconMargin, IconMargin, IconMargin, IconMargin)
end

function PANEL:Clear()
    for k, v in pairs(self:GetChildren()) do
        v:Remove()
    end
end

vgui.Register("gRust.ItemData", PANEL, "Panel")