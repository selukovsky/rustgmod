util.AddNetworkString("gRust.RadiationDamage")
util.AddNetworkString("gRust.RadiationLevel")
util.AddNetworkString("gRust.SafeZoneEnter")
util.AddNetworkString("gRust.SafeZoneExit")
util.AddNetworkString("gRust.ZonesSync")
util.AddNetworkString("gRust.RadiationSound")

-- Конфигурация зон
local RADIATION_ZONES = {
    { pos = Vector(4434.614746, 974.438416, 560.031250), radius = 1000, damage = 3, requiredItems = {"hazmatsuit"}, sound = "rust/geiger_hh.wav" },
    { pos = Vector(5060.912109, 116.745377, 560.031250), radius = 1000, damage = 3, requiredItems = {"hazmatsuit"}, sound = "rust/geiger_hh.wav" },
    { pos = Vector(6727.396973, 221.616531, 560.031250), radius = 1000, damage = 3, requiredItems = {"hazmatsuit"}, sound = "rust/geiger_hh.wav" },
    { pos = Vector(2874.051270, 1046.997681, 560.031250), radius = 1000, damage = 3, requiredItems = {"hazmatsuit"}, sound = "rust/geiger_hh.wav" }
}

local SAFE_ZONES = {
    { pos = Vector(1000, 1000, 0), radius = 500 }
}

local PlayerRadiation = {}
local PlayerRadiationSounds = {}

-- ================================
-- RUST_SAFEZONE ENTITY
-- ================================

-- Регистрация brush entity для rust_safezone
local ENT = {}
ENT.Type = "brush"
ENT.Base = "base_brush"
ENT.PrintName = "Rust Safe Zone"
ENT.Author = "GRust"
ENT.Contact = ""
ENT.Purpose = "Безопасная зона"
ENT.Instructions = "Размещается в Hammer Editor как brush entity"
ENT.Category = "GRust"
ENT.Spawnable = false
ENT.AdminOnly = false

function ENT:Initialize()
    self:SetSolid(SOLID_BSP)
    self:SetMoveType(MOVETYPE_PUSH)
    self:SetUse(self.Use)

    -- Делаем триггером
    self:SetTrigger(true)

    -- Невидимый
    self:SetNoDraw(true)

    -- Настройки для brush entity
    if self:GetModel() then
        self:SetModel(self:GetModel())
    end

    -- Параметры по умолчанию
    self.WelcomeMessage = "Добро пожаловать в безопасную зону!"
    self.ExitMessage = "Вы покинули безопасную зону. Будьте осторожны!"
    self.WelcomeSound = "buttons/butto9.wav"
    self.ExitSound = "buttons/butt10.wav"
    self.NoDamage = true
    self.NoWeapons = true
    self.NoBuild = false

    print("[GRust] Создана безопасная зона: " .. tostring(self))
end

function ENT:StartTouch(ent)
    if not IsValid(ent) then return end

    if ent:IsPlayer() then
        -- Игрок вошел в безопасную зону
        ent.InSafeZone = true
        ent.InSafeZoneEntity = self
        ent.SafeZoneEnterTime = CurTime()

        -- Принудительно убираем оружие
        if self.NoWeapons and IsValid(ent:GetActiveWeapon()) then
            ent:SelectWeapon("")
        end

        -- Уведомляем игрока
        if self.WelcomeMessage and self.WelcomeMessage ~= "" then
            ent:ChatPrint(self.WelcomeMessage)
        end

        -- Звук входа
        if self.WelcomeSound and self.WelcomeSound ~= "" then
            ent:EmitSound(self.WelcomeSound)
        end

        -- Отправляем на клиент
        net.Start("gRust.SafeZoneEnter")
        net.WriteEntity(self)
        net.WriteString(self.WelcomeMessage or "Добро пожаловать в безопасную зону!")
        net.WriteBool(self.NoWeapons or false)
        net.WriteBool(self.NoBuild or false)
        net.Send(ent)

        -- Вызываем хук для других аддонов
        hook.Call("PlayerEnteredSafeZone", GAMEMODE, ent, self)

        print("[GRust] " .. ent:Name() .. " вошел в безопасную зону")

    elseif ent:IsNPC() or ent:IsNextBot() then
        -- НПС в безопасной зоне становятся дружелюбными
        ent.InSafeZone = true
        ent.OriginalRelationship = ent:Disposition(LocalPlayer())
        ent:AddEntityRelationship(ents.GetAll(), D_LI, 99)
    end
end

function ENT:EndTouch(ent)
    if not IsValid(ent) then return end

    if ent:IsPlayer() then
        -- Игрок покинул безопасную зону
        ent.InSafeZone = false
        ent.InSafeZoneEntity = nil
        ent.SafeZoneEnterTime = nil

        -- Уведомляем игрока
        if self.ExitMessage and self.ExitMessage ~= "" then
            ent:ChatPrint(self.ExitMessage)
        end

        -- Звук выхода
        if self.ExitSound and self.ExitSound ~= "" then
            ent:EmitSound(self.ExitSound)
        end

        -- Отправляем на клиент
        net.Start("gRust.SafeZoneExit")
        net.WriteEntity(self)
        net.WriteString(self.ExitMessage or "Вы покинули безопасную зону.")
        net.Send(ent)

        -- Вызываем хук для других аддонов
        hook.Call("PlayerLeftSafeZone", GAMEMODE, ent, self)

        print("[GRust] " .. ent:Name() .. " покинул безопасную зону")

    elseif ent:IsNPC() or ent:IsNextBot() then
        -- Восстанавливаем отношения НПС
        ent.InSafeZone = false
        if ent.OriginalRelationship then
            ent:ClearEntityRelationship(ents.GetAll())
        end
    end
end

function ENT:Touch(ent)
    if not IsValid(ent) then return end

    if ent:IsPlayer() then
        -- Постоянно обновляем статус пока игрок в зоне
        ent.InSafeZone = true
        ent.InSafeZoneEntity = self

        -- Принудительно убираем оружие каждую секунду
        if self.NoWeapons and IsValid(ent:GetActiveWeapon()) and (ent.LastWeaponCheck or 0) + 1 < CurTime() then
            ent:SelectWeapon("")
            ent.LastWeaponCheck = CurTime()
        end
    end
end

function ENT:KeyValue(key, value)
    -- Параметры из Hammer Editor
    if key == "welcome_message" then
        self.WelcomeMessage = value
    elseif key == "exit_message" then
        self.ExitMessage = value
    elseif key == "welcome_sound" then
        self.WelcomeSound = value
    elseif key == "exit_sound" then
        self.ExitSound = value
    elseif key == "no_damage" then
        self.NoDamage = tobool(value)
    elseif key == "no_weapons" then
        self.NoWeapons = tobool(value)
    elseif key == "no_build" then
        self.NoBuild = tobool(value)
    elseif key == "zone_name" then
        self.ZoneName = value
    end
end

function ENT:AcceptInput(inputName, activator, caller, data)
    if inputName == "Enable" then
        self:SetNoDraw(true)
        self:SetSolid(SOLID_BSP)
        self:SetTrigger(true)
        return true
    elseif inputName == "Disable" then
        self:SetNoDraw(true)
        self:SetSolid(SOLID_NONE)
        self:SetTrigger(false)
        return true
    end

    return false
end

-- Регистрируем entity
scripted_ents.Register(ENT, "rust_safezone")

-- ================================
-- ОСНОВНАЯ ЛОГИКА ЗОН
-- ================================

local function ManageRadiationSound(ply, playSound, zone)
    if not IsValid(ply) then return end
    local steamID = ply:SteamID()

    if playSound then
        if not PlayerRadiationSounds[steamID] or not PlayerRadiationSounds[steamID].playing then
            net.Start("gRust.RadiationSound")
            net.WriteBool(true)
            net.WriteString(zone.sound or "rust/geiger_hh.wav")
            net.Send(ply)
            PlayerRadiationSounds[steamID] = { playing = true, zone = zone.name, startTime = CurTime() }
        end
    else
        if PlayerRadiationSounds[steamID] and PlayerRadiationSounds[steamID].playing then
            net.Start("gRust.RadiationSound")
            net.WriteBool(false)
            net.Send(ply)
            PlayerRadiationSounds[steamID].playing = false
            PlayerRadiationSounds[steamID].zone = nil
        end
    end
end

local function HasRadiationProtection(ply)
    if ply:HasItem("hazmatsuit", 1) then return true end
    if ply:HasItem("shoes", 1) and ply:HasItem("pantsg", 1) and ply:HasItem("hoodieblue", 1) then return true end
    if ply:HasItem("woodentors", 1) and ply:HasItem("woodenpants", 1) and ply:HasItem("burlap.pants", 1) and ply:HasItem("burlap.shirt", 1) then return true end
    return false
end

-- Основной таймер обработки зон
timer.Create("RadiationZonesThink", 1, 0, function()
    for _, ply in ipairs(player.GetAll()) do
        if not ply:Alive() then
            PlayerRadiation[ply] = PlayerRadiation[ply] or {}
            PlayerRadiation[ply].level = 0

            net.Start("gRust.RadiationLevel")
            net.WriteUInt(0, 16)
            net.Send(ply)

            if PlayerRadiationSounds[ply:SteamID()] then
                PlayerRadiationSounds[ply:SteamID()].playing = false
            end
            continue
        end

        local inRadiationZone = false
        local currentRadiationZone = nil

        -- Проверяем радиационные зоны
        for _, zone in ipairs(RADIATION_ZONES) do
            if ply:GetPos():Distance(zone.pos) <= zone.radius then
                inRadiationZone = true
                currentRadiationZone = zone
                PlayerRadiation[ply] = PlayerRadiation[ply] or { level = 0 }

                -- Если игрок в безопасной зоне, не получает урон от радиации
                if not ply.InSafeZone and not HasRadiationProtection(ply) then
                    PlayerRadiation[ply].level = math.min(PlayerRadiation[ply].level + 1, 180)

                    if not PlayerRadiation[ply].lastDamage then PlayerRadiation[ply].lastDamage = 0 end
                    if CurTime() - PlayerRadiation[ply].lastDamage >= 1 then
                        ply:TakeDamage(zone.damage, game.GetWorld(), game.GetWorld())
                        ply:EmitSound("ambient/energy1.wav")
                        PlayerRadiation[ply].lastDamage = CurTime()
                    end
                end
                break
            end
        end

        local level = (inRadiationZone and PlayerRadiation[ply].level) or 0
        net.Start("gRust.RadiationLevel")
        net.WriteUInt(level, 16)
        net.Send(ply)

        if inRadiationZone and currentRadiationZone and not ply.InSafeZone then
            ManageRadiationSound(ply, true, currentRadiationZone)
        else
            ManageRadiationSound(ply, false)
            if PlayerRadiation[ply] then
                PlayerRadiation[ply].level = 0
            end
        end
    end
end)

-- ================================
-- МЕТОДЫ ДЛЯ PLAYER
-- ================================

local PLAYER = FindMetaTable("Player")

function PLAYER:GetRadiationLevel()
    return PlayerRadiation[self] and PlayerRadiation[self].level or 0
end

function PLAYER:SetRadiationLevel(level)
    PlayerRadiation[self] = PlayerRadiation[self] or {}
    PlayerRadiation[self].level = math.Clamp(level, 0, 180)
end

function PLAYER:IsInSafeZone()
    return self.InSafeZone or false
end

function PLAYER:GetSafeZoneEntity()
    return self.InSafeZoneEntity
end

function PLAYER:GetTimeInSafeZone()
    if not self.InSafeZone or not self.SafeZoneEnterTime then return 0 end
    return CurTime() - self.SafeZoneEnterTime
end

-- ================================
-- ХУКИ И СОБЫТИЯ
-- ================================

-- Хуки для обработки событий безопасных зон
hook.Add("PlayerEnteredSafeZone", "RustSafeZoneHandler", function(ply, zone)
    -- Дополнительная логика при входе в безопасную зону
end)

hook.Add("PlayerLeftSafeZone", "RustSafeZoneHandler", function(ply, zone)
    -- Дополнительная логика при выходе из безопасной зоны
end)

-- Защита от урона в безопасной зоне
hook.Add("EntityTakeDamage", "SafeZoneProtection", function(target, dmginfo)
    if target:IsPlayer() and target.InSafeZone then
        local zone = target.InSafeZoneEntity
        if IsValid(zone) and zone.NoDamage then
            return true -- Блокируем урон
        end
    end
end)

-- Защита от строительства в безопасной зоне
hook.Add("CanPlayerBuild", "SafeZoneBuildCheck", function(ply, pos)
    if ply:IsInSafeZone() then
        local zone = ply:GetSafeZoneEntity()
        if IsValid(zone) and zone.NoBuild then
            ply:ChatPrint("Нельзя строить в безопасной зоне!")
            ply:EmitSound("buttons/button2.wav")
            return false
        end
    end
end)

-- Защита от применения оружия
hook.Add("PlayerSwitchWeapon", "SafeZoneWeaponCheck", function(ply, oldWeapon, newWeapon)
    if ply:IsInSafeZone() then
        local zone = ply:GetSafeZoneEntity()
        if IsValid(zone) and zone.NoWeapons and IsValid(newWeapon) then
            ply:ChatPrint("Оружие запрещено в безопасной зоне!")
            return true -- Блокируем смену оружия
        end
    end
end)

-- Очистка данных при выходе/смерти
hook.Add("PlayerDisconnected", "SafeZoneCleanup", function(ply)
    PlayerRadiation[ply] = nil
    ply.InSafeZone = nil
    ply.InSafeZoneEntity = nil
    ply.SafeZoneEnterTime = nil
    ManageRadiationSound(ply, false)
    PlayerRadiationSources[ply:SteamID()] = nil
end)

hook.Add("PlayerDeath", "SafeZoneDeathCleanup", function(ply)
    if PlayerRadiation[ply] then
        PlayerRadiation[ply].level = math.max(PlayerRadiation[ply].level - 30, 0)
    end
    ManageRadiationSound(ply, false)
end)

-- Синхронизируем зоны при загрузке карты
hook.Add("InitPostEntity", "SyncZones", function()
    timer.Simple(1, function()
        net.Start("gRust.ZonesSync")
        net.WriteTable(RADIATION_ZONES)
        net.WriteTable(SAFE_ZONES)
        net.Broadcast()
    end)
end)

hook.Add("PlayerInitialSpawn", "SyncZonesForPlayer", function(ply)
    timer.Simple(2, function()
        if IsValid(ply) then
            net.Start("gRust.ZonesSync")
            net.WriteTable(RADIATION_ZONES)
            net.WriteTable(SAFE_ZONES)
            net.Send(ply)
        end
    end)
end)
