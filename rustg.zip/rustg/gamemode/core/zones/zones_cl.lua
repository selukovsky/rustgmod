local radiationLevel = 0
local lastDamageTime = 0
local RadiationSound = nil
local RadiationSoundChannel = nil
local inSafeZone = false

net.Receive("gRust.RadiationDamage", function()
    local damage = net.ReadUInt(8)
    lastDamageTime = CurTime()
end)

net.Receive("gRust.SafeZoneNotify", function()
    inSafeZone = net.ReadBool()
end)

net.Receive("gRust.RadiationSound", function()
    local playSound = net.ReadBool()
    
    if playSound then
        local soundPath = net.ReadString()
        
        -- Выключаем предыдущий звук если есть
        if RadiationSound then
            RadiationSound:Stop()
            RadiationSound = nil
        end
        
        -- Включаем новый звук
        RadiationSound = CreateSound(LocalPlayer(), soundPath)
        if RadiationSound then
            RadiationSound:PlayEx(0.7, 100) -- Громкость 70%, нормальная высота тона
        end
    else
        -- Выключаем звук
        if RadiationSound then
            RadiationSound:Stop()
            RadiationSound = nil
        end
    end
end)

-- Очистка звука при отключении
hook.Add("OnPlayerDisconnected", "RadiationSoundCleanup", function()
    if RadiationSound then
        RadiationSound:Stop()
        RadiationSound = nil
    end
end)