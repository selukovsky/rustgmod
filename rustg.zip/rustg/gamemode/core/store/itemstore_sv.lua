util.AddNetworkString("Store.RequestData")
util.AddNetworkString("Store.UpdateData")
util.AddNetworkString("Store.BuyItem")
util.AddNetworkString("Store.PurchaseResponse")

local StoreItems = {
    {
        id = "ak47_tempered",
        title = "TEMPERED",
        subtitle = "ITEM SKIN",
        price = {
            { class = "scrap", amount = 150, icon = "materials/icons/scrap.png" },
            { class = "cloth", amount = 50, icon = "materials/icons/cloth.png" }
        },
        category = "limited",
        description = "Rare tempered skin for the AK-47 assault rifle.",
        icon = "materials/store/weapons/ak47_tempered.png",
        thumbnail = "materials/zohart/store/1/icon.png"
    },
    {
        id = "knife_carrot",
        title = "CARROT",
        subtitle = "ITEM SKIN",
        price = {
            { class = "scrap", amount = 50, icon = "materials/icons/scrap.png" }
        },
        category = "limited",
        description = "A novelty knife skin that looks like a carrot.",
        icon = "materials/zohart/store/4/icon.png"
    }
}

local PlayerData = {}

local function CreateTables()
    sql.Query([[CREATE TABLE IF NOT EXISTS player_balances (
        steamid TEXT PRIMARY KEY,
        balance INTEGER NOT NULL DEFAULT 1000
    )]])
    sql.Query([[CREATE TABLE IF NOT EXISTS store_purchases (
        steamid TEXT,
        itemid TEXT,
        price INTEGER,
        purchased_at INTEGER,
        UNIQUE(steamid, itemid)
    )]])
end
CreateTables()

local function GetPlayerStoreData(ply)
    local steamid = ply:SteamID64()
    PlayerData[steamid] = PlayerData[steamid] or {
        balance = 1000,
        ownedItems = {},
        lastPurchase = 0
    }
    return PlayerData[steamid]
end

local function LoadPlayerData(ply)
    local steamid = ply:SteamID64()
    local data = GetPlayerStoreData(ply)
    
    local balanceResult = sql.Query("SELECT balance FROM player_balances WHERE steamid = " .. SQLStr(steamid))
    if balanceResult and balanceResult[1] then
        data.balance = tonumber(balanceResult[1].balance) or 1000
    else
        sql.Query("INSERT OR IGNORE INTO player_balances (steamid, balance) VALUES (" .. SQLStr(steamid) .. ", 1000)")
        data.balance = 1000
    end
    
    local purchasesResult = sql.Query("SELECT itemid FROM store_purchases WHERE steamid = " .. SQLStr(steamid))
    if purchasesResult then
        data.ownedItems = {}
        for _, v in ipairs(purchasesResult) do
            data.ownedItems[v.itemid] = true
        end
    end
end

local function SavePlayerData(ply)
    local steamid = ply:SteamID64()
    local data = GetPlayerStoreData(ply)
    sql.Query("INSERT OR REPLACE INTO player_balances (steamid, balance) VALUES (" .. SQLStr(steamid) .. ", " .. data.balance .. ")")
end

hook.Add("PlayerInitialSpawn", "Store.LoadPlayerData", function(ply)
    timer.Simple(2, function()
        if IsValid(ply) then
            LoadPlayerData(ply)
        end
    end)
end)

hook.Add("PlayerDisconnected", "Store.SavePlayerData", function(ply)
    if IsValid(ply) then
        SavePlayerData(ply)
        PlayerData[ply:SteamID64()] = nil
    end
end)

local function GetStoreItemsForPlayer(ply)
    local data = GetPlayerStoreData(ply)
    local itemsWithOwnedStatus = {}
    for _, item in ipairs(StoreItems) do
        local clone = table.Copy(item)
        clone.owned = data.ownedItems[item.id] or false
        table.insert(itemsWithOwnedStatus, clone)
    end
    return itemsWithOwnedStatus
end

net.Receive("Store.RequestData", function(len, ply)
    if not IsValid(ply) then return end
    local items = GetStoreItemsForPlayer(ply)
    local data = GetPlayerStoreData(ply)
    
    net.Start("Store.UpdateData")
    net.WriteTable(items)
    net.WriteInt(data.balance, 32)
    net.Send(ply)
end)

net.Receive("Store.BuyItem", function(len, ply)
    if not IsValid(ply) then return end
    local itemId = net.ReadString()
    local data = GetPlayerStoreData(ply)
    local currentTime = CurTime()
    
    -- Проверка частоты покупок
    if currentTime - (data.lastPurchase or 0) < 3 then
        net.Start("Store.PurchaseResponse")
        net.WriteBool(false)
        net.WriteString("Подождите немного перед следующей покупкой.")
        net.WriteInt(data.balance, 32)
        net.Send(ply)
        return
    end
    
    local item = nil
    for _, storeItem in ipairs(StoreItems) do
        if storeItem.id == itemId then
            item = storeItem
            break
        end
    end
    
    if not item then
        net.Start("Store.PurchaseResponse")
        net.WriteBool(false)
        net.WriteString("Предмет не найден.")
        net.WriteInt(data.balance, 32)
        net.Send(ply)
        return
    end
    
    if data.ownedItems[itemId] then
        net.Start("Store.PurchaseResponse")
        net.WriteBool(false)
        net.WriteString("У вас уже есть этот предмет.")
        net.WriteInt(data.balance, 32)
        net.Send(ply)
        return
    end
    
    -- Проверяем ресурсы оплаты
    for _, cost in ipairs(item.price) do
        if not ply:HasItem(cost.class, cost.amount) then
            net.Start("Store.PurchaseResponse")
            net.WriteBool(false)
            net.WriteString("Недостаточно " .. cost.class .. " для покупки.")
            net.WriteInt(data.balance, 32)
            net.Send(ply)
            return
        end
    end
    
    -- Проверяем место в инвентаре
    if not ply:GiveItem(item.id, 1) then
        net.Start("Store.PurchaseResponse")
        net.WriteBool(false)
        net.WriteString("Нет свободного места в инвентаре.")
        net.WriteInt(data.balance, 32)
        net.Send(ply)
        return
    end
    
    -- Снимаем ресурсы оплаты
    for _, cost in ipairs(item.price) do
        ply:RemoveItem(cost.class, cost.amount)
    end
    
    data.ownedItems[itemId] = true
    data.lastPurchase = currentTime
    SavePlayerData(ply)
    
    net.Start("Store.PurchaseResponse")
    net.WriteBool(true)
    net.WriteString("Вы успешно купили " .. item.title .. "!")
    net.WriteInt(data.balance, 32)
    net.Send(ply)
    
    hook.Run("Store.PlayerPurchased", ply, item)
end)