util.AddNetworkString("gRust.UnloadAmmo")

net.Receive("gRust.UnloadAmmo", function(len, pl)
    local ent = net.ReadEntity()
    local slot = net.ReadUInt(6)
    if not IsValid(pl) or not IsValid(ent) then return end
    if ent ~= pl and ent:GetPos():Distance(pl:GetPos()) > 200 then return end
    if not ent.Inventory or not ent.Inventory[slot] then return end

    local item = ent.Inventory[slot]
    local itemData = gRust.Items[item:GetItem()]
    if not itemData then return end

    local weaponClass = itemData:GetWeapon()
    local weaponTable = weapons.Get(weaponClass)
    if not weaponTable then return end

    -- Определяем текущий тип боеприпасов
    local currentAmmoType = weaponTable.Ammo -- базовый тип по умолчанию
    local ammoCount = item:GetClip() or 0
    
    -- Приоритет 1: оружие в руках
    local activeWeapon = pl:GetActiveWeapon()
    if IsValid(activeWeapon) and activeWeapon:GetClass() == weaponClass then
        local weaponAmmoType = activeWeapon:GetCurrentAmmoType()
        if weaponAmmoType and weaponAmmoType ~= "" then
            currentAmmoType = weaponAmmoType
            print(string.format("[UNLOAD AMMO] Using ammo type from active weapon: %s", currentAmmoType))
        end
    -- Приоритет 2: сохраненный тип в предмете
    elseif item.AmmoType then
        currentAmmoType = item.AmmoType
        print(string.format("[UNLOAD AMMO] Using ammo type from item: %s", currentAmmoType))
    end

    if ammoCount <= 0 then 
        print("[UNLOAD AMMO] No ammo to unload")
        return 
    end

    -- Проверяем что тип боеприпасов валиден
    if not currentAmmoType or currentAmmoType == "" then
        currentAmmoType = weaponTable.Ammo
    end

    print(string.format("[UNLOAD AMMO] Unloading %d rounds of type %s", ammoCount, currentAmmoType))

    -- Опустошаем обойму
    item:SetClip(0)
    
    -- ВАЖНО: Сохраняем тип боеприпасов в предмете оружия
    if currentAmmoType ~= weaponTable.Ammo then
        item.AmmoType = currentAmmoType
        print(string.format("[UNLOAD AMMO] Saved ammo type in item: %s", currentAmmoType))
    end
    
    ent:SyncSlot(slot)

    -- Обновляем оружие в руках (только клип, тип не сбрасываем)
    if IsValid(activeWeapon) and activeWeapon:GetClass() == weaponClass then
        activeWeapon:SetClip1(0)
        -- НЕ сбрасываем тип боеприпасов в оружии!
        print("[UNLOAD AMMO] Updated clip in active weapon")
    end

    -- Отдаем патроны
    if pl:GiveItem(currentAmmoType, ammoCount) then
        print(string.format("[UNLOAD AMMO] Successfully returned %d rounds of %s", ammoCount, currentAmmoType))
    else
        print("[UNLOAD AMMO] Failed to return ammo to player")
    end
end)