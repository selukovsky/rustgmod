util.AddNetworkString("gRust.TechTreeBuy")
util.AddNetworkString("gRust.UpdateTechTree")
util.AddNetworkString("gRust.OpenTechTree")
util.AddNetworkString("gRust.SyncBlueprints")
util.AddNetworkString("gRust.RequestBlueprintSync")

-- Добавляем базовые чертежи, которые не требуют изучения
local function AddBasicBlueprints(ply)
    if not IsValid(ply) then return end

    if not ply.Blueprints then
        ply.Blueprints = {}
    end

    for itemClass, itemData in pairs(gRust.Items) do
        if not itemData:GetBlueprint() then
            if not ply.Blueprints[itemClass] then
                ply:AddBlueprint(itemClass)
                ply.Blueprints[itemClass] = true
                gRust_BPDB.Add(ply:SteamID64(), itemClass)
            end
        end
    end
end

-- Загружаем чертежи игрока из новой базы данных
local function LoadPlayerBlueprints(ply)
    if not IsValid(ply) then return end

    ply.Blueprints = gRust_BPDB.GetAll(ply:SteamID64()) or {}

    for class, _ in pairs(ply.Blueprints) do
        ply:AddBlueprint(class)
    end

    AddBasicBlueprints(ply)

    timer.Simple(1, function()
        if IsValid(ply) then
            if ply.SyncBlueprints then
                ply:SyncBlueprints()
            end
        end
    end)
end

-- Проверяем, можно ли добраться до нужного предмета по древу технологий
local function HasPathToItem(ply, tree, targetItem, visited)
    visited = visited or {}

    for _, v in ipairs(tree) do
        if not v.Item then continue end

        if visited[v.Item] then continue end
        visited[v.Item] = true

        if v.Item == targetItem then
            return true
        end

        if ply:HasBlueprint(v.Item) and v.Branch then
            if HasPathToItem(ply, v.Branch, targetItem, visited) then
                return true
            end
        end

        if (not v.RequiredItem or ply:HasBlueprint(v.RequiredItem)) then
            if v.Branch and HasPathToItem(ply, v.Branch, targetItem, visited) then
                return true
            end
        end
    end

    return false
end

-- Получаем стоимость предмета по древу
local function GetItemCost(itemClass)
    return gRust.TechTree[itemClass] or 0
end

-- Проверка, хватает ли лома (scrap)
local function HasEnoughScrap(ply, cost)
    if not ply.Inventory then return false end

    local scrapAmount = 0

    for i = 1, ply.InventorySlots do
        local item = ply.Inventory[i]
        if item and item:GetItem() == "scrap" then
            scrapAmount = scrapAmount + item:GetQuantity()
        end
    end

    return scrapAmount >= cost
end

-- Снимаем лом со слотов
local function TakeScrap(ply, amount)
    if not ply.Inventory then return false end

    local remaining = amount

    for i = 1, ply.InventorySlots do
        local item = ply.Inventory[i]
        if item and item:GetItem() == "scrap" and remaining > 0 then
            local itemAmount = item:GetQuantity()
            local toTake = math.min(itemAmount, remaining)

            if ply:RemoveItem("scrap", toTake) then
                remaining = remaining - toTake
            end

            if remaining <= 0 then break end
        end
    end

    return remaining <= 0
end

-- Обработчик принудительной синхронизации
net.Receive("gRust.RequestBlueprintSync", function(_, ply)
    if IsValid(ply) and ply.SyncBlueprints then
        print("[SYNC] Manual blueprint sync requested by ", ply:Nick())
        ply:SyncBlueprints()
    end
end)

-- Покупка чертежа через древо технологий
net.Receive("gRust.TechTreeBuy", function(_, ply)
    local itemClass = net.ReadString()
    local entity = net.ReadEntity()

    if not IsValid(ply) or not IsValid(entity) then return end
    if not itemClass or itemClass == "" then return end

    if entity:GetPos():Distance(ply:GetPos()) > 200 then
        ply:ChatPrint("You are too far from the research table!")
        return
    end

    local itemData = gRust.Items[itemClass]
    if not itemData then
        ply:ChatPrint("Unknown item!")
        return
    end

    if not itemData:GetBlueprint() then
        ply:ChatPrint("This item doesn't require learning!")
        return
    end

    if ply:HasBlueprint(itemClass) then
        ply:ChatPrint("You already know this blueprint!")
        return
    end

    local techTree = entity.TechTree
    if not techTree then
        ply:ChatPrint("This research table has no tech tree!")
        return
    end

    if not HasPathToItem(ply, techTree, itemClass) then
        ply:ChatPrint("You cannot learn this item! Learn the required previous technologies.")
        return
    end

    local cost = GetItemCost(itemClass)
    if cost <= 0 then
        ply:ChatPrint("Item cost is not defined!")
        return
    end

    if not HasEnoughScrap(ply, cost) then
        ply:ChatPrint("You don't have enough scrap! Required: " .. cost)
        return
    end

    if not TakeScrap(ply, cost) then
        ply:ChatPrint("Failed to deduct scrap!")
        return
    end

    ply:AddBlueprint(itemClass)
    ply.Blueprints[itemClass] = true

    gRust_BPDB.Add(ply:SteamID64(), itemClass)

    ply:ChatPrint("You learned: " .. itemData:GetName() .. " for " .. cost .. " scrap!")

    -- Синхронизируем чертежи с клиентом
    if ply.SyncBlueprints then
        ply:SyncBlueprints()
    end

    net.Start("gRust.UpdateTechTree")
    net.Send(ply)

    ply:EmitSound("buttons/button14.wav", 50, 100)
end)

-- Открытие древа технологий
hook.Add("PlayerUse", "gRust.TechTreeUse", function(ply, ent)
    if not ent.TechTree then return end

    if not ply.TechTreeCooldown then
        ply.TechTreeCooldown = 0
    end

    if CurTime() < ply.TechTreeCooldown then
        return false
    end

    ply.TechTreeCooldown = CurTime() + 0.5 -- 0.5 сек кулдаун

    net.Start("gRust.OpenTechTree")
    net.WriteEntity(ent)
    net.Send(ply)

    return false
end)

-- Загружаем чертежи при входе игрока
hook.Add("PlayerAuthed", "gRust.LoadPlayerBlueprints", function(ply, steamid)
    timer.Simple(3, function()
        if IsValid(ply) then
            LoadPlayerBlueprints(ply)
        end
    end)
end)