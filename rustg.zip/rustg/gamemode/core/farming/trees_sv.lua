Logger("Loading mining system")
hook.Add("PlayerSpawn", "FixSpawnShiz", function(ply)
    for k, v in pairs(ents.FindInSphere(ply:GetPos(), 10)) do
        if v:GetClass() == "rust_ore" then ply:SetPos(v:GetPos() + Vector(v:OBBMins().x, v:OBBMins().y, v:OBBMins().z + 12)) end
    end
end)

local WOOD_WEAPONS = {
    ["rust_rock"] = {
        mult = 1
    },
    ["rust_stonehatchet"] = {
        mult = 1.3
    },
    ["rust_betonhatchet"] = {
        mult = 1.3
    },
    ["rust_prothatchet"] = {
        mult = 1.8
    },
    ["rust_fronthatchet"] = {
        mult = 1.8
    },
    ["rust_hatchet"] = {
        mult = 1.8
    }
}

local WOOD_SEQ = {5, 10, 20, 32, 43, 55, 68, 83, 99, 128}
gRust.Mining.IsValidWoodcuttingTool = function(weaponClass) return WOOD_WEAPONS[weaponClass] ~= nil end
local function MakeTreeFall(ent)
    if not IsValid(ent) then return end
    ent:EmitSound("farming/tree_fall_" .. math.random(1, 2) .. ".wav")
    local treePos = ent:GetPos()
    local treeAngles = ent:GetAngles()
    local treeModel = ent:GetModel()
    ent:SetMoveType(MOVETYPE_VPHYSICS)
    ent:SetSolid(SOLID_VPHYSICS)
    ent:PhysicsInit(SOLID_VPHYSICS)
    ent:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
    local phys = ent:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(800)
        local fallDirection = Angle(0, math.random(0, 360), 0):Forward()
        fallDirection.z = 0
        fallDirection:Normalize()
        local torque = Vector(fallDirection.y, -fallDirection.x, 0) * 3000
        phys:ApplyTorqueCenter(torque)
        local push = fallDirection * 100
        push.z = -50
        phys:ApplyForceCenter(push)
        phys:SetMass(800)
    end

    timer.Simple(4, function()
        if IsValid(ent) then
            local alpha = 255
            local fadeTimer = "tree_fade_" .. ent:EntIndex()
            timer.Create(fadeTimer, 0.1, 40, function()
                if IsValid(ent) then
                    alpha = alpha - 6.375
                    ent:SetColor(Color(255, 255, 255, math.max(0, alpha)))
                    ent:SetRenderMode(RENDERMODE_TRANSALPHA)
                    if alpha <= 0 then
                        timer.Remove(fadeTimer)
                        ent:Remove()
                    end
                else
                    timer.Remove(fadeTimer)
                end
            end)
        end
    end)

    timer.Simple(math.random(600, 900), function()
        local newTree = ents.Create("rust_trees")
        if IsValid(newTree) then
            newTree:SetModel(treeModel)
            newTree:SetPos(treePos)
            newTree:SetAngles(treeAngles)
            newTree:Spawn()
            newTree:Activate()
            newTree.treeHealth = nil
            newTree.treeHits = nil
        end
    end)
end

gRust.Mining.MineTrees = function(ply, ent, maxHP, weapon, class, isBonusHit)
    local tool = WOOD_WEAPONS[class]
    if not tool then return end
    if not ent.treeHealth then ent.treeHealth, ent.treeHits = maxHP, 0 end
    if not ent.Multiplier then ent.Multiplier = 1 end

    ent.treeHealth, ent.treeHits = ent.treeHealth - 20, ent.treeHits + 1
    local idx = math.min(ent.treeHits, #WOOD_SEQ)
    local reward = math.Round(WOOD_SEQ[idx] * tool.mult)

    if isBonusHit then
        local bonusReward = math.Round(reward * ent.Multiplier)
        ply:GiveItem("wood", bonusReward)
        ply:SyncInventory()
        ent.Multiplier = ent.Multiplier + 0.03
    else
        ply:GiveItem("wood", reward)
        ply:SyncInventory()
    end

    if ent.treeHealth <= 0 then MakeTreeFall(ent) end
end