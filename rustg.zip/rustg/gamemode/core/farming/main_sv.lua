gRust = gRust or {}
gRust.Mining = gRust.Mining or {}
util.AddNetworkString("gRust.TreeEffects")
local TREE_MODELS = {
    ["models/zohart/trees/american_beech_a.mdl"] = 220,
    ["models/zohart/trees/american_beech_b.mdl"] = 190,
    ["models/zohart/trees/american_beech_d.mdl"] = 140,
    ["models/zohart/trees/american_beech_c.mdl"] = 220,
    ["models/zohart/trees/american_beech_e.mdl"] = 160,
    ["models/zohart/trees/birch_medium.mdl"] = 180,
    ["models/zohart/trees/birch_small.mdl"] = 190,
    ["models/zohart/trees/oak_d.mdl"] = 140,
    ["models/zohart/trees/oak_e.mdl"] = 170,
    ["models/zohart/trees/oak_f.mdl"] = 150,
    ["models/zohart/trees/pine_a_snow.mdl"] = 170,
    ["models/zohart/trees/pine_b_snow.mdl"] = 190
}

local CREATURES_ENTITIES = {
    ["npc_vj_f_killerchicken"] = true
}

local HOTSPOT_RADIUS = 30

local function SendTreeHit(ent, hitPos, angles)
    if not IsValid(ent) then return end

    net.Start("gRust.TreeEffects")
    net.WriteVector(hitPos)
    net.WriteAngle(angles)
    net.WriteEntity(ent)
    net.Broadcast()
end

local WOOD_WEAPONS = {
    ["rust_rock"] = {
        mult = 1
    },
    ["rust_stonehatchet"] = {
        mult = 1.3
    },
    ["rust_betonhatchet"] = {
        mult = 1.3
    },
    ["rust_prothatchet"] = {
        mult = 1.8
    },
    ["rust_fronthatchet"] = {
        mult = 1.8
    },
    ["rust_hatchet"] = {
        mult = 1.8
    }
}

hook.Add("EntityTakeDamage", "gRust.ResourceHits", function(ent, dmg)
    local ply = dmg:GetAttacker()
    if not IsValid(ply) or not ply:IsPlayer() then return end

    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) then return end
    local class = wep:GetClass()

    local maxHP = TREE_MODELS[ent:GetModel()]
    if maxHP then
        local validTool = gRust.Mining.IsValidWoodcuttingTool(class)
        if not validTool then
            dmg:SetDamage(0)
            return true
        end

        LoggerPlayer(ply, "is damaging a tree")

        local hitPos = dmg:GetDamagePosition()

        if not ent.HotspotPos then
            ent.HotspotPos = hitPos
            SendTreeHit(ent, hitPos, ply:EyeAngles())
        end

        local isBonusHit = hitPos:Distance(ent.HotspotPos) < 8

        if isBonusHit then
            ent:EmitSound("farming/tree_spray.wav", 75, 100)
            ent:EmitSound("farming/tree_x_hit" .. math.random(1, 4) .. ".wav", 75, 100)

            local tr = util.TraceLine({
                start = ent:GetPos(),
                endpos = hitPos,
                filter = ent
            })
            local normal = tr.HitNormal

            local pushOut = normal * 5

            local right = normal:Angle():Right()
            local up = normal:Angle():Up()

            local randomSide = right * math.Rand(-3, 3)
            local randomUp   = up * math.Rand(-2, 2)

            local finalOffset = pushOut + randomSide + randomUp

            ent.HotspotPos = hitPos + finalOffset
            SendTreeHit(ent, ent.HotspotPos, ply:EyeAngles())
        end

        gRust.Mining.MineTrees(ply, ent, maxHP, wep, class, isBonusHit)
        return
    end

    if ent:GetClass() == "rust_creature_corpse" then
        gRust.Mining.MineCreatures(ply, ent, wep, class)
        return
    end

    if ent:GetClass() == "rust_ore" then
        local validTool = gRust.Mining.IsValidMiningTool(class)
        if not validTool then return true end
        LoggerPlayer(ply, "is mining ore.")
        gRust.Mining.MineOres(ply, ent, wep, class, dmg)
        return
    end
end)

hook.Add("OnNPCKilled", "gRust.CreatureCorpses", function(npc, attacker, inflictor)
    if CREATURES_ENTITIES[npc:GetClass()] then
        if gRust.Mining and gRust.Mining.SpawnCreatureCorpse then gRust.Mining.SpawnCreatureCorpse(npc) end
    end
end)

hook.Add("EntityTakeDamage", "gRust.MiningDamage", function(ent, dmginfo)
    if ent:GetClass() ~= "rust_ore" then return end
    
    local attacker = dmginfo:GetAttacker()
    if not IsValid(attacker) or not attacker:IsPlayer() then return end
    
    local weapon = attacker:GetActiveWeapon()
    if not IsValid(weapon) then return end
    
    local class = weapon:GetClass()
    if not gRust.Mining.IsValidMiningTool(class) then return end
    
    -- FIXED: Get hit position safely
    local hitPos = dmginfo:GetDamagePosition()
    if not hitPos then
        -- Fallback: use trace to get hit position
        local tr = util.TraceLine({
            start = attacker:EyePos(),
            endpos = attacker:EyePos() + attacker:GetAimVector() * 100,
            filter = attacker
        })
        hitPos = tr.HitPos
    end
    
    gRust.Mining.MineOres(attacker, ent, weapon, class, hitPos)
    
    return true
end)