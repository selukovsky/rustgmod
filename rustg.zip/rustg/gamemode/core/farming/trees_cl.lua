local treeCrosses = {}

local function TreeEffects()
    local hitPos = net.ReadVector()
    local angles = net.ReadAngle()
    local ent = net.ReadEntity()
    if not IsValid(ent) then return end

    treeCrosses[ent:EntIndex()] = {
        pos = hitPos,
        ang = angles,
        ent = ent
    }

    local effectdata = EffectData()
    effectdata:SetOrigin(hitPos)
    effectdata:SetEntity(ent)
    effectdata:SetSurfaceProp(9)
    effectdata:SetDamageType(2)
    util.Effect("GlassImpact", effectdata)
end

net.Receive("gRust.TreeEffects", TreeEffects)

local crossMaterial = Material("decals/decal_xspray_a_red.vtf", "smooth")

hook.Add("PostDrawOpaqueRenderables", "DrawTreeXMarker", function()
    for k, v in pairs(treeCrosses) do
        if not IsValid(v.ent) then
            treeCrosses[k] = nil
        else
            cam.Start3D2D(v.pos, Angle(0, v.ang.y - 90, 90), 0.25)
                surface.SetMaterial(crossMaterial)
                surface.SetDrawColor(255, 0, 0, 255)
                surface.DrawTexturedRectRotated(0, 0, 50, 50, 0)
            cam.End3D2D()
        end
    end
end)