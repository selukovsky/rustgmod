util.AddNetworkString("gRust.StartRevive")
util.AddNetworkString("gRust.CancelRevive")
util.AddNetworkString("gRust.ReviveFinished")

local WOUND_DURATION = 20
local revivingPlayers = {}

hook.Add("PlayerSpawn", "Wounded.Initialize", function(ply)
    ply:SetNWBool("isWounded", false)
    ply:SetNWFloat("woundRecoveryChance", 0)
    ply:SetNWInt("woundRemaining", 0)
    ply:SetNWInt("woundTotalTime", 0)

    if timer.Exists("Wounded_" .. ply:SteamID64()) then
        timer.Remove("Wounded_" .. ply:SteamID64())
    end
end)

local function ApplyWound(ply, duration, chance)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if ply:GetNWBool("isWounded") then return end

    if timer.Exists("Wounded_"..ply:SteamID64()) then
        timer.Remove("Wounded_"..ply:SteamID64())
    end

    hook.Run("PlayerWounded", ply)

    ply:SetNWBool("isWounded", true)
    ply:SetHealth(1) -- Ставим здоровье 1 вместо 0, чтобы игрок не умер

    ply:SetNWFloat("woundRecoveryChance", chance)
    ply:SetNWInt("woundTotalTime", duration)
    ply:SetNWInt("woundRemaining", CurTime() + duration)

    timer.Create("Wounded_"..ply:SteamID64(), duration, 1, function()
        if not IsValid(ply) then return end
        
        if not ply:GetNWBool("isWounded") then return end
        
        ply:SetNWBool("isWounded", false)

        if math.random(1, 100) <= chance then
            ply:SetHealth(math.random(18, 30))
            hook.Run("PlayerRecovered", ply)
        else
            ply:Kill()
        end
    end)
end

local function RevivePlayer(rescuer, wounded)
    if not IsValid(rescuer) or not IsValid(wounded) or not wounded:GetNWBool("isWounded") then return end

    wounded:SetNWBool("isWounded", false)
    wounded:SetHealth(30)

    wounded:SetWalkSpeed(200)
    wounded:SetRunSpeed(320)

    if timer.Exists("Wounded_" .. wounded:SteamID64()) then
        timer.Remove("Wounded_" .. wounded:SteamID64())
    end

    net.Start("gRust.ReviveFinished")
    net.WriteEntity(wounded)
    net.Broadcast()

    revivingPlayers[rescuer] = nil
end

hook.Add("KeyPress", "Wounded.ReviveAttempt", function(ply, key)
    if key ~= IN_USE then return end

    local trace = ply:GetEyeTrace()
    local ent = trace.Entity

    if not IsValid(ent) or not ent:IsPlayer() or not ent:GetNWBool("isWounded") then return end

    if revivingPlayers[ply] and revivingPlayers[ply] == ent then return end

    if timer.Exists("Wounded_" .. ent:SteamID64()) then
        timer.Remove("Wounded_" .. ent:SteamID64())
    end

    revivingPlayers[ply] = ent

    ply:SetNWVector("ReviveStartPosition", ply:GetPos())

    net.Start("gRust.StartRevive")
    net.WriteEntity(ent)
    net.Send(ply)

    timer.Create("ReviveTimer_" .. ply:SteamID64(), 5, 1, function()
        if not IsValid(ply) or not IsValid(ent) or revivingPlayers[ply] ~= ent then return end
        RevivePlayer(ply, ent)
    end)
end)

hook.Add("KeyRelease", "Wounded.CancelRevive", function(ply, key)
    if key ~= IN_USE then return end

    if revivingPlayers[ply] then
        local ent = revivingPlayers[ply]

        net.Start("gRust.CancelRevive")
        net.WriteEntity(ent)
        net.Send(ply)

        local duration = ent:GetNWInt("woundTotalTime", 0)
        ent:SetNWInt("woundRemaining", CurTime() + duration)

        timer.Create("Wounded_" .. ent:SteamID64(), duration, 1, function()
            if not IsValid(ent) then return end
            ent:SetNWBool("isWounded", false)

            if not ent:Alive() then return end

            if math.random(1, 100) <= ent:GetNWFloat("woundRecoveryChance", 0) then
                ent:SetHealth(30)
                hook.Run("PlayerRecovered", ent)
            else
                ent:Kill()
            end
        end)

        revivingPlayers[ply] = nil

        if timer.Exists("ReviveTimer_" .. ply:SteamID64()) then
            timer.Remove("ReviveTimer_" .. ply:SteamID64())
        end
    end
end)

hook.Add("EntityTakeDamage", "Wounded.CheckDamage", function(target, dmg)
    if not IsValid(target) or not target:IsPlayer() then return end
    if target:GetNWBool("isWounded") then return end

    if target:GetNWBool("IsSleeping") then
        if target:Health() - dmg:GetDamage() <= 0 then
            dmg:SetDamage(100)
            return
        end
    end

    -- Проверяем, будет ли урон смертельным
    if target:Health() - dmg:GetDamage() <= 0 then
        -- Предотвращаем смерть и накладываем ранение
        dmg:SetDamage(0)
        
        local attacker = dmg:GetAttacker()
        local baseChance = math.random(20, 50)
        
        -- Упрощенная логика расчета шанса восстановления
        local recoveryChance = baseChance
        
        -- Бонус если атакующий - NPC
        if IsValid(attacker) and attacker:IsNPC() then
            recoveryChance = math.min(baseChance + 15, 60)
        -- Бонус если атакующий - игрок
        elseif IsValid(attacker) and attacker:IsPlayer() then
            recoveryChance = math.min(baseChance + 10, 50)
        -- Урон от мира (падение, утопление и т.д.)
        else
            recoveryChance = math.min(baseChance + 5, 40)
        end
        
        ApplyWound(target, WOUND_DURATION, recoveryChance)
        return false -- Предотвращаем дальнейшую обработку урона
    end
end)

hook.Add("PlayerCanPickupWeapon", "Wounded.BlockPickup", function(ply)
    return not ply:GetNWBool("isWounded")
end)

hook.Add("PlayerUse", "Wounded.BlockUse", function(ply, ent)
    if ply:GetNWBool("isWounded") then
        return false
    end
end)

hook.Add("PlayerTick", "Wounded.ForceCrouch", function(ply)
    if ply:GetNWBool("isWounded") and ply:Alive() then
        if ply:KeyDown(IN_JUMP) then
            ply:SetNWBool("isWounded", false)
            return
        end

        ply:SetWalkSpeed(50)
        ply:SetRunSpeed(50)
    else
        ply:SetWalkSpeed(190)
        ply:SetRunSpeed(250)
    end
end)

hook.Add("PlayerWounded", "Wounded.RemoveWeapons", function(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    
    local weapons = ply:GetWeapons()
    for _, weapon in pairs(weapons) do
        if IsValid(weapon) then
            ply:StripWeapon(weapon:GetClass())
        end
    end
    
    ply:SelectWeapon("rust_hands")
end)

hook.Add("PlayerDeath", "Wounded.ClearReviveData", function(victim)
    if not IsValid(victim) then return end
    
    if timer.Exists("Wounded_" .. victim:SteamID64()) then
        timer.Remove("Wounded_" .. victim:SteamID64())
    end
    
    for rescuer, target in pairs(revivingPlayers) do
        if target == victim then
            if IsValid(rescuer) then
                net.Start("gRust.CancelRevive")
                net.WriteEntity(target)
                net.Send(rescuer)
            end

            revivingPlayers[rescuer] = nil

            if timer.Exists("ReviveTimer_" .. rescuer:SteamID64()) then
                timer.Remove("ReviveTimer_" .. rescuer:SteamID64())
            end
        end
    end
    
    victim:SetNWBool("isWounded", false)
end)

concommand.Add("wound", function(ply, cmd, args)
    local targetNick = args[1]
    local targetPlayer

    for _, pl in ipairs(player.GetAll()) do
        if string.find(string.lower(pl:Nick()), string.lower(targetNick)) then
            targetPlayer = pl
            break
        end
    end

    if IsValid(targetPlayer) then
        ApplyWound(targetPlayer, WOUND_DURATION, math.random(20, 50))
    end
end)