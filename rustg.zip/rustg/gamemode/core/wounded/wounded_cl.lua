local mat_medical = Material("icons/medical.png")
local mat_time = Material("icons/time.png")
local mat_vignette = Material("ui/vignette.png")

local reviveTarget = nil
local reviveProgress = 0
local reviveStartTime = 0

local function drawBar(x, y, w, h, icon, text, val, maxval, postfix, r, g, b)
    local bh = 15
    y = y + h - bh
    
    surface.SetDrawColor(0, 0, 0, 150)
    surface.DrawRect(x, y, w, bh)
    
    surface.SetDrawColor(r, g, b, 150)
    surface.DrawRect(x, y, w * math.Clamp(val / maxval, 0, 1), bh)

    local s = 20
    surface.SetDrawColor(255, 255, 255)
    surface.SetMaterial(icon)
    surface.DrawTexturedRect(x + 5, y - (h - bh) + 1, s, s)

    local ty = y - bh - 8
    draw.SimpleText(text,"gRust.32px", x + 48, ty, color_white)
    draw.SimpleText(math.Round(val)..postfix,"gRust.32px", x + w, ty, color_white, TEXT_ALIGN_RIGHT)
end

hook.Add("HUDPaint", "HUD.Wounded", function()
    local ply = LocalPlayer()
    if not ply:GetNWBool("isWounded") or not ply:Alive() then return end

    local scrW, scrH = ScrW(), ScrH()

	surface.SetDrawColor(255, 255, 255, 170)
	surface.SetMaterial(mat_vignette)
	surface.DrawTexturedRect(0, 0, scrW, scrH)

    surface.SetDrawColor(0, 0, 0, 80)
    surface.DrawRect(0, 0, scrW, scrH)

    local x = scrW / 2
    local titleY = 110
    local subtitleY = 193
    
    draw.SimpleText("WOUNDED", "gRust.80px", x, titleY, color_white, TEXT_ALIGN_CENTER)
    draw.SimpleText("YOU WILL DIE UNLESS YOU GET HELP SOON", "gRust.42px", x, subtitleY, color_white, TEXT_ALIGN_CENTER)

    local mw, mh, ms, y = 360, 39, 46, 250
    x = x - mw - ms / 2

    drawBar(x, y, mw, mh, mat_medical, "RECOVERY CHANCE", 
        ply:GetNWFloat("woundRecoveryChance"), 100, "%", 201, 0, 0)
    
    drawBar(x + mw + ms, y, mw, mh, mat_time, "TIME REMAINING", 
        math.max(ply:GetNWInt("woundRemaining", 0) - CurTime(), 0), 
        ply:GetNWInt("woundTotalTime"), "s", 46, 198, 46)

    surface.SetDrawColor(255, 0, 0, 3)
    surface.DrawRect(0, 0, scrW, scrH)
end)

hook.Add("HUDPaint", "DrawReviveProgressBar", function()
    if not IsValid(reviveTarget) or not reviveTarget:Alive() then return end
    local ply = LocalPlayer()
    if not IsValid(reviveTarget) then return end

    if ply ~= LocalPlayer() then return end

    local progress = math.Clamp((CurTime() - reviveStartTime) / 5, 0, 1)
    local w, h = ScrW(), ScrH()

    local barWidth = 250
    local barHeight = 12
    local barX = w / 2 - barWidth / 2
    local barY = h / 2 + 10

    local text = "Help player"
    local textX = barX
    local textY = barY - 2

    draw.SimpleText(text, "gRust.32px", textX, textY, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)

    surface.SetDrawColor(0, 0, 0, 150)
    surface.DrawRect(barX, barY, barWidth, barHeight)

    surface.SetDrawColor(255, 255, 255, 255)
    surface.DrawRect(barX, barY, barWidth * progress, barHeight)
end)

net.Receive("gRust.StartRevive", function()
    local target = net.ReadEntity()
    if IsValid(target) then
        reviveTarget = target
        reviveProgress = 0
        reviveStartTime = CurTime()

        LocalPlayer():EmitSound("ui/piemenu/piemenu_open.wav", 30)
    end
end)

net.Receive("gRust.CancelRevive", function()
    reviveTarget = nil
    reviveProgress = 0
    reviveStartTime = 0

    LocalPlayer():EmitSound("ui/piemenu/piemenu_close.wav", 35)
end)

net.Receive("gRust.ReviveFinished", function()
    reviveTarget = nil
    reviveProgress = 0
    reviveStartTime = 0
end)

hook.Add("CreateMove", "Wounded.BlockJump", function(cmd)
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:IsPlayer() then return end
    
    if ply:GetNWBool("isWounded") and ply:Alive() then
        cmd:RemoveKey(IN_JUMP)
        cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
    end
end)

hook.Add("CreateMove", "BlockMovementDuringRevive", function(cmd)
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:IsPlayer() then return end

    if reviveTarget then
        cmd:SetForwardMove(0)
        cmd:SetSideMove(0)
        cmd:SetUpMove(0)
        cmd:RemoveKey(IN_JUMP)
    end
end)