local function ShowDeathScreen()



end



net.Receive("gRust.DeathScreen", ShowDeathScreen)