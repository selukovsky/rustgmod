gRust.LastDeath = SysTime()

local INTRO_ANIM_TIME = 0.65
local PANEL_COLOR = Color(33, 33, 33)
local SKULL_COLOR = Color(29, 29, 29)
local TEXT_COLOR = Color(99, 99, 99)
local STAT_FONT = "gRust.32px"
local STAT_COLOR = Color(255, 255, 255, 125)
local STAT_TITLE_FONT = "gRust.24px"
local STAT_TEXT_COLOR = Color(167, 159, 152)
local BAG_COLORS = {
    Color(146, 62, 48),
    Color(75, 91, 47),
    Color(65, 115, 155)
}

local function ShowDeathScreen()
    gRust.CloseInventory()
    gRust.CloseCrafting()
    
    local Killer = net.ReadEntity()
    local bagCount = net.ReadUInt(8)
    local sleepingBags = {}
    
    for i = 1, bagCount do
        local bagIndex = net.ReadUInt(13)
        local bagPos = net.ReadVector()
        local canRespawn = net.ReadBool()
        local timeLeft = 0
        
        if not canRespawn then 
            timeLeft = net.ReadFloat() 
        end
        
        table.insert(sleepingBags, {
            index = bagIndex,
            pos = bagPos,
            canRespawn = canRespawn,
            timeLeft = timeLeft
        })
        
        print("[DeathScreen] Bag " .. i .. ": index=" .. bagIndex .. ", canRespawn=" .. tostring(canRespawn) .. ", timeLeft=" .. timeLeft)
    end

    local pl = LocalPlayer()
    if not IsValid(Killer) then Killer = pl end
    
    local timeAlive = SysTime() - gRust.LastDeath
    if (timeAlive >= 3600) then
        timeAlive = string.FormattedTime(timeAlive, "%02ih%02im%02is")
    elseif (timeAlive >= 60) then
        timeAlive = string.FormattedTime(timeAlive, "%02im%02is")
    else
        timeAlive = string.format("%is", math.Round(timeAlive))
    end
    
    local killedByStr = "Unknown"
    if (IsValid(Killer)) then
        -- Проверяем, является ли Killer игроком
        if Killer:IsPlayer() then
            killedByStr = Killer:Nick()
        else
            -- Если это NPC или другой entity, используем класс имени
            killedByStr = Killer:GetClass()
            -- Можно добавить красивые названия для конкретных NPC
            if killedByStr == "npc_combine" then
                killedByStr = "Combine Soldier"
            elseif killedByStr == "npc_zombie" then
                killedByStr = "Zombie"
            elseif killedByStr == "npc_headcrab" then
                killedByStr = "Headcrab"
            -- Добавьте другие NPC по необходимости
            else
                -- Убираем префикс "npc_" для более красивого отображения
                killedByStr = killedByStr:gsub("^npc_", ""):gsub("_", " "):upper()
            end
        end
    end

    local distance = 0
    if IsValid(Killer) and Killer != pl then
        distance = pl:GetPos():Distance(Killer:GetPos()) * 0.05
    end
    local distanceStr = string.format("%.1fm", distance)

    local DeathScreen = vgui.Create("Panel")
    DeathScreen:Dock(FILL)
    DeathScreen:MakePopup()
    DeathScreen:SetMouseInputEnabled(true)
    
    local PanelHeight = 200 * gRust.Hud.Scaling

    local TopPanel = DeathScreen:Add("Panel")
    TopPanel:Dock(TOP)
    TopPanel:SetPos(0, 0)
    TopPanel:SetSize(ScrW(), PanelHeight)
    TopPanel:SetAlpha(0)
    TopPanel:AlphaTo(255, INTRO_ANIM_TIME, 1)
    TopPanel.Paint = function(me, w, h)
        surface.SetDrawColor(PANEL_COLOR)
        surface.DrawRect(0, 0, w, h)
        
        local x = 250 * gRust.Hud.Scaling
        local y = h * 0.5
        local iconSize = h * 3.25
        surface.SetDrawColor(SKULL_COLOR)
        surface.DrawTexturedRectRotated(x, y, iconSize, iconSize, 15)

        draw.SimpleText("DEAD", "gRust.92px", x, y, TEXT_COLOR, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local infoSpacing = 16 * gRust.Hud.Scaling
    local infoHeight = 60 * gRust.Hud.Scaling

    local InfoContainer = TopPanel:Add("Panel")
    InfoContainer:SetPos(0, 0)
    InfoContainer:SetSize(ScrW(), PanelHeight)

    local animateInTime = 1.2
    local function AnimateInInfo(panel, delay)
        local localPosX, localPosY = panel:LocalToScreen(0, 0)
        local initialY = -localPosY - infoHeight
        panel:SetY(initialY)
        panel.AnimStart = CurTime() + delay
        panel.Think = function(me)
            local animTime = CurTime() - me.AnimStart
            local toY = PanelHeight * 0.5 - infoHeight * 0.5
            if (animTime >= animateInTime) then
                me:SetY(toY)
                me.Think = nil
                return
            end

            local animProgress = animTime / animateInTime
            local anim = math.EaseInOut(math.Clamp(animProgress, 0, 1), 0, 1)
            local animY = initialY + (toY - initialY) * anim
            me:SetY(animY)
        end
    end
    
    local AliveForStat = InfoContainer:Add("Panel")
    surface.SetFont(STAT_FONT)
    local aliveForW, aliveForH = surface.GetTextSize(timeAlive)
    AliveForStat:SetSize(aliveForW + 64 * gRust.Hud.Scaling, infoHeight)
    local AliveForColor = Color(91, 113, 55)
    local AliveForTextColor = Color(205, 249, 123)
    AliveForStat:NoClipping(true)
    AliveForStat.Paint = function(me, w, h)
        surface.SetDrawColor(AliveForColor)
        surface.DrawRect(0, 0, w, h)

        draw.SimpleText(timeAlive, STAT_FONT, w * 0.5, h * 0.5, AliveForTextColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        -- ИЗМЕНИТЬ ВЫСОТУ ТЕКСТА "ALIVE FOR" - используем меньший отступ сверху
        draw.SimpleText("ALIVE FOR", STAT_TITLE_FONT, 8 * gRust.Hud.Scaling, 6 * gRust.Hud.Scaling, STAT_TEXT_COLOR, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end

    AnimateInInfo(AliveForStat, 0.5)

    local killedByW, killedByH = surface.GetTextSize(killedByStr)
    local KilledByStatContainer = InfoContainer:Add("Panel")
    KilledByStatContainer:SetSize((killedByW + 64 * gRust.Hud.Scaling) + infoHeight, infoHeight)
    KilledByStatContainer:NoClipping(true)
    local KilledByColor = gRust.Colors.Primary or Color(200, 60, 60)
    KilledByStatContainer.Paint = function(me, w, h)
        surface.SetDrawColor(KilledByColor)
        surface.DrawRect(0, 0, w, h)

        -- ИЗМЕНИТЬ ВЫСОТУ ТЕКСТА "KILLED BY" - используем меньший отступ сверху
        draw.SimpleText("KILLED BY", STAT_TITLE_FONT, 8 * gRust.Hud.Scaling, 6 * gRust.Hud.Scaling, STAT_TEXT_COLOR, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end

    AnimateInInfo(KilledByStatContainer, 0.7)

    local KilledByStat = KilledByStatContainer:Add("Panel")
    KilledByStat:Dock(FILL)
    surface.SetFont(STAT_FONT)
    local KilledByTextColor = Color(255, 165, 148)
    KilledByStat:NoClipping(true)
    KilledByStat.Paint = function(me, w, h)
        draw.SimpleText(killedByStr, STAT_FONT, w * 0.5, h * 0.5, KilledByTextColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    -- Показываем аватар только если убийца - игрок
    if IsValid(Killer) and Killer:IsPlayer() then
        local KilledByAvatar = KilledByStatContainer:Add("AvatarImage")
        KilledByAvatar:Dock(LEFT)
        KilledByAvatar:SetWide(infoHeight)
        KilledByAvatar:SetPlayer(Killer, 128)
    end

    local KilledByItemStat = InfoContainer:Add("Panel")
    local DistanceStat = InfoContainer:Add("Panel")

    -- Показываем оружие и дистанцию только если убийца - валидный entity и не сам игрок
    if (pl != Killer and IsValid(Killer)) then
        local weaponName = "Unknown"
        local weaponIcon = Material("icon16/gun.png")
        
        -- Для NPC также пытаемся получить оружие
        if Killer.GetActiveWeapon and IsValid(Killer:GetActiveWeapon()) then
            local weapon = Killer:GetActiveWeapon()
            weaponName = weapon.PrintName or string.sub(weapon:GetClass(), 6) or "Unknown"
        elseif Killer:IsNPC() then
            -- Для NPC используем стандартное название атаки
            weaponName = "Attack"
        end

        surface.SetFont(STAT_FONT)
        local killedByItemW, killedByItemH = surface.GetTextSize(weaponName)
        KilledByItemStat:SetSize((killedByItemW + 64 * gRust.Hud.Scaling) + infoHeight, infoHeight)
        KilledByItemStat:NoClipping(true)
        local KilledByColor = gRust.Colors.Primary or Color(200, 60, 60)
        KilledByItemStat.Paint = function(me, w, h)
            surface.SetDrawColor(KilledByColor)
            surface.DrawRect(0, 0, w, h)

            -- ИЗМЕНИТЬ ВЫСОТУ ТЕКСТА "WITH A" - используем меньший отступ сверху
            draw.SimpleText("WITH A", STAT_TITLE_FONT, 8 * gRust.Hud.Scaling, 6 * gRust.Hud.Scaling, STAT_TEXT_COLOR, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end

        AnimateInInfo(KilledByItemStat, 0.9)
        
        local KilledByWeaponStat = KilledByItemStat:Add("Panel")
        KilledByWeaponStat:Dock(FILL)
        surface.SetFont(STAT_FONT)
        local KilledByTextColor = Color(255, 165, 148)
        KilledByWeaponStat:NoClipping(true)
        KilledByWeaponStat.Paint = function(me, w, h)
            draw.SimpleText(weaponName, STAT_FONT, w * 0.5, h * 0.5, KilledByTextColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        local KilledByItemIcon = KilledByItemStat:Add("Panel")
        KilledByItemIcon:Dock(LEFT)
        KilledByItemIcon:SetWide(infoHeight)
        KilledByItemIcon:NoClipping(true)
        local extraSize = 16 * gRust.Hud.Scaling
        KilledByItemIcon.Paint = function(me, w, h)
            surface.SetDrawColor(255, 255, 255)
            surface.SetMaterial(weaponIcon)
            surface.DrawTexturedRect(-extraSize, -extraSize, w + extraSize * 2, h + extraSize * 2)
        end

        surface.SetFont(STAT_FONT)
        local distanceW, distanceH = surface.GetTextSize(distanceStr)
        DistanceStat:SetSize(distanceW + 128 * gRust.Hud.Scaling, infoHeight)
        local DistanceColor = Color(74, 73, 69)
        local DistanceTextColor = Color(133, 132, 130)
        DistanceStat:NoClipping(true)
        DistanceStat.Paint = function(me, w, h)
            surface.SetDrawColor(DistanceColor)
            surface.DrawRect(0, 0, w, h)
    
            draw.SimpleText(distanceStr, STAT_FONT, w * 0.5, h * 0.5, DistanceTextColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            -- ИЗМЕНИТЬ ВЫСОТУ ТЕКСТА "AT A DISTANCE OF" - используем меньший отступ сверху
            draw.SimpleText("AT A DISTANCE OF", STAT_TITLE_FONT, 8 * gRust.Hud.Scaling, 6 * gRust.Hud.Scaling, STAT_TEXT_COLOR, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end
    
        AnimateInInfo(DistanceStat, 1.1)
    else
        -- Suicide case - hide weapon and distance stats
        KilledByItemStat:SetVisible(false)
        DistanceStat:SetVisible(false)
    end

    InfoContainer.PerformLayout = function(me, w, h)
        local paddingBetween = 32 * gRust.Hud.Scaling
        local totalWidth = AliveForStat:GetWide() + KilledByStatContainer:GetWide() 
        
        if pl != Killer and IsValid(Killer) then
            totalWidth = totalWidth + KilledByItemStat:GetWide() + DistanceStat:GetWide() + paddingBetween * 3
        else
            totalWidth = totalWidth + paddingBetween
        end
        
        local padding = (w - totalWidth) * 0.5
        AliveForStat:SetX(padding)
        KilledByStatContainer:SetX(AliveForStat:GetWide() + padding + paddingBetween)
        
        if pl != Killer and IsValid(Killer) then
            KilledByItemStat:SetX(KilledByStatContainer:GetWide() + KilledByStatContainer.x + paddingBetween)
            DistanceStat:SetX(KilledByItemStat:GetWide() + KilledByItemStat.x + paddingBetween)
        end
    end
    
    local BottomPanel = DeathScreen:Add("Panel")
    BottomPanel:Dock(BOTTOM)
    BottomPanel:SetPos(0, -170 * gRust.Hud.Scaling)
    BottomPanel:SetSize(ScrW(), 170 * gRust.Hud.Scaling)
    BottomPanel:SetAlpha(0)
    BottomPanel:AlphaTo(255, INTRO_ANIM_TIME, 0.5)
    local padding = 32 * gRust.Hud.Scaling
    BottomPanel:DockPadding(padding, padding, padding, padding)
    BottomPanel.Paint = function(me, w, h)
        surface.SetDrawColor(PANEL_COLOR)
        surface.DrawRect(0, 0, w, h)
    end

    local RespawnButton = BottomPanel:Add("gRust.Button")
    RespawnButton:Dock(RIGHT)
    RespawnButton:SetWide(320 * gRust.Hud.Scaling)
    RespawnButton:DockMargin(0, 0, 98 * gRust.Hud.Scaling, 0)
    RespawnButton:SetFont("gRust.58px")
    RespawnButton:SetText("RESPAWN >>")
    RespawnButton:SetTextColor(Color(146, 188, 73))
    RespawnButton:SetColor(Color(58, 64, 41))
    RespawnButton.Paint = function(me, w, h)
        surface.SetDrawColor(me:IsHovered() and Color(74, 81, 52) or Color(58, 64, 41))
        surface.DrawRect(0, 0, w, h)
        draw.SimpleText(me:GetText(), "gRust.58px", w/2, h/2, me:GetTextColor(), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    RespawnButton.DoClick = function(me)
        print("[DeathScreen] Respawn button clicked")
        net.Start("gRust.Respawn")
        net.SendToServer()
        DeathScreen:Remove()
    end

    local CircleRadius = 38 * gRust.Hud.Scaling

    for k, bagData in ipairs(sleepingBags) do
        local SleepingBagButton = BottomPanel:Add("gRust.Button")
        SleepingBagButton:Dock(LEFT)
        SleepingBagButton:SetWide(320 * gRust.Hud.Scaling)
        SleepingBagButton:DockMargin(0, 0, 15 * gRust.Hud.Scaling, 0)
        SleepingBagButton:SetFont("gRust.36px")
        SleepingBagButton:SetText("BAG " .. k)
        SleepingBagButton:SetTextColor(Color(251, 240, 230))
        local BagColor = BAG_COLORS[(k - 1) % #BAG_COLORS + 1]
        SleepingBagButton:NoClipping(true)
        
        SleepingBagButton.Think = function(me)
            if not bagData.canRespawn and bagData.timeLeft > 0 then
                bagData.timeLeft = math.max(0, bagData.timeLeft - FrameTime())
                if bagData.timeLeft <= 0 then
                    bagData.canRespawn = true
                    me:SetText("BAG " .. k)
                else
                    me:SetText("BAG " .. k .. " [" .. math.ceil(bagData.timeLeft) .. "]")
                end
            end
        end

        SleepingBagButton.Paint = function(me, w, h)
            local canRespawn = bagData.canRespawn
            local col = canRespawn and (me:IsHovered() and Color(BagColor.r + 20, BagColor.g + 20, BagColor.b + 20) or BagColor) or Color(25, 25, 25)
            
            surface.SetDrawColor(col)
            surface.DrawRect(0, 0, w, h)
            
            local bagText = me:GetText()
            draw.SimpleText(bagText, "gRust.36px", w/2, h/2, canRespawn and Color(250, 237, 228) or Color(100, 100, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        
        SleepingBagButton.DoClick = function(me)
            if not bagData.canRespawn then 
                print("[DeathScreen] Bag not ready yet")
                return 
            end

            print("[DeathScreen] Bag respawn button clicked for bag " .. bagData.index)
            net.Start("gRust.BagRespawn")
            net.WriteUInt(bagData.index, 13)
            net.SendToServer()

            DeathScreen:Remove()
        end
    end

    gRust.LastDeath = SysTime()
end

-- Camera hook for death view
local view = {}
hook.Add("CalcView", "gRust.FPSDeath", function(pl, origin, angles, fov, znear, zfar)
    if (pl:Alive()) then return end
    
    local ragdoll = pl:GetRagdollEntity()
    if (!IsValid(ragdoll)) then return end
    
    local eyes = ragdoll:LookupAttachment("eyes")
    if (!eyes) then return end
    eyes = ragdoll:GetAttachment(eyes)
    if (!eyes) then return end

    view.origin = eyes.Pos - eyes.Ang:Forward() * 1.25
    view.angles = eyes.Ang
    view.fov = fov

    return view
end)

net.Receive("gRust.DeathScreen", ShowDeathScreen)