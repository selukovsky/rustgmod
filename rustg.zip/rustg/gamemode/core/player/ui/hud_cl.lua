local math_Clamp = math.Clamp
local ScrW = ScrW
local ScrH = ScrH
local draw_SimpleText = draw.SimpleText
local Color = Color
local Vector = Vector
local LocalPlayer = LocalPlayer
local util_TraceHull = util.TraceHull
local IsValid = IsValid
local Lerp = Lerp
local Material = Material
local hook_Add = hook.Add
local GetConVar = GetConVar
local halo_Add = halo.Add
local surface = surface
local surface_SetDrawColor  = surface.SetDrawColor
local surface_SetMaterial      = surface.SetMaterial
local surface_DrawRect      = surface.DrawRect
local surface_DrawTexturedRect      = surface.DrawTexturedRect

-- Перенесена система скейлинга из oldhud_cl.lua
gRust.Hud = gRust.Hud or {}


local Margin
local IconPadding
local IconOffset

local round = math.Round
local function UpdateHudVars()
    gRust.Hud.ScalingInfluence = 0.0 -- 0 = ScrW(), 1 = ScrH()
    gRust.Hud.AspectRatio = ScrW() / ScrH()
    gRust.Hud.Scaling = (ScrH() / 1440) * gRust.Hud.ScalingInfluence + (1 - gRust.Hud.ScalingInfluence) * ScrW() / 2560
    gRust.Hud.Margin = round(32 * gRust.Hud.Scaling)
    gRust.Hud.SlotSize = round(120 * gRust.Hud.Scaling)
    gRust.Hud.SlotPadding = round(8 * gRust.Hud.Scaling)
    gRust.Hud.BarWidth = round(384 * gRust.Hud.Scaling)
    gRust.Hud.BarHeight = round(52 * gRust.Hud.Scaling)
    gRust.Hud.BarPadding = round(6 * gRust.Hud.Scaling)
    gRust.Hud.BarSpacing = round(4 * gRust.Hud.Scaling)
    gRust.Hud.ShouldDraw = gRust.Hud.ShouldDraw != false

    Margin = gRust.Hud.Margin
    IconPadding = round(10 * gRust.Hud.Scaling)
    IconOffset = round(-2 * gRust.Hud.Scaling)
end

hook.Add("OnScreenSizeChanged", "gRust.Hud.OnScreenSizeChanged", UpdateHudVars)
UpdateHudVars()

gRust.Hud.ShouldDraw = true

local BarIndex = 1

-- Исправленная функция SetDrawColor
local function SafeSetDrawColor(r, g, b, a)
    r = r or 255
    g = g or 255
    b = b or 255
    a = a or 255
    surface_SetDrawColor(r, g, b, a)
end

local function DrawBar(val, min, max, icon, col)
    val = math_Clamp(val, min, max)

    -- Используем систему скейлинга из oldhud_cl.lua
    local BarWidth, BarHeight = gRust.Hud.BarWidth, gRust.Hud.BarHeight
    local BarPadding, BarSpacing = gRust.Hud.BarPadding, gRust.Hud.BarSpacing
    local Margin = gRust.Hud.Margin

    local x = ScrW() - Margin - BarWidth
    local y = (ScrH() - Margin - (BarHeight + BarSpacing) * BarIndex) + BarSpacing * 2

    SafeSetDrawColor(255, 255, 255, 4)
    surface_DrawRect(x, y, BarWidth, BarHeight)

    SafeSetDrawColor(160, 152, 140, 255)
    surface_SetMaterial(icon)
    surface_DrawTexturedRect(x + IconPadding + IconOffset, y + IconPadding, BarHeight - IconPadding * 2, BarHeight - IconPadding * 2)

    SafeSetDrawColor(col.r, col.g, col.b, col.a or 255)
    surface_DrawRect(x + BarHeight + IconOffset, y + BarPadding, (BarWidth - BarHeight - BarPadding) * (val / max), BarHeight - BarPadding * 2)

    local TextColor = Color(255, 255, 255, 215)
    draw_SimpleText(val, "gRust.32px", x + BarHeight + 10, y + BarHeight * 0.5, TextColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

    BarIndex = BarIndex + 1
end

-- Функции для отрисовки панелей (исправленные)
function gRust.DrawPanel(x, y, w, h, color)
    if not color then color = Color(50, 50, 50, 200) end
    SafeSetDrawColor(color.r, color.g, color.b, color.a or 255)
    surface_DrawRect(x, y, w, h)
end

function gRust.DrawPanelColored(x, y, w, h, color)
    if not color then color = Color(50, 50, 50, 200) end
    SafeSetDrawColor(color.r, color.g, color.b, color.a or 255)
    surface_DrawRect(x, y, w, h)
end

local MaxDist = gRust.Config.InteractRange
local LookingEnt
local Alpha = 0

local TraceMins, TraceMaxs = Vector(-4, -4, -4), Vector(4, 4, 4)
local function DrawEntityDisplay()
	local pl = LocalPlayer()
	local tr = {}
	tr.start = pl:EyePos()
	tr.endpos = tr.start + pl:GetAimVector() * 72.5
	tr.mins = TraceMins
	tr.maxs = TraceMaxs
	tr.filter = pl
	tr = util_TraceHull(tr)
	local ent = tr.Entity

	if (IsValid(ent) and ent.gRust) then
		LookingEnt = ent
	end
	
	local DisplayName = ent.GetDisplayName and ent:GetDisplayName()
	if (DisplayName == "") then DisplayName = nil end

	if (!IsValid(ent) or (!DisplayName and !ent.ShowHealth) or tr.HitPos:DistToSqr(pl:EyePos()) > MaxDist) then
		Alpha = Lerp(0.15, Alpha, 0)
	else
		Alpha = Lerp(0.15, Alpha, 255)
	end
	
	if (Alpha < 0.1) then return end
	if (!IsValid(LookingEnt)) then return end

	if (LookingEnt.ShowHealth) then -- Health
		local Health = LookingEnt:Health()
		local Width = ScrW() * 0.117
		local Height = ScrH() * 0.012
	
		SafeSetDrawColor(117, 120, 62, Alpha)
		surface_DrawRect(ScrW() * 0.5 - Width * 0.5, ScrH() * 0.224, Width, Height)
	
		SafeSetDrawColor(255, 255, 255, Alpha)
		surface_DrawRect(ScrW() * 0.5 - Width * 0.5, ScrH() * 0.224, Width * (Health / LookingEnt:GetMaxHealth()), Height)
	
		draw_SimpleText(Health .. "/" .. LookingEnt:GetMaxHealth(), "gRust.30px", ScrW() * 0.5 + Width * 0.5, ScrH() * 0.203, Color(255, 255, 255, Alpha), 2, 2)
	end

	DisplayName = LookingEnt:GetDisplayName()
	if (DisplayName == "") then DisplayName = nil end
	local scrw, scrh = ScrW(), ScrH()

	if (DisplayName) then
		if (Alpha < 1) then return end

		local IS = scrh * 0.036
		SafeSetDrawColor(255, 255, 255, Alpha)
		if LookingEnt.DisplayIcon then
			surface_SetMaterial(LookingEnt.DisplayIcon)
			surface_DrawTexturedRect(scrw * 0.5 - IS * 0.5, scrh * 0.435 - IS * 0.5, IS, IS)
		end

		draw_SimpleText(DisplayName, "gRust.32px", scrw * 0.5, scrh * 0.4625, Color(255, 255, 255, Alpha), 1, 1)

		local CS = scrh * 0.012
		SafeSetDrawColor(255, 255, 255, Alpha)
		surface_SetMaterial(gRust.GetIcon("circle"))
		surface_DrawTexturedRect(scrw * 0.5 - CS * 0.5, scrh * 0.5 - CS * 0.5, CS, CS)
	end

	if (LookingEnt.Options) then
		draw_SimpleText("MORE OPTIONS ARE AVAILABLE", "gRust.26px", scrw * 0.5, scrh * 0.535, Color(255, 255, 255, Alpha), 1, 1)
		draw_SimpleText("HOLD DOWN [USE] TO OPEN MENU", "gRust.26px", scrw * 0.5, scrh * 0.555, Color(255, 255, 255, Alpha), 1, 1)
	end
end

local VoiceIcon = Material("icons/voice.png", "smooth mips")

local function DrawVoiceChat()
	local scrw, scrh = ScrW(), ScrH()
	local size = scrh * 0.075
	local x, y = scrw * 0.5 - (size * 0.5), scrh * 0.1 - (size * 0.5)
	SafeSetDrawColor(61, 79, 29)
	surface_DrawRect(x, y, size, size)
	
	SafeSetDrawColor(141, 182, 28)
	
	local IconPadding = scrh * 0.025
	surface_SetMaterial(VoiceIcon)
	surface_DrawTexturedRect(x + (IconPadding * 0.5), y + (IconPadding * 0.5), size - IconPadding, size - IconPadding)
end

CreateClientConVar("grust_halos", "1", true)
hook_Add("PreDrawHalos", "gRust.ItemHalo", function()
	if (!IsValid(LookingEnt)) then return end
	if (GetConVar("grust_halos"):GetBool() == false) then return end

	local pl = LocalPlayer()
	local tr = {}
	tr.start = pl:EyePos()
	tr.endpos = tr.start + pl:GetAimVector() * 72.5
	tr.mins = TraceMins
	tr.maxs = TraceMaxs
	tr.filter = pl
	tr = util_TraceHull(tr)
	local ent = tr.Entity

	if (!ent.gRust or !ent.DrawHalo) then return end
	if (ent:GetPos():DistToSqr(pl:GetPos()) > MaxDist) then return end

	halo_Add({LookingEnt}, color_white, 3, 3, 2)
end)

gRust.DrawHUD = true
CreateClientConVar("grust_drawhud", "1", false)

function GM:HUDPaint()
	if (!LocalPlayer():Alive()) then return end
	if (GetConVar("grust_drawhud"):GetBool() == false || !gRust.DrawHUD) then return end

	DrawEntityDisplay()
	if (LocalPlayer():IsSpeaking()) then
		DrawVoiceChat()
	end
	self:DrawCompass()
end

function GM:PostRenderVGUI()
    if (!LocalPlayer():Alive()) then return end
    if (GetConVar("grust_drawhud"):GetBool() == false || !gRust.DrawHUD) then return end
    if (IsValid(gRust.TechTreeMenu)) then return end

    self:DrawTeam()
    self:DrawPieMenu()

    local pl = LocalPlayer()

    BarIndex = 1
    DrawBar(pl:GetHunger(), 0, 500, gRust.GetIcon("food"), Color(193, 109, 53))
    DrawBar(pl:GetThirst(), 0, 250, gRust.GetIcon("cup"), Color(69, 148, 205))
    DrawBar(pl:Health(), 0, pl:GetMaxHealth(), gRust.GetIcon("health"), Color(136, 179, 58))

    local playerVehicle = pl:GetVehicle()
    if (!IsValid(playerVehicle)) then return end
    
    local vehicle = playerVehicle:GetParent()
    if IsValid(vehicle) and vehicle.GetHP and vehicle:GetMaxHP() > 0 then
        DrawBar(vehicle:GetHP(), 0, vehicle:GetMaxHP(), gRust.GetIcon("gear"), Color(0, 0, 0, 175))
    end
end

local NoDraw = {
	["CHudHealth"] = true,
	["CHudWeaponSelection"] = true,
	["CHudAmmo"] = true,
	["CHudSecondaryAmmo"] = true,
	["CHudDamageIndicator"] = true,
	["CHudVoiceStatus"] = true
}

function GM:HUDShouldDraw(n)
	return !NoDraw[n]
end

gRust.Notifications = {}
gRust.PickupNotifications = {} -- Новая таблица для нотификаций о подборе

local NOTIFICATION = {}
NOTIFICATION.__index = NOTIFICATION

AccessorFunc(NOTIFICATION, "Color", "Color")
AccessorFunc(NOTIFICATION, "Text", "Text")
AccessorFunc(NOTIFICATION, "TextColor", "TextColor")
AccessorFunc(NOTIFICATION, "SideColor", "SideColor")
AccessorFunc(NOTIFICATION, "Icon", "Icon")
AccessorFunc(NOTIFICATION, "IconColor", "IconColor")
AccessorFunc(NOTIFICATION, "IconPadding", "IconPadding")
AccessorFunc(NOTIFICATION, "ExitDuration", "ExitDuration")
AccessorFunc(NOTIFICATION, "Side", "Side")

function NOTIFICATION:__tostring()
    return "Notification[" .. (self.index or "?") .. "]"
end

function NOTIFICATION:Init()
    self.index = table.insert(gRust.Notifications, self)
    self.entering = true
    self.removing = false
    self.enterTime = CurTime()
    self.animProgress = 0
    self.visible = true

    self.Color = gRust.Colors.Primary or Color(50,50,50,200)
    self.Text = "NOTIFICATION"
    self.Icon = "" -- можно указать путь к иконке
    self.IconColor = Color(255,255,255)
    self.TextColor = Color(255,255,255)
    self.IconPadding = 10
    self.EnterDuration = 0.15
    self.ExitDuration = 0.15
end

function NOTIFICATION:RemoveImmediate()
    table.remove(gRust.Notifications, self.index)
    self.entering = false
    for i = self.index, #gRust.Notifications do
        gRust.Notifications[i].index = i
    end
end

function NOTIFICATION:Remove()
    if self.removing then return end
    self.entering = false
    self.removing = true
    self.removeTime = CurTime()
end

function NOTIFICATION:Show()
    self.entering = true
    self.removing = false
    self.enterTime = CurTime()
    self.animProgress = 0
    self.visible = true

    table.remove(gRust.Notifications, self.index)
    self.index = table.insert(gRust.Notifications, self)
    for i = 1, #gRust.Notifications do
        gRust.Notifications[i].index = i
    end
end

function NOTIFICATION:Hide()
    if self.removing then return end
    self.entering = false
    self.removing = true
    self.removeTime = CurTime()
    timer.Simple(self.ExitDuration, function()
        self.visible = false
    end)
end

function NOTIFICATION:SetDuration(duration)
    self.duration = CurTime() + duration
end

function NOTIFICATION:SetCondition(fn)
    self.condition = fn
end

function NOTIFICATION:Update() end
function NOTIFICATION:PaintOver(x, y, w, h) end

function NOTIFICATION:Think()
    if self.duration and (self.duration < CurTime()) then
        self:Remove()
    end

    if self.condition and not self.condition() and self.visible and not self.removing then
        self:Hide()
    elseif self.condition and self.condition() then
        self:Update()
        if not self.visible and not self.entering then
            self:Show()
        end
    elseif not self.condition then
        self:Update()
    end

    if self.entering then
        self.animProgress = math.Clamp((CurTime() - self.enterTime) / self.EnterDuration, 0, 1)
        if self.animProgress == 1 then
            self.entering = false
        end
    elseif self.removing then
        self.animProgress = 1 - math.Clamp((CurTime() - self.removeTime) / self.ExitDuration, 0, 1)
    end
end

function gRust.CreateNotification()
    local notification = setmetatable({}, NOTIFICATION)
    notification:Init()
    return notification
end

-- Функция для создания нотификации о подборе
function gRust.CreatePickupNotification(itemClass, quantity, totalAmount)
    local notification = setmetatable({}, NOTIFICATION)

    notification.entering = true
    notification.removing = false
    notification.enterTime = CurTime()
    notification.animProgress = 0
    notification.visible = true
    notification.EnterDuration = 0.15
    notification.ExitDuration = 0.15

    notification.Color = Color(80, 92, 51, 250)
    notification.IconColor = Color(139, 228, 2)
    notification.TextColor = Color(255, 255, 255)
    notification.IconPadding = 3

    local itemData = gRust.Items[itemClass]
    local itemName = itemData and itemData:GetName() or itemClass

    local displayName = itemName

    notification.Text = displayName
    notification.Icon = "materials/icons/pickup.png"
    notification.Side = "+" .. quantity .. " (" .. totalAmount .. ")"

    notification.Think = function(self)
        if self.entering then
            self.animProgress = math.Clamp((CurTime() - self.enterTime) / self.EnterDuration, 0, 1)
            if self.animProgress == 1 then
                self.entering = false
            end
        elseif self.removing then
            self.animProgress = 1 - math.Clamp((CurTime() - self.removeTime) / self.ExitDuration, 0, 1)
        end
    end

    table.insert(gRust.PickupNotifications, notification)

    timer.Simple(2, function()
        if notification then
            notification.removing = true
            notification.removeTime = CurTime()

            timer.Simple(notification.ExitDuration, function()
                for i, notif in ipairs(gRust.PickupNotifications) do
                    if notif == notification then
                        table.remove(gRust.PickupNotifications, i)
                        break
                    end
                end
            end)
        end
    end)

    return notification
end

net.Receive("gRust.PickupNotification", function()
    local itemClass = net.ReadString()
    local quantity = net.ReadUInt(16)
    local totalAmount = net.ReadUInt(16)

    gRust.CreatePickupNotification(itemClass, quantity, totalAmount)
end)

-- Пример VITAL нотификаций
local VITAL_COLOR = Color(150, 49, 31, 250)
local VITAL_ICON_COLOR = Color(92, 30, 2)
local VITAL_TEXT_COLOR = Color(178, 136, 123)

-- STARVING
local starving = gRust.CreateNotification()
starving:SetColor(VITAL_COLOR)
starving:SetIconColor(VITAL_ICON_COLOR)
starving:SetTextColor(VITAL_TEXT_COLOR)
starving:SetCondition(function() return LocalPlayer():GetHunger() <= 30 end)
starving.Update = function(self)
    self.Text = "STARVING"
    self.Icon = "icons/food.png"
    self.Side = math.ceil(math.max(LocalPlayer():GetHunger(),0))
end

-- DEHYDRATED
local hydration = gRust.CreateNotification()
hydration:SetColor(VITAL_COLOR)
hydration:SetIconColor(VITAL_ICON_COLOR)
hydration:SetTextColor(VITAL_TEXT_COLOR)
hydration:SetCondition(function() return LocalPlayer():GetThirst() <= 30 end)
hydration.Update = function(self)
    self.Text = "DEHYDRATED"
    self.Icon = "icons/cup.png"
    self.Side = math.ceil(math.max(LocalPlayer():GetThirst(),0))
end

if (StormFox2) then
    local cold = gRust.CreateNotification()
    cold:SetColor(VITAL_COLOR)
    cold:SetIconColor(VITAL_ICON_COLOR)
    cold:SetTextColor(VITAL_TEXT_COLOR)
    cold:SetCondition(function()
        return StormFox2.Temperature.Get("celsius") <= 0
    end)
    cold.Update = function(self)
        self.Text = "TOO COLD"
        self.Icon = "icons/protection/freezing.png"
        self.Side = string.format("%i°C", math.floor(StormFox2.Temperature.Get("celsius")))
    end

    local hot = gRust.CreateNotification()
    hot:SetColor(VITAL_COLOR)
    hot:SetIconColor(VITAL_ICON_COLOR)
    hot:SetTextColor(VITAL_TEXT_COLOR)
    hot:SetCondition(function()
        return StormFox2.Temperature.Get("celsius") >= 30
    end)
    hot.Update = function(self)
        self.Text = "TOO HOT"
        self.Icon = "icons/protection/explosion.png"
        self.Side = string.format("%i°C", math.floor(StormFox2.Temperature.Get("celsius")))
    end
end

local crafting = gRust.CreateNotification()
crafting:SetColor(Color(40, 106, 144, 250))
crafting:SetIconColor(Color(79, 148, 190))
crafting:SetTextColor(Color(200, 220, 240))

crafting.Update = function(self)
    local activeCrafts = LocalPlayer().ActiveCrafts or {}
    local craftCount = table.Count(activeCrafts)
    
    if craftCount > 0 then
        -- Находим активный крафт с наибольшим оставшимся временем (самый новый)
        local currentCraft
        local maxTimeLeft = 0
        
        for _, craft in pairs(activeCrafts) do
            if craft.timeLeft and craft.timeLeft > maxTimeLeft then
                maxTimeLeft = craft.timeLeft
                currentCraft = craft
            end
        end
        
        if currentCraft then
            local itemData = gRust.Items[currentCraft.item]
            local itemName = itemData and itemData:GetName() or currentCraft.item
            
            -- Обрезаем длинное название если нужно
            if string.len(itemName) > 20 then
                itemName = string.sub(itemName, 1, 17) .. "..."
            end
            
            if craftCount > 1 then
                self.Text = itemName .. " (" .. (craftCount - 1) .. ")"
            else
                self.Text = itemName
            end
            self.Icon = "icons/gear.png"
            
            self.Side = math.ceil(currentCraft.timeLeft)
        else
            self.Text = "CRAFTING"
            self.Side = nil
        end
    else
        self.Text = "CRAFTING"
        self.Side = nil
    end
end

crafting:SetCondition(function()
    local activeCrafts = LocalPlayer().ActiveCrafts or {}
    return table.Count(activeCrafts) > 0
end)

local buildingStatus = "none" -- По умолчанию "none"

if not gRust then gRust = {} end
if not gRust.Building then gRust.Building = {} end

local buildingblocked = gRust.CreateNotification()
buildingblocked:SetText("BUILDING BLOCKED")
buildingblocked:SetIcon("buildingblocked")
buildingblocked:SetColor(Color(150, 49, 31, 250))
buildingblocked:SetIconColor(Color(255, 250, 250))
buildingblocked:SetTextColor(Color(178, 136, 123))

local buildingprivilege = gRust.CreateNotification()
buildingprivilege:SetText("BUILDING PRIVILEGE")
buildingprivilege:SetIcon("buildingprivilege")
buildingprivilege:SetColor(Color(94, 113, 40))
buildingprivilege:SetIconColor(Color(145, 193, 20))
buildingprivilege:SetTextColor(Color(240, 240, 209))

buildingblocked.Update = function(self)
    self.Text = "BUILDING BLOCKED"
    self.Icon = "icons/construction.png"
end

buildingprivilege.Update = function(self)
    self.Text = "BUILDING PRIVILEGE"
    self.Icon = "icons/alert2.png"
end

-- Функция обновления нотификаций
local function UpdateBuildingNotifications()
    -- Сначала скрываем обе нотификации
    buildingblocked:Hide()
    buildingprivilege:Hide()

    -- Показываем только если статус соответствует
    if buildingStatus == "nobuild" or buildingStatus == "blocked" then
        buildingblocked:Show()
    elseif buildingStatus == "privilege" then
        buildingprivilege:Show()
    end
    -- Если buildingStatus == "none" - обе нотификации остаются скрытыми
end

-- Сетевая функция для получения статуса билдинга
net.Receive("gRust.BuildingStatus", function()
    local newStatus = net.ReadString()
    if buildingStatus ~= newStatus then
        buildingStatus = newStatus
        print("[BUILDING] Status changed to: " .. newStatus)
        UpdateBuildingNotifications()
    end
end)

-- Запрос статуса при загрузке клиента
hook.Add("InitPostEntity", "gRust.RequestBuildingStatus", function()
    timer.Simple(2, function() -- Небольшая задержка для инициализации
        net.Start("gRust.RequestBuildingStatus")
        net.SendToServer()
        print("[BUILDING] Requested initial building status")
    end)
end)

-- Обновление статуса при спавне игрока
hook.Add("PlayerSpawn", "gRust.UpdateBuildingStatusOnSpawn", function(ply)
    if ply == LocalPlayer() then
        timer.Simple(1, function()
            net.Start("gRust.RequestBuildingStatus")
            net.SendToServer()
            print("[BUILDING] Requested building status after spawn")
        end)
    end
end)

function IsInNoBuildZone()
    return buildingStatus == "nobuild"
end

function IsBuildingBlocked()
    return buildingStatus == "nobuild" or buildingStatus == "blocked"
end

function HasBuildingPrivilege()
    return buildingStatus == "privilege"
end

gRust.Building.IsInNoBuildZone = IsInNoBuildZone
gRust.Building.IsBuildingBlocked = IsBuildingBlocked
gRust.Building.HasBuildingPrivilege = HasBuildingPrivilege

-- Инициализация нотификаций при загрузке
timer.Simple(3, function()
    UpdateBuildingNotifications()
    print("[BUILDING] Initialized building notifications with status: " .. buildingStatus)
end)

-- Сетевая функция для обновления крафтов
net.Receive("gRust.UpdateCrafts", function()
    local craftCount = net.ReadUInt(8)
    LocalPlayer().ActiveCrafts = {}
    
    for i = 1, craftCount do
        local itemClass = net.ReadString()
        local timeLeft = net.ReadFloat()
        LocalPlayer().ActiveCrafts[i] = {
            item = itemClass,
            timeLeft = timeLeft
        }
    end
end)

-- Сетевая функция для добавления крафта
net.Receive("gRust.CraftStarted", function()
    local itemClass = net.ReadString()
    local craftTime = net.ReadFloat()
    
    LocalPlayer().ActiveCrafts = LocalPlayer().ActiveCrafts or {}
    table.insert(LocalPlayer().ActiveCrafts, {
        item = itemClass,
        timeLeft = craftTime
    })
end)

-- Сетевая функция для завершения крафта
net.Receive("gRust.CraftCompleted", function()
    local itemClass = net.ReadString()
    
    if LocalPlayer().ActiveCrafts then
        for i, craft in ipairs(LocalPlayer().ActiveCrafts) do
            if craft.item == itemClass then
                table.remove(LocalPlayer().ActiveCrafts, i)
                print("[CRAFT] Completed: " .. itemClass)
                break
            end
        end
    end
end)

-- Таймер для обновления времени крафтов
timer.Create("gRust.CraftTimeUpdate", 0.5, 0, function()
    if not LocalPlayer().ActiveCrafts then return end
    
    for _, craft in pairs(LocalPlayer().ActiveCrafts) do
        if craft.timeLeft and craft.timeLeft > 0 then
            craft.timeLeft = craft.timeLeft - 0.5
        end
    end
end)

local radiationNotification = gRust.CreateNotification()
radiationNotification:SetColor(Color(150, 49, 31, 250))
radiationNotification:SetIconColor(Color(92, 30, 2))
radiationNotification:SetTextColor(Color(178, 136, 123))
radiationNotification.Update = function(self)
    local lvl = LocalPlayer().RadiationLevel or 0
    self.Text = "RADIATION"
    self.Icon = "icons/protection/radiation.png"
    self.Side = math.ceil(lvl)
end

radiationNotification:SetCondition(function()
    return (LocalPlayer().RadiationLevel or 0) > 0
end)

net.Receive("gRust.RadiationLevel", function()
    local level = net.ReadUInt(16)
    LocalPlayer().RadiationLevel = level

    if level > 0 then
        radiationNotification:Show()
    else
        radiationNotification:Hide()
    end
end)

local safeZoneNotification = gRust.CreateNotification()
safeZoneNotification:SetColor(Color(94, 113, 40))
safeZoneNotification:SetIconColor(Color(145, 193, 20))
safeZoneNotification:SetTextColor(Color(240, 240, 209))

safeZoneNotification.Update = function(self)
    local inSafeZone = LocalPlayer().InSafeZone or false
    local zoneName = LocalPlayer().CurrentSafeZoneName or "Safe Zone"
    
    if inSafeZone then
        self.Text = "Safe Zone"
        self.Icon = "icons/safe_zone.png"
        self.Side = ""
    else
        self.Text = ""
        self.Side = ""
    end
end

safeZoneNotification:SetCondition(function()
    return LocalPlayer().InSafeZone or false
end)

local bleedingNotification = gRust.CreateNotification()
bleedingNotification:SetColor(Color(150, 49, 31, 250))
bleedingNotification:SetIconColor(Color(92, 30, 2))
bleedingNotification:SetTextColor(Color(255, 200, 200))

bleedingNotification.Update = function(self)
    local bleedTime = LocalPlayer().BleedingTime or 0
    self.Text = "BLEEDING"
    self.Icon = "icons/bleeding.png" -- Если нет иконки, можно использовать существующую
    self.Side = math.ceil(bleedTime) .. ""
end

bleedingNotification:SetCondition(function()
    return (LocalPlayer().BleedingTime or 0) > 0
end)

-- Обработчик сетевого сообщения
net.Receive("gRust.BleedingSync", function()
    local bleedTime = net.ReadUInt(16)
    LocalPlayer().BleedingTime = bleedTime
    
    if bleedTime > 0 then
        print("[BLEEDING] Client received bleeding: " .. bleedTime .. "s")
    else
        print("[BLEEDING] Client: bleeding stopped")
    end
end)


-- Сбрасываем кровотечение при смерти
-- Сетевая функция для входа в сейф-зону
net.Receive("gRust.SafeZoneEnter", function()
    local zoneEntity = net.ReadEntity()
    local message = net.ReadString()
    local noWeapons = net.ReadBool()
    local noBuild = net.ReadBool()
    
    LocalPlayer().InSafeZone = true
    LocalPlayer().CurrentSafeZoneEntity = zoneEntity
    LocalPlayer().CurrentSafeZoneName = message
    LocalPlayer().SafeZoneEnterTime = CurTime()
    
    if message and message ~= "" then
        LocalPlayer():ChatPrint(message)
    end
    
    print("[SAFEZONE] Entered safe zone: " .. message)
end)

-- Сетевая функция для выхода из сейф-зоны
net.Receive("gRust.SafeZoneExit", function()
    local zoneEntity = net.ReadEntity()
    local message = net.ReadString()
    
    LocalPlayer().InSafeZone = false
    LocalPlayer().CurrentSafeZoneEntity = nil
    LocalPlayer().CurrentSafeZoneName = nil
    LocalPlayer().SafeZoneEnterTime = nil
    
    if message and message ~= "" then
        LocalPlayer():ChatPrint(message)
    end
    
    print("[SAFEZONE] Left safe zone")
end)

-- Сетевая функция для получения уведомления о добыче ресурсо

-- Сетевая функция для уведомления о подборе предмета

-- Отрисовка нотификаций
hook.Add("HUDPaint", "gRust.Notify", function()
    if not gRust.Hud or not gRust.Hud.ShouldDraw then return end
    if not gRust.Notifications then return end

    local scrw, scrh = ScrW(), ScrH()
    local hudHeight = 3 * (gRust.Hud.BarHeight or 52) + 3 * (gRust.Hud.BarSpacing or 4)
    local margin = gRust.Hud.Margin or 32
    local baseY = scrh - hudHeight - margin - 10
    local w, h = gRust.Hud.BarWidth or 384, gRust.Hud.BarHeight or 52
    local offset = 0
    local offsetRight = 15

    for i = #gRust.Notifications, 1, -1 do
        local n = gRust.Notifications[i]
        n:Think()
        if not n.visible then continue end

        local drawY = baseY - offset - h
        gRust.DrawPanelColored(scrw - w - margin, drawY, w, h, n.Color)

        if n.Icon and n.Icon ~= "" then
            local mat
            if isstring(n.Icon) then
                mat = Material(n.Icon)
                if mat:IsError() then mat = nil end
            else
                mat = n.Icon
            end
            if mat then
                surface.SetDrawColor(n.IconColor or color_white)
                surface.SetMaterial(mat)
                local iconSize = h - (n.IconPadding or 5) * 2
                surface.DrawTexturedRect(scrw - w - margin + (n.IconPadding or 5), drawY + (n.IconPadding or 5), iconSize, iconSize)
            end
        end

        draw.SimpleText(n.Text or "", "gRust.32px", scrw - w - margin + h + 5, drawY + h/2, n.TextColor or color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        if n.Side then
            draw.SimpleText(n.Side, "gRust.32px", scrw - margin - offsetRight, drawY + h/2, n.SideColor or n.TextColor or color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        end

        offset = offset + h + (gRust.Hud.BarSpacing or 4)
    end

    local pickupOffset = offset
    for i, notification in ipairs(gRust.PickupNotifications) do
        if notification and notification.visible then
            notification:Think()

            local drawY = baseY - pickupOffset - h
            gRust.DrawPanelColored(scrw - w - margin, drawY, w, h, notification.Color)

            if notification.Icon and notification.Icon ~= "" then
                local mat = Material(notification.Icon)
                if not mat:IsError() then
                    surface.SetDrawColor(notification.IconColor or color_white)
                    surface.SetMaterial(mat)
                    local iconSize = h - (notification.IconPadding or 3) * 2
                    surface.DrawTexturedRect(scrw - w - margin + (notification.IconPadding or 3), drawY + (notification.IconPadding or 3), iconSize, iconSize)
                end
            end

            draw.SimpleText(notification.Text or "", "gRust.32px", scrw - w - margin + h + 5, drawY + h/2, notification.TextColor or color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            if notification.Side then
                draw.SimpleText(notification.Side, "gRust.32px", scrw - margin - offsetRight, drawY + h/2, notification.SideColor or notification.TextColor or color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            end

            pickupOffset = pickupOffset + h + (gRust.Hud.BarSpacing or 4)
        end
    end
end)
