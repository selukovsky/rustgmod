local Notifications = {}

hook.Add("HUDPaint", "gRust.Notifications", function()
    --[[local scrw, scrh = ScrW(), ScrH()

    local notifications = gRust.Notifications

    local yOffset = 0
    for i = 1, #notifications do
        local notif = notifications[i]

        local x = scrw - gRust.Hud.BarWidth - gRust.Hud.Margin
        local y = scrh - gRust.Hud.Margin - (gRust.Hud.BarHeight + gRust.Hud.BarSpacing) * #gRust.Hud.Bars
        local w = gRust.Hud.BarWidth
        local h = gRust.Hud.BarHeight

        yOffset = yOffset - (1 - notif.animProgress) * -h

        y = y - (h + gRust.Hud.BarSpacing) * (notif.index - 1)
        y = y + yOffset

        surface.SetAlphaMultiplier(notif.animProgress)
    
        surface.SetDrawColor(gRust.Colors.Primary)
        surface.DrawRect(x, y - h, w, h)
    end]]
end)

--[[local wet = gRust.CreateNotification()
wet:SetCondition(function()
    return LocalPlayer():WaterLevel() > 0
end)]]