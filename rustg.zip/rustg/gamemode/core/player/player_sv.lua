util.AddNetworkString("gRust.NetReady")
util.AddNetworkString("gRust.BleedingSync")
util.AddNetworkString("gRust.BleedingEffect")
net.Receive("gRust.NetReady", function(len, ply)
    if IsValid(ply) then
        ply.Hunger = 200
        ply.Thirst = 200
        local randomHealth = math.random(50, 60)
        ply:SetHealth(randomHealth)
        ply:SyncMetabolism()
        ply:CreateInventory(36)
        local sleepingBag = FindPlayerSleepingBag(ply)
        if IsValid(sleepingBag) then
            -- Используем улучшенную функцию спавна
            SpawnOnSleepingBag(ply, sleepingBag)
            
            timer.Simple(0.1, function() 
                if IsValid(ply) and IsValid(sleepingBag) then 
                    TransferSleepingBagToPlayer(ply, sleepingBag) 
                end 
            end)
        else
            ply:GiveItem("rock", 1)
            ply:GiveItem("torch12", 1)
            ply:Give("rust_hands")
            ply:SelectWeapon("rust_hands")
        end
    end
end)

-- Функция для поиска безопасной позиции спавна
function FindSafeSpawnPosition(bagPos)
    local trace = {}
    trace.start = bagPos + Vector(0, 0, 50) -- Начинаем поиск на 50 юнитов выше мешка
    trace.endpos = bagPos + Vector(0, 0, 200) -- Ищем до 200 юнитов вверх
    trace.mask = MASK_SOLID_BRUSHONLY
    trace.collisiongroup = COLLISION_GROUP_PLAYER
    
    local tr = util.TraceLine(trace)
    
    if tr.Hit then
        -- Если есть препятствие сверху, спавним на 10 юнитов ниже точки столкновения
        return tr.HitPos - Vector(0, 0, 10)
    else
        -- Если свободно, спавним на 100 юнитов выше мешка
        return bagPos + Vector(0, 0, 100)
    end
end

-- Альтернативная функция с более надежным поиском
function FindSafeSpawnPositionAdvanced(bagPos)
    local playerHeight = 72 -- Примерная высота игрока
    local playerWidth = 32 -- Примерная ширина игрока
    
    -- Проверяем несколько высот для спавна
    local testHeights = {150, 100, 75, 50, 25}
    
    for _, height in ipairs(testHeights) do
        local testPos = bagPos + Vector(0, 0, height)
        
        -- Проверяем, свободно ли место для игрока
        local traceUp = util.TraceLine({
            start = testPos,
            endpos = testPos + Vector(0, 0, playerHeight),
            mask = MASK_SOLID_BRUSHONLY,
            collisiongroup = COLLISION_GROUP_PLAYER
        })
        
        local traceDown = util.TraceLine({
            start = testPos,
            endpos = testPos - Vector(0, 0, playerHeight),
            mask = MASK_SOLID_BRUSHONLY,
            collisiongroup = COLLISION_GROUP_PLAYER
        })
        
        -- Если сверху достаточно места и снизу есть поверхность
        if not traceUp.Hit and traceDown.Hit then
            return traceDown.HitPos + Vector(0, 0, 5) -- Спавним на 5 юнитов выше поверхности
        end
    end
    
    -- Если не нашли подходящее место, возвращаем позицию над мешком
    return bagPos + Vector(0, 0, 100)
end

-- Обновленная функция спавна на мешке (замените старую в NetReady)
local function SpawnOnSleepingBag(ply, sleepingBag)
    local bagPos = sleepingBag:GetPos()
    
    -- Используем улучшенную функцию поиска позиции
    local spawnPos = FindSafeSpawnPositionAdvanced(bagPos)
    
    -- Дополнительная проверка с помощью TraceHull для уверенности
    local hullTrace = util.TraceHull({
        start = spawnPos,
        endpos = spawnPos,
        mins = Vector(-playerWidth, -playerWidth, 0),
        maxs = Vector(playerWidth, playerWidth, playerHeight),
        mask = MASK_SOLID_BRUSHONLY,
        collisiongroup = COLLISION_GROUP_PLAYER
    })
    
    if hullTrace.Hit then
        -- Если все еще есть столкновение, используем принудительную позицию над мешком
        spawnPos = bagPos + Vector(0, 0, 200)
        print("[SPAWN] Using emergency spawn position for " .. ply:Nick())
    end
    
    ply:SetPos(spawnPos)
    ply:SetEyeAngles(Angle(0, math.random(0, 360), 0))
    ply:SetLocalVelocity(Vector(0, 0, 0)) -- Сбрасываем velocity
    
    print("[SPAWN] " .. ply:Nick() .. " spawned at " .. tostring(spawnPos) .. " (bag at " .. tostring(bagPos) .. ")")
end

local models = {"models/player/spike/rustguy_grust.mdl",}
local function InitializeDatabase()
    sql.Query([[
        CREATE TABLE IF NOT EXISTS grust_player_models (
            steamid TEXT PRIMARY KEY,
            model TEXT NOT NULL
        )
    ]])
end

local function LoadPlayerModel(steamID)
    local query = sql.QueryValue("SELECT model FROM grust_player_models WHERE steamid = " .. sql.SQLStr(steamID))
    return query
end

local function SavePlayerModel(steamID, model)
    local query = sql.Query("INSERT OR REPLACE INTO grust_player_models (steamid, model) VALUES (" .. sql.SQLStr(steamID) .. ", " .. sql.SQLStr(model) .. ")")
    return true
end

local function LoadAllPlayerModels()
    local query = sql.Query("SELECT steamid, model FROM grust_player_models")
    local result = {}
    if query then
        for i = 1, #query do
            result[query[i].steamid] = query[i].model
        end
    end
    return result
end

InitializeDatabase()
local PLAYER = FindMetaTable("Player")
function PLAYER:CanInteractWith(ent)
    if not IsValid(ent) or not IsValid(self) then return false end
    if self:GetPos():Distance(ent:GetPos()) > 150 then return false end
    return true
end

function PLAYER:GetAssignedModel()
    local steamID = self:SteamID()
    local savedModel = LoadPlayerModel(steamID)
    if savedModel then
        return savedModel
    else
        local model = models[math.random(#models)]
        return model
    end
end

hook.Add("PlayerSpawn", "gRust.AssignRandomModel", function(ply)
    timer.Simple(0, function()
        if IsValid(ply) then
            local model = ply:GetAssignedModel()
            ply:SetModel(model)
        end
    end)
end)

hook.Add("PlayerInitialSpawn", "gRust.InitialModelAssign", function(ply) timer.Simple(0, function() if IsValid(ply) then ply:GetAssignedModel() end end) end)
concommand.Add("spawnent", function(ply, cmd, args)
    if not ply:IsSuperAdmin() then return end
    local entityClass = args[1] or "prop_physics"
    local maxDistance = tonumber(args[2]) or 500
    local trace = ply:GetEyeTrace()
    local spawnPos = trace.HitPos
    local distance = ply:GetPos():Distance(spawnPos)
    if distance > maxDistance then return end
    local entity = ents.Create(entityClass)
    if IsValid(entity) then
        entity:SetPos(spawnPos + trace.HitNormal * 5)
        entity:SetAngles(ply:GetAngles())
        entity:Spawn()
        local phys = entity:GetPhysicsObject()
        if IsValid(phys) then phys:Wake() end
    else
    end
end)


local DMG_BLEED = 134217728 -- Флаг для кровотечения (или используем DMG_SLASH = 4 если нужно)

-- Храним данные кровотечения для игроков
local playerBleeding = {}

-- Конфигурация
local BLEED_DAMAGE = 2 -- Урон за каждую секунду кровотечения
local BLEED_INTERVAL = 1 -- Интервал урона в секундах

hook.Add("EntityTakeDamage", "gRust.BleedingSystem", function(target, dmg)
    if not IsValid(target) or not target:IsPlayer() then return end
    
    local attacker = dmg:GetAttacker()
    local damageAmount = dmg:GetDamage()
    
    -- Проверяем источник урона (исключаем сам урон от кровотечения)
    if dmg:GetDamageType() == DMG_BLEED then return end
    
    if IsValid(attacker) and (attacker:IsPlayer() or attacker:IsNPC()) and damageAmount > 0 then
        local ply = target
        
        -- Инициализируем данные игрока если нужно
        if not playerBleeding[ply] then
            playerBleeding[ply] = {
                time = 0,
                startTime = CurTime(),
                lastBleedTime = CurTime()
            }
        end
        
        -- Добавляем 2 секунды кровотечения
        playerBleeding[ply].time = playerBleeding[ply].time + 2
        playerBleeding[ply].startTime = CurTime()
        
        -- Синхронизируем с клиентом
        net.Start("gRust.BleedingSync")
        net.WriteUInt(playerBleeding[ply].time, 16)
        net.Send(ply)
        
        print("[BLEEDING] " .. ply:Nick() .. " now bleeding for " .. playerBleeding[ply].time .. "s")
    end
end)

-- Таймер обновления кровотечения и нанесения урона
timer.Create("gRust.BleedingUpdate", BLEED_INTERVAL, 0, function()
    for ply, data in pairs(playerBleeding) do
        if not IsValid(ply) then
            playerBleeding[ply] = nil
            continue
        end
        
        if data.time > 0 then
            local elapsed = CurTime() - data.startTime
            
            -- Наносим урон от кровотечения
            if CurTime() - data.lastBleedTime >= BLEED_INTERVAL then
                if ply:Alive() and ply:Health() > 0 then
                    -- Наносим урон (используем DMG_SLASH вместо DMG_BLEED)
                    local damage = DamageInfo()
                    damage:SetDamage(BLEED_DAMAGE)
                    damage:SetDamageType(DMG_SLASH) -- Используем существующий тип урона
                    damage:SetAttacker(game.GetWorld())
                    damage:SetInflictor(game.GetWorld())
                    damage:SetDamagePosition(ply:GetPos())
                    
                    ply:TakeDamageInfo(damage)
                    
                    -- Эффект крови на клиенте
                    net.Start("gRust.BleedingEffect")
                    net.WriteUInt(BLEED_DAMAGE, 8)
                    net.Send(ply)
                    
                    data.lastBleedTime = CurTime()
                    print("[BLEEDING] " .. ply:Nick() .. " took " .. BLEED_DAMAGE .. " bleed damage. Health: " .. ply:Health())
                end
            end
            
            if elapsed >= data.time then
                -- Кровотечение закончилось
                data.time = 0
                
                net.Start("gRust.BleedingSync")
                net.WriteUInt(0, 16)
                net.Send(ply)
                
                print("[BLEEDING] " .. ply:Nick() .. " stopped bleeding")
            else
                -- Обновляем клиент каждые 3 секунды
                if math.fmod(elapsed, 3) < BLEED_INTERVAL then
                    local remaining = math.ceil(data.time - elapsed)
                    net.Start("gRust.BleedingSync")
                    net.WriteUInt(remaining, 16)
                    net.Send(ply)
                end
            end
        else
            playerBleeding[ply] = nil
        end
    end
end)

-- Сброс при смерти
hook.Add("PlayerDeath", "gRust.BleedingReset", function(ply)
    if playerBleeding[ply] then
        playerBleeding[ply].time = 0
        
        net.Start("gRust.BleedingSync")
        net.WriteUInt(0, 16)
        net.Send(ply)
        
        print("[BLEEDING] " .. ply:Nick() .. " bleeding reset due to death")
    end
end)

-- Сброс при спавне
hook.Add("PlayerSpawn", "gRust.BleedingReset", function(ply)
    playerBleeding[ply] = nil -- Полностью удаляем данные
    
    net.Start("gRust.BleedingSync")
    net.WriteUInt(0, 16)
    net.Send(ply)
    
    print("[BLEEDING] " .. ply:Nick() .. " bleeding reset due to spawn")
end)

-- Синхронизация при подключении
hook.Add("PlayerInitialSpawn", "gRust.BleedingSync", function(ply)
    timer.Simple(3, function()
        if IsValid(ply) and playerBleeding[ply] then
            net.Start("gRust.BleedingSync")
            net.WriteUInt(playerBleeding[ply].time or 0, 16)
            net.Send(ply)
        end
    end)
end)