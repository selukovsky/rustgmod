util.AddNetworkString("gRust.DeathScreen")
util.AddNetworkString("gRust.Respawn")
util.AddNetworkString("gRust.BagRespawn")

local playerSleepingBags = {}

-- SQL таблица
if not sql.TableExists("player_sleeping_bags") then 
    sql.Query([[
        CREATE TABLE player_sleeping_bags (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            steam_id TEXT NOT NULL,
            entity_id INTEGER NOT NULL,
            pos_x REAL NOT NULL,
            pos_y REAL NOT NULL,
            pos_z REAL NOT NULL,
            respawn_delay INTEGER DEFAULT 300,
            last_respawn REAL DEFAULT 0
        );
    ]]) 
end

function LoadPlayerSleepingBags(steamID)
    local data = sql.Query("SELECT * FROM player_sleeping_bags WHERE steam_id = '" .. steamID .. "'")
    local bags = {}
    
    if data then
        for _, bag in ipairs(data) do
            local entity = ents.GetByIndex(tonumber(bag.entity_id))
            if IsValid(entity) and entity:GetClass() == "rust_sleepingbag" then
                table.insert(bags, {
                    entity = entity,
                    pos = Vector(tonumber(bag.pos_x), tonumber(bag.pos_y), tonumber(bag.pos_z))
                })

                -- Восстанавливаем владельца и данные
                local owner = player.GetBySteamID64(steamID)
                if IsValid(owner) then
                    entity.Owner = owner
                end
                entity.RespawnDelay = tonumber(bag.respawn_delay) or 300
                entity:SetNWFloat("LastRespawn", tonumber(bag.last_respawn) or 0)
            else
                -- Удаляем несуществующие мешки из базы
                sql.Query("DELETE FROM player_sleeping_bags WHERE entity_id = " .. tonumber(bag.entity_id))
            end
        end
    end
    
    return bags
end

function SavePlayerSleepingBags(ply)
    if not IsValid(ply) then return end
    local steamID = ply:SteamID64()
    
    sql.Query("DELETE FROM player_sleeping_bags WHERE steam_id = '" .. steamID .. "'")
    
    if playerSleepingBags[steamID] then
        for _, bagData in ipairs(playerSleepingBags[steamID]) do
            if IsValid(bagData.entity) and bagData.entity:GetClass() == "rust_sleepingbag" then
                local pos = bagData.entity:GetPos()
                sql.Query(string.format([[
                    INSERT INTO player_sleeping_bags
                    (steam_id, entity_id, pos_x, pos_y, pos_z, respawn_delay, last_respawn)
                    VALUES ('%s', %d, %f, %f, %f, %d, %f)
                ]], steamID, bagData.entity:EntIndex(), pos.x, pos.y, pos.z, 
                   bagData.entity.RespawnDelay or 300, 
                   bagData.entity:GetNWFloat("LastRespawn", 0))) 
            end
        end
    end
end

function AddSleepingBagToPlayer(ply, bagEntity)
    if not IsValid(ply) or not IsValid(bagEntity) then return end
    local steamID = ply:SteamID64()
    
    if not playerSleepingBags[steamID] then 
        playerSleepingBags[steamID] = {} 
    end
    
    -- Проверяем, нет ли уже этого мешка
    for _, bagData in ipairs(playerSleepingBags[steamID]) do
        if bagData.entity == bagEntity then return end
    end

    table.insert(playerSleepingBags[steamID], {
        entity = bagEntity,
        pos = bagEntity:GetPos()
    })

    bagEntity.Owner = ply
    bagEntity.RespawnDelay = 300
    bagEntity:SetNWFloat("LastRespawn", 0)
    
    SavePlayerSleepingBags(ply)
    print("[DeathSystem] Added sleeping bag for " .. ply:Nick() .. ", total: " .. #playerSleepingBags[steamID])
end

function RemoveSleepingBagFromPlayer(ply, bagEntity)
    if not IsValid(ply) then return end
    local steamID = ply:SteamID64()
    
    if playerSleepingBags[steamID] then
        for i, bagData in ipairs(playerSleepingBags[steamID]) do
            if bagData.entity == bagEntity then
                table.remove(playerSleepingBags[steamID], i)
                break
            end
        end
    end
    
    SavePlayerSleepingBags(ply)
    if IsValid(bagEntity) then 
        sql.Query(string.format("DELETE FROM player_sleeping_bags WHERE steam_id = '%s' AND entity_id = %d", steamID, bagEntity:EntIndex())) 
    end
    
    print("[DeathSystem] Removed sleeping bag for " .. ply:Nick())
end

function GetPlayerSleepingBags(ply)
    if not IsValid(ply) then return {} end
    local steamID = ply:SteamID64()
    
    if not playerSleepingBags[steamID] then 
        playerSleepingBags[steamID] = LoadPlayerSleepingBags(steamID)
    end
    
    local validBags = {}
    for i = #playerSleepingBags[steamID], 1, -1 do
        local bagData = playerSleepingBags[steamID][i]
        if bagData and IsValid(bagData.entity) and bagData.entity:GetClass() == "rust_sleepingbag" then
            table.insert(validBags, bagData)
        else
            table.remove(playerSleepingBags[steamID], i)
        end
    end
    
    if #validBags ~= #playerSleepingBags[steamID] then 
        SavePlayerSleepingBags(ply) 
    end
    
    return validBags
end

local function SendDeathScreenData(victim, attacker)
    if not IsValid(victim) then return end
    
    local sleepingBags = GetPlayerSleepingBags(victim)
    print("[DeathScreen] Sending " .. #sleepingBags .. " bags for player " .. victim:Nick())
    
    net.Start("gRust.DeathScreen")
    net.WriteEntity(attacker or victim) -- Киллиер
    net.WriteUInt(#sleepingBags, 8)
    
    for _, bagData in ipairs(sleepingBags) do
        if IsValid(bagData.entity) then
            net.WriteUInt(bagData.entity:EntIndex(), 13)
            net.WriteVector(bagData.entity:GetPos())
            
            local lastRespawn = bagData.entity:GetNWFloat("LastRespawn", 0)
            local respawnDelay = bagData.entity.RespawnDelay or 300
            local canRespawn = (lastRespawn + respawnDelay) <= CurTime()
            
            net.WriteBool(canRespawn)
            
            if not canRespawn then
                local timeLeft = math.max(0, (lastRespawn + respawnDelay) - CurTime())
                net.WriteFloat(timeLeft)
                print("[DeathScreen] Bag cooldown: " .. timeLeft .. "s (last: " .. lastRespawn .. ", delay: " .. respawnDelay .. ")")
            else
                print("[DeathScreen] Bag ready for respawn")
            end
        end
    end
    
    net.Send(victim)
end

hook.Add("PlayerDeath", "gRust.PlayerDeaths", function(victim, inflictor, attacker)
    if not IsValid(victim) then return end
    
    timer.Simple(1.0, function()
        if IsValid(victim) then
            SendDeathScreenData(victim, attacker)
        end
    end)
end)

net.Receive("gRust.Respawn", function(len, ply)
    if not IsValid(ply) then return end
    
    print("[Respawn] Player " .. ply:Nick() .. " requested respawn")
    
    if ply:Alive() then 
        print("[Respawn] Player is already alive")
        return 
    end
    
    ply:Spawn()
    print("[Respawn] Player " .. ply:Nick() .. " respawned")
end)

net.Receive("gRust.BagRespawn", function(len, ply)
    if not IsValid(ply) then return end
    
    print("[BagRespawn] Player " .. ply:Nick() .. " requested bag respawn")
    
    if ply:Alive() then 
        print("[BagRespawn] Player is already alive")
        return 
    end
    
    local bagIndex = net.ReadUInt(13)
    local sleepingBags = GetPlayerSleepingBags(ply)
    local selectedBag = nil
    
    for _, bagData in ipairs(sleepingBags) do
        if IsValid(bagData.entity) and bagData.entity:EntIndex() == bagIndex then
            selectedBag = bagData
            break
        end
    end

    if not selectedBag or not IsValid(selectedBag.entity) then 
        print("[BagRespawn] Invalid bag selected: " .. bagIndex)
        return 
    end
    
    local lastRespawn = selectedBag.entity:GetNWFloat("LastRespawn", 0)
    local respawnDelay = selectedBag.entity.RespawnDelay or 300
    
    if lastRespawn + respawnDelay > CurTime() then 
        print("[BagRespawn] Bag not ready yet")
        return 
    end
    
    -- Сначала спавним игрока
    ply:Spawn()
    
    -- Затем телепортируем к мешку
    timer.Simple(0.1, function() 
        if IsValid(ply) and IsValid(selectedBag.entity) then 
            local spawnPos = selectedBag.entity:GetPos() + Vector(0, 0, 50)
            ply:SetPos(spawnPos)
            print("[BagRespawn] Player " .. ply:Nick() .. " respawned at sleeping bag at " .. tostring(spawnPos))
        end 
    end)
    
    -- Обновляем время последнего респавна
    local now = CurTime()
    selectedBag.entity:SetNWFloat("LastRespawn", now)
    
    sql.Query(string.format("UPDATE player_sleeping_bags SET last_respawn = %f WHERE steam_id = '%s' AND entity_id = %d", 
        now, ply:SteamID64(), selectedBag.entity:EntIndex()))
    
    SavePlayerSleepingBags(ply)
    print("[BagRespawn] Player " .. ply:Nick() .. " respawned at sleeping bag")
end)

hook.Add("PlayerInitialSpawn", "gRust.LoadSleepingBags", function(ply)
    local steamID = ply:SteamID64()
    playerSleepingBags[steamID] = LoadPlayerSleepingBags(steamID)
    print("[SleepingBags] Loaded " .. (playerSleepingBags[steamID] and #playerSleepingBags[steamID] or 0) .. " bags for " .. ply:Nick())
end)

hook.Add("PlayerDisconnected", "gRust.CleanupSleepingBags", function(ply)
    SavePlayerSleepingBags(ply)
end)

hook.Add("EntityRemoved", "gRust.CleanupRemovedBags", function(ent)
    if ent:GetClass() == "rust_sleepingbag" and IsValid(ent.Owner) then
        RemoveSleepingBagFromPlayer(ent.Owner, ent)
    end
end)

-- Автосохранение каждые 5 минут
timer.Create("gRust.SaveSleepingBags", 300, 0, function()
    for _, ply in pairs(player.GetAll()) do
        SavePlayerSleepingBags(ply)
    end
end)

-- Сохранение при выключении сервера
hook.Add("ShutDown", "gRust.SaveAllSleepingBags", function()
    for _, ply in pairs(player.GetAll()) do
        SavePlayerSleepingBags(ply)
    end
end)