gRust.Attire = {}
gRust.CategoryItems = gRust.CategoryItems or {}

ATTIRE_FULLBODY = 0
ATTIRE_HEAD = 1
ATTIRE_HAZIK = 2 -- антирадиационный костюм
ATTIRE_TORS = 3 -- нагрудник
ATTIRE_HEAD2 = 4 -- вторая маска
ATTIRE_PANTS = 5
ATTIRE_SHOES = 6
ATTIRE_SHIRT = 7
ATTIRE_ROAD = 8
ATTIRE_KILT = 9
ATTIRE_BURPANTS = 10
ATTIRE_BURSHOES = 11
ATTIRE_BURSHIRT = 12
ATTIRE_BURHEAD = 13
ATTIRE_TSHIRT = 14
ATTIRE_WOODTORS = 15
ATTIRE_WOODPANTS = 16
ATTIRE_BONE = 17
ATTIRE_WOLF = 18
ATTIRE_BUCKET = 19

----------------------------------------------------------------------
-- Таблица соответствия предметов и бодигрупп
-- Ключи ДОЛЖНЫ совпадать с тем, что передаётся в SetAttire()
----------------------------------------------------------------------

gRust.AttireProtection = {
    ["chestplate"] = { Projectile = 0.15, Melee = 0.20 },
    ["hoodie"] = { Cold = 0.10, Projectile = 0.02, Radiation = 0.10, Melee = 0.08 },
    ["pants"] = { Cold = 0.10, Projectile = 0.02, Radiation = 0.10, Melee = 0.06 },
    ["coffee_mask"] = { Projectile = 0.10, Melee = 0.08 },
    ["shoest"] = { Cold = 0.05, Projectile = 0.1, Radiation = 0.05, Melee = 0.08 },
    ["hqm.mask"] = { Cold = 0.1, Projectile = 0.15, Melee = 0.08 },
    ["burlapshirt"] = { Cold = 0.08, Projectile = 0.01, Radiation = 0.06, Melee = 0.02 },
    ["burlappants"] = { Cold = 0.08, Projectile = 0.01, Radiation = 0.04, Melee = 0.02 },
    ["burlapshoes"] = { Cold = 0.05, Projectile = 0.01, Radiation = 0.02, Melee = 0.02 },
    ["burlaphead"] = { Cold = 0.04, Projectile = 0.01, Radiation = 0.02, Melee = 0.02 },
    ["road"] = { Cold = 0.01, Projectile = 0.10, Melee = 0.08 },
    ["wtors"] = { Cold = 0.05, Projectile = 0.01, Radiation = 0.05, Melee = 0.08 },
    ["wpants"] = { Cold = 0.05, Projectile = 0.01, Radiation = 0.05, Melee = 0.08 },
    ["bone"] = { Cold = 0.03, Projectile = 0.03, Radiation = 0.10, Melee = 0.08 },
    ["wolfhed"] = { Cold = 0.08, Projectile = 0.04, Radiation = 0.10, Melee = 0.08 },
    ["metbucket"] = { Cold = 0.02, Projectile = 0.06, Melee = 0.08 },
    ["kiltroad"] = { Cold = 0.01, Projectile = 0.05, Melee = 0.08 },
    ["tshirt"] = { Cold = 0.10, Radiation = 0.15, Melee = 0.08 },
    ["hazmat"] = { Cold = 0.08, Radiation = 0.50, Projectile = 0.15, Melee = 0.08 },
    ["limber"] = { Cold = 0.08, Radiation = 0.50, Projectile = 0.15, Melee = 0.08 },
    ["holodno"] = { Cold = 0.33, Radiation = 0.50, Projectile = 0.15, Melee = 0.08 },
    ["nomad"] = { Cold = 0.08, Radiation = 0.50, Projectile = 0.15, Melee = 0.08 },
    -- Добавьте остальные предметы по аналогииhazmat
}

gRust.BodygroupsData = {
    ["chestplate"] = {
        [6] = 3
    },
    ["coffee_mask"] = {
        [8] = 4
    },
    ["hqm.mask"] = {
        [8] = 6
    },
    ["burlapshirt"] = {
        [2] = 2
    },
    ["burlappants"] = {
        [3] = 2
    },
    ["burlapshoes"] = {
        [5] = 2
    },
    ["burlaphead"] = {
        [8] = 1
    },
    ["hoodie"] = {
        [2] = 1
    },
    ["pants"] = {
        [3] = 1
    },
    ["shoest"] = {
        [5] = 1
    },
    ["road"] = {
        [6] = 1
    },
    ["wtors"] = {
        [6] = 2
    },
    ["wpants"] = {
        [7] = 2
    },
    ["tshirt"] = {
        [2] = 3
    },
    ["bone"] = {
        [8] = 2
    },
    ["wolfhed"] = {
        [8] = 5
    },
    ["metbucket"] = {
        [8] = 3
    },
    ["kiltroad"] = {
        [7] = 1
    }
}

----------------------------------------------------------------------
-- Применение бодигрупп игроку
----------------------------------------------------------------------

function ApplyAttireBodygroups(ply)
    if not IsValid(ply) then return end
    if not ply.EquippedAttire then
        return
    end

    -- Сброс всех бодигрупп
    for _, bg in pairs(ply:GetBodyGroups()) do
        ply:SetBodygroup(bg.id, 0)
    end

    -- Применение бодигрупп по экипировке
    for _, attireId in pairs(ply.EquippedAttire) do
        local bgData = gRust.BodygroupsData[attireId]
        if bgData then
            for bgId, val in pairs(bgData) do
                ply:SetBodygroup(bgId, val)
            end
        end
    end

    -- Обновляем кости модели (InvalidateBoneCache больше нет)
    if ply.SetupBones then
        ply:SetupBones()
    end
end

function CalculateTotalProtection(ply)
    if not IsValid(ply) then return {} end
    
    local totalProtection = {
        Projectile = 0,
        Melee = 0,
        Bite = 0,
        Radiation = 0,
        Cold = 0,
        Explosive = 0
    }
    
    if ply.EquippedAttire then
        for slot, attireId in pairs(ply.EquippedAttire) do
            local protection = gRust.AttireProtection[attireId]
            if protection then
                for protectionType, value in pairs(protection) do
                    if totalProtection[protectionType] then
                        totalProtection[protectionType] = totalProtection[protectionType] + value
                    end
                end
            end
        end
    end
    
    for protectionType, value in pairs(totalProtection) do
        totalProtection[protectionType] = math.Clamp(value, 0, 1)
    end
    
    ply.AttireProtection = totalProtection

    net.Start("gRust_UpdateProtection")
    net.WriteTable(totalProtection)
    net.Send(ply)
    
    return totalProtection
end


-- Делаем функцию глобально доступной
gRust.CalculateTotalProtection = CalculateTotalProtection

----------------------------------------------------------------------
-- Обновление надетых предметов
----------------------------------------------------------------------

function UpdatePlayerEquippedAttire(ply, newAttireTable)
    if not IsValid(ply) then return end

    local oldAttire = ply.EquippedAttire or {}
    ply.EquippedAttire = newAttireTable or {}

    -- Вызов хуков: что надели
    for slot, attireId in pairs(newAttireTable) do
        if oldAttire[slot] ~= attireId then
            hook.Run("gRust.OnEquipAttire", ply, attireId)
        end
    end

    -- Вызов хуков: что сняли
    for slot, attireId in pairs(oldAttire) do
        if newAttireTable[slot] ~= attireId then
            hook.Run("gRust.OnUnequipAttire", ply, attireId)
        end
    end

    -- Применить бодигруппы
    ApplyAttireBodygroups(ply)
    
    -- ОБЯЗАТЕЛЬНО: пересчитываем защиту
    CalculateTotalProtection(ply)
end

-- Логика экипировки предмета
function gRust.EquipItem(ply, slot, itemID)
    -- твоя логика надевания
    ply.EquippedAttire[slot] = itemID

    -- сразу обновляем бодигруппы и панель защиты
    UpdatePlayerEquippedAttire(ply, ply.EquippedAttire)
end
----------------------------------------------------------------------
-- Хуки для применения бодигрупп
----------------------------------------------------------------------

hook.Add("gRust.OnEquipAttire", "UpdateProtectionStats", function(ply, attireId)
    if not IsValid(ply) then return end
    ApplyAttireBodygroups(ply)
    CalculateTotalProtection(ply)
end)

hook.Add("gRust.OnUnequipAttire", "UpdateProtectionStats", function(ply, attireId)
    if not IsValid(ply) then return end
    ApplyAttireBodygroups(ply)
    CalculateTotalProtection(ply)
end)

-- Добавляем хук для инициализации при спавне
hook.Add("PlayerSpawn", "InitProtectionOnSpawn", function(ply)
    timer.Simple(1, function()
        if IsValid(ply) then
            CalculateTotalProtection(ply)
        end
    end)
end)

hook.Add("Think", "DebugTrackEquippedAttire", function()
    for _, ply in ipairs(player.GetAll()) do
        if ply.EquippedAttire then
            for slot, attire in pairs(ply.EquippedAttire) do
                -- Без принтов
            end
        end
    end
end)

timer.Create("UpdateBodygroupsTimer", 1, 0, function()
    for _, ply in ipairs(player.GetAll()) do
        if ply.EquippedAttire then
            UpdatePlayerEquippedAttire(ply, ply.EquippedAttire)
        end
    end
end)

----------------------------------------------------------------------
-- Регистрация одежды
----------------------------------------------------------------------

function gRust.RegisterAttire(id, data)
    if data.model then
        util.PrecacheModel(data.model)
    elseif data.possible_models then
        for _, mdl in ipairs(data.possible_models) do
            util.PrecacheModel(mdl)
        end
    else
        -- модель не обязательна для бодигрупп
        print("[WARN] Attire '" .. id .. "' registered without model")
    end

    gRust.Attire[id] = data
end

-- Пример регистрации кофейной маски
gRust.RegisterAttire("coffee_mask", {
    type = ATTIRE_HEAD,
    model = "models/player/spike/rustguy_grust.mdl", -- базовая модель
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.5,
    offset = {
        pos = Vector(-4, 0, -72),
        ang = Angle(0, 0, 0),
    }
})

-- Железная маска
gRust.RegisterAttire("hqm.mask", {
    type = ATTIRE_HEAD2,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.5,
    offset = {
        pos = Vector(-4, 0, -72),
        ang = Angle(0, 0, 0),
    }
})

-- Нагрудник
gRust.RegisterAttire("chestplate", {
    type = ATTIRE_TORS,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("burlapshirt", {
    type = ATTIRE_BURSHIRT,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("tshirt", {
    type = ATTIRE_TSHIRT,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("wtors", {
    type = ATTIRE_WOODTORS,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("wpants", {
    type = ATTIRE_WOODPANTS,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("bone", {
    type = ATTIRE_BONE,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("wolfhed", {
    type = ATTIRE_WOLF,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("metbucket", {
    type = ATTIRE_BUCKET,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("burlappants", {
    type = ATTIRE_BURPANTS,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("burlapshoes", {
    type = ATTIRE_BURSHOES,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("burlaphead", {
    type = ATTIRE_BURHEAD,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    arms = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("hoodie", {
    type = ATTIRE_SHIRT,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    arms = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("pants", {
    type = ATTIRE_PANTS,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("shoest", {
    type = ATTIRE_SHOES,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("road", {
    type = ATTIRE_ROAD,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("kiltroad", {
    type = ATTIRE_KILT,
    model = "models/player/spike/rustguy_grust.mdl",
    hands = "models/player/darky_m/rust/c_arms_human.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("hazmat", {
    type = ATTIRE_HAZIK,
    model = "models/player/darky_m/rust/hazmat.mdl",
    hands = "models/player/darky_m/rust/hazmat_arms.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("limber", {
    type = ATTIRE_HAZIK,
    model = "models/zohart/store/60/hazmat_grust.mdl",
    hands = "models/zohart/store/60/hazmat_hands.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("holodno", {
    type = ATTIRE_HAZIK,
    model = "models/zohart/store/56/hazmat_grust.mdl",
    hands = "models/zohart/store/56/hazmat_arms.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})

gRust.RegisterAttire("nomad", {
    type = ATTIRE_HAZIK,
    model = "models/zohart/store/68/hazmat_grust.mdl",
    hands = "models/zohart/store/68/hazmat_arms.mdl",
    head = 0.6,
    body = 0.6,
    legs = 0.6,
})


hook.Add("gRust.LoadedCore", "RegisterClothingItems", function()

    local hazmatsuit_scientist = gRust.ItemRegister("hazmatsuit_scientist")
    hazmatsuit_scientist:SetName("Scientist Suit")
    hazmatsuit_scientist:SetCategory("Clothing")
    hazmatsuit_scientist:SetAttire("hazmatsuit_scientist")
    hazmatsuit_scientist:SetStack(1)
    hazmatsuit_scientist:SetIcon("materials/items/clothing/scientist.png")
    gRust.RegisterItem(hazmatsuit_scientist)

    local hazmatsuit_heavyscientist = gRust.ItemRegister("hazmatsuit_heavyscientist")
    hazmatsuit_heavyscientist:SetName("Heavy Scientist Suit")
    hazmatsuit_heavyscientist:SetCategory("Clothing")
    hazmatsuit_heavyscientist:SetAttire("hazmatsuit_heavyscientist")
    hazmatsuit_heavyscientist:SetStack(1)
    hazmatsuit_heavyscientist:SetIcon("materials/items/clothing/scientist.png")
    gRust.RegisterItem(hazmatsuit_heavyscientist)

    local coffeemask = gRust.ItemRegister("coffee.mask")
    coffeemask:SetName("Coffee Can Helmet")
    coffeemask:SetCategory("Clothing")
    coffeemask:SetAttire("coffee_mask")
    coffeemask:SetStack(1)
    coffeemask:SetIcon("materials/icons2/coffeecanhelmet.png")
    coffeemask:SetDescription("The coffee can helmet is a face protector that is one tier below the metal facemask, it offers good protection against physical damage to the head and costs less to craft than its older and better brother, the metal facemask.")
    coffeemask:SetTier(2)
    coffeemask:SetBlueprint(125)
    coffeemask:SetSound("road")
    coffeemask:SetCraft({
        { item = "leather", amount = 15 },
        { item = "sewingkit", amount = 2 },
        { item = "metal.fragments", amount = 100 }
    })
    gRust.RegisterItem(coffeemask)

    local hqmm = gRust.ItemRegister("hqm.mask")
    hqmm:SetName("Metal Facemask")
    hqmm:SetCategory("Clothing")
    hqmm:SetAttire("hqm.mask")
    hqmm:SetStack(1)
    hqmm:SetIcon("materials/icons2/metalfacemask.png")
    hqmm:SetDescription("A high-tier protective face mask which somehow protects the entire head.")
    hqmm:SetTier(3)
    hqmm:SetSound("refined")
    hqmm:SetCraft({
        { item = "leather", amount = 50 },
        { item = "metal.refined", amount = 15 },
        { item = "sewingkit", amount = 6 }
    })
    gRust.RegisterItem(hqmm)

    local hqmms = gRust.ItemRegister("hqm.chest")
    hqmms:SetName("Metal Chest Plate")
    hqmms:SetCategory("Clothing")
    hqmms:SetAttire("chestplate")
    hqmms:SetStack(1)
    hqmms:SetIcon("materials/icons2/metaplatetorso.png")
    hqmms:SetDescription("The metal chest plate is a versatile end-game armor used most often when roaming and raiding.")
    hqmms:SetTier(3)
    hqmms:SetSound("refined")
    hqmms:SetCraft({
        { item = "leather", amount = 50 },
        { item = "metal.refined", amount = 18 },
        { item = "sewingkit", amount = 8 }
    })
    gRust.RegisterItem(hqmms)

    local brshirt = gRust.ItemRegister("burlap.shirt")
    brshirt:SetName("Burlap Shirt")
    brshirt:SetCategory("Clothing")
    brshirt:SetAttire("burlapshirt")
    brshirt:SetStack(1)
    brshirt:SetIcon("materials/icons2/burlapshirt.png")
    brshirt:SetDescription("While its resistances are far from fantastic, this cheap mess of cloth may give a player the edge they need as they struggle to establish themselves.")
    brshirt:SetSound("cloth")
    brshirt:SetCraft({
        { item = "cloth", amount = 25 }
    })
    gRust.RegisterItem(brshirt)

    local brpants = gRust.ItemRegister("burlap.pants")
    brpants:SetName("Burlap Trousers")
    brpants:SetCategory("Clothing")
    brpants:SetAttire("burlappants")
    brpants:SetStack(1)
    brpants:SetIcon("materials/icons2/burlaptrousers.png")
    brpants:SetDescription("About as basic as it gets. Burlap Trousers offer meager protection across the board at a cheap price, yet remains better at cold resistance than some of its perceived 'superiors' such as the Hide Pants.")
    brpants:SetSound("cloth")
    brpants:SetCraft({
        { item = "cloth", amount = 20 }
    })
    gRust.RegisterItem(brpants)

    local brshoes = gRust.ItemRegister("burlap.shoes")
    brshoes:SetName("Burlap Shoes")
    brshoes:SetCategory("Clothing")
    brshoes:SetAttire("burlapshoes")
    brshoes:SetStack(1)
    brshoes:SetIcon("materials/icons2/burlapshoes.png")
    brshoes:SetDescription("Burlap shoes are a peice of clothing that goes on the feet, Burlap shoes also are the quietest, making footsteps harder to hear. This could provide an advantage to close range fighting when it comes to flanking or ambushing.")
    brshoes:SetSound("cloth")
    brshoes:SetCraft({
        { item = "cloth", amount = 10 }
    })
    gRust.RegisterItem(brshoes)

    local brhead = gRust.ItemRegister("burlap.head")
    brhead:SetName("Burlap Headwrap")
    brhead:SetCategory("Clothing")
    brhead:SetAttire("burlaphead")
    brhead:SetStack(1)
    brhead:SetIcon("materials/icons2/burlaheadwrap.png")
    brhead:SetDescription("As a default blueprint, the burlap headwrap is occasionally crafted during early-game after the hunting bow and bandages.")
    brhead:SetSound("cloth")
    brhead:SetCraft({
        { item = "cloth", amount = 15 }
    })
    gRust.RegisterItem(brhead)

    local hoodie = gRust.ItemRegister("hoodieblue")
    hoodie:SetName("Hoodie")
    hoodie:SetCategory("Clothing")
    hoodie:SetAttire("hoodie")
    hoodie:SetStack(1)
    hoodie:SetIcon("materials/icons2/hoodie1.png")
    hoodie:SetDescription("The hoodie offers the greatest projectile and melee resistance out of all the under armor variants. This superiority is offset by its high research and production cost.")
    hoodie:SetTier(2)
    hoodie:SetSound("cloth")
    hoodie:SetCraft({
        { item = "cloth", amount = 40 },
        { item = "sewingkit", amount = 1 }
    })
    gRust.RegisterItem(hoodie)

    local pants = gRust.ItemRegister("pantsg")
    pants:SetName("Pants")
    pants:SetCategory("Clothing")
    pants:SetAttire("pants")
    pants:SetStack(1)
    pants:SetIcon("materials/icons2/pants.png")
    pants:SetDescription("As the best available clothing for the legs the pants are a must-research.")
    pants:SetTier(2)
    pants:SetSound("cloth")
    pants:SetCraft({
        { item = "cloth", amount = 40 },
        { item = "sewingkit", amount = 1 }
    })
    gRust.RegisterItem(pants)

    local shoesс = gRust.ItemRegister("shoes")
    shoesс:SetName("Boots")
    shoesс:SetCategory("Clothing")
    shoesс:SetAttire("shoest")
    shoesс:SetStack(1)
    shoesс:SetIcon("materials/icons2/shoboots.png")
    shoesс:SetDescription("The limited available clothing slots often force a player to choose between boots, gloves, and bandanas, with the superior stats of the boots usually giving it priority")
    shoesс:SetTier(2)
    shoesс:SetSound("cloth")
    shoesс:SetCraft({
        { item = "leather", amount = 40 },
        { item = "metal.fragments", amount = 15 },
        { item = "sewingkit", amount = 1 }
    })
    gRust.RegisterItem(shoesс)

    local road = gRust.ItemRegister("roadchest")
    road:SetName("Road Sign Jacket")
    road:SetCategory("Clothing")
    road:SetAttire("road")
    road:SetStack(1)
    road:SetIcon("materials/icons2/roadsignjacket.png")
    road:SetDescription("The road sign jacket has become the staple of mid-game armor due primarily to its worthwhile projectile resistance without necessitating high quality metal.")
    road:SetTier(2)
    road:SetSound("road")
    road:SetBlueprint(125)
    road:SetCraft({
        { item = "leather", amount = 40 },
        { item = "metal.fragments", amount = 50 },
        { item = "sewingkit", amount = 1 }
    })
    gRust.RegisterItem(road)

    local roadkilt = gRust.ItemRegister("kilt")
    roadkilt:SetName("Road Sign Kilt")
    roadkilt:SetCategory("Clothing")
    roadkilt:SetAttire("kiltroad")
    roadkilt:SetStack(1)
    roadkilt:SetIcon("materials/icons2/roadsigkilt.png")
    roadkilt:SetDescription("The lack of a metal chest plate or jacket equivalent to leg armor allows the road sign kilt a monopoly on both mid and end-game leg armor. Heavy plate pants are all that can surpass it statistically, but those are seldom seen outside of airlock brawls due to their movement penalty.")
    roadkilt:SetTier(2)
    roadkilt:SetBlueprint(125)
    roadkilt:SetSound("road")
    roadkilt:SetCraft({
        { item = "leather", amount = 10 },
        { item = "metal.fragments", amount = 50 },
        { item = "sewingkit", amount = 1 }
    })
    gRust.RegisterItem(roadkilt)

    local footboal = gRust.ItemRegister("footboalka")
    footboal:SetName("T-Shirt")
    footboal:SetCategory("Clothing")
    footboal:SetAttire("tshirt")
    footboal:SetStack(1)
    footboal:SetIcon("materials/icons2/tshirt.png")
    footboal:SetDescription("Same resistances as longsleeve t-shirt while being nowhere near as common.")
    footboal:SetTier(1)
    footboal:SetSound("cloth")
    footboal:SetCraft({
        { item = "cloth", amount = 25 }
    })
    gRust.RegisterItem(footboal)

    local woodenchest = gRust.ItemRegister("woodentors")
    woodenchest:SetName("Wood Chestplate")
    woodenchest:SetCategory("Clothing")
    woodenchest:SetAttire("wtors")
    woodenchest:SetStack(1)
    woodenchest:SetIcon("materials/icons2/woodarmorjacket.png")
    woodenchest:SetDescription("A shoddy piece of body armor made from Wood and rope.")
    woodenchest:SetSound("wood")
    woodenchest:SetCraft({
        { item = "wood", amount = 250 },
        { item = "cloth", amount = 20 }
    })
    gRust.RegisterItem(woodenchest)

    local woodenkilt = gRust.ItemRegister("woodenpants")
    woodenkilt:SetName("Wood Armor Pants")
    woodenkilt:SetCategory("Clothing")
    woodenkilt:SetAttire("wpants")
    woodenkilt:SetStack(1)
    woodenkilt:SetIcon("materials/icons2/woodarmorpants.png")
    woodenkilt:SetDescription("The wood armor pants are a cheap, effective source of leg protection, uncontested in their role until the road sign kilt makes itself available. Though its projectile resistance is meager, it prospers in the early game as a melee meat shield.")
    woodenkilt:SetSound("wood")
    woodenkilt:SetCraft({
        { item = "wood", amount = 150 },
        { item = "cloth", amount = 15 }
    })
    gRust.RegisterItem(woodenkilt)

    local bonehead = gRust.ItemRegister("bonehed")
    bonehead:SetName("Bone Helmet")
    bonehead:SetCategory("Clothing")
    bonehead:SetAttire("bone")
    bonehead:SetStack(1)
    bonehead:SetIcon("materials/icons2/deerskullmask.png")
    bonehead:SetDescription("Second only to the wolf headdress in primitive headwear, the bone helmet is a welcome sink for bone frags until metal can take its place.")
    bonehead:SetSound("wood")
    bonehead:SetCraft({
        { item = "bone.fragments", amount = 30 },
        { item = "cloth", amount = 15 }
    })
    gRust.RegisterItem(bonehead)

    local wolf = gRust.ItemRegister("wolfhead")
    wolf:SetName("Wolf Headdress")
    wolf:SetCategory("Clothing")
    wolf:SetAttire("wolfhed")
    wolf:SetStack(1)
    wolf:SetIcon("materials/icons2/hatwolf.png")
    wolf:SetDescription("Scavenging the wolf skull necessary to produce this headdress won't be easy, but it pays for itself and then some with the resistances it grants; phenomenal melee and explosive protection, excellent projectile defense, and a pleasant resistance to cold makes this thing a primitive powerhouse.")
    wolf:SetSound("wood")
    wolf:SetCraft({
        { item = "bone.fragments", amount = 10 },
        { item = "cloth", amount = 15 }
    })
    gRust.RegisterItem(wolf)

    local backet = gRust.ItemRegister("backethead")
    backet:SetName("Bucket Helmet")
    backet:SetCategory("Clothing")
    backet:SetAttire("metbucket")
    backet:SetStack(1)
    backet:SetIcon("materials/icons2/buckethelmet.png")
    backet:SetDescription("A mid-tier helmet that protects the user's head. Made without the need for High-Quality-Metal, the helmet is an inexpensive form of protection that substitutes metal frags with cloth and suffers for it. It currently floats an awkward position between the wood helm and the wolf headdress. The default skin is very bright and noticeable, though other user skins replace the color palette.")
    backet:SetSound("metal")
    backet:SetCraft({
        { item = "metal.fragments", amount = 35 }
    })
    gRust.RegisterItem(backet)

    local hazmatsuit = gRust.ItemRegister("hazmatsuit")
    hazmatsuit:SetName("Hazmat Suit")
    hazmatsuit:SetCategory("Clothing")
    hazmatsuit:SetAttire("hazmat")
    hazmatsuit:SetStack(1)
    hazmatsuit:SetIcon("materials/items/clothing/hazmat.png")
    hazmatsuit:SetDescription("The Hazmat Suit allows the wearer to travel through rad-towns and other irradiated areas safely.")
    hazmatsuit:SetTier(2)
    hazmatsuit:SetBlueprint(125)
    hazmatsuit:SetCraft({
        { item = "tarp", amount = 5 },
        { item = "sewingkit", amount = 3 },
        { item = "metal.refined", amount = 50 }
    })
    gRust.RegisterItem(hazmatsuit)

    local limber = gRust.ItemRegister("limberjack")
    limber:SetName("Костюм лесоруба")
    limber:SetCategory("Clothing")
    limber:SetAttire("limber")
    limber:SetStack(1)
    limber:SetIcon("materials/icons2/hazmatsuitlumberjack.png")
    limber:SetTier(2)
    limber:SetCraft({
        { item = "tarp", amount = 5 },
        { item = "sewingkit", amount = 3 },
        { item = "metal.refined", amount = 50 }
    })
    gRust.RegisterItem(limber)

    local snow = gRust.ItemRegister("holod")
    snow:SetName("Арктический костюм")
    snow:SetCategory("Clothing")
    snow:SetAttire("holodno")
    snow:SetStack(1)
    snow:SetIcon("materials/icons2/hazmatsuitarcticsuit.png")
    snow:SetTier(2)
    snow:SetCraft({
        { item = "tarp", amount = 5 },
        { item = "sewingkit", amount = 3 },
        { item = "metal.refined", amount = 8 }
    })
    gRust.RegisterItem(snow)

    local nomad = gRust.ItemRegister("surivor")
    nomad:SetName("Костюм кочевника")
    nomad:SetCategory("Clothing")
    nomad:SetAttire("nomad")
    nomad:SetStack(1)
    nomad:SetIcon("materials/icons2/hazmatsuitnomadsuit.png")
    nomad:SetTier(2)
    nomad:SetCraft({
        { item = "tarp", amount = 5 },
        { item = "sewingkit", amount = 3 },
        { item = "metal.refined", amount = 8 }
    })
    gRust.RegisterItem(nomad)

    -- Пример предмета нагрудника можно добавить здесь (если нужен)

end)


----------------------------------------------------------------------
-- Запрет на вторую маску
----------------------------------------------------------------------

hook.Add("gRust.CanEquipAttire", "gRust_BlockSecondMask", function(ply, attireId, slot)
    local data = gRust.Attire[attireId]
    if not data then return true end

    if data.type == ATTIRE_HEAD then
        for s = 31, 36 do
            local equipped = ply.EquippedAttire and ply.EquippedAttire[s]
            if equipped and gRust.Attire[equipped] and gRust.Attire[equipped].type == ATTIRE_HEAD then
                return false -- уже есть маска
            end
        end
    end

    return true
end)

----------------------------------------------------------------------
-- Отладка состояния
----------------------------------------------------------------------

concommand.Add("grust_debug_attire", function(ply)
    if not IsValid(ply) then return end
    print("===== EquippedAttire =====")
    PrintTable(ply.EquippedAttire or {})
end)

----------------------------------------------------------------------

-- СУММИРОВАНИЕ ЗАЩИТЫ (HAZIK + МАСКА)

----------------------------------------------------------------------

hook.Add("EntityTakeDamage", "gRust.AttireDamageReductionByType", function(target, dmginfo)
    if not target:IsPlayer() then return end

    local ply = target
    if not ply.EquippedAttire then return end

    local totalReduction = 0
    -- Проверяем все надетые вещи
    for slot = 31, 36 do
        local attireId = ply.EquippedAttire[slot]
        if attireId and gRust.Attire[attireId] then
            local typ = gRust.Attire[attireId].type
            if typ == ATTIRE_HAZIK then
                totalReduction = totalReduction + 0.15 -- HAZIK снижает урон на 20%
            elseif typ == ATTIRE_HEAD then
                totalReduction = totalReduction + 0.10 -- маска снижает урон на 15
            elseif typ == ATTIRE_TORS then
                totalReduction = totalReduction + 0.35 -- маска снижает урон на 15%
            elseif typ == ATTIRE_HEAD2 then
                totalReduction = totalReduction + 0.35 -- маска снижает урон на 15%
            elseif typ == ATTIRE_BURPANTS then
                totalReduction = totalReduction + 0.01 -- маска снижает урон на 15%
            elseif typ == ATTIRE_BURSHOES then
                totalReduction = totalReduction + 0.01 -- маска снижает урон на 15%
            elseif typ == ATTIRE_BURSHIRT then
                totalReduction = totalReduction + 0.01 -- маска снижает урон на 15%
            elseif typ == ATTIRE_BURHEAD then
                totalReduction = totalReduction + 0.01 -- маска снижает урон на 15%
            elseif typ == ATTIRE_PANTS then
                totalReduction = totalReduction + 0.02 -- маска снижает урон на 15%
            elseif typ == ATTIRE_SHOES then
                totalReduction = totalReduction + 0.03 -- маска снижает урон на 15%
            elseif typ == ATTIRE_WOODTORS then
                totalReduction = totalReduction + 0.03 -- маска снижает урон на 15%
            elseif typ == ATTIRE_WOODPANTS then
                totalReduction = totalReduction + 0.03 -- маска снижает урон на 15%
            elseif typ == ATTIRE_WOLF then
                totalReduction = totalReduction + 0.03 -- маска снижает урон на 15%
            elseif typ == ATTIRE_BONE then
                totalReduction = totalReduction + 0.04 -- маска снижает урон на 15%
            elseif typ == ATTIRE_SHOES then
                totalReduction = totalReduction + 0.02 -- маска снижает урон на 15%
            elseif typ == ATTIRE_SHIRT then
                totalReduction = totalReduction + 0.02 -- маска снижает урон на 15%
            elseif typ == ATTIRE_BUCKET then
                totalReduction = totalReduction + 0.06
            elseif typ == ATTIRE_ROAD then
                totalReduction = totalReduction + 0.10 -- маска снижает урон на 15%
            elseif typ == ATTIRE_KILT then
                totalReduction = totalReduction + 0.05 -- маска снижает урон на 15%
            elseif typ == ATTIRE_FULLBODY then
                totalReduction = totalReduction + 0.15 -- FULLBODY костюм (на будущее)
            end
        end
    end

    if totalReduction <= 0 then return end

    local attacker = dmginfo:GetAttacker()
    if not IsValid(attacker) then return end

    local class = attacker.GetClass and attacker:GetClass() or ""

    if attacker:IsNPC() or class:find("npc_combine_s") or class:find("npc_metropolice") then
        if totalReduction > 0.9 then totalReduction = 0.9 end -- максимум 90%

        local original = dmginfo:GetDamage()
        dmginfo:SetDamage(original * (1 - totalReduction))
    end
end)

concommand.Add("grust_debug_ui", function()
    local ply = LocalPlayer()
    if ply.AttireProtection then
        PrintTable(ply.AttireProtection)
    end
    print("EquippedAttire:")
    PrintTable(ply.EquippedAttire or {})
end)