gRust.SavedBlueprints = gRust.SavedBlueprints or {}

local PLAYER = FindMetaTable("Player")

function PLAYER:InitBlueprints()
    self.Blueprints = self.Blueprints or {}
end

function PLAYER:AddBlueprint(class)
    self.Blueprints = self.Blueprints or {}
    self.Blueprints[class] = true

    local steamid = self:SteamID()
    gRust.SavedBlueprints[steamid] = gRust.SavedBlueprints[steamid] or {}
    gRust.SavedBlueprints[steamid][class] = true

    net.Start("gRust.AddBlueprint")
    net.WriteString(class)
    net.Send(self)
end

function PLAYER:SyncBlueprints()
    self.Blueprints = self.Blueprints or {}
    
    net.Start("gRust.SyncBlueprints")
    
    local count = table.Count(self.Blueprints)
    net.WriteUInt(count, 16)
    
    for class, _ in pairs(self.Blueprints) do
        net.WriteString(class)
    end
    
    net.Send(self)
end

hook.Add("PlayerInitialSpawn", "gRust.InitBlueprints", function(ply)
    ply:InitBlueprints()

    timer.Simple(1, function()
        if not IsValid(ply) then return end

        local steamid = ply:SteamID()
        local saved = gRust.SavedBlueprints[steamid]

        if saved then
            for class, _ in pairs(saved) do
                if gRust.Items[class] and not ply:HasBlueprint(class) then
                    ply:AddBlueprint(class)
                end
            end
        end

        ply:SyncBlueprints()
    end)
end)

util.AddNetworkString("gRust.SyncBlueprints")
util.AddNetworkString("gRust.AddBlueprint")
util.AddNetworkString("gRust.LearnBlueprint")

net.Receive("gRust.LearnBlueprint", function(len, ply)
    local ent = net.ReadEntity()
    local slot = net.ReadUInt(8)

    if (!IsValid(ent) or !IsValid(ply)) then return end
    if (ent:GetPos():Distance(ply:GetPos()) > 200) then return end

    local inv = ent.Inventory 

    if (!inv or !inv[slot]) then return end

    local item = inv[slot]
    local itemClass = item:GetItem()
    local itemData = gRust.Items[itemClass]

    if (!itemData or !itemData:GetBlueprint()) then return end

    if (ply:HasBlueprint(itemClass)) then
        return
    end

    local baseClass = string.gsub(item:GetItem(), "%.Blueprint$", "")
    ply:AddBlueprint(baseClass)
    
    ply:SendLua('surface.PlaySound("ui/blueprint_read.wav")')

    if item:GetQuantity() <= 1 then
        ent:RemoveSlot(slot)
    else
        item:RemoveQuantity(1)
        ent:SyncSlot(slot)
    end
end)