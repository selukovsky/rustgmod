local PLAYER = FindMetaTable("Player")

net.Receive("gRust.SyncBlueprints", function()
    local pl = LocalPlayer()
    if not IsValid(pl) then return end

    pl.Blueprints = {}

    for i = 1, net.ReadUInt(16) do
        pl.Blueprints[net.ReadString()] = true
    end
end)

net.Receive("gRust.AddBlueprint", function()
    local pl = LocalPlayer()
    if not IsValid(pl) then return end

    pl.Blueprints = pl.Blueprints or {}

    local class = net.ReadString()
    pl.Blueprints[class] = true
end)