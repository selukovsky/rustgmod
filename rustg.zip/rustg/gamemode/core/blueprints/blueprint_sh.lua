local PLAYER = FindMetaTable("Player")

function PLAYER:HasBlueprint(class)
    local Item = gRust.Items[class]
    if not Item then return false end
    if not Item:GetBlueprint() then return true end
    if self.Blueprints then
        return self.Blueprints[class] == true
    end
    return false
end

local function LoadBlueprintActions()
    for k, v in pairs(gRust.Items) do
        if v:GetBlueprint() ~= true then continue end
        v.Actions = v.Actions or {}
        v.Actions[#v.Actions + 1] = {
            Name = "Learn Blueprint",
            Icon = "study",
            Func = function(ent, i)
                local item = ent.Inventory[i]
                if item then
                    local baseClass = string.gsub(item:GetItem(), "%.Blueprint$", "")
                    if LocalPlayer():HasBlueprint(baseClass) then return end
                end
                
                net.Start("gRust.LearnBlueprint")
                net.WriteEntity(ent)
                net.WriteUInt(i, 8)
                net.SendToServer()
            end
        }
    end
end

timer.Simple(0, LoadBlueprintActions)