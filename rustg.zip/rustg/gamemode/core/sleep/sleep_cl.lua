local mat_sleeping = Material("icons/sleeping.png")
local mat_vignette = Material("ui/vignette.png")
local mat_noise = Material("ui/background.png")

hook.Add("CalcMainActivity", "SleepingAnimation", function(ply, velocity)
    if ply:GetNWBool("isSleeping") then
        local seq = ply:LookupSequence("lay") or ply:LookupSequence("sleep")
        if seq then
            return seq, 0
        end
    end
end)

hook.Add("HUDPaint", "Sleeping.HUD", function()
    local ply = LocalPlayer()
    if not ply:GetNWBool("isSleeping") or not ply:Alive() then return end

    local scrW, scrH = ScrW(), ScrH()

    surface.SetDrawColor(255, 255, 255, 210)
    surface.SetMaterial(mat_vignette)
    surface.DrawTexturedRect(0, 0, scrW, scrH)

    surface.SetDrawColor(27, 32, 27, 60)
    surface.SetMaterial(mat_noise)
    surface.DrawTexturedRect(0, 0, scrW, scrH)

    surface.SetDrawColor(0, 0, 0, 80)
    surface.DrawRect(0, 0, scrW, scrH)

    local w, h = 525, 108
    local x, y = (scrW - w) / 2, 78

    surface.SetDrawColor(27, 32, 27)
    surface.DrawRect(x, y, w, h)

    local s = 90
    surface.SetDrawColor(109, 105, 99)
    surface.SetMaterial(mat_sleeping)
    surface.DrawTexturedRect(x + 24, y + 11, s, s)

    local tx = x + w / 2 + 39
    draw.SimpleText("YOU'RE SLEEPING", "gRust.58px", tx, y + 17, color_white, TEXT_ALIGN_CENTER)
    draw.SimpleText("(Press any key to wake up)", "gRust.34px", tx, y + 60, Color(165, 157, 150), TEXT_ALIGN_CENTER)
end)

hook.Add("Think", "Sleeping.WakeUp", function()
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() then return end
        
    if ply:GetNWBool("isSleeping") then
        if input.IsKeyDown(KEY_SPACE) or input.IsMouseDown(MOUSE_LEFT) or input.IsMouseDown(MOUSE_RIGHT) or input.IsKeyDown(KEY_TAB) or input.IsKeyDown(KEY_Q) or input.IsKeyDown(KEY_H) or input.IsKeyDown(KEY_G) then
            net.Start("gRust.SleepingWakeUp")
            net.SendToServer()
        end
    else
        if not gRust or not gRust.Inventory or not IsValid(gRust.Inventory) then return end
    end
end)

hook.Add("CalcView", "Sleeping.View", function(ply, pos, ang, fov)
    if not ply:GetNWBool("isSleeping") then return end

    local view = {
        origin = ply:GetPos() + Vector(0, 0, 5),
        angles = Angle(0, ang.y, -120),
        fov = fov,
        drawviewer = false
    }

    return view
end)

hook.Add("StartCommand", "Sleeping.BlockWeapons", function(ply, cmd)
    if not IsValid(ply) or not ply:GetNWBool("isSleeping") then return end
    cmd:ClearButtons()
    cmd:ClearMovement()
    cmd:SetMouseX(0)
    cmd:SetMouseY(0)
end)

hook.Add("CreateMove", "Sleeping.BlockArrowKeys", function(cmd)
    local ply = LocalPlayer()
    if ply:GetNWBool("isSleeping") then
        cmd:SetViewAngles(Angle(0, ply:GetAngles().y, 0))
    end
end)