util.AddNetworkString("gRust.SleepingWakeUp")

SLEEPING_MODELS = SLEEPING_MODELS or {}
LAST_POSITIONS = LAST_POSITIONS or {}

hook.Add("PlayerDisconnected", "CreateSleepingModel", function(ply)
    if not IsValid(ply) then return end

    local model = ents.Create("prop_physics")
    if not IsValid(model) then return end

    model:SetModel(ply:GetModel())
    model:SetPos(ply:GetPos())
    model:SetAngles(Angle(0, ply:GetAngles().y, 0))
    model:SetSkin(ply:GetSkin())

    model:SetBodygroup(1, ply:GetBodygroup(1))
    model:SetBodygroup(3, ply:GetBodygroup(3))
    model:SetBodygroup(4, ply:GetBodygroup(4))

    model:SetSequence("lay")
    model:SetPlaybackRate(0)
    model:Spawn()

    model:SetCollisionGroup(COLLISION_GROUP_WEAPON)
    model:SetSolid(SOLID_BBOX)
    model:SetCollisionBounds(Vector(-30, -30, 0), Vector(30, 30, 60))

    local phys = model:GetPhysicsObject()
    if IsValid(phys) then
        phys:EnableGravity(false)
        phys:EnableCollisions(false)
        phys:EnableMotion(false)
    end

    model:SetHealth(80)
    model:SetMaxHealth(80)
    model.IsSleepingModel = true
    model.steamID64 = ply:SteamID64()

    local seq = model:LookupSequence("lay") or model:LookupSequence("sleep")
    if seq <= 0 then
        model:SetSequence("idle_all")
    end

    SLEEPING_MODELS[ply:SteamID64()] = model
    LAST_POSITIONS[ply:SteamID64()] = ply:GetPos()
end)

hook.Add("EntityTakeDamage", "HandleSleepingModelDamage", function(ent, dmg)
    if not IsValid(ent) or not ent.IsSleepingModel then return end

    local newHealth = ent:Health() - dmg:GetDamage()
    ent:SetHealth(newHealth)

    if newHealth <= 0 then
        local ragdoll = ents.Create("prop_ragdoll")
        if IsValid(ragdoll) then
            ragdoll:SetModel(ent:GetModel())
            ragdoll:SetPos(ent:GetPos())
            ragdoll:SetAngles(ent:GetAngles())
            ragdoll:SetSkin(ent:GetSkin())

            ragdoll:SetBodygroup(1, ent:GetBodygroup(1))
            ragdoll:SetBodygroup(3, ent:GetBodygroup(3))
            ragdoll:SetBodygroup(4, ent:GetBodygroup(4))

            ragdoll:SetCollisionGroup(COLLISION_GROUP_INTERACTIVE_DEBRIS)
            ragdoll:Spawn()

            timer.Simple(300, function()
                if IsValid(ragdoll) then
                    ragdoll:Remove()
                end
            end)
        end

        local steamID64 = ent.steamID64
        SLEEPING_MODELS[steamID64] = nil
        LAST_POSITIONS[steamID64] = nil
        ent:Remove()
    end
    return true
end)

hook.Add("PlayerInitialSpawn", "RestorePlayerData", function(ply)
    timer.Simple(0, function()
        if not IsValid(ply) then return end
        
        local steamID64 = ply:SteamID64()
        local model = SLEEPING_MODELS[steamID64]
        
        if IsValid(model) then
            ply:SetPos(model:GetPos() + Vector(0,0,60))
            model:Remove()
            SLEEPING_MODELS[steamID64] = nil
            LAST_POSITIONS[steamID64] = nil
        elseif LAST_POSITIONS[steamID64] then
            ply:SetPos(LAST_POSITIONS[steamID64])
        end

        ply:SetNWBool("isSleeping", true)
    end)
end)

hook.Add("PlayerUse", "PreventSleepingModelUse", function(ply, ent)
    if IsValid(ent) and ent.IsSleepingModel then
        return false
    end
end)

hook.Add("PlayerSpawn", "SetSleepingOnSpawn", function(ply)
    timer.Simple(0.0, function()
        if IsValid(ply) then
            ply:SetNWBool("isSleeping", true)
        end
    end)
end)

net.Receive("gRust.SleepingWakeUp", function(len, ply)
    if not IsValid(ply) or not ply:GetNWBool("isSleeping") then return end
    ply:SetNWBool("isSleeping", false)
end)