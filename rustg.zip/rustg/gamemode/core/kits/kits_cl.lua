local PANEL_KIT = {}

function PANEL_KIT:Init()
    self:SetCursor('hand')

    -- Используем вашу систему цветов gRust.Button
    self:SetDefaultColor(Color(255, 255, 255, 38))
    self:SetHoveredColor(Color(255, 255, 255, 25))
    self:SetActiveColor(Color(255, 255, 255, 13))
    self:SetTextColor(Color(255, 255, 255, 220))

    self:DockPadding(10, 10, 10, 10)
    self:SetTall(150)

    local header = vgui.Create('DPanel', self)
    header:Dock(TOP)
    header:DockMargin(0, 0, 0, 10)
    header:SetTall(40)
    header:SetMouseInputEnabled(false)
    header.Paint = function() end -- Прозрачная панель

    local label = vgui.Create('DLabel', header)
    label:Dock(FILL)
    label:SetTextColor(Color(255, 255, 255, 220))
    label:SetFont("gRust.24px")
    label:SetContentAlignment(4)

    self.label = label

    local cooldown = vgui.Create('DLabel', header)
    cooldown:Dock(RIGHT)
    cooldown:SetTextColor(Color(255, 255, 255))
    cooldown:SetFont("gRust.16px")
    cooldown:SetContentAlignment(6)

    self.cooldown = cooldown

    local grid = vgui.Create('DIconLayout', self)
    grid:Dock(TOP)
    grid:SetSpaceX(5)
    grid:SetSpaceY(5)
    grid:SetMouseInputEnabled(false)

    self.grid = grid
end

function PANEL_KIT:SetKitID(id)
    local kit = gRust.Kits[id]
    if not kit then return end

    self.kit = kit
    self.kitID = id

    -- Используем поле 'name' вместо 'title' для совместимости
    local kitName = kit.name or kit.title or "Unknown Kit"
    self.label:SetText(kitName .. (' (%s)'):format(id))

    local grid = self.grid

    grid:Clear()

    local slotS = 90

    for _, itemData in ipairs(kit.items) do
        local itemInfo = gRust.Items[itemData.id]
        if itemInfo then
            -- Создаем панель для слота
            local slotPanel = vgui.Create('DPanel', grid)
            slotPanel:SetSize(slotS, slotS)
            slotPanel:SetMouseInputEnabled(false)
            
            -- Рисуем прозрачный фон слота
            slotPanel.Paint = function(panel, w, h)
                surface.SetDrawColor(50, 50, 50, 150) -- Слегка прозрачный серый
                surface.DrawRect(0, 0, w, h)
                
                surface.SetDrawColor(80, 80, 80, 100) -- Обводка
                surface.DrawOutlinedRect(0, 0, w, h)
            end

            -- Создаем иконку предмета
            local icon = vgui.Create('DImage', slotPanel)
            icon:SetSize(slotS - 20, slotS - 20) -- Немного меньше чем слот
            icon:Center()
            icon:SetImage(itemInfo:GetIcon())
            icon:SetMouseInputEnabled(false)
            
            -- Текст с количеством
            local amountLabel = vgui.Create('DLabel', slotPanel)
            amountLabel:SetText("x" .. itemData.amount)
            amountLabel:SetFont("gRust.24px")
            amountLabel:SetTextColor(Color(255, 255, 255))
            amountLabel:SizeToContents()
            amountLabel:SetPos(slotS - amountLabel:GetWide() - 5, slotS - amountLabel:GetTall() - 5)
            amountLabel:SetMouseInputEnabled(false)
            
            grid:Add(slotPanel)
        end
    end
end

function PANEL_KIT:PaintOver(w, h)
    local kit = self.kit
    local kitID = self.kitID

    if not kit then return end

    local disabledMessage

    -- Проверка customCheck (если есть)
    if kit.customCheck then
        local status, message = kit.customCheck(LocalPlayer())
        if not status then
            disabledMessage = message or 'You can\'t use this kit.'
        end
    end

    -- Проверка кулдауна
    if not disabledMessage then
        local timeLeft = RUST.kits:GetCooldown(LocalPlayer(), kitID)
        if timeLeft > 0 then
            disabledMessage = 'Unlocks in ' .. (zlib and zlib.time.formatPretty(timeLeft) or (timeLeft .. "s"))
        end
    end

    -- Проверка цены
    if not disabledMessage and kit.price then
        for _, costItem in ipairs(kit.price) do
            if not LocalPlayer():HasItem(costItem.id, costItem.amount) then
                disabledMessage = "Not enough " .. costItem.id
                break
            end
        end
    end

    if disabledMessage then
        self:SetEnabled(false)

        surface.SetDrawColor(Color(0, 0, 0, 170))
        surface.DrawRect(0, 0, w, h)

        draw.SimpleText(disabledMessage, "gRust.24px", w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    else
        self:SetEnabled(true)
    end
end

function PANEL_KIT:PerformLayout(w, h)
    self:SizeToChildren(false, true)
end

function PANEL_KIT:DoClick()
    if not self:IsEnabled() then
        return
    end

    net.Start('Rust.ActivateKit')
    net.WriteString(self.kitID)
    net.SendToServer()
    
    -- Закрываем меню после выбора
    if IsValid(gRust.KitsMenu) then
        gRust.KitsMenu:Remove()
    end
end

vgui.Register('RustKitPanel', PANEL_KIT, 'gRust.Button')

-- Основная функция открытия меню китов
function gRust.OpenKitsMenu()
    if IsValid(gRust.KitsMenu) then
        gRust.KitsMenu:Remove()
        return
    end

    local container = vgui.Create('DFrame')
    container:SetSize(ScrW(), ScrH())
    container:SetAlpha(0)
    container:SetTitle('')
    container:SetDraggable(false)
    container:ShowCloseButton(false)
    container:MakePopup()
    container:Center()

    function container:Paint(w, h)
        surface.SetDrawColor(Color(47, 48, 38, 210))
        surface.DrawRect(0, 0, w, h)
    end

    function container:Show()
        self:SetVisible(true)
        self:AlphaTo(255, 0.05)
    end

    function container:Hide()
        self:AlphaTo(0, 0.1, 0, function()
            self:Remove()
        end)
    end

    local frame = vgui.Create('DPanel', container)
    frame:SetSize(1005, 795)
    frame:DockPadding(20, 20, 20, 20)
    frame:SetBackgroundColor(Color(50, 50, 50))
    frame:Center()

    local header = vgui.Create('DPanel', frame)
    header:Dock(TOP)
    header:DockMargin(0, 0, 0, 20)
    header:SetTall(40)
    header:SetBackgroundColor(Color(0, 0, 0, 0))

    local title = vgui.Create('DLabel', header)
    title:Dock(FILL)
    title:SetText('KITS')
    title:SetTextColor(Color(255, 255, 255))
    title:SetFont("gRust.32px")
    title:SetContentAlignment(4)

    local button = vgui.Create('gRust.Button', header)
    button:Dock(RIGHT)
    button:SetWide(100)
    button:SetFont("gRust.24px")
    button:SetText('CLOSE')
    button:SetTextColor(Color(255, 255, 255, 120))

    function button:DoClick()
        container:Hide()
    end

    local content = vgui.Create('DScrollPanel', frame)
    content:Dock(FILL)

    local kitsMap = gRust.Kits
    local kits = table.GetKeys(gRust.Kits)

    table.sort(kits, function(kitIDA, kitIDB)
        local kitA = kitsMap[kitIDA]
        local kitB = kitsMap[kitIDB]

        local priorityA = kitA.priority or 0
        local priorityB = kitB.priority or 0

        if priorityA ~= priorityB then
            return priorityA < priorityB
        end

        local cooldownA = kitA.cooldown or 0
        local cooldownB = kitB.cooldown or 0

        if cooldownA ~= cooldownB then
            return cooldownA < cooldownB
        end

        return kitIDA < kitIDB
    end)

    local gap = 5

    for _, kitID in ipairs(kits) do
        local kitPanel = vgui.Create('RustKitPanel', content)
        kitPanel:Dock(TOP)
        kitPanel:DockMargin(0, 0, 0, gap)
        kitPanel:SetKitID(kitID)
    end

    container:Show()
    gRust.KitsMenu = container
end

net.Receive("gRust.OpenKitMenu", gRust.OpenKitsMenu)

-- Инициализация системы кулдаунов
RUST = RUST or {}
RUST.kits = RUST.kits or {}
RUST.kits.list = gRust.Kits

function RUST.kits:GetCooldown(ply, kitID)
    -- Эта функция будет заполнена данными с сервера
    return 0
end

-- Получение данных о китах с сервера
net.Receive("gRust.SyncKits", function()
    gRust.Kits = net.ReadTable()
    RUST.kits.list = gRust.Kits
end)