gRust.Kits = gRust.Kits or {}



gRust.RegisterKit = function(name, dat)

    gRust.Kits[name] = dat

end

