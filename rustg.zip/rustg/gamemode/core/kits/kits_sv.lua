util.AddNetworkString("gRust.OpenKitMenu")
util.AddNetworkString("Rust.ActivateKit")
util.AddNetworkString("gRust.SyncKits")

gRust.Kits = gRust.Kits or {}

gRust.RegisterKit = function(name, dat)
    gRust.Kits[name] = dat
    print("[gRust] Kit registered: " .. name)
end

hook.Add("Initialize", "gRust.LoadKits", function()
    -- Пример регистрации китов
    gRust.RegisterKit("hunt", {
        name = "Hunter's Basics",
        title = "Hunter's Basics",
        items = {
            {id = "knife.bone", amount = 1},
            {id = "bow.hunting", amount = 1},
            {id = "arrow.wooden", amount = 32},
            {id = "attire.hide.boots", amount = 1},
            {id = "attire.hide.pants", amount = 1},
            {id = "attire.hide.poncho", amount = 1},
            {id = "attire.hide.vest", amount = 1},
            {id = "hat.wolf", amount = 1}
        }
    })

    gRust.RegisterKit("build", {
        name = "Builder's Basics",
        title = "Builder's Basics",
        items = {
            {id = "building.planner", amount = 1},
            {id = "hammer", amount = 1}
        }
    })

    gRust.RegisterKit("medic", {
        name = "Combat Medical Supplies",
        title = "Combat Medical Supplies",
        items = {
            {id = "syringe.medical", amount = 5},
            {id = "bandage", amount = 5}
        }
    })

    gRust.RegisterKit("start", {
        name = "Wipe Start Resources",
        title = "Wipe Start Resources",
        items = {
            {id = "wood", amount = 5000},
            {id = "stones", amount = 7500},
            {id = "metal.fragments", amount = 3000},
            {id = "workbench1", amount = 1},
            {id = "cupboard.tool", amount = 1},
            {id = "furnace", amount = 1},
            {id = "door.hinged.metal", amount = 2},
            {id = "lock.code", amount = 2},
            {id = "building.planner", amount = 1},
            {id = "hammer", amount = 1}
        }
    })

    gRust.RegisterKit("daily", {
        name = "Daily VIP Supplies",
        title = "Daily VIP Supplies",
        priority = 1,
        items = {
            {id = "wood", amount = 12500},
            {id = "stones", amount = 12500},
            {id = "metal.fragments", amount = 7500},
            {id = "metal.refined", amount = 150},
            {id = "cloth", amount = 1500},
            {id = "leather", amount = 1500},
            {id = "lowgradefuel", amount = 1000},
            {id = "gunpowder", amount = 2000},
            {id = "sulfur", amount = 5000},
            {id = "charcoal", amount = 7500}
        },
        customCheck = function(ply)
            return ply:HasStorePurchase(92) or ply:HasStorePurchase(93), "This is a VIP kit."
        end
    })

    gRust.RegisterKit("guns1", {
        name = "VIP Guns",
        title = "VIP Guns",
        priority = 1,
        items = {
            {id = "ammo.pistol", amount = 96},
            {id = "coffeecan.helmet", amount = 1},
            {id = "roadsign.jacket", amount = 1},
            {id = "roadsign.kilt", amount = 1},
            {id = "hoodie", amount = 1},
            {id = "pants", amount = 1},
            {id = "shoes.boots", amount = 1},
            {id = "pistol.m92", amount = 1},
            {id = "syringe.medical", amount = 10},
            {id = "bandage", amount = 10}
        },
        customCheck = function(ply)
            return ply:HasStorePurchase(92) or ply:HasStorePurchase(93), "This is a VIP kit."
        end
    })

    gRust.RegisterKit("guns2", {
        name = "Elite Guns",
        title = "Elite Guns",
        priority = 2,
        items = {
            {id = "ammo.pistol", amount = 128},
            {id = "weapon.mod.holosight", amount = 1},
            {id = "weapon.mod.flashlight", amount = 1},
            {id = "metal.facemask", amount = 1},
            {id = "roadsign.jacket", amount = 1},
            {id = "roadsign.kilt", amount = 1},
            {id = "roadsign.gloves", amount = 1},
            {id = "hoodie", amount = 1},
            {id = "pants", amount = 1},
            {id = "shoes.boots", amount = 1},
            {id = "smg.mp5", amount = 1},
            {id = "syringe.medical", amount = 10},
            {id = "bandage", amount = 10},
            {id = "largemedkit", amount = 1},
            {id = "barricade.wood.cover", amount = 3}
        },
        customCheck = function(ply)
            return ply:HasStorePurchase(93), "This is an Elite kit."
        end
    })

    gRust.RegisterKit("explosives", {
        name = "Daily Elite Explosives",
        title = "Daily Elite Explosives",
        priority = 2,
        items = {
            {id = "ammo.rifle.explosive", amount = 150},
            {id = "explosive.satchel", amount = 12}
        },
        customCheck = function(ply)
            return ply:HasStorePurchase(93), "This is an Elite kit."
        end
    })

    print("[gRust] Kits loaded. Total:", table.Count(gRust.Kits))
end)

-- Обработка активации кита
local playerKitsCooldown = {}

net.Receive("Rust.ActivateKit", function(len, ply)
    local kitName = net.ReadString()
    local kit = gRust.Kits[kitName]
    if not kit then
        ply:ChatPrint("Кит не найден.")
        return
    end

    -- Проверка customCheck
    if kit.customCheck then
        local status, message = kit.customCheck(ply)
        if not status then
            ply:ChatPrint(message or "You can't use this kit.")
            return
        end
    end

    local now = os.time()
    local lastUsed = playerKitsCooldown[ply:SteamID()] and playerKitsCooldown[ply:SteamID()][kitName] or 0
    
    if kit.cooldown and now - lastUsed < kit.cooldown then
        local wait = kit.cooldown - (now - lastUsed)
        ply:ChatPrint("Кит можно активировать через " .. wait .. " секунд.")
        return
    end

    -- Проверка и списание цены
    if kit.price then
        for _, costItem in ipairs(kit.price) do
            if not ply:HasItem(costItem.id, costItem.amount) then
                ply:ChatPrint("Недостаточно предметов для покупки: " .. costItem.id)
                return
            end
        end
        for _, costItem in ipairs(kit.price) do
            ply:RemoveItem(costItem.id, costItem.amount)
        end
    end

    -- Выдача предметов из кита
    for _, item in ipairs(kit.items or {}) do
        ply:GiveItem(item.id, item.amount)
        print("Выдан предмет", item.id, "в количестве", item.amount, "игроку", ply:Nick())
    end

    playerKitsCooldown[ply:SteamID()] = playerKitsCooldown[ply:SteamID()] or {}
    playerKitsCooldown[ply:SteamID()][kitName] = now
    ply:ChatPrint("Кит '" .. kit.title .. "' активирован!")
end)

-- Открытие меню по чат-команде /kit
hook.Add("PlayerSay", "OpenKitsMenuCommand", function(ply, text)
    if string.lower(text) == "/kit" then
        net.Start("gRust.OpenKitMenu")
        net.Send(ply)
        return ""
    end
end)

local function SendKitsToClient(ply)
    net.Start("gRust.SyncKits")
    net.WriteTable(gRust.Kits)
    net.Send(ply)
end

hook.Add("PlayerInitialSpawn", "SendKitsToClientOnJoin", function(ply)
    SendKitsToClient(ply)
end)

-- Также отправляйте данные перед открытием меню, если необходимо
net.Receive("gRust.OpenKitMenu", function(len, ply)
    SendKitsToClient(ply)
end)

-- Функция для получения кулдауна
function RUST.kits:GetCooldown(ply, kitID)
    local cooldowns = playerKitsCooldown[ply:SteamID()] or {}
    return math.max((cooldowns[kitID] or 0) - os.time(), 0)
end