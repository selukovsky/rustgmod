LANG["English"] = {}
LANG["English"]["dont_have"] = "Error removing resources: "
LANG["English"]["not_enough_resources"] = "Not enough resources! Required: "
LANG["English"]["error_removing"] = "Error removing resources!"