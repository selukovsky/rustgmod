include("shared.lua")
include("lang/cl_english.lua")
AddCSLuaFile("gamemode/core/inventory/vgui/slot_cl.lua")  -- Отдаёт файл клиенту
include("gamemode/core/inventory/vgui/slot_cl.lua") 

do
	RunConsoleCommand("cl_interp", 0)
end

timer.Create("UpdateSyncAll", 0.1, 0, function()
	//gRust.UpdateInventory()
end)

hook.Add("InitPostEntity", "InitializeHands", function()
    -- Подождать загрузку всех элементов
end)

hook.Add("PlayerSpawn", "SetRustHands", function(ply)
    timer.Simple(0, function()
        if not IsValid(ply) then return end

        -- Путь к модели рук с правильными аннимациями, замените на нужный
        local handModel = "models/player/hand_rust.mdl"

        ply:SetHandsModel(handModel)

        -- Также нужно убедиться в синхронизации модели рук на клиенте
        -- В большинстве случаев SetHandsModel работает автоматически
    end)
end)