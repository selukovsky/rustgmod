--[[
gamemodes/rust/entities/weapons/rust_scard/cl_init.lua
--]]
include("shared.lua")

SWEP.VMPos = Vector(-2, -1, 0.5)
SWEP.VMAng = Vector(0, 0, 0)

function SWEP:PrimaryAttack()
end

