SWEP.Base       = "rust_baseshotgun"

SWEP.WorldModel = "models/weapons/darky_m/rust/w_grenadelauncher.mdl"

SWEP.ViewModel  = "models/weapons/darky_m/rust/c_grenadelauncher.mdl"



SWEP.Primary.Automatic = false



--

-- Stats

--

SWEP.Damage     = 30

SWEP.RPM        = 400

SWEP.AimCone    = 0.25

SWEP.Capacity   = 6

SWEP.ReloadTime = 5

SWEP.DrawTime   = 0.5



SWEP.Ammo       = "ammo.mgl.basic"



SWEP.HoldType 	= "smg"



--

-- Ironsights

--

SWEP.IronSightsPos = Vector(-5.919, -6.89, 4.763)
SWEP.IronSightsAng = Vector(-4.45, -1.241, 8.677)

SWEP.IronSightTime  = 0.075

SWEP.IronSightFOV   = 35



--

-- Sounds

--

SWEP.ShootSound		= "darky_rust.grenade-launcher-attack"

SWEP.SilencedSound	= "darky_rust.semi-pistol-attack-silenced"



--

-- Recoil

--

SWEP.RecoilAmount   = 1.5

SWEP.RecoilTable = {

	Angle(-2.5, 0, 0),

}



SWEP.Primary.Automatic = false

function SWEP:ShootBullet()

    if (CLIENT) then return end



    local pl = self:GetOwner()

    local ang = pl:GetAimVector():Angle()

    local ent = ents.Create("rust_projectile")

    ent:SetOwner(pl)

    ent:SetModel("models/weapons/darky_m/rust/gl_ammo.mdl")

    ent:SetPos(pl:GetShootPos() + pl:EyeAngles():Forward() * 0.1)

    ent:SetAngles(ang)

    ent:Spawn()

    ent:SetModel(self.WorldModel)

    ent:Activate()

    ent:Throw(ang:Forward(), 8000)

    ent.PhysicsCollide = function()

        util.ScreenShake(ent:GetPos(), 5, 1, 2, 1000)

        util.BlastDamage(ent, ent:GetOwner(), ent:GetPos(), 90, 2000)

        

        ent:EmitSound("darky_rust.beancan-grenade-explosion")

        ParticleEffect("rust_big_explosion", ent:GetPos(), ent:GetAngles())

        ent:Remove()

    end

end