SWEP.Base       = "rust_basegun"

SWEP.WorldModel = "models/weapons/darky_m/rust/w_thompson.mdl"

SWEP.ViewModel  = "models/weapons/darky_m/rust/c_thompson.mdl"

SWEP.ViewModelFOV = 55

--

-- Stats

--

SWEP.Damage     = 37

SWEP.RPM        = 462

SWEP.AimCone    = 0.2

SWEP.Capacity   = 20

SWEP.ReloadTime = 4

SWEP.DrawTime   = 1



SWEP.Ammo       = "ammo.pistol"



SWEP.HoldType 	= "smg"



--

-- Ironsights

--

SWEP.IronSightPos 	= Vector(-5, -4, 3)

SWEP.IronSightAng 	= Vector(-0.401, 0.4, 0)

SWEP.IronSightTime  = 0.075

SWEP.IronSightFOV   = 25



--

-- Sounds

--

SWEP.ShootSound		= "darky_rust.thompson-attack"

SWEP.SilencedSound	= "darky_rust.thompson-attack-silenced"



--

-- Recoil

--

SWEP.RecoilLerp   = 0.075

SWEP.RecoilTable = {
    Angle(-1.0, 0.2, 0),
    Angle(-1.3, -0.3, 0),
    Angle(-1.1, 0.1, 0),
    Angle(-1.0, -0.2, 0),
    Angle(-0.9, 0.3, 0),
    Angle(-0.8, 0, 0),
    Angle(-0.7, -0.1, 0),
    Angle(-0.8, 0.2, 0),
    Angle(-0.6, 0, 0),
    Angle(-0.6, 0.1, 0),
}



local HoloMat = Material("models/darky_m/rust_weapons/mods/holosight.reticle.standard.png")

SWEP.AttachmentData =

{

	["holosight"] = {

		model = "models/weapons/darky_m/rust/mod_holo.mdl",

		pos = Vector(-0.07, -1.5-0.5, -0.8),

		ang = Angle(180, -90, 0),



		ispos = Vector(-4.963, -6, 2.078),

		isang = Vector(-0.025, 0.46, 0.36),

		scale = 0.0085,

		modelscale = 0.9,



		painttype = "3d2d",

		paintpos = Vector(0, 0, 0.5),

		paintang = Angle(0, 0, 0),

		scale = 0.0065,

		paint = function()

			surface.SetDrawColor(180, 0, 0)

			surface.SetMaterial(HoloMat)

			surface.DrawTexturedRect(315, -72, 140, 140)

		end

	},

	["flashlight"] = {
    model = "models/weapons/darky_m/rust/mod_flash.mdl", -- или другая модель фонарика
    pos = Vector(-0.08, 2.03, 15.1),
    ang = Angle(0, -90, 180),
    
    -- Функциональность фонарика будет обрабатываться отдельно
    isattachment = true
   }

}