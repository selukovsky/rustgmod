AddCSLuaFile()



SWEP.Base = "rust_basethrow"



SWEP.WorldModel         = "models/weapons/darky_m/rust/w_f1.mdl"

SWEP.ViewModel          = "models/weapons/darky_m/rust/c_f1.mdl"



SWEP.ThrowDelay = 0.25

SWEP.ThrowForce = 1500

SWEP.FuseTime	= 2

SWEP.Stick		= false

SWEP.Damage     = 75