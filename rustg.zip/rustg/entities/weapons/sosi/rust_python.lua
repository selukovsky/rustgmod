SWEP.Base       = "rust_basegun"
SWEP.WorldModel = "models/weapons/darky_m/rust/w_python.mdl"
SWEP.ViewModel  = "models/weapons/darky_m/rust/c_python.mdl"

SWEP.Primary.Automatic = false

--
-- Stats
--
SWEP.Damage     = 55
SWEP.RPM        = 400
SWEP.AimCone    = 0.25
SWEP.Capacity   = 6
SWEP.ReloadTime = 3.75
SWEP.DrawTime   = 0.5

SWEP.Ammo       = "pistol_ammo"

SWEP.HoldType 	= "pistol"

--
-- Ironsights
--
SWEP.IronSightPos 	= Vector(-4.385, -5.453, 2.475)
SWEP.IronSightAng 	= Vector(0.1, 0.07, 0)
SWEP.IronSightTime  = 0.075
SWEP.IronSightFOV   = 25

--
-- Sounds
--
SWEP.ShootSound		= "darky_rust.python-attack"
SWEP.SilencedSound	= "darky_rust.python-attack-silenced"

--
-- Recoil
--

SWEP.RecoilLerp = 0.4
SWEP.RecoilShootReturnTime = 0.05
SWEP.RecoilTable = {
	Angle(-2.5, 0, 0),
}

local HoloMat = Material("models/darky_m/rust_weapons/mods/holosight.reticle.standard.png")
SWEP.AttachmentData =
{
	["holosight"] = {
		model = "models/weapons/darky_m/rust/mod_holo.mdl",
		pos = Vector(-0.15, -1.5-1.0, -0.8+3.9),
		ang = Angle(180, -90, 0),

		ispos = Vector(-4.405, -5.5, 1.54),
		isang = Angle(0.1, 0.07, 0),
		modelscale = 0.8,
		bone = "main",
		
		painttype = "3d2d",
		scale = 0.0085,
		paint = function()
			surface.SetDrawColor(180, 0, 0)
			surface.SetMaterial(HoloMat)
			surface.DrawTexturedRect(97, -61, 140, 140)
		end
	},
}