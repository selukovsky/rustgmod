SWEP.Base       = "rust_basegun"
SWEP.WorldModel = "models/weapons/darky_m/rust/w_ak47u.mdl"
SWEP.ViewModel  = "models/weapons/darky_m/rust/c_ak47u.mdl"

--
-- Stats
--
SWEP.Damage     = 50
SWEP.RPM        = 450
SWEP.AimCone    = 0.075
SWEP.Capacity   = 30
SWEP.ReloadTime = 4.4
SWEP.DrawTime   = 1

SWEP.Ammo       = "rifle_ammo"

SWEP.HoldType 	= "ar2"

--
-- Ironsights
--
SWEP.IronSightPos   = Vector(-6.115, -6.896, 3.68)
SWEP.IronSightAng   = Vector(-0.21, 0.029, 0)
SWEP.IronSightTime  = 0.075
SWEP.IronSightFOV   = 25

--
-- Sounds
--
SWEP.ShootSound		= "darky_rust.ak74u-attack"
SWEP.SilencedSound	= "darky_rust.ak74u-attack-silenced"

--
-- Recoil
--

SWEP.RecoilLerp = 0.075
SWEP.RecoilTable = {
	Angle(-2.5531914893617, 3, 0),
	Angle(-4.2553191489362, -3.5, 0),
	Angle(-4.2553191489362, 0.5, 0),
	Angle(-3.8297872340426, -4, 0),
	Angle(-3.4042553191489, -3, 0),
	Angle(-4.0425531914894, -0.75, 0),
	Angle(-3.4042553191489, 1.75, 0),
	Angle(-2.7659574468085, 3.75, 0),
	Angle(-1.4893617021277, 5.75, 0),
	Angle(-1.2765957446809, 6, 0),
	Angle(-1.9148936170213, 5, 0),
	Angle(-3.4042553191489, 3.75, 0),
	Angle(-3.6170212765957, 1.75, 0),
	Angle(-4.2553191489362, 0.75, 0),
	Angle(-4.0425531914894, -1.75, 0),
	Angle(-3.1914893617021, -3, 0),
	Angle(-2.7659574468085, -4, 0),
	Angle(-2.3404255319149, -5.25, 0),
	Angle(-2.7659574468085, -5.75, 0),
	Angle(-1.9148936170213, -6.25, 0),
	Angle(-1.7021276595745, -5.5, 0),
	Angle(-1.4893617021277, -5, 0),
	Angle(-1.7021276595745, -4.5, 0),
	Angle(-3.8297872340426, -2.5, 0),
	Angle(-3.6170212765957, 4, 0),
	Angle(-2.1276595744681, 3.75, 0),
	Angle(-2.5531914893617, 4.5, 0),
	Angle(-2.1276595744681, 4.25, 0),
	Angle(-1.7021276595745, 4, 0),
	Angle(-1.7021276595745, 3.75, 0),
}
/*
SWEP.VElements =
{
	["ms_holosight"] = { type = "Model", , bone = "main", rel = "", , size = Vector(1.15, 1.15, 1.15), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bonemerge = false, active = false, bodygroup = {} },
	["ms_holosight_xhair"] = { type = "Quad", bone = "main", rel = "ms_holosight", pos = Vector(0.519, 0, 0), angle = Angle(-90, 0, 90), size = 0.01, active = false, draw_func = function()   surface.SetDrawColor(255,255,255,255) surface.SetMaterial( rust_ms_material ) surface.DrawTexturedRect(-70, -70, 140, 140) end },

	["holosight"] = { type = "Model", model = "models/weapons/darky_m/rust/mod_holo.mdl", bone = "main", rel = "", pos = Vector(-0.15, -2.5, -0.2), angle = Angle(180, -90, 0), size = Vector(0.9, 0.9, 0.9), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bonemerge = false, active = false, bodygroup = {} },
	["holosight_lens"] = { type = "Quad", bone = "main", rel = "holosight", pos = Vector(0.47, -0.123, 0.3), angle = Angle(0, -90, 0), size = 0.01, active = false, draw_func = function()     surface.SetDrawColor(255,0,0,255) surface.SetMaterial( rust_holo_material ) surface.DrawTexturedRect(-40, -40, 80, 80) end },
	["8xscope"] = { type = "Model", model = "models/weapons/darky_m/rust/mod_8xScope.mdl", bone = "main", rel = "", pos = Vector(-0.06, -1.354, 3.079), angle = Angle(180, 0, -90), size = Vector(1, 1, 1), color = Color(255, 255, 255, 255), surpresslightning = false, materials = {"","","!tfa_rtmaterial"}, skin = 0, bonemerge = false, active = false, bodygroup = {} },
	["4xscope"] = { type = "Model", model = "models/weapons/darky_m/rust/mod_reddot.mdl", bone = "main", rel = "", pos = Vector(0.148, -3.13, 0.281), angle = Angle(0, 0, -90), size = Vector(1, 1, 1), color = Color(255, 255, 255, 255), surpresslightning = false, materials = {"","","!tfa_rtmaterial"}, skin = 0, bonemerge = false, active = false, bodygroup = {} },
	

	["silencer"] = { type = "Model", model = "models/weapons/darky_m/rust/mod_silencer.mdl", bone = "main", rel = "", pos = Vector(0, 0.5, 29), angle = Angle(0, 0, 180), size = Vector(1, 1, 1), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bonemerge = false, active = false, bodygroup = {} },
	["mbrake"] = { type = "Model", model = "models/weapons/darky_m/rust/mod_muzzlebrake.mdl", bone = "main", rel = "", pos = Vector(0, 0.6, 26), angle = Angle(0, 90, -90), size = Vector(2.5, 2.5, 2.5), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bonemerge = false, active = false, bodygroup = {} },
	["mboost"] = { type = "Model", model = "models/weapons/darky_m/rust/mod_muzzleboost.mdl", bone = "main", rel = "", pos = Vector(0, 0.6, 26), angle = Angle(0, 90, -90), size = Vector(2.5, 2.5, 2.5), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bonemerge = false, active = false, bodygroup = {} },
	
	["lasersight"] = { type = "Model", model = "models/weapons/darky_m/rust/mod_laser.mdl", bone = "main", rel = "", pos = Vector(0, 1.568, 15.238), angle = Angle(0, -90, 180), size = Vector(1.1, 1.1, 1.1), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bonemerge = false, active = false, bodygroup = {} },
	["flashlight"] = { type = "Model", model = "models/weapons/darky_m/rust/mod_flash.mdl", bone = "main", rel = "", pos = Vector(-0.08, 2.03, 15.1), angle = Angle(0, -90, 180), size = Vector(1.1, 1.1, 0.9), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bonemerge = false, active = false, bodygroup = {} },

	["laser_beam"] = { type = "Model", model = "models/tfa/lbeam.mdl", bone = "main", rel = "lasersight", pos = Vector(0.5,0,0), angle = Angle(-90, 0, 0), size = Vector(2, 0.5, 0.5), color = Color(255, 255, 255, 32), surpresslightning = false, material = "", skin = 0, bodygroup = {}, bonemerge = false, active = false },
}
*/

local HoloMat = Material("models/darky_m/rust_weapons/mods/holosight.reticle.standard.png")
local Scope8xMat = Material("models/darky_m/rust_weapons/mods/8x_crosshair.png")
SWEP.AttachmentData =
{
	["holosight"] = {
		model = "models/weapons/darky_m/rust/mod_holo.mdl",
		pos = Vector(-0.15, -2.5, -0.2),
		ang = Angle(180, -90, 0),

		ispos = Vector(-6.073, -2.6, 2.785),
		isang = Angle(0, 0, 0),
		painttype = "3d2d",
		scale = 0.0085,
		paint = function()
			surface.SetDrawColor(180, 0, 0)
			surface.SetMaterial(HoloMat)
			surface.DrawTexturedRect(279, -67, 140, 140)
		end
	},
	["silencer"] = {
		model = "models/weapons/darky_m/rust/mod_silencer.mdl",
		pos = Vector(0, 0.5, 29),
		ang = Angle(0, 0, 180),
	},
	["8x_scope"] =
	{
		model = "models/weapons/darky_m/rust/mod_reddot.mdl",
		pos = Vector(0.148, -3.13, 0.281),
		ang = Angle(0, 0, -90),

		ispos = Vector(-6.106, -2.6, 2.85),
		isang = Vector(0, 0, 0),
		painttype = "screen",
		zoom = 8,
		paint = function(scopetime)
			local scrw, scrh = ScrW(), ScrH()

			local XOffset = scrw * 0.5 - scrh * 0.5

			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(0, 0, XOffset, scrh)

			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(XOffset + scrh, 0, XOffset, scrh)

			surface.SetDrawColor(255, 255, 255)
			surface.SetMaterial(Scope8xMat)
			surface.DrawTexturedRect(XOffset, 0, scrh, scrh)

			surface.SetDrawColor(0, 0, 0, 255 - (CurTime() - scopetime) * 200)
			surface.DrawRect(0, 0, scrw, scrh)
		end
	},
	["16x_scope"] =
	{
		model = "models/weapons/darky_m/rust/mod_8xScope.mdl",
		pos = Vector(-0.06, -1.354, 3.079),
		ang = Angle(180, 0, -90),

		ispos = Vector(-6.106, -2.6, 2.85),
		isang = Vector(0, 0, 0),
		painttype = "screen",
		zoom = 16,
		paint = function(scopetime)
			local scrw, scrh = ScrW(), ScrH()

			local XOffset = scrw * 0.5 - scrh * 0.5

			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(0, 0, XOffset, scrh)

			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(XOffset + scrh, 0, XOffset, scrh)

			surface.SetDrawColor(255, 255, 255)
			surface.SetMaterial(Scope8xMat)
			surface.DrawTexturedRect(XOffset, 0, scrh, scrh)

			surface.SetDrawColor(0, 0, 0, 255 - (CurTime() - scopetime) * 200)
			surface.DrawRect(0, 0, scrw, scrh)
		end
	}
}