AddCSLuaFile()

SWEP.Base = "rust_basethrow"

SWEP.WorldModel         = "models/weapons/darky_m/rust/w_smokegrenade.mdl"
SWEP.ViewModel          = "models/weapons/darky_m/rust/c_smokegrenade.mdl"

SWEP.ThrowDelay = 0.25
SWEP.ThrowForce = 750
SWEP.FuseTime	= 30

SWEP.Damage     = 0

function SWEP:FuseCallback(ent, damage)
    local pos = ent:GetPos()
    pos.z = 7000
    
    local ent = ents.Create("rust_supplyplane")
    ent:SetPos(pos)
    ent:Spawn()
end