--[[
gamemodes/rust/entities/weapons/rust_spear.lua
--]]
SWEP.Base = "rust_melee"
SWEP.ViewModel = "models/weapons/darky_m/rust/c_Machete.mdl"
SWEP.WorldModel = "models/weapons/darky_m/rust/w_Machete.mdl"
SWEP.DownPos = Vector(-5, 0, -6)
SWEP.Damage = 35
SWEP.Range = 80
SWEP.SwingDelay = 0.25
SWEP.SwingInterval = 0.9
SWEP.SwingSound = "darky_rust.machete-attack"
SWEP.StrikeSound = "darky_rust.spear-strike-soft"
SWEP.Stick = false
SWEP.HarvestAmount = {
	["rust_ore"] = 0,
	["tree"] = 0,
}