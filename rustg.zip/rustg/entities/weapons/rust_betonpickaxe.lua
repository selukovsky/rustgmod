--[[
gamemodes/rust/entities/weapons/rust_stonepickaxe.lua
--]]
SWEP.Base               = "rust_melee"



SWEP.ViewModel          = "models/zohart/store/65/c_stone_pickaxe.mdl"

SWEP.WorldModel         = "models/zohart/store/65/w_stone_pickaxe.mdl"



SWEP.DownPos            = Vector(-5, 0, -4)



SWEP.Damage             = 15



SWEP.SwingDelay         = 0

SWEP.SwingInterval      = 1

SWEP.SwingSound         = "darky_rust.hatchet-stone-attack"

SWEP.StrikeSound        = "darky_rust.hatchet-stone-strike"



SWEP.HarvestAmount =

{

	["rust_ore"] = 1.5,

	["tree"] = 0,

}

