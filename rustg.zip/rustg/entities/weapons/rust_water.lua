AddCSLuaFile()

SWEP.Base = "rust_base"

SWEP.PrintName = "water"
SWEP.Instructions = "Left click to heal yourself"

SWEP.ViewModel = "models/weapons/sweps/stalker2/water/v_item_water.mdl"
SWEP.WorldModel = "models/weapons/sweps/stalker2/water/w_item_water.mdl"

SWEP.VMPos = Vector()
SWEP.VMAng = Vector()
SWEP.DownPos = Vector(0, 0, -2)

SWEP.HoldType = "knife"
SWEP.DrawTime = 1

SWEP.Delay = 2 
SWEP.AddHealth = 1


SWEP.AddThirst = 50     -- Кол-во пополнения жажды (настройка)

function SWEP:PrimaryAttack()
    local pl = self:GetOwner()
    if not IsValid(pl) then return end
    
    if pl:Health() >= pl:GetMaxHealth() then
        return
    end

    self:PlayAnimation("PrimaryAttack")

    self.NextUse = CurTime() + self.Delay
    self:SetNextPrimaryFire(self.NextUse)
end

function SWEP:Think()
    if SERVER and self.NextUse and self.NextUse < CurTime() then
        self.NextUse = nil

        local pl = self:GetOwner()
        if not IsValid(pl) then return end

        self:Heal(pl)
    end
end

function SWEP:Heal(target)
    local Owner = self:GetOwner()
    local selectedSlotIndex = Owner.SelectedSlotIndex
    if not selectedSlotIndex then return end

    local slot = Owner.Inventory[selectedSlotIndex]
    if not slot then return end

    -- Применяем лечение
    target:SetHealth(math.min(target:GetMaxHealth(), target:Health() + self.AddHealth))

    -- Пополняем голод и жажду, если методы доступны
    if target.AddHunger then
        target:AddHunger(self.AddHunger)
    elseif target.SetHunger then
        target:SetHunger(math.min(511, target:GetHunger() + self.AddHunger))
    end

    if target.AddThirst then
        target:AddThirst(self.AddThirst)
    elseif target.SetThirst then
        target:SetThirst(math.min(255, target:GetThirst() + self.AddThirst))
    end

    -- Потребляем один слот (еду)
    if slot:GetQuantity() > 1 then
        slot:SetQuantity(slot:GetQuantity() - 1)
        Owner:SyncSlot(selectedSlotIndex)
    else
        Owner:RemoveSlot(selectedSlotIndex)
        timer.Simple(0.1, function()
            if IsValid(Owner) then
                ClearPlayerWeapon(Owner)
            end
        end)
    end
end

function SWEP:Holster()
    self.NextUse = nil
    return true
end

function SWEP:SecondaryAttack()
    -- Нет вторичной атаки
end