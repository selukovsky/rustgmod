SWEP.ViewModel      = "models/player/darky_m/rust/c_arms_human.mdl"

SWEP.WorldModel     = ""

SWEP.DrawCrosshair = false

function SWEP:Initialize()

    self:SetHoldType("none")

end



function SWEP:PrimaryAttack()

end



function SWEP:SecondaryAttack()

end