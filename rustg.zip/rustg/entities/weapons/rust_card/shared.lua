SWEP.Base = "rust_base"

SWEP.WorldModel = "models/darky_m/rust/puzzle/access_card.mdl"
SWEP.ViewModel = "models/weapons/darky_m/rust/c_keycard.mdl"

SWEP.DownPos = Vector(-5, 0, -4)