AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function SWEP:OnItemSet()
    local item = self:GetInventorySlot()
    if not item then return end
    local id = item:GetItem()

    if id == "keycard_green" then
        self:GetOwner():GetViewModel():SetSkin(0)
        self.Level = 0
    elseif id == "keycard_blue" then
        self:GetOwner():GetViewModel():SetSkin(1)
        self.Level = 1
    elseif id == "keycard_red" then
        self:GetOwner():GetViewModel():SetSkin(2)
        self.Level = 2
    end
end

function SWEP:Deploy()
    timer.Simple(0.01, function()
        if IsValid(self) then
            self:OnItemSet()
        end
    end)
    return true
end

function SWEP:PrimaryAttack()
    if CLIENT then return end

    local ply = self.Owner
    local tr = util.TraceLine({
        start = ply:GetShootPos(),
        endpos = ply:GetShootPos() + ply:GetAimVector() * 75,
        filter = ply
    })

    if tr.Hit and IsValid(tr.Entity) and tr.Entity:GetClass() == "rust_cardreader" then
        local slotID = self.InventorySlot
        if slotID then
            tr.Entity:AcceptKeycard(ply, self.Level, slotID)
        end
    end

    self:SetNextPrimaryFire(CurTime() + 1)
    self:PlayAnimation("PrimaryAttack")
end