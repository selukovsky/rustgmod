SWEP.Base       = "rust_basegun"

SWEP.WorldModel = "models/weapons/darky_m/rust/w_mp5.mdl"

SWEP.ViewModel  = "models/weapons/darky_m/rust/c_mp5.mdl"


SWEP.ViewModelFOV = 55
--

-- Stats

--

SWEP.Damage     = 35

SWEP.RPM        = 600

SWEP.AimCone    = 0.2

SWEP.Capacity   = 30

SWEP.ReloadTime = 4

SWEP.DrawTime   = 1.6



SWEP.Ammo       = "ammo.pistol"



SWEP.HoldType 	= "pistol"



--

-- Ironsights

--

SWEP.IronSightPos 	= Vector(-6.41, -2, 3)

SWEP.IronSightAng 	= Vector(0.5, 1, -1.465)

SWEP.IronSightTime  = 0.075

SWEP.IronSightFOV   = 30



--

-- Sounds

--

SWEP.ShootSound		= "darky_rust.mp5-attack"

SWEP.SilencedSound	= "darky_rust.mp5-attack-silenced"



--

-- Recoil

--

SWEP.RecoilAmount   = 1.0

SWEP.RecoilTable = {
    Angle(-0.7, 0.3, 0),
    Angle(-0.9, -0.2, 0),
    Angle(-0.8, 0.1, 0),
    Angle(-0.7, -0.1, 0),
    Angle(-0.6, 0.2, 0),
    Angle(-0.5, 0, 0),
    Angle(-0.4, -0.1, 0),
    Angle(-0.5, 0.1, 0),
    Angle(-0.3, 0, 0),
    Angle(-0.3, 0.05, 0),
}

local HoloMat = Material("models/darky_m/rust_weapons/mods/holosight.reticle.standard.png")

local Scope8xMat = Material("models/darky_m/rust_weapons/mods/8x_crosshair.png")

SWEP.AttachmentData = {
	["simple_handmade_sight"] = {
		model = "models/weapons/darky_m/rust/mod_ms_holosight.mdl",
		pos = Vector(0, -4.2, 4.35), -- Vector(0, -1.9-2.3, -0.65+5)
		ang = Angle(180, -90, -90),
		modelscale = 1.15,
		bone = "main",

		ispos = Vector(-6.45, 0, 2.125),
		isang = Angle(-0.18, -1.36, 0),
		painttype = "3d2d",
		scale = 0.01,
		paintpos = Vector(0.519, 0, 0),
		paintang = Angle(-90, 0, 90),
		paint = function()
			surface.SetDrawColor(0, 0, 0)
			surface.SetMaterial(SIMPLESIGHT_MATERIAL)
			surface.DrawTexturedRect(-70, -70, 140, 140)
		end
	},

	["holosight"] = {

		model = "models/weapons/darky_m/rust/mod_holo.mdl",

		pos = Vector(-0.09, -3.8, 4.2),

		ang = Angle(180, -90, 0),



		ispos = Vector(0, -1.9-2.3, -0.65+5),

		isang = Angle(180, -90, -90),

		painttype = "3d2d",

		scale = 0.0085,

		paint = function()

			surface.SetDrawColor(255, 0, 0)

			surface.SetMaterial(HoloMat)

			surface.DrawTexturedRect(-40, -40, 80, 80)

		end

	},

	["silencer"] = {
		model = "models/weapons/darky_m/rust/mod_silencer.mdl",
		pos = Vector(0, -1.4, 21),
		ang = Angle(0, 0, 180),
		modelscale = 0.8,
		bone = "main"
	},

	["weapon_flashlight"] = {
		model = "models/weapons/darky_m/rust/mod_flash.mdl",
		pos = Vector(-0.1, 0.2, 13.1), -- Vector(-0.1, 0.2, 8.1+5)
		ang = Angle(0, -90, 180),
		modelscale = 1.0,
		bone = "main"
	},

	["8x_zoom_scope"] = {
		model = "models/weapons/darky_m/rust/mod_reddot.mdl",
		pos = Vector(0.25, -4.6, 4), -- Vector(0.25, -2.3-2.3, -1+5)
		ang = Angle(0, 0, -90),
		modelscale = 1.0,
		bone = "main",

		ispos = Vector(-6.106, -2.6, 2.85),
		isang = Vector(0, 0, 0),
		painttype = "screen",
		zoom = 8,
		paint = function(scopetime)
			local scrw, scrh = ScrW(), ScrH()
			local XOffset = scrw * 0.5 - scrh * 0.5

			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(0, 0, XOffset, scrh)

			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(XOffset + scrh, 0, XOffset, scrh)

			surface.SetDrawColor(255, 255, 255)
			surface.SetMaterial(Scope8xMat)
			surface.DrawTexturedRect(XOffset, 0, scrh, scrh)

			surface.SetDrawColor(0, 0, 0, 255 - (CurTime() - scopetime) * 200)
			surface.DrawRect(0, 0, scrw, scrh)
		end
	},

	["16x_zoom_scope"] = {
		model = "models/weapons/darky_m/rust/mod_8xScope.mdl",
		pos = Vector(0.03, -2.7, 6.9), -- Vector(0.03, -0.4-2.3, 1.9+5)
		ang = Angle(180, 0, -90),
		modelscale = 1.0,
		bone = "main",

		ispos = Vector(-6.106, -2.6, 2.85),
		isang = Vector(0, 0, 0),
		painttype = "screen",
		zoom = 16,
		paint = function(scopetime)
			local scrw, scrh = ScrW(), ScrH()
			local XOffset = scrw * 0.5 - scrh * 0.5

			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(0, 0, XOffset, scrh)

			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(XOffset + scrh, 0, XOffset, scrh)

			surface.SetDrawColor(255, 255, 255)
			surface.SetMaterial(Scope8xMat)
			surface.DrawTexturedRect(XOffset, 0, scrh, scrh)

			surface.SetDrawColor(0, 0, 0, 255 - (CurTime() - scopetime) * 200)
			surface.DrawRect(0, 0, scrw, scrh)
		end
	},

	["weapon_lasersight"] = {
		model = "models/weapons/darky_m/rust/w_mod_laser.mdl",
		pos = Vector(0, -0.4, 12.68), -- Vector(0, -0.4, 7.18+5.5)
		ang = Angle(0, -90, 180),
		modelscale = 1.0,
		bone = "main"
	},

	["muzzle_brake"] = {
		model = "models/weapons/darky_m/rust/mod_muzzlebrake.mdl",
		pos = Vector(0, -1.35, 18),
		ang = Angle(0, 90, -90),
		modelscale = 1.8,
		bone = "main"
	},

	["muzzle_boost"] = {
		model = "models/weapons/darky_m/rust/mod_muzzleboost.mdl",
		pos = Vector(0, -1.35, 18),
		ang = Angle(0, 90, -90),
		modelscale = 1.8,
		bone = "main"
	}
}