SWEP.Base       = "rust_basegun"

SWEP.WorldModel = "models/weapons/darky_m/rust/w_m92.mdl"

SWEP.ViewModel  = "models/weapons/darky_m/rust/c_m92.mdl"



SWEP.Primary.Automatic = false



--

-- Stats

--

SWEP.Damage     = 45

SWEP.RPM        = 400

SWEP.AimCone    = 0.3

SWEP.Capacity   = 15

SWEP.ReloadTime = 2.2

SWEP.DrawTime   = 0.5



SWEP.Ammo       = "ammo.pistol"



--

-- Ironsights

--

SWEP.IronSightPos 	= Vector(-3.711, 0, 1.799)

SWEP.IronSightAng 	= Vector(0.209, 0, 0)

SWEP.IronSightTime  = 0.075

SWEP.IronSightFOV   = 30



--

-- Sounds

--

SWEP.ShootSound		= "darky_rust.m92-attack"

SWEP.SilencedSound	= "darky_rust.m92-attack-silenced"



--

-- Recoil

--

SWEP.RecoilAmount   = 0.35

SWEP.RecoilLerp = 0.05

SWEP.RecoilTable = {
	Angle(-2.5 * 3, -0.4 * 2, 0),
}


SWEP.AttachmentData =

{

	["flashlight"] = {
    model = "models/weapons/darky_m/rust/mod_flash.mdl", -- или другая модель фонарика
    pos = Vector(-0.08, 2.03, 15.1),
    ang = Angle(0, -90, 180),
    
    -- Функциональность фонарика будет обрабатываться отдельно
    isattachment = true
   }

}