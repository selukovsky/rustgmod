SWEP.Base       = "rust_basegun"

SWEP.WorldModel = "models/weapons/darky_m/rust/w_ak47u.mdl"

SWEP.ViewModel  = "models/weapons/darky_m/rust/c_ak47u.mdl"

SWEP.ViewModelFOV = 55

--

-- Stats

--

SWEP.Damage     = 50

SWEP.RPM        = 450

SWEP.AimCone    = 0.075

SWEP.Capacity   = 30

SWEP.ReloadTime = 4.4

SWEP.DrawTime   = 1



SWEP.Ammo       = "ammo.rifle" 

SWEP.HoldType 	= "ar2"


--

-- Ironsights

--

SWEP.IronSightPos   = Vector(-6.115, -6.896, 3.68)

SWEP.IronSightAng   = Vector(-0.21, 0.029, 0)

SWEP.IronSightTime  = 0.075

SWEP.IronSightFOV   = 25



--

-- Sounds

--

SWEP.ShootSound		= "darky_rust.ak74u-attack"

SWEP.SilencedSound	= "darky_rust.ak74u-attack-silenced"



--

-- Recoil

--



SWEP.RecoilLerp = 0.075

SWEP.RecoilTable = {
	Angle(-2.257792, -0.000000),
	Angle(-2.300758, -0.323242),
	Angle(-2.299759, -0.649593),
	Angle(-2.259034, -0.848786),
	Angle(-2.323947, -1.075408),
	Angle(-2.215956, -1.268491),
	Angle(-2.236556, -1.330963),
	Angle(-2.218203, -1.336833),
	Angle(-2.143454, -1.505516),
	Angle(-2.233091, -1.504423),
	Angle(-2.270194, -1.442116),
	Angle(-2.204318, -1.478543),
	Angle(-2.165817, -1.392874),
	Angle(-2.177887, -1.480824),
	Angle(-2.270915, -1.597069),
	Angle(-2.145893, -1.449996),
	Angle(-2.270450, -1.369179),
	Angle(-2.298334, -1.582363),
	Angle(-2.235066, -1.516872),
	Angle(-2.238401, -1.498249),
	Angle(-2.331642, -1.465769),
	Angle(-2.242621, -1.564812),
	Angle(-2.303052, -1.517519),
	Angle(-2.211946, -1.422433),
	Angle(-2.248043, -1.553195),
	Angle(-2.285327, -1.510463),
	Angle(-2.240047, -1.553878),
	Angle(-2.221839, -1.520380),
	Angle(-2.240047, -1.553878),
	Angle(-2.248043, -1.553195),
}





local HoloMat = Material("models/darky_m/rust_weapons/mods/holosight.reticle.standard.png")

local Scope8xMat = Material("models/darky_m/rust_weapons/mods/8x_crosshair.png")

SWEP.AttachmentData =

{

	["holosight"] = {

		model = "models/weapons/darky_m/rust/mod_holo.mdl",

		pos = Vector(-0.15, -2.5, -0.2),

		ang = Angle(180, -90, 0),



		ispos = Vector(-6.073, -2.6, 2.785),

		isang = Angle(0, 0, 0),

		painttype = "3d2d",

		scale = 0.0085,

		paint = function()

			surface.SetDrawColor(180, 0, 0)

			surface.SetMaterial(HoloMat)

			surface.DrawTexturedRect(279, -67, 140, 140)

		end

	},

	["silencer"] = {

		model = "models/weapons/darky_m/rust/mod_silencer.mdl",

		pos = Vector(0, 0.5, 29),

		ang = Angle(0, 0, 180),

	},

	["8x_scope"] =

	{

		model = "models/weapons/darky_m/rust/mod_reddot.mdl",

		pos = Vector(0.148, -3.13, 0.281),

		ang = Angle(0, 0, -90),



		ispos = Vector(-6.106, -2.6, 2.85),

		isang = Vector(0, 0, 0),

		painttype = "screen",

		zoom = 8,

		paint = function(scopetime)

			local scrw, scrh = ScrW(), ScrH()



			local XOffset = scrw * 0.5 - scrh * 0.5



			surface.SetDrawColor(0, 0, 0)

			surface.DrawRect(0, 0, XOffset, scrh)



			surface.SetDrawColor(0, 0, 0)

			surface.DrawRect(XOffset + scrh, 0, XOffset, scrh)



			surface.SetDrawColor(255, 255, 255)

			surface.SetMaterial(Scope8xMat)

			surface.DrawTexturedRect(XOffset, 0, scrh, scrh)



			surface.SetDrawColor(0, 0, 0, 255 - (CurTime() - scopetime) * 200)

			surface.DrawRect(0, 0, scrw, scrh)

		end

	},

	["16x_scope"] =

	{

		model = "models/weapons/darky_m/rust/mod_8xScope.mdl",

		pos = Vector(-0.06, -1.354, 3.079),

		ang = Angle(180, 0, -90),



		ispos = Vector(-6.106, -2.6, 2.85),

		isang = Vector(0, 0, 0),

		painttype = "screen",

		zoom = 16,

		paint = function(scopetime)

			local scrw, scrh = ScrW(), ScrH()



			local XOffset = scrw * 0.5 - scrh * 0.5



			surface.SetDrawColor(0, 0, 0)

			surface.DrawRect(0, 0, XOffset, scrh)



			surface.SetDrawColor(0, 0, 0)

			surface.DrawRect(XOffset + scrh, 0, XOffset, scrh)



			surface.SetDrawColor(255, 255, 255)

			surface.SetMaterial(Scope8xMat)

			surface.DrawTexturedRect(XOffset, 0, scrh, scrh)



			surface.SetDrawColor(0, 0, 0, 255 - (CurTime() - scopetime) * 200)

			surface.DrawRect(0, 0, scrw, scrh)

		end

	},

	["flashlight"] = {
    model = "models/weapons/darky_m/rust/mod_flash.mdl", -- или другая модель фонарика
    pos = Vector(-0.08, 2.03, 15.1),
    ang = Angle(0, -90, 180),
    
    -- Функциональность фонарика будет обрабатываться отдельно
    isattachment = true
   }

}