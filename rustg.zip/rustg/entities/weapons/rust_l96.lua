SWEP.Base       = "rust_basegun"

SWEP.WorldModel = "models/weapons/darky_m/rust/w_l96.mdl"

SWEP.ViewModel  = "models/weapons/darky_m/rust/c_l96.mdl"



--

-- Stats

--

SWEP.Damage     = 80

SWEP.RPM        = 35

SWEP.AimCone    = 0

SWEP.Capacity   = 5

SWEP.ReloadTime = 3

SWEP.DrawTime   = 1



SWEP.Bullets 	= 1



SWEP.Ammo       = "ammo.rifle"



--

-- Ironsights

--

SWEP.IronSightPos   = Vector(-4.699, -1.5, 3.319)

SWEP.IronSightAng   = Vector(-0.981, 0.15, 0)

SWEP.IronSightTime  = 0.075

SWEP.IronSightFOV   = 40



--

-- Sounds

--

SWEP.ShootSound		= "weapons/l96-attack-1.mp3"

SWEP.SilencedSound	= "darky_rust.bolt-rifle-attack-silenced"



--

-- Recoil

--



SWEP.RecoilLerp = 3

SWEP.RecoilTable = {

	Angle(-0.2, 0.05, 0),

}



local HoloMat = Material("models/darky_m/rust_weapons/mods/holosight.reticle.standard.png")

local Scope8xMat = Material("models/darky_m/rust_weapons/mods/8x_crosshair.png")

SWEP.AttachmentData =

{

	["holosight"] = {

		model = "models/weapons/darky_m/rust/mod_holo.mdl",

		pos = Vector(-0.125, -4.0, 10.0),

		ang = Angle(180, -90, 0),



		ispos = Vector(-3.41, 0, 1.6),

		isang = Vector(-0.09, 0, 1.275),

		scale = 0.00375,

		paint = function()

			surface.SetDrawColor(180, 0, 0)

			surface.SetMaterial(HoloMat)

			surface.DrawTexturedRect(1130, -75, 140, 140)

		end

	},

	["silencer"] = {

		model = "models/weapons/darky_m/rust/mod_silencer.mdl",

		pos = Vector(-0.05, -3, 41.0),

		ang = Angle(0, 0, 180)

	},

	["8x_scope"] =

	{

		model = "models/weapons/darky_m/rust/mod_8xScope.mdl",

		pos = Vector(0, -4.0, 6.8),

		ang = Angle(180, 0, -90),



		ispos = Vector(-4.523, -1.5, 1.696),

		isang = Vector(0.22, 1.07, 0),

		painttype = "screen",

		zoom = 8,

		paint = function(scopetime)

			local scrw, scrh = ScrW(), ScrH()



			local XOffset = scrw * 0.5 - scrh * 0.5



			surface.SetDrawColor(0, 0, 0)

			surface.DrawRect(0, 0, XOffset, scrh)



			surface.SetDrawColor(0, 0, 0)

			surface.DrawRect(XOffset + scrh, 0, XOffset, scrh)



			surface.SetDrawColor(255, 255, 255)

			surface.SetMaterial(Scope8xMat)

			surface.DrawTexturedRect(XOffset, 0, scrh, scrh)



			surface.SetDrawColor(0, 0, 0, 255 - (CurTime() - scopetime) * 200)

			surface.DrawRect(0, 0, scrw, scrh)

		end

	},

	["16x_scope"] =

	{

		model = "models/weapons/darky_m/rust/mod_8xScope.mdl",

		pos = Vector(0, -4.0, 6.8),

		ang = Angle(180, 0, -90),



		ispos = Vector(-4.523, -1.5, 1.696),

		isang = Vector(0.22, 1.07, 0),

		painttype = "screen",

		zoom = 16,

		paint = function(scopetime)

			local scrw, scrh = ScrW(), ScrH()



			local XOffset = scrw * 0.5 - scrh * 0.5



			surface.SetDrawColor(0, 0, 0)

			surface.DrawRect(0, 0, XOffset, scrh)



			surface.SetDrawColor(0, 0, 0)

			surface.DrawRect(XOffset + scrh, 0, XOffset, scrh)



			surface.SetDrawColor(255, 255, 255)

			surface.SetMaterial(Scope8xMat)

			surface.DrawTexturedRect(XOffset, 0, scrh, scrh)



			surface.SetDrawColor(0, 0, 0, 255 - (CurTime() - scopetime) * 200)

			surface.DrawRect(0, 0, scrw, scrh)

		end

	}

}