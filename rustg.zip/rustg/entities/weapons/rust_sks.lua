SWEP.Base       = "rust_basegun"

SWEP.WorldModel = "models/weapons/tfa_ins2/w_sks.mdl"

SWEP.ViewModel  = "models/weapons/tfa_ins2/c_sks.mdl"



SWEP.Primary.Automatic = false



--

-- Stats

--

SWEP.Damage     = 48

SWEP.RPM        = 500

SWEP.AimCone    = 0.05

SWEP.Capacity   = 15

SWEP.ReloadTime = 3.0

SWEP.DrawTime   = 1.6



SWEP.Ammo       = "ammo.rifle"



SWEP.HoldType 	= "ar2"



--

-- Ironsights

--

SWEP.IronSightPos = Vector(-2.89, 0, 2.)

SWEP.IronSightAng = Angle(0.1, 1.12, 0)


SWEP.IronSightTime  = 0.075

SWEP.IronSightFOV   = 30



--

-- Sounds

--

SWEP.ShootSound		= "TFA_INS2.SKS.1"

SWEP.SilencedSound	= "darky_rust.sar_attack-silenced"



--

-- Recoil

--



SWEP.RecoilLerp = 0.06

SWEP.RecoilTable = {
    Angle(-1.5, 0.2, 0),   -- Первые выстрелы, небольшая отдача вверх и вправо
    Angle(-2.0, -0.1, 0),  -- Слегка вправо влево
    Angle(-2.5, 0.15, 0),
    Angle(-3.0, -0.2, 0),
    Angle(-3.5, 0.1, 0),
    Angle(-4.0, 0, 0),     -- Максимальная отдача строго вверх
}



local HoloMat = Material("models/darky_m/rust_weapons/mods/holosight.reticle.standard.png")

local Scope8xMat = Material("models/darky_m/rust_weapons/mods/8x_crosshair.png")

SWEP.AttachmentData =

{

	["holosight"] = {

		model = "models/weapons/darky_m/rust/mod_holo.mdl",

		pos = Vector(-0.15, -2.5, -0.2),

		ang = Angle(180, -90, 0),



		ispos = Vector(-5.19, -2.6, 2.785),

		isang = Angle(-1.09, 0, 0),

		painttype = "3d2d",

		scale = 0.0085,

		paint = function()

			surface.SetDrawColor(180, 0, 0)

			surface.SetMaterial(HoloMat)

			surface.DrawTexturedRect(279, -67, 140, 140)

		end

	},

	["silencer"] = {

		model = "models/weapons/darky_m/rust/mod_silencer.mdl",

		pos = Vector(0, -1.4, 31.5),

		ang = Angle(0, 0, 180),

		modelscale = 0.9,

	},

	["8x_scope"] =

	{

		model = "models/weapons/darky_m/rust/mod_reddot.mdl",

		pos = Vector(0.25, -4.0, 5-1),

		ang = Angle(180, 0, -90),



		ispos = Vector(-6.106, -2.6, 2.85),

		isang = Vector(0, 0, 0),

		painttype = "screen",

		zoom = 8,

		paint = function(scopetime)

			local scrw, scrh = ScrW(), ScrH()



			local XOffset = scrw * 0.5 - scrh * 0.5



			surface.SetDrawColor(0, 0, 0)

			surface.DrawRect(0, 0, XOffset, scrh)



			surface.SetDrawColor(0, 0, 0)

			surface.DrawRect(XOffset + scrh, 0, XOffset, scrh)



			surface.SetDrawColor(255, 255, 255)

			surface.SetMaterial(Scope8xMat)

			surface.DrawTexturedRect(XOffset, 0, scrh, scrh)



			surface.SetDrawColor(0, 0, 0, 255 - (CurTime() - scopetime) * 200)

			surface.DrawRect(0, 0, scrw, scrh)

		end

	},

	["16x_scope"] =

	{

		model = "models/weapons/darky_m/rust/mod_8xScope.mdl",

		pos = Vector(0.005, -2.2, 6.2-1),

		ang = Angle(180, 0, -90),



		ispos = Vector(-6.106, -2.6, 2.85),

		isang = Vector(0, 0, 0),

		painttype = "screen",

		zoom = 16,

		paint = function(scopetime)

			local scrw, scrh = ScrW(), ScrH()



			local XOffset = scrw * 0.5 - scrh * 0.5



			surface.SetDrawColor(0, 0, 0)

			surface.DrawRect(0, 0, XOffset, scrh)



			surface.SetDrawColor(0, 0, 0)

			surface.DrawRect(XOffset + scrh, 0, XOffset, scrh)



			surface.SetDrawColor(255, 255, 255)

			surface.SetMaterial(Scope8xMat)

			surface.DrawTexturedRect(XOffset, 0, scrh, scrh)



			surface.SetDrawColor(0, 0, 0, 255 - (CurTime() - scopetime) * 200)

			surface.DrawRect(0, 0, scrw, scrh)

		end

	}

}