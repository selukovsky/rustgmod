SWEP.Base       = "rust_basegun"

SWEP.WorldModel = "models/hdtf/weapons/w_hl2_pistol.mdl"

SWEP.ViewModel  = "models/hdtf/weapons/c_hl2_pistol.mdl"



SWEP.Primary.Automatic = false



--

-- Stats

--

SWEP.Damage     = 35

SWEP.RPM        = 400

SWEP.AimCone    = 0.12

SWEP.Capacity   = 8

SWEP.ReloadTime = 1.8

SWEP.DrawTime   = 0.5



SWEP.Ammo       = "ammo.pistol"



SWEP.HoldType 	= "pistol"



--

-- Ironsights

--

SWEP.IronSightPos = Vector(-3.06, 0, 2.44)
SWEP.IronSightAng = Angle(0.029, 0.039, 0)

SWEP.IronSightTime  = 0.075

SWEP.IronSightFOV   = 35



--

-- Sounds

--

SWEP.ShootSound		= "HDTF_WeaponHL2Pistol.Fire"

SWEP.SilencedSound	= "darky_rust.semi-pistol-attack-silenced"



--

-- Recoil

--

SWEP.RecoilAmount   = 1.5

SWEP.RecoilTable = {

	Angle(-2.5, 0, 0),

}