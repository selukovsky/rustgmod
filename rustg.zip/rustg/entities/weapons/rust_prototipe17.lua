SWEP.Base       = "rust_basegun"

SWEP.WorldModel = "models/weapons/bnw_eder22/w_eder22.mdl"

SWEP.ViewModel  = "models/weapons/bnw_eder22/c_eder22.mdl"



SWEP.Primary.Automatic = true



--

-- Stats

--

SWEP.Damage     = 28

SWEP.RPM        = 400

SWEP.AimCone    = 0.25

SWEP.Capacity   = 17

SWEP.ReloadTime = 2.0

SWEP.DrawTime   = 0.5



SWEP.Ammo       = "ammo.pistol"



SWEP.HoldType 	= "pistol"



--

-- Ironsights


SWEP.IronSightPos = Vector(-2.34, -3.863, 1.379)
SWEP.IronSightAng = Vector(0.2, -0.201, 0)

SWEP.IronSightTime  = 0.075

SWEP.IronSightFOV   = 20



--

-- Sounds

--

SWEP.ShootSound		= "weapons/glock_fire.wav"

SWEP.SilencedSound	= "darky_rust.semi-pistol-attack-silenced"



--

-- Recoil

--

SWEP.RecoilAmount   = 1.5

SWEP.RecoilTable = {

	Angle(-2.5, 0, 0),

}



-- Функция для обработки стрельбы очередью

