local BaseClass = baseclass.Get("rust_base")
SWEP.Base = "rust_base"
SWEP.WorldModel = "models/weapons/darky_m/rust/w_bow.mdl"
SWEP.ViewModel = "models/weapons/darky_m/rust/c_bow.mdl"

-- Сделаем "обойму" на 1 патрон (стрелу)
SWEP.Primary = SWEP.Primary or {}
SWEP.Primary.ClipSize = 1
SWEP.Primary.DefaultClip = 0

SWEP.ShootSound = "darky_rust.bow-attack-1"

function SWEP:PrimaryAttack()
    local pl = self:GetOwner()
    if not IsValid(pl) then return end

    -- Только если в обойме есть стрела
    if (self:Clip1() or 0) <= 0 then
        -- можно тут проиграть звук "пусто"
        return
    end

    if CurTime() < (self.NextAttack or 0) then return end
    self.NextAttack = CurTime() + 1.35

    self:PlayAnimation("PrimaryAttack")

    self:EmitSound(self.ShootSound, 90, 100, 1, CHAN_WEAPON)

    -- Серверная часть — создаём снаряд
    if SERVER then
        local ang = pl:GetAimVector():Angle()
        local ent = ents.Create("rust_projectile")
        if not IsValid(ent) then return end
        ent:SetModel("models/weapons/darky_m/rust/bone_arrow.mdl")
        ent:SetOwner(pl)
        ent:SetPos(pl:GetShootPos())
        ent:SetAngles(ang + Angle(90, 0, 0))
        ent:Spawn()
        local phys = ent:GetPhysicsObject()
        if IsValid(phys) then
            phys:SetMass(0.75)
            phys:SetDamping(-15, 1)
        end
        ent:Activate()
        ent:Throw(ang:Forward(), 25000)

        ent.PhysicsCollide = function(me, coldata, collider)
            if me.Damaged then return end
            me.Damaged = true
            ent:FireBullets({
                Attacker = pl,
                Damage = 35,
                Tracer = 0,
                Src = coldata.HitPos,
                Dir = coldata.HitNormal,
                Callback = function(attacker, tr, dmg) dmg:SetDamageType(DMG_BULLET) end
            })
            me:Remove()
        end

        util.SpriteTrail(ent, 0, Color(255, 255, 255), false, 12, 0, 0.15, 1 / 12 * 0.5, "trails/laser")
    end

    -- потратим стрелу из обоймы (сервер сетает сетью, клиенты увидят)
    if SERVER then
        self:SetClip1(math.max(0, (self:Clip1() or 1) - 1))
        self.Fired = true
        self.Charged = false
    end
end

function SWEP:Think()
    local pl = self:GetOwner()
    if not IsValid(pl) then return end

    if pl:KeyDown(IN_ATTACK2) then
        -- Если уже заряжено/только что стрелял или в обойме уже есть стрела — ничего не делаем
        if self.Charged or self.Fired then return end
        if (self:Clip1() or 0) >= 1 then return end

        -- Проверяем, есть ли стрелы в инвентаре на сервере и удаляем одну
        if SERVER then
            -- защита: метод RemoveItem может отсутствовать в вашей системе — проверим
            if type(pl.RemoveItem) ~= "function" then
                print("[BOW] WARNING: pl:RemoveItem is nil — inventory API not found on server!")
                -- Если API отсутствует, просто не заряжаем (альтернатива: импортировать нужный модуль)
                return
            end

            if not pl:HasItem("arrow.wooden", 1) then
                -- нет стрел в инвентаре — не заряжаем
                return
            end

            local removed = pl:RemoveItem("arrow.wooden", 1)
            if not removed then
                print("[BOW] Failed to remove arrow from player's inventory")
                return
            end

            -- перенесли стрелу в обойму
            self:SetClip1(1)
        end

        -- воспроизводим анимацию и ставим флаги (анимация появится и у клиента)
        self:PlayAnimation("Deploy")
        self.Charged = true
        self.NextAttack = CurTime() + 1.35
    else
        self.Fired = false
        if self.Charged and CurTime() > self.NextAttack then
            self:SendWeaponAnim(ACT_VM_UNDEPLOY)
            self.Charged = false
        end
    end
end


function SWEP:Deploy()
    //self:PlayAnimation("Deploy")
end