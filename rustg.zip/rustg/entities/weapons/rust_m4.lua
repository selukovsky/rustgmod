SWEP.Base       = "rust_baseshotgun"

SWEP.WorldModel = "models/weapons/w_tti_m1014.mdl"

SWEP.ViewModel  = "models/weapons/c_tti_m1014_2a.mdl"



--

-- Stats

--

SWEP.Damage     = 25

SWEP.RPM        = 300

SWEP.AimCone    = 0.1

SWEP.Capacity   = 6

SWEP.ReloadTime = 4.9

SWEP.DrawTime   = 1



SWEP.Bullets 	= 16



SWEP.Ammo       = "ammo.shotgun"



SWEP.HoldType 	= "shotgun"



--

-- Ironsights

--
SWEP.IronSightPos = Vector(-1.38, 0, 1.85)

SWEP.IronSightAng = Angle(-0.2, 0.5, 0)

SWEP.IronSightTime  = 0.075

SWEP.IronSightFOV   = 32



--

-- Sounds

--

SWEP.ShootSound		= "TTI_M1014FIRE1"

SWEP.SilencedSound	= "darky_rust.spas12-attack-silenced"



--

-- Recoil

--

SWEP.RecoilAmount   = 0.1

SWEP.RecoilTable = {

	Angle(-20, -2, 0),

}