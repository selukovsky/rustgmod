SWEP.Base       = "rust_basegun"

SWEP.WorldModel = "models/weapons/darky_m/rust/w_revolver.mdl"

SWEP.ViewModel  = "models/weapons/darky_m/rust/c_revolver.mdl"



SWEP.Primary.Automatic = false



--

-- Stats

--

SWEP.Damage     = 35

SWEP.RPM        = 343

SWEP.AimCone    = 0.075

SWEP.Capacity   = 8

SWEP.ReloadTime = 3.4

SWEP.DrawTime   = 0.5



SWEP.Ammo       = "ammo.pistol"



SWEP.HoldType 	= "pistol"



--

-- Ironsights

--

SWEP.IronSightPos 	= Vector(-3.33, 0, 0.875)

SWEP.IronSightAng 	= Vector(1.129, 0.035, 0)

SWEP.IronSightTime  = 0.075

SWEP.IronSightFOV   = 28



--

-- Sounds

--

SWEP.ShootSound		= "darky_rust.revolver-attack"

SWEP.SilencedSound	= "darky_rust.silenced_shot" 



--

-- Recoil

--



SWEP.RecoilLerp = 0.03

SWEP.RecoilShootReturnTime = 0.05



SWEP.RecoilTable = {
	Angle(-2.5 * 10, 0.4 * 2),
}



local HoloMat = Material("models/darky_m/rust_weapons/mods/holosight.reticle.standard.png")

SWEP.AttachmentData =

{

	["silencer"] = {

		model = "models/weapons/darky_m/rust/mod_silencer.mdl",

		pos = Vector(-2.2, -2.15, 10),

		ang = Angle(0, 90, 180),

		bone = "barrel",

		modelscale = 0.8,

	}

}