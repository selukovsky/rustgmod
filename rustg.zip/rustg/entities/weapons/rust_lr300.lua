SWEP.Base       = "rust_basegun"

SWEP.WorldModel = "models/weapons/darky_m/rust/w_lr300.mdl"

SWEP.ViewModel  = "models/weapons/darky_m/rust/c_lr300.mdl"

SWEP.ViewModelFOV = 55

--

-- Stats

--

SWEP.Damage     = 40

SWEP.RPM        = 500

SWEP.AimCone    = 0.1

SWEP.Capacity   = 30

SWEP.ReloadTime = 4

SWEP.DrawTime   = 2



SWEP.Ammo       = "ammo.rifle"



SWEP.HoldType 	= "ar2"



--

-- Ironsights

--

SWEP.IronSightPos   = Vector(-4.425, 0, 1.05)

SWEP.IronSightAng   = Vector(0.37, 0.05, 0.1)

SWEP.IronSightTime  = 0.075

SWEP.IronSightFOV   = 35



--

-- Sounds

--

SWEP.ShootSound		= "darky_rust.lr300-attack"

SWEP.SilencedSound	= "darky_rust.lr300-attack-silenced"



--

-- Recoil

--

SWEP.RecoilAmount   = 0.3

SWEP.RecoilTable = {
	Angle(-2.052616 * 1, -0.000000 * 1.5),
	Angle(-2.052616 * 1, -0.000000 * 1.5),
	Angle(-1.897695 * 1, -0.055584 * 1.5),
	Angle(-1.863222 * 1, 0.247226 * 1.5),
	Angle(-1.940010 * 1, 0.243871 * 1.5),
	Angle(-1.966751 * 1, -0.095727 * 1.5),
	Angle(-1.885520 * 1, -0.107707 * 1.5),
	Angle(-1.946722 * 1, -0.324888 * 1.5),
	Angle(-1.880342 * 1, 0.181137 * 1.5),
	Angle(-1.820107 * 1, -0.162399 * 1.5),
	Angle(-1.994940 * 1, 0.292076 * 1.5),
	Angle(-1.837156 * 1, -0.064575 * 1.5),
	Angle(-1.887880 * 1, 0.126699 * 1.5),
	Angle(-1.832799 * 1, 0.090568 * 1.5),
	Angle(-1.807480 * 1, -0.065338 * 1.5),
	Angle(-1.705888 * 1, 0.197343 * 1.5),
	Angle(-1.785949 * 1, 0.216561 * 1.5),
	Angle(-1.806371 * 1, -0.042567 * 1.5),
	Angle(-1.757623 * 1, 0.065534 * 1.5),
	Angle(-1.904010 * 1, -0.086380 * 1.5),
	Angle(-1.969296 * 1, 0.097326 * 1.5),
	Angle(-1.850288 * 1, 0.213034 * 1.5),
	Angle(-1.730867 * 1, 0.017790 * 1.5),
	Angle(-1.783686 * 1, 0.045577 * 1.5),
	Angle(-1.886260 * 1, 0.053309 * 1.5),
	Angle(-1.793076 * 1, -0.055072 * 1.5),
	Angle(-1.921906 * 1, 0.091874 * 1.5),
	Angle(-1.796160 * 1, 0.033719 * 1.5),
	Angle(-1.993952 * 1, -0.266464 * 1.5),
	Angle(-1.921165 * 1, -0.079090 * 1.5),
}

local HoloMat = Material("models/darky_m/rust_weapons/mods/holosight.reticle.standard.png")

local Scope8xMat = Material("models/darky_m/rust_weapons/mods/8x_crosshair.png")
SWEP.AttachmentData = {
	["simple_handmade_sight"] = {
		model = "models/weapons/darky_m/rust/mod_ms_holosight.mdl",
		pos = Vector(0.03, -4.4, 0.2),
		ang = Angle(180, -90, -90),
		modelscale = 1.15,
		bone = "main",

		ispos = Vector(-4.415, 0, 1.12),
		isang = Angle(0, 0, 0),
		painttype = "3d2d",
		scale = 0.01,
		paintpos = Vector(0.519, 0, 0),
		paintang = Angle(-90, 0, 90),
		paint = function()
			surface.SetDrawColor(0, 0, 0)
			surface.SetMaterial(SIMPLESIGHT_MATERIAL)
			surface.DrawTexturedRect(-70, -70, 140, 140)
		end
	},

	["holosight"] = {
		model = "models/weapons/darky_m/rust/mod_holo.mdl",
		pos = Vector(-0.05, -4.0, 0.2),
		ang = Angle(180, -90, 0),
		modelscale = 0.9,
		bone = "main",

		ispos = Vector(-4.372, 0, 1.572),
		isang = Angle(0, 0, 0),
		painttype = "3d2d",
		scale = 0.01,
		paintpos = Vector(0.47, -0.123, 0.3),
		paintang = Angle(0, -90, 0),
		paint = function()
			surface.SetDrawColor(255, 0, 0)
			surface.SetMaterial(HoloMat)
			surface.DrawTexturedRect(-40, -40, 80, 80)
		end
	},

	["silencer"] = {
		model = "models/weapons/darky_m/rust/mod_silencer.mdl",
		pos = Vector(0, -1.55, 26.2),
		ang = Angle(0, 0, 180),
		bone = "main"
	},

	["flashlight"] = {
		model = "models/weapons/darky_m/rust/mod_flash.mdl",
		pos = Vector(0, 0.9, 15),
		ang = Angle(0, -90, 180),
		modelscale = 1.1,
		bone = "main"
	},

	["8x_zoom_scope"] = {
		model = "models/weapons/darky_m/rust/mod_reddot.mdl",
		pos = Vector(0.3, -4.95, 0),
		ang = Angle(0, 0, -90),
		bone = "main",

		ispos = Vector(-6.106, -2.6, 2.85), -- Используем стандартные позиции из примера
		isang = Vector(0, 0, 0),
		painttype = "screen",
		zoom = 8,
		paint = function(scopetime)
			local scrw, scrh = ScrW(), ScrH()
			local XOffset = scrw * 0.5 - scrh * 0.5

			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(0, 0, XOffset, scrh)

			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(XOffset + scrh, 0, XOffset, scrh)

			surface.SetDrawColor(255, 255, 255)
			surface.SetMaterial(Scope8xMat)
			surface.DrawTexturedRect(XOffset, 0, scrh, scrh)

			surface.SetDrawColor(0, 0, 0, 255 - (CurTime() - scopetime) * 200)
			surface.DrawRect(0, 0, scrw, scrh)
		end
	},

	["16x_zoom_scope"] = {
		model = "models/weapons/darky_m/rust/mod_8xScope.mdl",
		pos = Vector(0.04, -3.0, 2.3),
		ang = Angle(180, 0, -90),
		bone = "main",

		ispos = Vector(-6.106, -2.6, 2.85), -- Используем стандартные позиции из примера
		isang = Vector(0, 0, 0),
		painttype = "screen",
		zoom = 16,
		paint = function(scopetime)
			local scrw, scrh = ScrW(), ScrH()
			local XOffset = scrw * 0.5 - scrh * 0.5

			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(0, 0, XOffset, scrh)

			surface.SetDrawColor(0, 0, 0)
			surface.DrawRect(XOffset + scrh, 0, XOffset, scrh)

			surface.SetDrawColor(255, 255, 255)
			surface.SetMaterial(Scope8xMat)
			surface.DrawTexturedRect(XOffset, 0, scrh, scrh)

			surface.SetDrawColor(0, 0, 0, 255 - (CurTime() - scopetime) * 200)
			surface.DrawRect(0, 0, scrw, scrh)
		end
	},

	["weapon_lasersight"] = {
		model = "models/weapons/darky_m/rust/w_mod_laser.mdl",
		pos = Vector(0.5, 0, 0),
		ang = Angle(-90, 0, 0),
		modelscale = 1.0,
		bone = "main"
	},

	["muzzle_brake"] = {
		model = "models/weapons/darky_m/rust/mod_muzzlebrake.mdl",
		pos = Vector(0, -1.55, 22.2),
		ang = Angle(0, 90, -90),
		modelscale = 2.5,
		bone = "main"
	},

	["muzzle_boost"] = {
		model = "models/weapons/darky_m/rust/mod_muzzleboost.mdl",
		pos = Vector(0, -1.55, 22.2),
		ang = Angle(0, 90, -90),
		modelscale = 2.5,
		bone = "main"
	}
}