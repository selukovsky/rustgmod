

include("shared.lua")



SWEP.VMPos = Vector()

SWEP.VMAng = Vector()



SWEP.DownPos = Vector(0, 0, -4)

