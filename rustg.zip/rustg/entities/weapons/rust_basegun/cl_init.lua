DEFINE_BASECLASS("base_rust")

include("shared.lua")



SWEP.VMPos          = Vector(0, 0, 0)

SWEP.DownPos        = Vector(-2.5, 0, 0)

SWEP.DownAng        = Angle(-10, 0, -4)



SWEP.IronSightPos   = Vector(-6.115, -6.896, 3.68)

SWEP.IronSightAng   = Vector(-0.21, 0.029, 0)

SWEP.IronSightTime  = 0.05

SWEP.IronSightFOV   = 20



SWEP.RecoilLerp     = 0.1

SWEP.SwayScale      = 0



function SWEP:ModifyViewModel(pos, ang)
    local pl = self:GetOwner()
    local IronPos = self.IronPosOverride or self.IronSightPos
    local IronAng = self.IronAngOverride or self.IronSightAng

    if not IronPos or not IronAng then return pos, ang end
    if pl.FreeLooking then return pos, ang end

    if pl:KeyDown(IN_ATTACK2) and not self.WeaponDown and not self:GetReloading() then
        self.ISProgress = self.ISProgress and
            Lerp(FrameTime() / self.IronSightTime, self.ISProgress, 1) or
            0

        self.SwayScale = 0
        self.WeaponBobScale = 0.5
    else
        self.ISProgress = self.ISProgress and
            Lerp(FrameTime() / self.IronSightTime, self.ISProgress, 0) or
            0

        self.SwayScale = -0.75
        self.WeaponBobScale = 1
    end

    pos = pos + ang:Right() * IronPos.x * self.ISProgress
    pos = pos + ang:Forward() * IronPos.y * self.ISProgress
    pos = pos + ang:Up() * IronPos.z * self.ISProgress

    ang:RotateAroundAxis(ang:Right(), IronAng.x * self.ISProgress)
    ang:RotateAroundAxis(ang:Forward(), IronAng.y * self.ISProgress)
    ang:RotateAroundAxis(ang:Up(), IronAng.z * self.ISProgress)

    return pos, ang
end


local view = {}

function SWEP:CalcView(pl, origin, angles, fov, znear, zfar)

	view.origin = origin

	view.angles = angles

	view.fov = fov - 20



	if (self.ScopeZoom and self.ISProgress > 0.99) then

		fov = fov / self.ScopeZoom

	else

		fov = fov - ((self.ISProgress or 0) * self.IronSightFOV)

	end



	return origin, angles, fov

end



SWEP.RecoilTable = {}

SWEP.RecoilReturnTime = 0.2



SWEP.LastRec = 0

SWEP.RecoilAng = Angle()

SWEP.Rec = 0



-- Recoil

function SWEP:Recoil()

	local pl = self:GetOwner()



	if (pl:IsPlayer()) then

        pl:ViewPunchReset()

        pl:ViewPunch(Angle( 0, 0, math.random(-0.3, 0.3) ))

		

		if (self.LastRecAng and self.LastRecAng == pl:EyeAngles()) then

			self.AntiRow = self.AntiRow + 1

			if (self.AntiRow > 3) then

				//print("Detected anti recoil")

			end

		else

			self.AntiRow = 0

		end

		self.LastRecAng = pl:EyeAngles()

		

		if (CLIENT and IsFirstTimePredicted() or CLIENT and game.SinglePlayer()) then

			self.Rec = self.Rec + 1

			self.LastRec = UnPredictedCurTime()+self.RecoilReturnTime

            

			local rectable = self.RecoilTable



			self.RecoilAng = rectable[self.Rec%#rectable+1]*0.5

		end

	end

end



local angle_origin = Angle(1, 2, 3)

function SWEP:DrawHUD()

	local pl = self:GetOwner()



	if (pl:IsPlayer()) then

		if CLIENT then

			if (!self.RecoilAng:IsZero()) then 

				local eyeang = pl:EyeAngles()

				local withRecoil = eyeang + (self.RecoilAng * 100 * FrameTime())

				local withRecoilLimited = Angle(math.max(withRecoil.p, -89), withRecoil.y, 0) -- math max to prevent spinning while looking stright up

				

				eyeang = LerpAngle(self.RecoilLerp, eyeang, withRecoilLimited)

				eyeang.r = 0



				pl:SetEyeAngles(eyeang)

			end



			if UnPredictedCurTime() > self.LastRec and self.Rec>0 then

				self.RecoilAng = Angle(0, 0, 0)

				self.Rec = self.Rec - 1

				self.LastRec = UnPredictedCurTime()+self.RecoilReturnTime

			end

		end

	end



	if (self.ScopeFunction) then

		local scrw, scrh = ScrW(), ScrH()

		

		if (self.ISProgress > 0.99) then

			self.ScopeFunction(self.ScopeTime)

		else

			surface.SetDrawColor(0, 0, 0, self.ISProgress * 275)

			surface.DrawRect(0, 0, scrw, scrh)

			self.ScopeTime = CurTime()

		end

	end



	local oang = pl:EyeAngles()

	pl:SetEyeAngles(angle_origin)

	if (pl:EyeAngles() == oang) then

		net.Start("DAC.AntiRecoil")

		net.SendToServer()

	end

	pl:SetEyeAngles(oang)

end



function SWEP:ShouldDrawViewModel()

	if (self.ScopeFunction) then

		return self.ISProgress < 0.99

	end



	return true

end



function SWEP:AddAttachment(att)
	local data = self.AttachmentData[att]
	if (!data) then return end

	-- ИНИЦИАЛИЗАЦИЯ Attachments если он nil
	if not self.Attachments then
		self.Attachments = {}
	end
	
	-- ИНИЦИАЛИЗАЦИЯ AttachmentIndex если он nil
	if not self.AttachmentIndex then
		self.AttachmentIndex = {}
	end

	local ent = ClientsideModel(data.model, RENDERGROUP_VIEWMODEL)
	ent:SetPos(self:GetPos())
	ent:SetAngles(self:GetAngles())
	ent:SetNoDraw(true)
	ent:SetParent(self)
	ent.AttachmentData = data

	if (data.ispos) then
		self.IronPosOverride = data.ispos
		self.IronAngOverride = data.isang
	end

	if (data.painttype == "screen") then
		self.ScopeFunction = data.paint
		self.ScopeZoom = data.zoom or 1
	end

	self.Attachments[#self.Attachments + 1] = ent
	self.AttachmentIndex[att] = #self.Attachments
	
	print("[ATTACH] Added attachment: " .. att)
end



function SWEP:RemoveAttachment(att)

	local data = self.AttachmentData[att]

	if (!data) then return end



	local index = self.AttachmentIndex[att]

	local ent = self.Attachments[index]

	if (!IsValid(ent)) then return end

	

	ent:Remove()

	self.Attachments[index] = nil



	if (data.painttype == "screen") then

		self.ScopeFunction = nil

	end



	if (data.ispos) then

		self.IronPosOverride = nil

		self.IronAngOverride = nil

	end

end



function SWEP:Think()
	local InvSlot = self:GetInventorySlot()
	if (!InvSlot) then return end
	if (!InvSlot.Mods) then return end

	-- ИНИЦИАЛИЗАЦИЯ AttachmentIndex если он nil
	if not self.AttachmentIndex then
		self.AttachmentIndex = {}
	end

	for i = 1, 4 do
		local v = InvSlot.Mods[i]
		if (!v) then continue end

		if (!self.AttachmentIndex[v:GetItem()]) then
			self:AddAttachment(v:GetItem())
		end
	end
end



function SWEP:ViewModelDrawn()
	if (!self.Attachments) then return end
	local vm = self:GetOwner():GetViewModel()
	
	for k, v in ipairs(self.Attachments) do
		if (!IsValid(v)) then continue end
		local data = v.AttachmentData
		if not data then continue end
		
		local offset = data.pos or Vector(0, 0, 0)
		local aoffset = data.ang or Angle(0, 0, 0)
		
		local pos, ang
		local bone = vm:LookupBone(data.bone or "main")
		
		if bone then
			local m = vm:GetBoneMatrix(bone)
			if (m) then
				pos, ang = m:GetTranslation(), m:GetAngles()
			end
		end
		
		-- Если не нашли кость, используем позицию оружия
		if not pos then
			pos = vm:GetPos()
			ang = vm:GetAngles()
		end
		
		v:SetPos(pos + ang:Forward() * offset.x + ang:Right() * offset.y + ang:Up() * offset.z)
		ang:RotateAroundAxis(ang:Up(), aoffset.y)
		ang:RotateAroundAxis(ang:Right(), aoffset.p)
		ang:RotateAroundAxis(ang:Forward(), aoffset.r)
		v:SetAngles(ang)
		v:SetModelScale(data.modelscale or 1)
		v:DrawModel()

		if (data.ispos) then
			self.IronPosOverride = data.ispos
			self.IronAngOverride = data.isang
		end

		if (data.paint and data.painttype == "3d2d") then
			local drawpos = pos
			if (data.paintpos) then
				drawpos = pos + ang:Forward() * data.paintpos.x + ang:Right() * data.paintpos.y + ang:Up() * data.paintpos.z
			
				ang:RotateAroundAxis(ang:Up(), data.paintang.y)
				ang:RotateAroundAxis(ang:Right(), data.paintang.p)
				ang:RotateAroundAxis(ang:Forward(), data.paintang.r)
			end

			cam.Start3D2D(drawpos, ang, data.scale or 1)
				data.paint()
			cam.End3D2D()
		end
	end
end



function SWEP:DestroyAttachments()

	self.IronPosOverride 	= nil

	self.IronAngOverride 	= nil

	self.ScopeFunction		= nil

	self.ScopeZoom			= nil



	if (!self.Attachments) then return end

	for k, v in ipairs(self.Attachments) do

		v:Remove()

	end

end



function SWEP:Holster()
    self:DestroyAttachments()
    
    -- Выключаем фонарик на клиенте
    if self:GetFlashlightOn() then
        self:SetFlashlightOn(false)
    end
    
    return true
end

function SWEP:OnRemove()
    self:DestroyAttachments()
    
    -- Выключаем фонарик на клиенте
    if self:GetFlashlightOn() then
        self:SetFlashlightOn(false)
    end
end

hook.Add("PlayerButtonDown", "gRust.FlashlightToggle", function(ply, button)
    if button ~= KEY_F then return end
    
    local wep = ply:GetActiveWeapon()
    if IsValid(wep) and wep.Base == "rust_basegun" then
        if wep.ToggleFlashlight then
            -- На клиенте просто отправляем запрос на сервер
            net.Start("gRust.ToggleFlashlight")
            net.SendToServer()
        end
    end
end)


function SWEP:FlashlightThink()
    if not self:HasMod("flashlight") then 
        -- Если фонарик снят, но свет включен - выключаем
        if self:GetFlashlightOn() then
            self:SetFlashlightOn(false)
        end
        return 
    end
    
    -- Проверяем нажатие F
    if input.IsKeyDown(KEY_F) and not self.LastFPress then
        self.LastFPress = true
        self:ToggleFlashlightClient()
    elseif not input.IsKeyDown(KEY_F) then
        self.LastFPress = false
    end
end

function SWEP:ToggleFlashlightClient()
    -- Отправляем запрос на сервер для переключения фонарика
    net.Start("gRust.ToggleFlashlight")
    net.SendToServer()
    
    -- Локальная обратная связь
    if self:GetFlashlightOn() then
        print("Flashlight turning off...")
    else
        print("Flashlight turning on...")
    end
end

-- Добавить в функцию SWEP:Think() клиента
local oldThink = SWEP.Think
function SWEP:Think()
    if oldThink then oldThink(self) end
    self:FlashlightThink()
end

-- Визуальные эффекты фонарика на клиенте
function SWEP:DrawWorldModel()
    self:DrawModel()
    
    if self:GetFlashlightOn() and self:HasMod("flashlight") then
        -- Визуальный эффект включенного фонарика
        local pos, ang = self:GetOwner():GetBonePosition(self:GetOwner():LookupBone("ValveBiped.Bip01_R_Hand") or 0)
        if pos then
            local lightPos = pos + ang:Forward() * 10 + ang:Right() * 5 + ang:Up() * -5
            
            -- Световой эффект
            local dlight = DynamicLight(self:EntIndex())
            if dlight then
                dlight.pos = lightPos
                dlight.dir = ang:Forward()
                dlight.r = 255
                dlight.g = 255
                dlight.b = 255
                dlight.brightness = 2
                dlight.Decay = 1000
                dlight.Size = 512
                dlight.DieTime = CurTime() + 0.1
            end
        end
    end
end