DEFINE_BASECLASS("rust_base")

SWEP.Base   = "rust_base"

SWEP.Primary.Automatic = true

--
-- Stats
--

SWEP.Damage     = 50
SWEP.RPM        = 450
SWEP.AimCone    = 0.2
SWEP.Capacity   = 30
SWEP.ReloadTime = 4.4
SWEP.DrawTime   = 1

SWEP.Bullets    = 1
SWEP.Ammo       = "ammo.rifle"

--
-- Effects
--

SWEP.MuzzleEffect   = "CS_MuzzleFlash"
SWEP.ShellEject     = "EjectBrass_762Nato"

function SWEP:SetupDataTables()
    BaseClass.SetupDataTables(self)
    self:NetworkVar("Bool", 0, "Reloading")
    self:NetworkVar("Bool", 1, "FlashlightOn")
    self:NetworkVar("String", 0, "CurrentAmmoType")
end

function SWEP:DoEffects(ent)
    --
    -- Shell Eject
    --

    local Shell = self.ShellEject
    if (Shell) then
        local Attach = ent:GetAttachment(2)
        if (!Attach) then return end
    
        local Effect = EffectData()
        Effect:SetOrigin(Attach.Pos)
        Effect:SetAngles(Attach.Ang)
        Effect:SetEntity(ent)
        Effect:SetFlags(50)
        Effect:SetAttachment(2)
        util.Effect(Shell, Effect)
    end

    --
    -- Muzzle Flash
    --

    local Flash = self.MuzzleEffect
    if (Flash) then
        local Attach = ent:GetAttachment(1)
        if (!Attach) then return end

        local Effect = EffectData()
        Effect:SetOrigin(Attach.Pos)
        Effect:SetAngles(Attach.Ang)
        Effect:SetEntity(ent)
        Effect:SetFlags(50)
        Effect:SetAttachment(1)
        util.Effect(Flash, Effect)
    end
end

SWEP.MaxTrajSteps = 50
SWEP.TrajStepSpeed = 0.1 -- seconds per step
SWEP.TrajStraightStep = 1250 -- straignt line step (no ballistics & damage drop)
SWEP.TrajStepLength = 750 -- every step legth after straight one
SWEP.TrajDropPerStep = 4 -- multiplier of bullet drop and damage drop on every step

function SWEP:ShootBullet(damage, aimcone)
    local pl = self:GetOwner()
    
    -- Модификация урона в зависимости от типа патронов
    local modifiedDamage = damage
    local currentAmmoType = self:GetCurrentAmmoType() or self.Ammo
    
    if currentAmmoType:EndsWith(".incendiary") then
        modifiedDamage = damage + 7 -- +7 урона для зажигательных
    end

    local bullet = {}
    bullet.Num      = self.Bullets
    bullet.Src      = pl:GetShootPos()          -- Source
    bullet.Dir      = pl:GetAimVector()         -- Dir of bullet
    bullet.Spread   = Vector(aimcone, aimcone, 0)       -- Aim Cone
    bullet.Tracer   = 5                     -- Show a tracer on every x bullets
    bullet.Force    = 1                     -- Amount of force to give to phys objects
    bullet.Damage   = modifiedDamage        -- Используем модифицированный урон
    bullet.Callback = function(ent, tr, dmg)
        dmg:SetDamageType(DMG_BULLET)
        
        -- Эффекты для специальных патронов
        if currentAmmoType:EndsWith(".incendiary") then
            dmg:SetDamageType(bit.bor(DMG_BULLET, DMG_BURN))
        end
    end

    --pl:FireBullets(bullet)

    if (CLIENT) then
        self:DoEffects(pl:ShouldDrawLocalPlayer() and self or pl:GetViewModel())
    else
        self:GetInventorySlot():SetWear(self:GetInventorySlot():GetWear() - 3)
    end

    local function traceit(start, endpos, drop)
        local Result = util.TraceLine({
            start = start,
            endpos = endpos - Vector(0, 0, drop),
            filter = pl,
            mask = MASK_SHOT,
        })

        --debugoverlay.Line(Result.StartPos, Result.HitPos, 0.5)

        local effectdata = EffectData()
        effectdata:SetOrigin(endpos)
        effectdata:SetStart(start)
        effectdata:SetMagnitude(self.TrajStepSpeed*100) -- using SetMagnitude for trajectory speed
        effectdata:SetEntity(self)
        util.Effect( "bullet_tracer", effectdata )

        return Result.StartPos, Result.HitPos, Result.Normal, Result.Hit
    end

    local HS, HP, HN, HH = traceit(pl:GetShootPos(), pl:GetShootPos() + (pl:GetAimVector() + Vector(math.Rand(-aimcone, aimcone), math.Rand(-aimcone, aimcone), math.Rand(-aimcone, aimcone))) * self.TrajStraightStep, 0)

    local TimerID = "trajectory"..CurTime()

    local function endfire(dmgmin)
        bullet.Src = HS
        bullet.Dir = HN
        bullet.Damage = modifiedDamage - dmgmin*self.TrajDropPerStep

        pl:FireBullets(bullet)

        timer.Remove(TimerID)
    end

    if HH then
        endfire(0)
        return
    end

    if CLIENT then return end

    local ms = self.MaxTrajSteps

    timer.Create(TimerID, self.TrajStepSpeed, ms, function()
        if not pl:IsValid() or not self:IsValid() then return end -- just to be safe

        local repsleft = timer.RepsLeft(TimerID)
        HS, HP, HN, HH = traceit(HP, HP + HN*self.TrajStepLength, self.TrajDropPerStep * (ms-repsleft))

        -- debugoverlay.Text(HP, ""..damage-(ms-repsleft)*4, 0.1)

        if HH then endfire(ms-repsleft) end
    end)
end

function SWEP:PrimaryAttack()
    self:SetNextPrimaryFire(CurTime() + (60 / self.RPM))
    local pl = self:GetOwner()
    if (pl.FreeLooking) then return end
    
    if (self:Clip1() <= 0) then return end
    if (self:IsBroken()) then return end

    local AimCone = self.AimCone

    if (pl:KeyDown(IN_ATTACK2) && self.Bullets == 1) then
        self:PlayAnimation("PrimaryAttackEmpty")
        AimCone = 0
    else
        self:PlayAnimation("PrimaryAttack")
    end
    
    pl:SetAnimation(PLAYER_ATTACK1)

    local ShootSound = self:HasMod("silencer") and self.SilencedSound or self.ShootSound
    local InvSlot = self:GetInventorySlot()

    self:EmitSound(ShootSound, 511)
    
    if (IsFirstTimePredicted()) then
        self:ShootBullet(self.Damage, AimCone)
    end
    if (SERVER) then
        InvSlot:SetClip(InvSlot:GetClip() - 1)
        self:SetClip1(InvSlot:GetClip())
        pl:HaltSprint(0.6)

        pl:SyncSlot(self.InventorySlot)
    else
        self:Recoil()
    end
end

-- ============================================================================
-- СИСТЕМА РАЗНЫХ БОЕПРИПАСОВ
-- ============================================================================

-- Переменные для отслеживания состояния
SWEP.RKeyHoldTime = 0
SWEP.ForceAmmoMenu = false
SWEP.LastAmmoType = nil

-- Получаем доступные типы боеприпасов для оружия
function SWEP:GetAvailableAmmoTypes(ply)
    if not ply then ply = self:GetOwner() end
    if not IsValid(ply) then return {} end
    
    local available = {}
    local baseAmmo = self.Ammo
    
    if baseAmmo then
        -- Базовые патроны
        local baseCount = ply:ItemCount(baseAmmo)
        if baseCount > 0 then
            table.insert(available, {
                type = baseAmmo,
                name = "5.56 Ammo",
                icon = "materials/icons/rifle_bullet.png",
                description = string.format("Обычные патроны (%d)", baseCount)
            })
        end
        
        -- Зажигательные патроны
        local incendiaryAmmo = baseAmmo .. ".incendiary"
        local incendiaryCount = ply:ItemCount(incendiaryAmmo)
        if incendiaryCount > 0 then
            table.insert(available, {
                type = incendiaryAmmo,
                name = "Incendiary 5.56",
                icon = "materials/icons/rifle_bullet.png",
                description = string.format("Зажигательные патроны (+7 урона) (%d)", incendiaryCount)
            })
        end
        
        -- Бронебойные патроны (добавляем если нужно)
        local armorPiercingAmmo = baseAmmo .. ".ap"
        local apCount = ply:ItemCount(armorPiercingAmmo)
        if apCount > 0 then
            table.insert(available, {
                type = armorPiercingAmmo,
                name = "Explosive 5.56",
                icon = "materials/icons/rifle_bullet.png",
                description = string.format("Бронебойные патроны (%d)", apCount)
            })
        end
    end
    
    print(string.format("[AMMO CHECK] Found %d available ammo types", #available))
    for i, ammo in ipairs(available) do
        print(string.format("  %d. %s (%s) - %d rounds", i, ammo.name, ammo.type, ply:ItemCount(ammo.type)))
    end
    
    return available
end

-- Основная функция перезарядки
function SWEP:PerformReload()
    if self:GetReloading() then 
        print("[PERFORM RELOAD] Already reloading, skipping")
        return 
    end
    
    local currentClip = self:Clip1()
    local pl = self:GetOwner()
    
    if not IsValid(pl) then
        print("[PERFORM RELOAD] No owner")
        return
    end
    
    -- Автоматически выбираем тип боеприпасов если текущий не установлен или отсутствует
    local currentAmmoType = self:GetCurrentAmmoType()
    if not currentAmmoType or currentAmmoType == "" or pl:ItemCount(currentAmmoType) == 0 then
        local autoSelectedType = self:AutoSelectAmmoType()
        if autoSelectedType then
            self:SetCurrentAmmoType(autoSelectedType)
            currentAmmoType = autoSelectedType
            
            -- Сохраняем выбранный тип в предмете оружия
            local InvSlot = self:GetInventorySlot()
            if InvSlot then
                InvSlot.AmmoType = autoSelectedType
                print(string.format("[PERFORM RELOAD] Auto-selected and saved ammo type: %s", autoSelectedType))
            end
        else
            print("[PERFORM RELOAD] No ammo available for auto-selection")
            return
        end
    end
    
    local AmmoCount = pl:ItemCount(currentAmmoType)
    
    print(string.format("[PERFORM RELOAD] Starting reload - Type: %s, Count: %d, Clip: %d/%d", 
          currentAmmoType, AmmoCount, currentClip, self.Capacity))
    
    -- Проверяем, нужна ли вообще перезарядка
    if currentClip >= self.Capacity then
        print("[PERFORM RELOAD] Clip already full, skipping")
        return
    end
    
    if AmmoCount <= 0 then
        print("[PERFORM RELOAD] No ammo available for type: " .. currentAmmoType)
        return
    end
    
    -- Вычисляем сколько патронов нужно дозарядить
    local needed = self.Capacity - currentClip
    local toLoad = math.min(needed, AmmoCount)
    
    if toLoad <= 0 then
        print("[PERFORM RELOAD] Nothing to load")
        return
    end
    
    print(string.format("[PERFORM RELOAD] Will load %d rounds of %s", toLoad, currentAmmoType))
    
    -- Запускаем анимацию перезарядки
    self:SetReloading(true)
    self:PlayAnimation("Reload")
    self.NextReload = CurTime() + self.ReloadTime
    pl:SetAnimation(PLAYER_RELOAD)
    self:SetNextPrimaryFire(CurTime() + self.ReloadTime)
    
    if SERVER then
        print("[PERFORM RELOAD] Server reload timer started")
        
        timer.Simple(self.ReloadTime, function()
            if not IsValid(self) or not IsValid(pl) then
                print("[PERFORM RELOAD] Timer: Weapon or owner invalid")
                return 
            end
            
            print("[PERFORM RELOAD] Timer: Executing reload completion")
            
            local InvSlot = self:GetInventorySlot()
            local currentClip = self:Clip1()
            local currentAmmoType = self:GetCurrentAmmoType()
            local currentAmmoCount = pl:ItemCount(currentAmmoType)
            
            local needed = self.Capacity - currentClip
            local toLoad = math.min(needed, currentAmmoCount)
            
            print(string.format("[PERFORM RELOAD] Completing - Need: %d, Available: %d, Will load: %d", 
                  needed, currentAmmoCount, toLoad))
            
            if toLoad > 0 then
                if pl:RemoveItem(currentAmmoType, toLoad) then
                    local newClip = currentClip + toLoad
                    if InvSlot then
                        InvSlot:SetClip(newClip)
                        
                        -- Сохраняем тип боеприпасов в предмете оружия после перезарядки
                        if currentAmmoType ~= self.Ammo then
                            InvSlot.AmmoType = currentAmmoType
                            print(string.format("[PERFORM RELOAD] Saved ammo type after reload: %s", currentAmmoType))
                        end
                    end
                    self:SetClip1(newClip)
                    if pl.SyncSlot then
                        pl:SyncSlot(self.InventorySlot)
                    end
                    print(string.format("[RELOAD COMPLETE] Successfully loaded %d rounds of %s. New clip: %d/%d", 
                          toLoad, currentAmmoType, newClip, self.Capacity))
                else
                    print("[RELOAD COMPLETE] Failed to remove ammo from inventory")
                end
            else
                print("[RELOAD COMPLETE] No rounds to load")
            end
            
            self:SetReloading(false)
        end)
    else
        print("[PERFORM RELOAD] Client reload started")
    end
end


-- Функция смены типа боеприпасов
function SWEP:SwitchAmmoType(newAmmoType)
    if self:GetReloading() then return false end
    
    local ply = self:GetOwner()
    if not IsValid(ply) then return false end
    
    local currentAmmo = self:GetCurrentAmmoType() or self.Ammo
    
    print(string.format("[AMMO SWITCH] Switching from %s to %s", currentAmmo, newAmmoType))
    
    -- Если тип не меняется, просто перезаряжаем
    if currentAmmo == newAmmoType then
        print("[AMMO SWITCH] Same ammo type, performing reload")
        self:PerformReload()
        return true
    end
    
    local currentClip = self:Clip1()
    
    -- Возвращаем патроны из обоймы в инвентарь только если тип меняется И есть патроны в обойме
    if currentClip > 0 then
        ply:GiveItem(currentAmmo, currentClip)
        print(string.format("[AMMO SWITCH] Returned %d rounds of %s to inventory", currentClip, currentAmmo))
    end
    
    -- Устанавливаем новый тип боеприпасов
    self:SetCurrentAmmoType(newAmmoType)
    
    -- Сохраняем выбор в предмете оружия
    local InvSlot = self:GetInventorySlot()
    if InvSlot then
        InvSlot.AmmoType = newAmmoType
        print(string.format("[AMMO SWITCH] Saved ammo type %s to weapon item", newAmmoType))
    end
    
    -- Обнуляем обойму
    self:SetClip1(0)
    if SERVER then
        if InvSlot then
            InvSlot:SetClip(0)
            ply:SyncSlot(self.InventorySlot)
        end
    end
    
    print(string.format("[AMMO SWITCH] Switched to %s, clip reset to 0", newAmmoType))
    
    -- НЕМЕДЛЕННО выполняем перезарядку после смены типа
    self:PerformReload()
    
    return true
end

function SWEP:AutoSelectAmmoType()
    local ply = self:GetOwner()
    if not IsValid(ply) then return nil end
    
    local availableAmmo = self:GetAvailableAmmoTypes(ply)
    
    if #availableAmmo == 0 then
        print("[AUTO SELECT] No ammo available")
        return nil
    end
    
    -- Проверяем что availableAmmo[1] существует
    if not availableAmmo[1] or not availableAmmo[1].type then
        print("[AUTO SELECT] Invalid ammo data in availableAmmo")
        return nil
    end
    
    -- Если есть сохраненный тип и он доступен - используем его
    local savedType = self:GetLastAmmoType()
    if savedType then
        for _, ammo in ipairs(availableAmmo) do
            if ammo and ammo.type == savedType and ply:ItemCount(savedType) > 0 then
                print(string.format("[AUTO SELECT] Using saved ammo type: %s", savedType))
                return savedType
            end
        end
    end
    
    -- Иначе используем первый доступный тип
    local firstAvailable = availableAmmo[1].type
    print(string.format("[AUTO SELECT] Using first available ammo type: %s", firstAvailable))
    return firstAvailable
end


-- Открытие меню выбора боеприпасов
function SWEP:OpenAmmoSelectionMenu()
    if CLIENT then
        local availableAmmo = self:GetAvailableAmmoTypes()
        
        if #availableAmmo <= 1 then
            print("[AMMO MENU] Only one ammo type, performing quick reload")
            self:PerformReload()
            return
        end
        
        local menuElements = {}
        for _, ammoData in ipairs(availableAmmo) do
            table.insert(menuElements, {
                Name = ammoData.name,
                Icon = ammoData.icon or "icon16/bullet.png",
                AmmoType = ammoData.type,
                Description = ammoData.description or ""
            })
        end
        
        print(string.format("[AMMO MENU] Opening menu with %d options", #menuElements))
        
        -- Используем существующее круговое меню
        gRust.OpenPieMenu(menuElements, function(index, ent)
            if index and menuElements[index] then
                local selectedAmmo = menuElements[index].AmmoType
                print(string.format("[AMMO MENU] Selected: %s (index: %d)", selectedAmmo, index))
                
                -- НЕМЕДЛЕННО отправляем на сервер и выполняем смену типа
                net.Start("gRust.SelectAmmoType")
                    net.WriteString(selectedAmmo)
                net.SendToServer()
            else
                print("[AMMO MENU] Invalid selection")
            end
        end)
    end
end

function SWEP:GetLastAmmoType()
    local InvSlot = self:GetInventorySlot()
    if InvSlot and InvSlot.AmmoType then
        return InvSlot.AmmoType
    end
    return nil
end

-- Обработка ввода через хуки (на клиенте)
if CLIENT then
    -- Хук для отслеживания нажатия R
    hook.Add("Think", "gRust.AmmoMenuThink", function()
        local ply = LocalPlayer()
        if not IsValid(ply) then return end
        
        local wep = ply:GetActiveWeapon()
        if not IsValid(wep) or wep.Base ~= "rust_basegun" then return end
        
        -- Проверяем что оружие все еще валидно и имеет необходимые методы
        if not wep.HasMod or not wep.GetAvailableAmmoTypes or not wep.PerformReload then
            return
        end
        
        -- Отслеживаем зажатие R
        if input.IsKeyDown(KEY_R) then
            if wep.RKeyHoldTime == 0 then
                wep.RKeyHoldTime = CurTime()
            else
                local holdTime = CurTime() - wep.RKeyHoldTime
                
                -- Если зажали более 0.5 секунд и меню еще не открыто
                if holdTime > 0.5 and not wep.ForceAmmoMenu then
                    wep.ForceAmmoMenu = true
                    
                    local availableAmmo = wep:GetAvailableAmmoTypes(ply)
                    if #availableAmmo > 1 then
                        print("[R HOLD] Opening ammo selection menu")
                        wep:OpenAmmoSelectionMenu()
                    else
                        -- Если только один тип - обычная перезарядка
                        print("[R HOLD] Only one ammo type, performing reload")
                        wep:PerformReload()
                    end
                end
            end
        else
            -- Кнопка отпущена
            if wep.RKeyHoldTime > 0 then
                local totalHoldTime = CurTime() - wep.RKeyHoldTime
                
                -- Если меню было открыто - закрываем при отпускании
                if wep.ForceAmmoMenu then
                    if gRust and gRust.ClosePieMenu then
                        gRust.ClosePieMenu(false)
                    end
                elseif totalHoldTime < 0.5 then
                    -- Быстрое нажатие - проверяем сколько типов патронов
                    local availableAmmo = wep:GetAvailableAmmoTypes(ply)
                    if #availableAmmo == 1 then
                        -- Если только один тип - обычная перезарядка
                        print("[R QUICK] Single ammo type, performing reload")
                        wep:PerformReload()
                    else
                        -- Если несколько типов - используем сохраненный тип или первый доступный
                        local savedAmmoType = wep:GetLastAmmoType()
                        local ammoTypeToUse = savedAmmoType or availableAmmo[1].type
                        if not wep:GetCurrentAmmoType() or wep:GetCurrentAmmoType() == "" then
                            wep:SetCurrentAmmoType(ammoTypeToUse)
                            print(string.format("[R QUICK] Set current ammo type to: %s", ammoTypeToUse))
                        end
                        print(string.format("[R QUICK] Multiple ammo types, using saved: %s", ammoTypeToUse))
                        wep:PerformReload()
                    end
                end
                
                wep.RKeyHoldTime = 0
                wep.ForceAmmoMenu = false
            end
        end
    end)
end

-- Переопределяем стандартную функцию Reload (для консольной команды)
function SWEP:Reload()
    if self:GetReloading() then return end
    
    local ply = self:GetOwner()
    if not IsValid(ply) then return end
    
    local availableAmmo = self:GetAvailableAmmoTypes(ply)
    
    if #availableAmmo == 0 then
        print("[RELOAD] No ammo available")
        return
    end
    
    if #availableAmmo == 1 then
        -- Если только один тип - обычная перезарядка
        self:PerformReload()
    else
        -- Если несколько типов - используем сохраненный тип или первый доступный
        local savedAmmoType = self:GetLastAmmoType()
        local ammoTypeToUse = savedAmmoType or (availableAmmo[1] and availableAmmo[1].type) or self.Ammo
        
        if not self:GetCurrentAmmoType() or self:GetCurrentAmmoType() == "" then
            self:SetCurrentAmmoType(ammoTypeToUse)
        end
        self:PerformReload()
    end
end

-- Инициализация при взятии оружия
function SWEP:Deploy()
    self:PlayAnimation("Deploy")
    
    -- Инициализация аттачментов
    if not self.Attachments then self.Attachments = {} end
    if not self.AttachmentIndex then self.AttachmentIndex = {} end

    if (CLIENT) then
        self:LoadAttachments()
    end
    
    if (SERVER) then
        self:SetClip1(self:GetInventorySlot():GetClip())
        self:SetNextPrimaryFire(CurTime() + self.DrawTime)
        
        -- Восстанавливаем сохраненный тип боеприпасов из предмета оружия
        local InvSlot = self:GetInventorySlot()
        if InvSlot and InvSlot.AmmoType then
            self:SetCurrentAmmoType(InvSlot.AmmoType)
            print(string.format("[DEPLOY] Restored saved ammo type: %s", InvSlot.AmmoType))
        else
            -- Устанавливаем тип боеприпасов по умолчанию
            if not self:GetCurrentAmmoType() or self:GetCurrentAmmoType() == "" then
                self:SetCurrentAmmoType(self.Ammo)
                print(string.format("[DEPLOY] Set default ammo type: %s", self.Ammo))
            else
                print(string.format("[DEPLOY] Using existing ammo type: %s", self:GetCurrentAmmoType()))
            end
        end
    end
    
    if (self.HoldType) then
        self:SetHoldType(self.HoldType)
    end
    
    -- Сброс состояния
    self.RKeyHoldTime = 0
    self.ForceAmmoMenu = false
    
    print(string.format("[DEPLOY] Weapon deployed, ammo type: %s", self:GetCurrentAmmoType() or "default"))
end

function SWEP:HasMod(mod)
    if not IsValid(self) then return false end
    
    if (SERVER) then
        local InvSlot = self:GetInventorySlot()
        if (InvSlot and InvSlot.Mods) then
            for i = 1, 4 do
                local v = InvSlot.Mods[i]
                if (!v) then continue end
                if (v:GetItem() == mod) then
                    return true
                end
            end
        end
    else
        return self.AttachmentIndex and self.AttachmentIndex[mod] or false
    end
    
    return false
end

function SWEP:LoadAttachments()
    if CLIENT then
        -- ИНИЦИАЛИЗАЦИЯ если nil
        if not self.Attachments then
            self.Attachments = {}
        end
        if not self.AttachmentIndex then
            self.AttachmentIndex = {}
        end
        
        -- Очищаем старые аттачменты
        for k, v in pairs(self.Attachments) do
            if IsValid(v) then
                v:Remove()
            end
        end
        self.Attachments = {}
        self.AttachmentIndex = {}
        
        local InvSlot = self:GetInventorySlot()
        if not InvSlot or not InvSlot.Mods then 
            -- Если фонарика нет, но свет включен - выключаем
            if self:GetFlashlightOn() then
                self:SetFlashlightOn(false)
            end
            return 
        end
        
        -- Проверяем, есть ли еще фонарик
        local hasFlashlight = false
        for i = 1, 4 do
            local mod = InvSlot.Mods[i]
            if mod and mod:GetItem() == "flashlight" then
                hasFlashlight = true
                break
            end
        end
        
        -- Если фонарика нет, но свет включен - выключаем
        if not hasFlashlight and self:GetFlashlightOn() then
            self:SetFlashlightOn(false)
            if SERVER then
                self:RemoveFlashlight()
            end
        end
        
        -- Загружаем новые аттачменты
        for i = 1, 4 do
            local mod = InvSlot.Mods[i]
            if mod then
                local modData = self.AttachmentData[mod:GetItem()]
                if modData then
                    self:AddAttachment(mod:GetItem())
                end
            end
        end
    end
    
    -- Обновляем индекс аттачментов для сервера
    self.AttachmentIndex = self.AttachmentIndex or {}
    local InvSlot = self:GetInventorySlot()
    if InvSlot and InvSlot.Mods then
        for i = 1, 4 do
            local mod = InvSlot.Mods[i]
            if mod then
                self.AttachmentIndex[mod:GetItem()] = true
            end
        end
    end
end

function SWEP:ToggleFlashlight()
    if not self:HasMod("flashlight") then 
        print("No flashlight attached")
        return false 
    end
    
    local newState = not self:GetFlashlightOn()
    self:SetFlashlightOn(newState)
    
    print(string.format("Flashlight toggled: %s (Weapon: %s)", tostring(newState), self:GetClass()))
    
    if SERVER then
        -- Создаем/удаляем источник света
        if newState then
            self:CreateFlashlight()
        else
            self:RemoveFlashlight()
        end
    end
    
    return true
end

if SERVER then
    function SWEP:CreateFlashlight()
        -- Сначала удаляем старый фонарик, если есть
        self:RemoveFlashlight()
        
        local flashlight = ents.Create("env_projectedtexture")
        if not IsValid(flashlight) then 
            print("Failed to create flashlight entity")
            return 
        end
        
        flashlight:SetPos(self:GetOwner():GetShootPos())
        flashlight:SetAngles(self:GetOwner():EyeAngles())
        flashlight:SetKeyValue("enableshadows", 1)
        flashlight:SetKeyValue("farz", 1024)
        flashlight:SetKeyValue("nearz", 8)
        flashlight:SetKeyValue("lightfov", 50)
        flashlight:SetKeyValue("lightcolor", "255 255 255")
        flashlight:SetParent(self:GetOwner())
        flashlight:Spawn()
        
        self.FlashlightEntity = flashlight
        print("Flashlight created")
    end
    
    function SWEP:RemoveFlashlight()
        if IsValid(self.FlashlightEntity) then
            self.FlashlightEntity:Remove()
            self.FlashlightEntity = nil
            print("Flashlight removed")
        end
    end
    
    -- Хук для выключения фонарика при смене оружия
    hook.Add("PlayerSwitchWeapon", "gRust.FlashlightHolster", function(ply, oldWeapon, newWeapon)
        if IsValid(oldWeapon) and oldWeapon.Base == "rust_basegun" then
            if oldWeapon:GetFlashlightOn() then
                print("Auto-disabling flashlight on weapon switch")
                oldWeapon:SetFlashlightOn(false)
                oldWeapon:RemoveFlashlight()
            end
        end
    end)
end

function SWEP:Holster()
    -- Выключаем фонарик при смене оружия
    if self:GetFlashlightOn() then
        self:SetFlashlightOn(false)
        if SERVER then
            self:RemoveFlashlight()
        end
    end
    
    return true
end

function SWEP:OnRemove()
    -- Выключаем фонарик при удалении оружия
    if self:GetFlashlightOn() then
        self:SetFlashlightOn(false)
        if SERVER then
            self:RemoveFlashlight()
        end
    end
end