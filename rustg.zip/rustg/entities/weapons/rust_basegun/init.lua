AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")
util.AddNetworkString("gRust.AttachMod")
util.AddNetworkString("gRust.DetachMod")
util.AddNetworkString("gRust.ToggleFlashlight")
util.AddNetworkString("DAC.AntiRecoil")
util.AddNetworkString("gRust.SelectAmmoType")
util.AddNetworkString("gRust.OpenAmmoMenu")

net.Receive("DAC.AntiRecoil", function(len, ply)
    print("[ANTI-RECOIL] Player " .. ply:Nick() .. " triggered anti-recoil check.")
    -- Можно добавить логику кика/бана или предупреждений
end)

-- Эффекты выстрела (гильзы + дульное пламя)
function SWEP:DoEffects(ent)
    local Shell = self.ShellEject
    if Shell then
        local Attach = ent:GetAttachment(2)
        if Attach then
            local Effect = EffectData()
            Effect:SetOrigin(Attach.Pos)
            Effect:SetAngles(Attach.Ang)
            Effect:SetEntity(ent)
            Effect:SetAttachment(2)
            util.Effect(Shell, Effect)
        end
    end

    local Flash = self.MuzzleEffect
    if Flash then
        local Attach = ent:GetAttachment(1)
        if Attach then
            local Effect = EffectData()
            Effect:SetOrigin(Attach.Pos)
            Effect:SetAngles(Attach.Ang)
            Effect:SetEntity(ent)
            Effect:SetAttachment(1)
            util.Effect(Flash, Effect)
        end
    end
end

-- Проверка модов (серверная часть)

net.Receive("gRust.AttachMod", function(len, ply)
	local ent = net.ReadEntity()
	local weaponIndex = net.ReadUInt(8)
	local attachmentSlot = net.ReadUInt(3)
	local itemIndex = net.ReadUInt(8)
	
	if not IsValid(ent) or not ent.Inventory then 
		print("[ATTACH ERROR] Invalid entity or no inventory")
		return 
	end
	if not IsValid(ply) or ent:GetPos():Distance(ply:GetPos()) > 200 then 
		print("[ATTACH ERROR] Player too far")
		return 
	end
	
	local weaponItem = ent.Inventory[weaponIndex]
	if not weaponItem then 
		print("[ATTACH ERROR] No weapon item at index " .. weaponIndex)
		return 
	end
	
	local attachmentItem = ent.Inventory[itemIndex]
	if not attachmentItem then 
		print("[ATTACH ERROR] No attachment item at index " .. itemIndex)
		return 
	end
	
	-- Проверяем, является ли предмет аттачментом
	local itemData = gRust.Items[attachmentItem:GetItem()]
	if not itemData or not itemData.IsAttachment then 
		print("[ATTACH ERROR] Item is not an attachment: " .. attachmentItem:GetItem())
		return 
	end
	
	-- Проверяем, не занят ли уже слот
	if weaponItem.Mods and weaponItem.Mods[attachmentSlot] then
		print("[ATTACH ERROR] Attachment slot already occupied: " .. attachmentSlot)
		return
	end
	
	-- Добавляем аттачмент к оружию
	if not weaponItem.Mods then
		weaponItem.Mods = {}
	end
	
	weaponItem.Mods[attachmentSlot] = attachmentItem
	
	-- Убираем предмет из основного инвентаря
	ent.Inventory[itemIndex] = nil
	
	-- Синхронизируем изменения
	if ent.SyncInventory then
		ent:SyncInventory()
	end
	
	-- Обновляем оружие, если оно в руках
	local wep = ent:GetActiveWeapon() -- ИСПРАВЛЕНИЕ: используем GetActiveWeapon()
	if IsValid(wep) and wep:GetInventorySlot() == weaponItem then
		if wep.LoadAttachments then
			wep:LoadAttachments()
		end
	end
	
	print(string.format("[ATTACH SUCCESS] Added %s to weapon slot %d, attachment slot %d", 
		attachmentItem:GetItem(), weaponIndex, attachmentSlot))
end)

net.Receive("gRust.DetachMod", function(len, ply)
	local ent = net.ReadEntity()
	local weaponIndex = net.ReadUInt(8)
	local attachmentSlot = net.ReadUInt(3)
	
	if not IsValid(ent) or not ent.Inventory then 
		print("[DETACH ERROR] Invalid entity or no inventory")
		return 
	end
	if not IsValid(ply) or ent:GetPos():Distance(ply:GetPos()) > 200 then 
		print("[DETACH ERROR] Player too far")
		return 
	end
	
	local weaponItem = ent.Inventory[weaponIndex]
	if not weaponItem then 
		print("[DETACH ERROR] No weapon item at index " .. weaponIndex)
		return 
	end
	
	-- Проверяем, есть ли аттачмент в слоте
	if not weaponItem.Mods or not weaponItem.Mods[attachmentSlot] then
		print("[DETACH ERROR] No attachment in slot " .. attachmentSlot)
		return
	end
	
	local attachmentItem = weaponItem.Mods[attachmentSlot]
	
	-- Находим свободный слот в инвентаре
	local freeSlot
	for i = 1, #ent.Inventory do
		if not ent.Inventory[i] then
			freeSlot = i
			break
		end
	end
	
	if not freeSlot then
		print("[DETACH ERROR] No free slots in inventory")
		return
	end
	
	-- Возвращаем аттачмент в инвентарь
	ent.Inventory[freeSlot] = attachmentItem
	weaponItem.Mods[attachmentSlot] = nil
	
	-- Синхронизируем изменения
	if ent.SyncInventory then
		ent:SyncInventory()
	end
	
	-- Обновляем оружие, если оно в руках
	local wep = ent:GetActiveWeapon() -- ИСПРАВЛЕНИЕ: используем GetActiveWeapon()
	if IsValid(wep) and wep:GetInventorySlot() == weaponItem then
		if wep.LoadAttachments then
			wep:LoadAttachments()
		end
	end
	
	print(string.format("[DETACH SUCCESS] Removed attachment from weapon slot %d, attachment slot %d", 
		weaponIndex, attachmentSlot))
end)



net.Receive("gRust.ToggleFlashlight", function(len, ply)
    local wep = ply:GetActiveWeapon()
    if IsValid(wep) and wep.ToggleFlashlight then
        wep:ToggleFlashlight()
    end
end)

if SERVER then
    scripted_ents.Register({Type = "anim", Base = "base_entity"}, "rust_fire_zone")
end

-- Сетевое сообщение для выбора типа боеприпасов


net.Receive("gRust.OpenAmmoMenu", function(len, ply)
    print("[SERVER] Received OpenAmmoMenu request")
    local wep = ply:GetActiveWeapon()
    if IsValid(wep) and wep.OpenAmmoSelectionMenu then
        wep:OpenAmmoSelectionMenu()
    end
end)

net.Receive("gRust.SelectAmmoType", function(len, ply)
    local ammoType = net.ReadString()
    local wep = ply:GetActiveWeapon()
    
    print(string.format("[SERVER] Received ammo type selection: %s", ammoType))
    
    if IsValid(wep) then
        if wep.SwitchAmmoType then
            wep:SwitchAmmoType(ammoType)
        end
        
        -- Также сохраняем в сетевой переменной для немедленного доступа
        wep:SetCurrentAmmoType(ammoType)
    else
        print("[SERVER] Invalid weapon")
    end
end)