include("shared.lua")



function SWEP:Think()

	local InvSlot = self:GetInventorySlot()

	if (!InvSlot.Mods) then return end



	for i = 1, 4 do

		local v = InvSlot.Mods[i]

		if (!v) then continue end



		if (!self.AttachmentIndex[v:GetItem()]) then

			self:AddAttachment(v:GetItem())

		end

	end

end