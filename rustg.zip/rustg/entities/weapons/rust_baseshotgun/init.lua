AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

util.AddNetworkString("DAC.AntiRecoil")

net.Receive("DAC.AntiRecoil", function(len, ply)
    print("[ANTI-RECOIL] Player " .. ply:Nick() .. " triggered anti-recoil check.")
    -- Можно добавить логику кика/бана или предупреждений
end)

-- Эффекты выстрела (гильзы + дульное пламя)
function SWEP:DoEffects(ent)
    local Shell = self.ShellEject
    if Shell then
        local Attach = ent:GetAttachment(2)
        if Attach then
            local Effect = EffectData()
            Effect:SetOrigin(Attach.Pos)
            Effect:SetAngles(Attach.Ang)
            Effect:SetEntity(ent)
            Effect:SetAttachment(2)
            util.Effect(Shell, Effect)
        end
    end

    local Flash = self.MuzzleEffect
    if Flash then
        local Attach = ent:GetAttachment(1)
        if Attach then
            local Effect = EffectData()
            Effect:SetOrigin(Attach.Pos)
            Effect:SetAngles(Attach.Ang)
            Effect:SetEntity(ent)
            Effect:SetAttachment(1)
            util.Effect(Flash, Effect)
        end
    end
end

-- Проверка модов (серверная часть)
function SWEP:HasMod(mod)
    local InvSlot = self:GetInventorySlot()
    if not InvSlot or not InvSlot.Mods then return false end
    for i = 1, 4 do
        local v = InvSlot.Mods[i]
        if v and v:GetItem() == mod then
            return true
        end
    end
    return false
end