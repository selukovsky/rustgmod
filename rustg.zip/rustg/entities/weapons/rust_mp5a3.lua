SWEP.Base       = "rust_basegun"

SWEP.WorldModel = "models/weapons/yurie_rustalpha/wm-mp5.mdl"

SWEP.ViewModel  = "models/weapons/yurie_rustalpha/c-vm-mp5.mdl"



--

-- Stats

--

SWEP.Damage     = 35

SWEP.RPM        = 600

SWEP.AimCone    = 0.2

SWEP.Capacity   = 30

SWEP.ReloadTime = 4

SWEP.DrawTime   = 1.6



SWEP.Ammo       = "ammo.pistol"



SWEP.HoldType 	= "pistol"



--

-- Ironsights

--

SWEP.IronSightPos = Vector(-4.975, -4, 2.099)
SWEP.IronSightAng = Vector(1.019, -0.004, 0)

SWEP.IronSightTime  = 0.075

SWEP.IronSightFOV   = 44
--

-- Sounds

--

SWEP.ShootSound		= "weapons/rust-modular-gunshots-08.wav"

SWEP.SilencedSound	= "darky_rust.mp5-attack-silenced"



--

-- Recoil

--

SWEP.RecoilAmount   = 1.0

SWEP.RecoilTable = {
    Angle(-0.7, 0.3, 0),
    Angle(-0.9, -0.2, 0),
    Angle(-0.8, 0.1, 0),
    Angle(-0.7, -0.1, 0),
    Angle(-0.6, 0.2, 0),
    Angle(-0.5, 0, 0),
    Angle(-0.4, -0.1, 0),
    Angle(-0.5, 0.1, 0),
    Angle(-0.3, 0, 0),
    Angle(-0.3, 0.05, 0),
}