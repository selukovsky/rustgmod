SWEP.Base       = "rust_basegun"

SWEP.WorldModel = "models/weapons/darky_m/rust/w_rocketlauncher.mdl"

SWEP.ViewModel  = "models/weapons/darky_m/rust/c_rocketlauncher.mdl"

SWEP.Primary.Automatic = false

--
-- Stats
--

SWEP.Damage     = 40
SWEP.RPM        = 400
SWEP.AimCone    = 0.25
SWEP.Capacity   = 1
SWEP.ReloadTime = 5
SWEP.DrawTime   = 0.5

SWEP.Ammo       = "ammo.rocket.basic"

SWEP.HoldType 	= "pistol"

--
-- Ironsights
--

SWEP.IronSightPos 	= Vector(-3, 5, 3.25)
SWEP.IronSightAng 	= Vector(2, -10, 4)
SWEP.IronSightTime  = 0.075
SWEP.IronSightFOV   = 35

--
-- Sounds
--

SWEP.ShootSound		= "darky_rust.rpg_fire"
SWEP.SilencedSound	= "darky_rust.semi-pistol-attack-silenced"

--
-- Recoil
--

SWEP.RecoilAmount   = 1.5
SWEP.RecoilTable = {
	Angle(-2.5, 0, 0),
}

-- ============================================================================
-- СИСТЕМА РАЗНЫХ РАКЕТ ДЛЯ РПГ (ИСПРАВЛЕННАЯ)
-- ============================================================================

-- Переопределяем функцию получения доступных типов боеприпасов
function SWEP:GetAvailableAmmoTypes(ply)
    if not ply then ply = self:GetOwner() end
    if not IsValid(ply) then return {} end
    
    local available = {}
    
    -- Базовые ракеты
    if ply:ItemCount("ammo.rocket.basic") > 0 then
        table.insert(available, {
            type = "ammo.rocket.basic",
            name = "Обычные",
            icon = "materials/darky_rust/rocket_normal.png",
            description = "Стандартная ракета"
        })
    end
    
    -- Скоростные ракеты
    if ply:ItemCount("ammo.rocket.highvelocity") > 0 then
        table.insert(available, {
            type = "ammo.rocket.highvelocity", 
            name = "Скоростные",
            icon = "materials/darky_rust/rocket_highvelocity.png",
            description = "Высокая скорость, малый урон"
        })
    end
    
    -- Зажигательные ракеты
    if ply:ItemCount("ammo.rocket.incendiary") > 0 then
        table.insert(available, {
            type = "ammo.rocket.incendiary",
            name = "Зажигательные", 
            icon = "materials/darky_rust/rocket_incendiary.png",
            description = "Создает огненную зону"
        })
    end
    
    return available
end

-- Переопределяем функцию стрельбы для ракетницы (ИСПРАВЛЕННАЯ)
function SWEP:ShootBullet(damage, aimcone)
    if (CLIENT) then return end

    local pl = self:GetOwner()
    if not IsValid(pl) then
        print("[RPG SHOOT] Owner is not valid")
        return
    end

    local ang = pl:GetAimVector():Angle()
    local currentAmmoType = self:GetCurrentAmmoType() or self.Ammo
    
    -- Всегда используем существующую сущность rust_projectile
    local projectileClass = "rust_projectile"
    local model = "models/weapons/darky_m/rust/rocket.mdl"
    local speed = 8000
    local rocketDamage = 2000
    local radius = 256
    local rocketType = "basic"
    
    -- Настройки для разных типов ракет
    if currentAmmoType == "ammo.rocket.highvelocity" then
        speed = 11000  -- Высокая скорость
        rocketDamage = 90   -- Меньший урон
        radius = 128   -- Меньший радиус
        rocketType = "highvelocity"
    elseif currentAmmoType == "ammo.rocket.incendiary" then
        speed = 5000   -- Низкая скорость
        rocketDamage = 1  -- Средний урон
        radius = 192   -- Средний радиус
        rocketType = "incendiary"
    end
    
    print(string.format("[RPG SHOOT] Creating projectile: %s, Type: %s", projectileClass, rocketType))
    
    local ent = ents.Create(projectileClass)
    if not IsValid(ent) then
        print("[RPG SHOOT] Failed to create projectile entity")
        return
    end
    
    -- Устанавливаем владельца ДО установки позиции
    ent:SetOwner(pl)
    
    local shootPos = pl:GetShootPos() + pl:EyeAngles():Forward() * 50 -- Увеличиваем отступ для безопасности
    ent:SetPos(shootPos)
    ent:SetAngles(ang)
    ent:SetModel(model)
    ent:Spawn()
    ent:Activate()
    
    -- Сохраняем параметры ракеты в самой сущности
    ent.RocketType = rocketType
    ent.RocketDamage = rocketDamage
    ent.RocketRadius = radius
    ent.RocketSpeed = speed
    ent.LaunchTime = CurTime()
    
    print(string.format("[RPG SHOOT] Projectile created, type: %s, speed: %d, damage: %d", rocketType, speed, rocketDamage))
    
    -- Запускаем ракету
    local phys = ent:GetPhysicsObject()
    if IsValid(phys) then
        phys:SetVelocity(ang:Forward() * speed)
        phys:AddAngleVelocity(Vector(0, 500, 0)) -- Вращение для эффекта
    end
    
    -- Устанавливаем обработчик столкновений
    ent.PhysicsCollide = function(rocket, data)
        if IsValid(rocket) then
            self:RocketExplosion(rocket, data)
        end
    end
    
    -- Автоматический взрыв через 10 секунд (на всякий случай)
    timer.Simple(10, function()
        if IsValid(ent) then
            self:RocketExplosion(ent, nil)
        end
    end)
end

-- Универсальный обработчик взрыва ракет
function SWEP:RocketExplosion(rocket, data)
    if not IsValid(rocket) then return end
    
    local pos = rocket:GetPos()
    local rocketType = rocket.RocketType or "basic"
    local damage = rocket.RocketDamage or 2000
    local radius = rocket.RocketRadius or 256
    local owner = rocket:GetOwner()
    
    print(string.format("[ROCKET EXPLOSION] Type: %s, Damage: %d, Radius: %d", rocketType, damage, radius))
    
    if rocketType == "basic" then
        self:BasicRocketExplosion(rocket, pos, damage, radius, owner)
    elseif rocketType == "highvelocity" then
        self:HighVelocityRocketExplosion(rocket, pos, damage, radius, owner)
    elseif rocketType == "incendiary" then
        self:IncendiaryRocketExplosion(rocket, pos, damage, radius, owner)
    else
        -- По умолчанию обычный взрыв
        self:BasicRocketExplosion(rocket, pos, damage, radius, owner)
    end
end

-- Взрыв обычной ракеты
function SWEP:BasicRocketExplosion(rocket, pos, damage, radius, owner)
    if IsValid(owner) then
        util.ScreenShake(pos, 5, 1, 2, 1000)
        util.BlastDamage(rocket, owner, pos, radius, damage)
    end
    
    rocket:EmitSound("darky_rust.beancan-grenade-explosion")
    
    -- Стандартные эффекты взрыва
    local effect = EffectData()
    effect:SetOrigin(pos)
    effect:SetMagnitude(8) -- Размер взрыва
    effect:SetScale(1) -- Интенсивность
    effect:SetRadius(256) -- Радиус
    util.Effect("Explosion", effect, true, true)
    util.Effect("HelicopterMegaBomb", effect, true, true)
    
    if IsValid(rocket) then
        rocket:Remove()
    end
end

-- Взрыв скоростной ракеты
function SWEP:HighVelocityRocketExplosion(rocket, pos, damage, radius, owner)
    if IsValid(owner) then
        util.ScreenShake(pos, 3, 1, 1, 500)
        util.BlastDamage(rocket, owner, pos, radius, damage)
    end
    
    rocket:EmitSound("darky_rust.beancan-grenade-explosion")
    
    -- Меньший эффект взрыва для скоростной ракеты
    local effect = EffectData()
    effect:SetOrigin(pos)
    effect:SetMagnitude(4) -- Меньший размер
    effect:SetScale(0.7) -- Меньшая интенсивность
    effect:SetRadius(128) -- Меньший радиус
    util.Effect("Explosion", effect, true, true)
    
    if IsValid(rocket) then
        rocket:Remove()
    end
end

-- Взрыв зажигательной ракеты
function SWEP:IncendiaryRocketExplosion(rocket, pos, damage, radius, owner)
    if IsValid(owner) then
        util.ScreenShake(pos, 4, 1, 2, 800)
        util.BlastDamage(rocket, owner, pos, radius, damage)
    end
    
    rocket:EmitSound("darky_rust.beancan-grenade-explosion")
    
    -- Эффект взрыва с огнем
    local effect = EffectData()
    effect:SetOrigin(pos)
    effect:SetMagnitude(6) -- Средний размер
    effect:SetScale(1.2) -- Увеличенная интенсивность
    effect:SetRadius(192) -- Средний радиус
    util.Effect("Explosion", effect, true, true)
    
    -- Добавляем огненные эффекты
    for i = 1, 8 do
        timer.Simple(i * 0.1, function()
            if IsValid(rocket) then
                local fireEffect = EffectData()
                fireEffect:SetOrigin(pos + Vector(math.Rand(-64, 64), math.Rand(-64, 64), math.Rand(0, 32)))
                fireEffect:SetScale(2)
                util.Effect("fire_jet_01", fireEffect, true, true)
            end
        end)
    end
    
    -- Создаем огненную зону
    self:CreateFireZone(pos, owner)
    
    if IsValid(rocket) then
        rocket:Remove()
    end
end

-- Создание огненной зоны для зажигательных ракет
function SWEP:CreateFireZone(pos, owner)
    local fireZone = ents.Create("rust_fire_zone")
    if IsValid(fireZone) then
        fireZone:SetPos(pos)
        fireZone:SetOwner(owner)
        fireZone:Spawn()
        
        -- Автоудаление через 10 секунд
        timer.Simple(20, function()
            if IsValid(fireZone) then
                fireZone:Remove()
            end
        end)
    end
end

-- Переопределяем PrimaryAttack для RPG
function SWEP:PrimaryAttack()
    self:SetNextPrimaryFire(CurTime() + (60 / self.RPM))
    local pl = self:GetOwner()
    if (pl.FreeLooking) then return end
    
    if (self:Clip1() <= 0) then return end
    if (self:IsBroken()) then return end

    self:PlayAnimation("PrimaryAttack")
    pl:SetAnimation(PLAYER_ATTACK1)

    local InvSlot = self:GetInventorySlot()

    self:EmitSound(self.ShootSound, 511)
    
    if (IsFirstTimePredicted()) then
        self:ShootBullet(self.Damage, self.AimCone)
    end
    
    if (SERVER) then
        InvSlot:SetClip(InvSlot:GetClip() - 1)
        self:SetClip1(InvSlot:GetClip())
        pl:HaltSprint(0.6)

        pl:SyncSlot(self.InventorySlot)
    else
        self:Recoil()
    end
end
