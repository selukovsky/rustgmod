AddCSLuaFile()



ENT.Base = "rust_base"



ENT.Model    = "models/deployable/wooden_barricade.mdl"


ENT.Deploy          = {}

ENT.Deploy.Rotation = 0

ENT.Deploy.Model    = "models/deployable/wooden_barricade.mdl"

ENT.Deploy.Sound	= "deploy/wood_bars_deploy.wav"



ENT.woodupkeep = 50



ENT.Pickup = "table"

function ENT:Initialize()

    if (CLIENT) then return end

    

    self:SetDamageable(true)

    self:SetHealth(150)

    self:SetMaxHealth(150)



    self:SetMeleeDamage(0.2)

    self:SetBulletDamage(0.5)

    self:SetExplosiveDamage(0.4)

end