AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

DEFINE_BASECLASS("rust_storage")

function ENT:Initialize()
    if CLIENT then return end

    self:CreateInventory(18)
    self:SetInteractable(true)
    self:SetDamageable(false)

    self:SetModel("models/environment/crates/env_loot_supplydrop.mdl")
    self:SetSolid(SOLID_VPHYSICS)
    self:PhysicsInit(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:EnableMotion(true)
        phys:Wake()
    
        phys:SetMass(50)
        phys:SetMaterial("wood")
        phys:EnableDrag(true)
        phys:SetDragCoefficient(15)
        phys:SetAngleDragCoefficient(3000)
        phys:SetInertia(Vector(1500, 1500, 1500))
    end
    
    self:SetUseType(SIMPLE_USE)

    self.IsFalling = true
    self.MaxFallSpeed = 40
    self.LandingSound = false

    self:SetBodygroup(0, 0)

    -- Создаем таймер для проверки пустоты ВНУТРИ функции Initialize
    timer.Create("CheckEmpty_" .. self:EntIndex(), 2, 0, function()
        if IsValid(self) then
            self:CheckAndRespawnIfEmpty()
        else
            timer.Remove("CheckEmpty_" .. self:EntIndex())
        end
    end)

    timer.Simple(0.1, function()
        if IsValid(self) then
            self.SpawnPosition = self:GetPos()
            self.SpawnAngles = self:GetAngles()
            self:PopulateWithItems()
        end
    end)
end

-- Добавляем недостающую функцию CheckAndRespawnIfEmpty
function ENT:CheckAndRespawnIfEmpty()
    if self:IsInventoryEmpty() then
       self:ScheduleRespawn()
    end
end

function ENT:PopulateWithItems()
    local suplyCrateLootItems = {
        {
            itemid = "shotgun.pump",
            amount = {1, 2},
            chance = 0.25,
        },
        {
            itemid = "shotgun.spas12",
            amount = {1, 1},
            chance = 0.25,
        },
        {
            itemid = "smg.2",
            amount = {1, 2},
            chance = 0.30,
        },
        {
            itemid = "smg.thompson",
            amount = {1, 2},
            chance = 0.25,
        },
        {
            itemid = "smg.mp5",
            amount = {1, 1},
            chance = 0.18,
        },
        {
            itemid = "semibody",
            amount = {1, 2},
            chance = 0.15,
        },
        {
            itemid = "metalspring",
            amount = {1, 2},
            chance = 0.15,
        },
        {
            itemid = "sheetmetal",
            amount = {1, 6},
            chance = 0.35,
        },
        {
            itemid = "scrap",
            amount = {85, 240},
            chance = 100.0,
        },
        {
            itemid = "metalpipe",
            amount = {1, 10},
            chance = 0.35,
        },
        {
            itemid = "pistol.semiauto",
            amount = {1, 1},
            chance = 0.45,
        },
        {
            itemid = "usp",
            amount = {1, 1},
            chance = 0.40,
        },
        {
            itemid = "sar.m39",
            amount = {1, 2},
            chance = 0.40,
        },
        {
            itemid = "rifle.semiauto",
            amount = {1, 2},
            chance = 0.40,
        },
        {
            itemid = "roadchest",
            amount = {1, 1},
            chance = 0.25,
        },
        {
            itemid = "backethead",
            amount = {1, 1},
            chance = 0.40,
        },
        {
            itemid = "jackhammer",
            amount = {1, 1},
            chance = 0.25,
        },
        {
            itemid = "hoodieblue",
            amount = {1, 2},
            chance = 0.35,
        },
        {
            itemid = "coffee.mask",
            amount = {1, 2},
            chance = 0.25,
        },
        {
            itemid = "ammo.pistol",
            amount = {25, 80},
            chance = 0.45,
        },
        {
            itemid = "ammo.rifle",
            amount = {15, 25},
            chance = 0.45,
        },
        {
            itemid = "explosive.timed",
            amount = {1, 1},
            chance = 0.10,
        },
        {
            itemid = "explosive.satchel",
            amount = {2, 4},
            chance = 0.15,
        },
        {
            itemid = "gears",
            amount = {2, 5},
            chance = 0.25,
        }
    }

    local availableItems = {}
    for _, itemData in ipairs(suplyCrateLootItems) do
        local itemDef = gRust.Items[itemData.itemid]
        if itemDef then
            table.insert(availableItems, itemData)
        end
    end

    if #availableItems == 0 then return end

    if self.Inventory then
        for i = 1, self.InventorySlots do
            if self.Inventory[i] then
                self:RemoveSlot(i)
            end
        end
    end

    local itemCount = math.random(4, 8)
    local shuffledItems = {}
    
    for i = 1, #availableItems do
        table.insert(shuffledItems, availableItems[i])
    end
    for i = #shuffledItems, 2, -1 do
        local j = math.random(i)
        shuffledItems[i], shuffledItems[j] = shuffledItems[j], shuffledItems[i]
    end

    local currentSlot = 1
    local addedItems = 0

    for _, itemData in ipairs(shuffledItems) do
        if addedItems >= itemCount or currentSlot > self.InventorySlots then
            break
        end

        local randomChance = math.random()
        if randomChance <= itemData.chance then
            local amount = 1
            if type(itemData.amount) == "table" then
                amount = math.random(itemData.amount[1], itemData.amount[2])
            else
                amount = itemData.amount
            end

            local item = gRust.CreateItem(itemData.itemid, amount)
            if item then
                self:SetSlot(item, currentSlot)
                currentSlot = currentSlot + 1
                addedItems = addedItems + 1
            end
        end
    end
end

function ENT:RemoveSlot(slot)
    BaseClass.RemoveSlot(self, slot)

    timer.Simple(0.1, function()
        if IsValid(self) then
            self:CheckIfEmptyAndScheduleRespawn()
        end
    end)
end

function ENT:IsInventoryEmpty()
    if not self.Inventory then return true end
    
    for i = 1, self.InventorySlots do
        if self.Inventory[i] then
            return false
        end
    end
    
    return true
end

function ENT:CheckIfEmptyAndScheduleRespawn()
    if self:IsInventoryEmpty() then
       self:ScheduleRespawn()
    end
end

function ENT:ScheduleRespawn()
    local pos = self.SpawnPosition or self:GetPos()
    local ang = self.SpawnAngles or self:GetAngles()
    local respawnTime = 600 -- 5m

    timer.Remove("CheckEmpty_" .. self:EntIndex())
    
    self:Remove()
end

function ENT:Use(activator, caller)
    BaseClass.Use(self, activator, caller)
end

function ENT:Think()
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        local vel = phys:GetVelocity()

        -- Ограничиваем скорость падения
        if vel.z < -self.MaxFallSpeed then
            vel.z = -self.MaxFallSpeed
            phys:SetVelocity(vel)
        end

        -- Дополнительное торможение при падении
        if self.IsFalling and vel.z < -10 then -- Уменьшен порог
            -- Увеличена тормозящая сила
            local brakeForce = Vector(0, 0, math.abs(vel.z) * 4)
            phys:ApplyForceCenter(brakeForce)

            -- Более медленное покачивание
            local swayForce = Vector(
                math.sin(CurTime() * 0.2) * 2, -- Еще медленнее
                math.cos(CurTime() * 0.15) * 2,
                0
            )
            phys:ApplyForceCenter(swayForce)
        end

        if self.IsFalling then
            local tr = util.TraceLine({
                start = self:GetPos(),
                endpos = self:GetPos() + Vector(0, 0, -200), -- Увеличена дистанция
                filter = self
            })
            
            if tr.Hit and tr.HitNormal.z > 0.7 then
                -- Приземление при еще меньшей скорости
                if vel.z > -15 and not self.LandingSound then
                    self.IsFalling = false
                    self.LandingSound = true

                    self:SetBodygroup(0,0)
                    

                    timer.Simple(0.1, function()
                        if IsValid(self) and IsValid(phys) then
                            phys:SetDragCoefficient(0.1)
                            phys:SetAngleDragCoefficient(500)
                            phys:SetMass(15000) 
                        end
                    end)
                end
            end
        end
    end
    
    self:NextThink(CurTime() + 0.03) -- Еще более частая проверка
    return true
end

function ENT:OnDestroyed(dmg)
    if self.SpawnPosition then
        self:ScheduleRespawn()
    end
end

function ENT:OnRemove()
    timer.Remove("CheckEmpty_" .. self:EntIndex())
end
