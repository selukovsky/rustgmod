AddCSLuaFile()

if SERVER then Logger("Loaded rust_recycler") end

ENT.Base = "rust_process"
ENT.Deploy = {}
ENT.Deploy.Model = "models/environment/misc/recycler.mdl"
ENT.ProcessTime = 1.0
ENT.StopOnEmpty = true
ENT.RecycleRate = 0.5
ENT.OpenSoundType = "recycler"
ENT.DisplayIcon = gRust.GetIcon("open")

function ENT:Initialize()
    if CLIENT then return end

    self:SetUseType(SIMPLE_USE)
    self:SetModel("models/environment/misc/recycler.mdl")
    self:PhysicsInitStatic(SOLID_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetInteractable(true)
    self:CreateInventory(12)
    self:SetDisplayName("OPEN")
    self:SetNW2Bool("gRust.Enabled", false)
    self:SetNW2Bool("gRust.Processing", false)
    self:SetNW2Float("gRust.ProcessProgress", 0)

    -- Переменные для управления звуками
    self.IsLoopSoundPlaying = false
    self.LastEnabledState = false
end

function ENT:PlayRecyclerLoopSound()
    if self.IsLoopSoundPlaying then return end
    
    self.IsLoopSoundPlaying = true
    self.RecyclerLoopSound = CreateSound(self, "rust/loop.wav")
    if self.RecyclerLoopSound then
        self.RecyclerLoopSound:Play()
    end
end

function ENT:StopRecyclerLoopSound()
    if not self.IsLoopSoundPlaying then return end
    
    self.IsLoopSoundPlaying = false
    if self.RecyclerLoopSound then
        self.RecyclerLoopSound:Stop()
        self.RecyclerLoopSound = nil
    end
end

function ENT:PlayDisableSound()
    self:EmitSound("rust/stop.wav", 75, 100)
end

function ENT:SetEnabledState(state)
    local currentState = self:GetNW2Bool("gRust.Enabled", false)
    if state == currentState then return end
    
    self:SetNW2Bool("gRust.Enabled", state)
    
    if state then
        self:StartProcessing()
        self:PlayRecyclerLoopSound() -- Начинаем непрерывный звук работы
    else
        self:StopProcessing()
        self:StopRecyclerLoopSound() -- Останавливаем непрерывный звук
        self:PlayDisableSound() -- Проигрываем звук выключения один раз
    end
end

function ENT:OnRemove()
    self:StopRecyclerLoopSound()
end

function ENT:OnTakeDamage()
    return false
end

function ENT:SyncSlot(i)
    local item = self.Inventory[i]
    if item then
        self:SetNW2String("Slot_" .. i .. "_Class", item:GetItem())
        self:SetNW2Int("Slot_" .. i .. "_Quantity", item:GetQuantity())
    else
        self:SetNW2String("Slot_" .. i .. "_Class", "")
        self:SetNW2Int("Slot_" .. i .. "_Quantity", 0)
    end
end

function ENT:SyncAllSlots()
    if not self.Inventory then return end
    for i = 1, #self.Inventory do
        self:SyncSlot(i)
    end
end

function ENT:GetProcessResult(itemClass)
    local itemData = gRust.Items[itemClass]
    if not itemData then return nil end
    local craft = itemData:GetCraft()
    if type(craft) ~= "table" then return nil end
    local results = {}
    for _, ingredient in ipairs(craft) do
        local amount = math.floor(ingredient.amount * self.RecycleRate)
        if amount > 0 then
            table.insert(results, {
                item = ingredient.item,
                amount = amount
            })
        end
    end
    self:SyncAllSlots()
    return #results > 0 and results or nil
end

function ENT:CanProcess()
    for i = 7, 12 do
        local item = self.Inventory[i]
        if item then
            local results = self:GetProcessResult(item:GetItem())
            if results and #results > 0 then return true end
        end
    end
    return true
end

function ENT:Toggle()
    local newState = not self:GetNW2Bool("gRust.Enabled", false)
    self:SetEnabledState(newState)
end

function ENT:StartProcessing()
    if self:GetNW2Bool("gRust.Processing", false) then return end

    if not self:CanProcess() then
        self:SetEnabledState(false)
        return
    end

    self:SetNW2Bool("gRust.Processing", true)
    self:SetNW2Float("gRust.ProcessStart", CurTime())
    self:SetNW2Float("gRust.ProcessTime", self.ProcessTime)

    timer.Create("Recycler_" .. self:EntIndex(), self.ProcessTime, 1, function()
        if IsValid(self) then
            self:CompleteProcess()
        end
    end)
end

function ENT:Use(activator, caller)
    if caller:IsPlayer() then self.LastUser = caller end
end

function ENT:StopProcessing()
    self:SetNW2Bool("gRust.Processing", false)
    self:SetNW2Float("gRust.ProcessProgress", 0)
    timer.Remove("Recycler_" .. self:EntIndex())
end

function ENT:AddItem(itemClass, amount, data, startSlot, endSlot)
    startSlot = startSlot or 1
    endSlot = endSlot or 6

    local itemData = gRust.Items[itemClass]
    if not itemData then 
        return false 
    end

    local maxStack = itemData:GetStack() or 1
    local remainingAmount = amount


    -- Функция для создания нового предмета
    local function CreateNewItem(qty)
        local newItem = gRust.CreateItem(itemClass, qty, data)
        if not newItem then
            return nil
        end
        return newItem
    end

    -- Шаг 1: Попытка добавить к существующим стакам
    for i = startSlot, endSlot do
        if remainingAmount <= 0 then break end
        
        local slotItem = self.Inventory[i]
        if slotItem and slotItem:GetItem() == itemClass then
            local currentQty = slotItem:GetQuantity()
            if currentQty < maxStack then
                local canAdd = math.min(remainingAmount, maxStack - currentQty)
                
                if canAdd > 0 then
                    
                    if slotItem.AddQuantity then
                        slotItem:AddQuantity(canAdd)
                    elseif slotItem.SetQuantity then
                        slotItem:SetQuantity(currentQty + canAdd)
                    else
                        -- Создаем новый предмет и заменяем старый
                        local newItem = CreateNewItem(currentQty + canAdd)
                        if newItem then
                            self.Inventory[i] = newItem
                        end
                    end
                    
                    remainingAmount = remainingAmount - canAdd
                    self:SyncSlot(i)
                end
            end
        end
    end

    -- Шаг 2: Создание новых стаков в пустых слотах
    if remainingAmount > 0 then
        for i = startSlot, endSlot do
            if remainingAmount <= 0 then break end
            
            if not self.Inventory[i] then
                local createAmount = math.min(remainingAmount, maxStack)
                local newItem = CreateNewItem(createAmount)
                
                if newItem then
                    self.Inventory[i] = newItem
                    remainingAmount = remainingAmount - createAmount
                    self:SyncSlot(i)
                else
                end
            end
        end
    end

    -- Шаг 3: Если все еще есть остаток, пытаемся добавить в частично заполненные стаки
    -- (на случай если новые стаки создались а в старых осталось место)
    if remainingAmount > 0 then
        for i = startSlot, endSlot do
            if remainingAmount <= 0 then break end
            
            local slotItem = self.Inventory[i]
            if slotItem and slotItem:GetItem() == itemClass then
                local currentQty = slotItem:GetQuantity()
                if currentQty < maxStack then
                    local canAdd = math.min(remainingAmount, maxStack - currentQty)
                    
                    if canAdd > 0 then
                        
                        if slotItem.AddQuantity then
                            slotItem:AddQuantity(canAdd)
                        elseif slotItem.SetQuantity then
                            slotItem:SetQuantity(currentQty + canAdd)
                        end
                        
                        remainingAmount = remainingAmount - canAdd
                        self:SyncSlot(i)
                    end
                end
            end
        end
    end

    -- Синхронизируем все слоты
    self:SyncAllSlots()
    
    local success = remainingAmount <= 0
    if success then
    else
    end
    
    return success
end

function ENT:CompleteProcess()
    local processed = false
    
    for i = 7, 12 do
        local item = self.Inventory[i]
        if item then
            local results = self:GetProcessResult(item:GetItem())
            if results then
                -- Проверяем можем ли мы добавить все результаты
                local canAddAll = true
                local requiredSlots = {}
                
                for _, result in ipairs(results) do
                    local neededAmount = result.amount
                    local availableSpace = 0
                    
                    -- Проверяем существующие стаки
                    for slot = 1, 6 do
                        local slotItem = self.Inventory[slot]
                        if slotItem and slotItem:GetItem() == result.item then
                            local maxStack = gRust.Items[result.item]:GetStack() or 1
                            availableSpace = availableSpace + (maxStack - slotItem:GetQuantity())
                        end
                    end
                    
                    -- Проверяем пустые слоты
                    local emptySlots = 0
                    for slot = 1, 6 do
                        if not self.Inventory[slot] then
                            emptySlots = emptySlots + 1
                        end
                    end
                    
                    local maxStack = gRust.Items[result.item]:GetStack() or 1
                    local totalAvailableSpace = availableSpace + (emptySlots * maxStack)
                    
                    if totalAvailableSpace < result.amount then
                        canAddAll = false
                        break
                    end
                end
                
                if canAddAll then
                    -- Удаляем 1 предмет из входного слота
                    item:RemoveQuantity(1)
                    
                    if item:GetQuantity() <= 0 then
                        self.Inventory[i] = nil
                        self:SyncSlot(i)
                    else
                        self:SyncSlot(i)
                    end
                    
                    -- Добавляем результаты переработки
                    for _, result in ipairs(results) do
                        local added = self:AddItem(result.item, result.amount, nil, 1, 6)
                        if not added then
                        end
                    end
                    
                    processed = true
                    break
                else
                    -- Не хватает места для результатов
                    self:SetNW2Bool("gRust.Enabled", false)
                    self:StopProcessing()
                    if self.LastUser and IsValid(self.LastUser) then
                        self.LastUser:ChatPrint("Recycler: Not enough space in output slots!")
                    end
                    return
                end
            end
        end
    end
    
    if processed then
        self:StopProcessing()
        
        -- Проверяем есть ли еще предметы для переработки
        if self:GetNW2Bool("gRust.Enabled", false) and self:CanProcess() then
            timer.Simple(0.1, function()
                if IsValid(self) then 
                    self:StartProcessing() 
                end
            end)
        else
            if self.StopOnEmpty then
                self:SetNW2Bool("gRust.Enabled", false)
                if self.LastUser and IsValid(self.LastUser) then
                    self.LastUser:ChatPrint("Recycler: No more items to process.")
                end
            end
        end
    else
        -- Не нашли предметов для переработки
        self:SetNW2Bool("gRust.Enabled", false)
        self:StopProcessing()
        if self.LastUser and IsValid(self.LastUser) then
            self.LastUser:ChatPrint("Recycler: No valid items to process.")
        end
    end
end

function ENT:FindEmptySlot(start, finish, item)
    if not self.Inventory then return nil end
    start = start or 1
    finish = finish or 12
    
    -- Сначала ищем существующие стаки для этого предмета
    if item then
        local itemClass = item:GetItem()
        local maxStack = gRust.Items[itemClass] and gRust.Items[itemClass]:GetStack() or 1
        
        for i = start, finish do
            local existingItem = self.Inventory[i]
            if existingItem and existingItem:GetItem() == itemClass then
                if existingItem:GetQuantity() < maxStack then
                    return i
                end
            end
        end
    end
    
    -- Затем ищем пустые слоты
    for i = start, finish do
        if not self.Inventory[i] then
            return i
        end
    end
    
    return nil
end

function ENT:Togglez()
    net.Start("gRust.RecyclerToggle")
    net.WriteEntity(self)
    net.SendToServer()
end

net.Receive("gRust.RecyclerToggle", function(len, ply)
    local ent = net.ReadEntity()
    if IsValid(ent) and ent:GetClass() == "rust_recycler" and ent.LastUser == ply then ent:Toggle() end
end)

local Container
local upd = nil

-- Фон панели управления
local function PaintBackground(me, w, h)
    surface.SetDrawColor(50, 50, 50, 200)
    surface.DrawRect(0, 0, w, h)
    surface.SetDrawColor(0, 0, 0, 150)
    surface.DrawOutlinedRect(0, 0, w, h)
end

-- Текст для подсказки
local TOGGLE_ON_TEXT = [[The recycler is enabled.
It will continue to recycle items until it runs out or is turned off.]]
local TOGGLE_OFF_TEXT = [[The recycler is off.
Place items in the input slots and turn it on.]]

-- Основная функция построения интерфейса
function ENT:ConstructInventory(panel, data, rows)
    if IsValid(Container) then 
        Container:Remove() 
    end

    Container = panel:Add("Panel")
    Container:Dock(FILL)

    local LeftMargin = ScrW() * 0.02
    local RightMargin = ScrW() * 0.05
    local Margin = ScrH() * 0.01

    ------------------------------------------------------------------------
    -- ПАНЕЛЬ УПРАВЛЕНИЯ (ПЕРЕНЕСЕНА ИЗ CL_INIT.LUA)
    ------------------------------------------------------------------------
    local ControlPanel = Container:Add("Panel")
    ControlPanel:Dock(BOTTOM)
    ControlPanel:DockMargin(LeftMargin, 20 * gRust.Scaling, RightMargin, ScrH() * 0.15)
    ControlPanel:SetTall(184 * gRust.Scaling)
    ControlPanel.Paint = PaintBackground

    -- Заголовок панели управления
    local Title = ControlPanel:Add("Panel")
    Title:Dock(TOP)
    Title:SetTall(30 * gRust.Scaling)
    Title:DockMargin(0, 0, 0, 2 * gRust.Scaling)
    Title.Paint = function(me, w, h)
        surface.SetDrawColor(80, 76, 70, 100)
        surface.DrawRect(0, 0, w, h)
        draw.SimpleText("CONTROLS", "gRust.28px", 8 * gRust.Scaling, h / 2, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    local ContentPanel = ControlPanel:Add("Panel")
    ContentPanel:Dock(FILL)
    ContentPanel:DockPadding(10 * gRust.Scaling, 10 * gRust.Scaling, 10 * gRust.Scaling, 10 * gRust.Scaling)

    local ToggleButton = ContentPanel:Add("gRust.ToggleButton")
    ToggleButton:Dock(LEFT)
    ToggleButton:SetWide(256 * gRust.Scaling)
    ToggleButton:SetToggled(self:GetNW2Bool("gRust.Enabled", false))

    local Info = ContentPanel:Add("DLabel")
    Info:Dock(FILL)
    Info:SetWrap(true)
    Info:SetFont("gRust.28px")
    Info:SetTextColor(Color(255, 255, 255))
    Info:DockMargin(20 * gRust.Scaling, 0, 0, 0)
    Info:SetContentAlignment(7)
    
    -- Тексты подсказок
    local TOGGLE_ON_TEXT = [[The recycler is on. It will continue to recycle items until they run out or it is switched off.]]
    local TOGGLE_OFF_TEXT = [[The recycler is off. Input items to recycle and switch it on.]]

    -- Устанавливаем начальный текст
    Info:SetText(self:GetNW2Bool("gRust.Enabled", false) and TOGGLE_ON_TEXT or TOGGLE_OFF_TEXT)

    -- Обработка переключения
    ToggleButton.OnToggle = function(me, toggled)
        net.Start("gRust.RecyclerToggle")
        net.WriteEntity(self)
        net.SendToServer()
    end

    -- Обновление состояния
    ToggleButton.Think = function(me)
        local toggled = self:GetNW2Bool("gRust.Enabled", false)
        if toggled then
            Info:SetText(TOGGLE_ON_TEXT)
            ToggleButton:SetToggled(true)
        else
            Info:SetText(TOGGLE_OFF_TEXT)
            ToggleButton:SetToggled(false)
        end
    end

    ------------------------------------------------------------------------
    -- СЛОТЫ ИНВЕНТАРЯ
    ------------------------------------------------------------------------
    local i = 1
    local function CreateRow(name)
        local Grid = Container:Add("gRust.Inventory.SlotGrid")
        Grid:Dock(BOTTOM)
        Grid:SetCols(6)
        Grid:SetRows(1)
        Grid:SetInventoryOffset((i - 1) * 6)
        Grid:SetEntity(self)
        Grid:SetMargin(data.margin)
        Grid:DockMargin(LeftMargin, 0, RightMargin, ScrH() * 0.01)
        Grid:SetTall((data.wide / 8) + data.margin)

        local Name = Container:Add("Panel")
        Name:Dock(BOTTOM)
        Name:SetTall(ScrH() * 0.03)
        Name:DockMargin(LeftMargin - ScrW() * 0.005, 0, RightMargin, ScrH() * 0.008)
        Name.Paint = function(me, w, h)
            surface.SetDrawColor(80, 76, 70, 100)
            surface.DrawRect(0, 0, w, h)
            draw.SimpleText(name, "gRust.38px", w * 0.01, h * 0.5, Color(255, 255, 255, 200), 0, 1)
        end

        i = i + 1
    end

    -- Добавляем строки: "Выход" и "Вход"
    CreateRow("Output")
    CreateRow("Input")

    ------------------------------------------------------------------------
    -- Закрытие инвентаря, если игрок слишком далеко
    ------------------------------------------------------------------------
    local distance = LocalPlayer():GetPos():Distance(self:GetPos())
    if distance > 200 then
        gRust.CloseInventory()
        return
    end

    upd = data.entity
end


hook.Add("InitPostEntity", "SpawnRecyclerOnStart", function()
    timer.Simple(5, function() -- Задержка 5 секунд для полной инициализации сервера
        if not game.IsDedicated() then return end -- Только на сервере
        
        -- Позиция и угол для спавна (настройте под вашу карту)
        local spawnPos = Vector(0, 0, 0) -- Замените на нужные координаты
        local spawnAng = Angle(0, 0, 0)  -- Замените на нужный угол
        
        -- Проверяем, нет ли уже recycler на карте
        local existingRecyclers = ents.FindByClass("rust_recycler")
        if #existingRecyclers > 0 then
            print("Recycler already exists on map, skipping auto-spawn")
            return
        end
        
        -- Создаем recycler
        local recycler = ents.Create("rust_recycler")
        if IsValid(recycler) then
            recycler:SetPos(spawnPos)
            recycler:SetAngles(spawnAng)
            recycler:Spawn()
            
            print("Auto-spawned recycler at position: " .. tostring(spawnPos))
        else
            print("Failed to auto-spawn recycler")
        end
    end)
end)

-- Альтернативный вариант с проверкой через PostCleanupMap (после очистки карты)
hook.Add("PostCleanupMap", "SpawnRecyclerAfterCleanup", function()
    timer.Simple(3, function()
        if not game.IsDedicated() then return end
        
        local spawnPos = Vector(0, 0, 0) -- Замените на нужные координаты
        local spawnAng = Angle(0, 0, 0)  -- Замените на нужный угол
        
        local existingRecyclers = ents.FindByClass("rust_recycler")
        if #existingRecyclers == 0 then
            local recycler = ents.Create("rust_recycler")
            if IsValid(recycler) then
                recycler:SetPos(spawnPos)
                recycler:SetAngles(spawnAng)
                recycler:Spawn()
                
                print("Spawned recycler after map cleanup at: " .. tostring(spawnPos))
            end
        end
    end)
end)