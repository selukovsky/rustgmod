AddCSLuaFile()

ENT.Base = "rust_base"

ENT.Model    = "models/darky_m/rust/reinforcedwindow.mdl"
ENT.MaxHealth   = 500

ENT.MeleeDamage     = 0.0
ENT.BulletDamage    = 0.1
ENT.ExplosiveDamage = 0.3

ENT.Deploy          = {}
ENT.Deploy.Rotation = 0
ENT.Deploy.Model    = "models/darky_m/rust/reinforcedwindow.mdl"
ENT.Deploy.Socket   = "window"
ENT.Deploy.Sound	= "deploy/reinforced_window_deploy.wav"

ENT.hqupkeep = 1

ENT.Pickup = "reinforced_window"