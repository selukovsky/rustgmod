AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")
util.AddNetworkString("gRust.PickupLock")

-- Переносим функцию FindNearestTC в начало файла
local function FindNearestTC(pos, radius)
    local nearest, best = nil, math.huge
    for _, v in ipairs(ents.FindInSphere(pos, radius or 300)) do
        if IsValid(v) and v:GetClass() == "rust_toolcupboard" then
            local d = pos:Distance(v:GetPos())
            if d < best then
                best = d
                nearest = v
            end
        end
    end
    return nearest
end

function ENT:SetupDataTables()
    self:NetworkVar("Bool", 0, "Opened")
    self:NetworkVar("String", 0, "DoorCode")
end

function ENT:Initialize()
    self:SetModel(self.Deploy.Model or "models/deployable/door_wood.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_NONE)
    
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(100)
        phys:EnableMotion(false)
    end

    self:SetOpened(false)
    self:SetBodygroup(2, 0)
    self.OriginalAngles = self:GetAngles()
    self.IsAnimating = false
    self.DoorCode = nil
    self:SetUseType(SIMPLE_USE)
    
    -- Создаем двойные двери
    self:CreateDoubleDoors()
end

function ENT:CreateDoubleDoors()
    local spacing = self.DoorSpacing or 50.7
    
    -- Левая дверь
    self.LeftDoor = ents.Create("prop_dynamic")
    if IsValid(self.LeftDoor) then
        self.LeftDoor:SetModel(self.LeftDoorModel or "models/darky_m/rust/metal_door_l.mdl")
        self.LeftDoor:SetPos(self:LocalToWorld(Vector(spacing, 0, 5)))
        self.LeftDoor:SetAngles(self:GetAngles() + Angle(0, 180, 0))
        self.LeftDoor:SetParent(self)
        self.LeftDoor:Spawn()
        self.LeftDoor:SetMoveType(MOVETYPE_NONE)
        self.LeftDoor:SetSolid(SOLID_VPHYSICS)
        
        -- Use функция для левой двери
        self.LeftDoor:SetUseType(SIMPLE_USE)
        self.LeftDoor.Use = function(door, activator, caller)
            if IsValid(self) then
                self:Use(activator, caller)
            end
        end
        
        -- Физика
        self.LeftDoor:PhysicsInit(SOLID_VPHYSICS)
        local leftPhys = self.LeftDoor:GetPhysicsObject()
        if IsValid(leftPhys) then
            leftPhys:EnableMotion(false)
            leftPhys:SetMass(50)
        end
    end
    
    -- Правая дверь
    self.RightDoor = ents.Create("prop_dynamic")
    if IsValid(self.RightDoor) then
        self.RightDoor:SetModel(self.RightDoorModel or "models/deployable/metal_door.mdl")
        self.RightDoor:SetPos(self:LocalToWorld(Vector(-spacing, 0, 5)))
        self.RightDoor:SetAngles(self:GetAngles() + Angle(0, 0, 0))
        self.RightDoor:SetParent(self)
        self.RightDoor:Spawn()
        self.RightDoor:SetMoveType(MOVETYPE_NONE)
        self.RightDoor:SetSolid(SOLID_VPHYSICS)
        
        -- Use функция для правой двери
        self.RightDoor:SetUseType(SIMPLE_USE)
        self.RightDoor.Use = function(door, activator, caller)
            if IsValid(self) then
                self:Use(activator, caller)
            end
        end
        
        -- Физика
        self.RightDoor:PhysicsInit(SOLID_VPHYSICS)
        local rightPhys = self.RightDoor:GetPhysicsObject()
        if IsValid(rightPhys) then
            rightPhys:EnableMotion(false)
            rightPhys:SetMass(50)
        end
    end
    
    -- Сохраняем исходные углы
    if IsValid(self.LeftDoor) then
        self.LeftDoorOriginalAngles = self.LeftDoor:GetAngles()
    end
    if IsValid(self.RightDoor) then
        self.RightDoorOriginalAngles = self.RightDoor:GetAngles()
    end
end

function ENT:Use(activator, caller)
    if not IsValid(activator) or not activator:IsPlayer() then return end
    if self.IsAnimating then return end

    local trace = activator:GetEyeTrace()
    local hitEntity = trace.Entity
    
    -- Если нажали на левую или правую дверь
    if hitEntity == self.LeftDoor or hitEntity == self.RightDoor then
        hitEntity = self
    end
    
    if hitEntity ~= self then return end

    local tc = self:FindNearestTC(self:GetPos(), 300)

    if self:GetBodygroup(2) == 0 then
        self:ToggleDoor()
        return
    end

    if tc then
        local hasAccess = tc:IsAuthorized(activator)
        if hasAccess then
            self:ToggleDoor()
        else
            activator:ChatPrint("You are not authorized on the nearby Tool Cupboard.")
        end
    else
        activator:ChatPrint("A Tool Cupboard is required nearby to unlock this door.")
    end
end

function ENT:FindNearestTC(pos, radius)
    local nearest, best = nil, math.huge
    for _, v in ipairs(ents.FindInSphere(pos, radius or 300)) do
        if IsValid(v) and v:GetClass() == "rust_toolcupboard" then
            local d = pos:Distance(v:GetPos())
            if d < best then
                best = d
                nearest = v
            end
        end
    end
    return nearest
end

function ENT:ToggleDoor()
    if self.IsAnimating then return end
    
    local isOpened = self:GetOpened()
    self:SetOpened(not isOpened)
    self.IsAnimating = true
    
    self:ToggleDoubleDoor(not isOpened)
end

function ENT:ToggleDoubleDoor(shouldOpen)
    if not IsValid(self.LeftDoor) or not IsValid(self.RightDoor) then 
        self.IsAnimating = false
        return 
    end
    
    local leftTarget, rightTarget
    
    if shouldOpen then
        leftTarget = self.LeftDoorOriginalAngles + Angle(0, -90, 0)
        rightTarget = self.RightDoorOriginalAngles + Angle(0, 90, 0)
        self:EmitSound("doors/door_metal_open.wav")
    else
        leftTarget = self.LeftDoorOriginalAngles
        rightTarget = self.RightDoorOriginalAngles
        self:EmitSound("doors/door_metal_close.wav")
    end
    
    self:AnimateDoubleDoors(leftTarget, rightTarget, 0.5)
end

function ENT:AnimateDoubleDoors(leftTarget, rightTarget, duration)
    local startTime = CurTime()
    local leftStart = self.LeftDoor:GetAngles()
    local rightStart = self.RightDoor:GetAngles()
    
    local function updateDoors()
        if not IsValid(self) or not IsValid(self.LeftDoor) or not IsValid(self.RightDoor) then 
            self.IsAnimating = false
            return 
        end
        
        local progress = math.min((CurTime() - startTime) / duration, 1)
        
        local leftCurrent = LerpAngle(progress, leftStart, leftTarget)
        local rightCurrent = LerpAngle(progress, rightStart, rightTarget)
        
        self.LeftDoor:SetAngles(leftCurrent)
        self.RightDoor:SetAngles(rightCurrent)
        
        if progress >= 1 then
            self.IsAnimating = false
            
            if not self:GetOpened() then
                self:EmitSound("doors/door_metal_shut.wav")
            end
            
            return
        end

        timer.Simple(0.01, updateDoors)
    end

    updateDoors()
end

function ENT:OnRemove()
    if IsValid(self.LeftDoor) then
        self.LeftDoor:Remove()
    end
    if IsValid(self.RightDoor) then
        self.RightDoor:Remove()
    end
end