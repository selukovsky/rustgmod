AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

DEFINE_BASECLASS("rust_base")

function ENT:Initialize()
    if CLIENT then return end

    self:SetModel("models/darky_m/rust/puzzle/card_reader.mdl")
    self:SetSolid(SOLID_VPHYSICS)
    self:PhysicsInit(SOLID_VPHYSICS)
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:EnableMotion(false)
        phys:Sleep()
    end
    BaseClass.Initialize(self)

    self:AutoSetLevel()
    self.LinkedDoor = nil
    self:FindAndSetLinkedDoor()
    self:SetSkin(0)
end

function ENT:AutoSetLevel()
    local pos = self:GetPos()

    if math.abs(pos.x - 4012) < 10 and math.abs(pos.y - 864) < 10 and math.abs(pos.z - 551.310974) < 10 then
        self.Level = 2
    elseif math.abs(pos.x - (-8273.379883)) < 10 and math.abs(pos.y - 9811.030273) < 10 and math.abs(pos.z - 349.311005) < 10 then
        self.Level = 1
    elseif math.abs(pos.x - (-1744)) < 10 and math.abs(pos.y - (-1279.239990)) < 10 and math.abs(pos.z - 439.311005) < 10 then
        self.Level = 0
    else
        self.Level = 0
    end
end

function ENT:GetLevel()
    return self.Level
end

function ENT:SetLinkedDoor(doorEntity)
    self.LinkedDoor = doorEntity
end

function ENT:FindAndSetLinkedDoor()
    local dist = 100
    for _, ent in pairs(ents.FindInSphere(self:GetPos(), dist)) do
        if IsValid(ent) and ent:GetClass() == "rust_puzzledoor" then
            self:SetLinkedDoor(ent)
            break
        end
    end
end

function ENT:AcceptKeycard(user, cardLevel, slotID)
    local door = self.LinkedDoor
    if IsValid(door) and (door:GetOpened() or door.IsAnimating) then return false end
    if cardLevel ~= self:GetLevel() then return false end
    if not self:HasPower() then return false end

    user:EmitSound("weapons/rust_mp3/keycard_swipe.mp3")

    timer.Simple(0.5, function()
        if not IsValid(self) or not IsValid(user) then return end

        local item = user.Inventory[slotID]
        if item and item.GetWear then
            local currentWear = item:GetWear()
            local newWear = currentWear - (1000 * 0.35)
            newWear = math.max(0, newWear)
            item:SetWear(newWear)

            if newWear <= 0 then
                user:RemoveSlot(slotID)
                if user:GetActiveWeapon():GetClass() == "rust_card" then
                    user:StripWeapon("rust_card")
                end
            end

            user:SyncSlot(slotID)
        end

        local door = self.LinkedDoor
        if IsValid(door) then
            door:EmitSound("doors/keypad_beep.wav")
            door:EmitSound("doors/door_metal_open.wav")
            door:OpenDoorForDuration(10)
            self.LastUseTime = CurTime()
        end
    end)

    return true
end

function ENT:HasPower()
    local dist = 2000
    for _, ent in pairs(ents.FindInSphere(self:GetPos(), dist)) do
        if ent:GetClass() == "rust_fusebox" and ent.HasPower then
            self:SetSkin(self.Level + 1)
            return ent.HasPower
        end
    end
    self:SetSkin(0)
    return false
end

function ENT:Think()
    self:HasPower()
    self:NextThink(CurTime() + 1)
    return true
end