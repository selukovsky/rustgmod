AddCSLuaFile()

ENT.Base = "rust_base"

-- Настройки деплоя
ENT.Deploy = {}
ENT.Deploy.Model = "models/props_lab/citizenradio.mdl"
ENT.Deploy.HitNormal = 0.7
ENT.Deploy.SnapNormal = 0.7
ENT.Deploy.MaxPerPlayer = 2

ENT.RadioStations = {
    ["rust"] = {
        name = "Rust Radio",
        sounds = {
            "radio/rust/rust-farm.wav",
            "radio/rust/rust-airwolf.wav",
            "radio/rust/rust-beach.wav",
            "radio/rust/rust-boat.wav",
            "radio/rust/rust-wastes.wav"
        },
        volume = 0.7
    },
    ["chippy"] = {
        name = "Chippy Radio", 
        sounds = {
            "radio/chippy/chippy-main.wav"
        },
        volume = 0.8
    },
    ["sonis"] = {
        name = "Sonis Radio",
        sounds = {
            "radio/sonis/sonis-dis.wav",
            "radio/sonis/sonis-six.wav", 
            "radio/sonis/sonis-stone.wav"
        },
        volume = 0.75
    }
}

function ENT:SetupDataTables()
    self:NetworkVar("String", 1, "CurrentStation")
    self:NetworkVar("Bool", 1, "RadioEnabled")
    self:NetworkVar("Float", 0, "Volume")
end

function ENT:Initialize()
    if self.BaseClass and self.BaseClass.Initialize then
        self.BaseClass.Initialize(self)
    end
    
    self:SetModel(self.Deploy.Model or "models/props_lab/citizenradio.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(10)
        phys:EnableMotion(false) -- Статичный после деплоя
    end

    -- Настройки повреждений
    self:SetDamageable(true)
    self:SetHealth(150)
    self:SetMeleeDamage(0.2)
    self:SetBulletDamage(0.2)
    self:SetExplosiveDamage(0.4)
    
    -- Настройки радио
    self:SetCurrentStation("")
    self:SetRadioEnabled(false)
    self:SetVolume(0.7)
    
    -- Убираем проблемную строку и заменяем на альтернативный способ
    if SERVER then
        self:SetUseType(SIMPLE_USE) -- Включаем использование
    end
    
    self.CurrentSound = nil
    self.SoundQueue = {}
    self.IsPlaying = false
    
    if SERVER then
        self:SetSaveValue("m_bStatic", true)
    end
end

function ENT:Use(activator, caller)
    if CLIENT then return end
    if not IsValid(activator) or not activator:IsPlayer() then return end
    
    -- Проверяем расстояние
    if self:GetPos():Distance(activator:GetPos()) > 200 then
        activator:ChatPrint("You are too far from the radio!")
        return
    end
    
    -- Открываем круговое меню
    net.Start("gRust.OpenRadioMenu")
    net.WriteEntity(self)
    net.Send(activator)
end

-- Серверные функции для управления радио
if SERVER then
    util.AddNetworkString("gRust.OpenRadioMenu")
    util.AddNetworkString("gRust.ChangeRadioStation")
    util.AddNetworkString("gRust.StopRadio")
    
    -- Обработчик смены радиостанции
    net.Receive("gRust.ChangeRadioStation", function(len, ply)
        local radio = net.ReadEntity()
        local stationName = net.ReadString()
        
        if not IsValid(radio) or not IsValid(ply) then return end
        if radio:GetClass() ~= "rust_radio" then return end
        
        -- Проверяем расстояние
        if radio:GetPos():Distance(ply:GetPos()) > 200 then
            ply:ChatPrint("You are too far from the radio!")
            return
        end
        
        -- Запускаем станцию
        if radio:StartStation(stationName) then
            local stationData = radio.RadioStations[stationName]
            local stationDisplayName = stationData and stationData.name or stationName
            ply:ChatPrint("Radio tuned to: " .. stationDisplayName)
            
            print("[RADIO] " .. ply:Nick() .. " changed station to: " .. stationName)
        else
            ply:ChatPrint("Failed to change radio station!")
            print("[RADIO] Failed to change station: " .. stationName)
        end
    end)
    
    -- Обработчик выключения радио
    net.Receive("gRust.StopRadio", function(len, ply)
        local radio = net.ReadEntity()
        
        if not IsValid(radio) or not IsValid(ply) then return end
        if radio:GetClass() ~= "rust_radio" then return end
        
        -- Проверяем расстояние
        if radio:GetPos():Distance(ply:GetPos()) > 200 then
            ply:ChatPrint("You are too far from the radio!")
            return
        end
        
        if radio:StopRadio() then
            ply:ChatPrint("Radio turned off")
            print("[RADIO] " .. ply:Nick() .. " turned off the radio")
        else
            ply:ChatPrint("Failed to turn off radio!")
        end
    end)
    
    function ENT:StartStation(stationName)
        if not self.RadioStations[stationName] then 
            print("[RADIO] Station not found: " .. stationName)
            return false 
        end
        
        self:SetCurrentStation(stationName)
        self:SetRadioEnabled(true)
        
        -- Запускаем воспроизведение на всех клиентах
        net.Start("gRust.ChangeRadioStation")
        net.WriteEntity(self)
        net.WriteString(stationName)
        net.WriteBool(true) -- start playing
        net.Broadcast()
        
        print("[RADIO] Station started: " .. stationName)
        return true
    end
    
    function ENT:StopRadio()
        if not self:GetRadioEnabled() then
            print("[RADIO] Radio is already off")
            return false
        end
        
        self:SetRadioEnabled(false)
        self:SetCurrentStation("")
        
        -- Останавливаем воспроизведение на всех клиентах
        net.Start("gRust.StopRadio")
        net.WriteEntity(self)
        net.Broadcast()
        
        print("[RADIO] Radio stopped successfully")
        return true
    end
    
    function ENT:OnRemove()
        self:StopRadio()
    end
    
    function ENT:OnDestroyed(dmg)
        self:StopRadio()
    end
end

-- Клиентские функции
if CLIENT then
    net.Receive("gRust.OpenRadioMenu", function()
        local radio = net.ReadEntity()
        if not IsValid(radio) then return end
        
        local menuElements = {
            {
                Name = "Rust Radio",
                Icon = "icons/fun.png",
                Condition = function(ent) return true end
            },
            {
                Name = "Chippy Radio", 
                Icon = "icons/fun.png",
                Condition = function(ent) return true end
            },
            {
                Name = "Sonis Radio",
                Icon = "icons/fun.png", 
                Condition = function(ent) return true end
            },
            {
                Name = "Turn Off",
                Icon = "icons/power.png",
                Condition = function(ent) 
                    return IsValid(ent) and ent.GetRadioEnabled and ent:GetRadioEnabled() == true
                end
            }
        }
        
        gRust.OpenPieMenu(menuElements, function(selection, ent)
            if not IsValid(ent) then return end
            
            if selection == 1 then
                net.Start("gRust.ChangeRadioStation")
                net.WriteEntity(ent)
                net.WriteString("rust")
                net.SendToServer()
            elseif selection == 2 then
                net.Start("gRust.ChangeRadioStation") 
                net.WriteEntity(ent)
                net.WriteString("chippy")
                net.SendToServer()
            elseif selection == 3 then
                net.Start("gRust.ChangeRadioStation")
                net.WriteEntity(ent) 
                net.WriteString("sonis")
                net.SendToServer()
            elseif selection == 4 then
                net.Start("gRust.StopRadio")
                net.WriteEntity(ent)
                net.SendToServer()
            end
        end, radio)
    end)
    
    net.Receive("gRust.ChangeRadioStation", function()
        local radio = net.ReadEntity()
        local stationName = net.ReadString()
        local startPlaying = net.ReadBool()
        
        if not IsValid(radio) then return end
        
        if startPlaying then
            radio:ClientStartStation(stationName)
        end
    end)
    
    net.Receive("gRust.StopRadio", function()
        local radio = net.ReadEntity()
        if IsValid(radio) then
            radio:ClientStopRadio()
        end
    end)
    
    function ENT:ClientStartStation(stationName)
        local station = self.RadioStations[stationName]
        if not station then 
            print("[RADIO] Station not found: " .. stationName)
            return 
        end
        
        self:ClientStopRadio() -- Останавливаем предыдущее воспроизведение
        
        self.CurrentStation = stationName
        self.SoundQueue = table.Copy(station.sounds)
        self.IsPlaying = true
        
        print("[RADIO] Client started station: " .. stationName .. " with " .. #self.SoundQueue .. " songs")
        self:PlayNextSong()
    end
    
    function ENT:ClientStopRadio()
        if self.CurrentSound then
            self.CurrentSound:Stop()
            self.CurrentSound = nil
        end
        
        if self.NextSongTimer then
            timer.Remove(self.NextSongTimer)
            self.NextSongTimer = nil
        end
        
        self.SoundQueue = {}
        self.IsPlaying = false
        self.CurrentStation = ""
        
        print("[RADIO] Client stopped radio")
    end
    
    function ENT:PlayNextSong()
        if not self.IsPlaying then 
            print("[RADIO] Not playing, stopping")
            return 
        end
        
        -- Если песни закончились, начинаем сначала
        if #self.SoundQueue == 0 then
            local station = self.RadioStations[self.CurrentStation]
            if station then
                self.SoundQueue = table.Copy(station.sounds)
                print("[RADIO] Restarting playlist for station: " .. self.CurrentStation)
            else
                print("[RADIO] No station found for: " .. tostring(self.CurrentStation))
                return
            end
        end
        
        local soundFile = table.remove(self.SoundQueue, 1)
        local station = self.RadioStations[self.CurrentStation]
        
        -- Проверяем существование файла
        if not file.Exists("sound/" .. soundFile, "GAME") then
            print("[RADIO] Sound file not found: sound/" .. soundFile)
            -- Пропускаем этот файл и играем следующий через 3 секунды
            timer.Simple(3, function()
                if IsValid(self) and self.IsPlaying then
                    self:PlayNextSong()
                end
            end)
            return
        end
        
        print("[RADIO] Playing: " .. soundFile)
        
        -- Останавливаем предыдущий звук
        if self.CurrentSound then
            self.CurrentSound:Stop()
            self.CurrentSound = nil
        end
        
        -- Создаем новый звук
        self.CurrentSound = CreateSound(self, soundFile)
        if not self.CurrentSound then
            print("[RADIO] Failed to create sound for: " .. soundFile)
            timer.Simple(3, function()
                if IsValid(self) and self.IsPlaying then
                    self:PlayNextSong()
                end
            end)
            return
        end
        
        local volume = station.volume or 0.7
        self.CurrentSound:SetSoundLevel(75)
        self.CurrentSound:PlayEx(volume, 100)
        
        print("[RADIO] Sound created and playing at volume: " .. volume)
        
        -- Получаем реальную длительность звука ДО воспроизведения
        sound.PlayFile("sound/" .. soundFile, "noplay", function(audio, errorId, errorName)
            if audio and not errorId then
                local duration = audio:GetLength()
                audio:Stop() -- Останавливаем тестовое воспроизведение
                
                print("[RADIO] Song duration: " .. duration .. " seconds")
                
                -- Планируем следующий трек через реальную длительность
                if self.NextSongTimer then
                    timer.Remove(self.NextSongTimer)
                end
                
                self.NextSongTimer = timer.Simple(duration + 1, function() -- +1 секунда задержки
                    if IsValid(self) and self.IsPlaying then
                        print("[RADIO] Moving to next song...")
                        self:PlayNextSong()
                    end
                end)
                
            else
                -- Если не удалось получить длительность, используем fallback
                print("[RADIO] Could not get duration for: " .. soundFile .. ", error: " .. (errorName or "unknown"))
                
                -- Слушаем когда звук закончится
                if self.NextSongTimer then
                    timer.Remove(self.NextSongTimer)
                end
                
                -- Альтернативный метод: проверяем каждую секунду, играет ли еще звук
                self.NextSongTimer = timer.Create("RadioCheck_" .. self:EntIndex(), 1, 0, function()
                    if not IsValid(self) or not self.IsPlaying then
                        timer.Remove("RadioCheck_" .. self:EntIndex())
                        return
                    end
                    
                    if not self.CurrentSound or not self.CurrentSound:IsPlaying() then
                        timer.Remove("RadioCheck_" .. self:EntIndex())
                        if self.IsPlaying then
                            print("[RADIO] Sound finished, playing next...")
                            self:PlayNextSong()
                        end
                    end
                end)
            end
        end)
    end

    function ENT:GetRadioEnabled()
        return self:GetNW2Bool("RadioEnabled", false) or self:GetNWBool("RadioEnabled", false)
    end

    function ENT:GetCurrentStation()
        return self:GetNW2String("CurrentStation", "") or self:GetNWString("CurrentStation", "")
    end
    
    function ENT:Think()
        -- Периодическая проверка состояния воспроизведения (fallback)
        if self.IsPlaying and not self.NextCheck then
            self.NextCheck = CurTime() + 10
        elseif self.NextCheck and CurTime() > self.NextCheck then
            self.NextCheck = nil
            if self.IsPlaying and (not self.CurrentSound or not self.CurrentSound:IsPlaying()) then
                print("[RADIO] Sound stopped unexpectedly, playing next...")
                self:PlayNextSong()
            end
        end
    end
    
    function ENT:OnRemove()
        self:ClientStopRadio()
    end
    
    function ENT:Draw()
        self:DrawModel()
    end
end