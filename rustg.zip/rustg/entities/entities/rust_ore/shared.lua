ENT.Base        = "rust_base"
ENT.Type        = "anim"