AddCSLuaFile()

ENT.Base = "rust_storage"
ENT.InventorySlots = 2
ENT.InventoryName = "Locker"

ENT.Deploy = {}
ENT.Deploy.Model = "models/props_lab/lockers.mdl"
ENT.Deploy.Sound = "deploy/small_wooden_box_deploy.wav"

ENT.Pickup = "loker"
ENT.DisplayIcon = gRust.GetIcon("open")
ENT.ShowHealth = true

function ENT:Initialize()
    if CLIENT then return end

    self:SetModel(self.Deploy.Model)
    self:PhysicsInitStatic(SOLID_VPHYSICS)
    self:CreateInventory(24)

    self:SetInteractable(true)
    self:SetDamageable(true)
    self:SetHealth(150)
    self:SetMaxHealth(150)

    self:SetMeleeDamage(0.2)
    self:SetBulletDamage(0.2)
    self:SetExplosiveDamage(0.4)
end

if CLIENT then
    function ENT:SwapLocker(slotid)
        if not IsValid(self) then return end
        if not self.Inventory then return end

        local player = LocalPlayer()
        if not player or not player.Inventory then return end

        slotid = slotid or 1

        if type(slotid) ~= "number" then
            slotid = 1
        end

        local takenItems = {}

        for slot = slotid, self.InventorySlots or 24 do
            local item = self.Inventory[slot]

            if item then
                local freeSlot = nil
                for playerSlot = 1, player.InventorySlots or 30 do
                    if not player.Inventory[playerSlot] then
                        freeSlot = playerSlot
                        break
                    end
                end

                if freeSlot then
                    player.Inventory[freeSlot] = item
                    self.Inventory[slot] = nil

                    LocalPlayer():MoveSlot(self, player, slot, freeSlot, item.Amount or 1)

                    table.insert(takenItems, {
                        item = item,
                        fromSlot = slot,
                        toSlot = freeSlot
                    })
                else
                    break
                end
            end
        end
        return takenItems
    end

    function ENT:ConstructInventory(panel, data, rows)
        if (IsValid(Container)) then
            Container:Remove()
            Container = nil
            InventoryPanel = nil
        end

        if (table.IsEmpty(data)) then
            return
        end

        local Rows = rows or (self.InventorySlots / 6)

        Container = panel:Add("Panel")
        Container:Dock(FILL)

        local LeftMargin = ScrW() * 0.02
        local RightMargin = ScrW() * 0.04

        InventoryPanel = Container:Add("Panel")
        InventoryPanel:Dock(BOTTOM)
        InventoryPanel:DockMargin(LeftMargin, 0, RightMargin, ScrH() * 0.165)

        local i = 1
        local function CreateRow(startSlot)
            local Margin = ScrH() * 0.01

            local ButtonPanel = Container:Add("Panel")
            ButtonPanel:Dock(BOTTOM)
            ButtonPanel:SetTall(ScrH() * 0.04)
            ButtonPanel:DockMargin(ScrW() * 0.02, 0, ScrW() * 0.04, ScrH() * 0.01)
            ButtonPanel.Paint = function(me, w, h)
                surface.SetMaterial(Material("materials/ui/background.png"))
                surface.SetDrawColor(126, 126, 126, 39)
                surface.DrawTexturedRect(0, 0, w, h)
            end

            local Grid = Container:Add("gRust.Inventory.SlotGrid")
            Grid:Dock(BOTTOM)
            Grid:SetCols(6)
            Grid:SetRows(1)
            Grid:SetInventoryOffset((i - 1) * 12)
            Grid:SetEntity(self)
            Grid:SetMargin(data.margin)
            Grid:DockMargin(LeftMargin, 0, RightMargin, ScrH() * 0.01)
            Grid:SetTall((data.wide / 8) + data.margin)

            local ToggleButton = ButtonPanel:Add("gRust.Button")
            ToggleButton:Dock(LEFT)
            ToggleButton:SetText("Swap")
            ToggleButton:SetDefaultColor(Color(69, 153, 0, 241))
            ToggleButton:SetHoveredColor(Color(42, 121, 42))
            ToggleButton.ActiveColor = Color(69, 153, 0, 241)
            ToggleButton:DockMargin(ScrH() * 0.15, Margin, Margin, Margin)
            ToggleButton:SetWide(ScrW() * 0.11)

            ToggleButton.DoClick = function(me)
                if IsValid(self) then
                    self:SwapLocker(startSlot or 1)
                end
            end

            local Name = Container:Add("Panel")
            Name:Dock(BOTTOM)
            Name:SetTall(ScrH() * 0.03)
            Name:DockMargin(LeftMargin - ScrW() * 0.005, 0, RightMargin, ScrH() * 0.008)
            Name.Paint = function(me, w, h)
                surface.SetMaterial(Material("materials/ui/background.png"))
                surface.SetDrawColor(126, 126, 126, 39)
                surface.DrawTexturedRect(0, 0, w, h)
                local inventoryName = "Locker"

                draw.SimpleText(inventoryName, "gRust.32px", 16 * gRust.Scaling, h * 0.5, gRust.Colors.Text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end

            i = i + 1
        end

        Container.Think = function(me)
            if (!IsValid(self)) then
                Container:Remove()
                Container = nil
                InventoryPanel = nil
                return
            end

            local distance = LocalPlayer():GetPos():Distance(self:GetPos())
            if (distance > 200) then
                gRust.CloseInventory()
                return
            end
        end

        CreateRow(1)
        CreateRow(7)

        local Loot = Container:Add("DLabel")
        Loot:Dock(BOTTOM)
        Loot:SetFont("gRust.58px")
        Loot:SetText("LOOT")
        Loot:SetColor(Color(255, 255, 255, 225))
        Loot:DockMargin(LeftMargin, 0, RightMargin, ScrH() * 0.01)
        Loot:SetTall(ScrH() * 0.025)
    end

    function ENT:Initialize()
        self.LeftRightSingle = {}

        local left = ClientsideModel("models/props_lab/lockerdoorleft.mdl", RENDERGROUP_OPAQUE)
        left:SetParent(self)
        left:SetLocalPos(Vector(10, -15, 38))
        left:SetLocalAngles(Angle(0, 0, 0))
        table.insert(self.LeftRightSingle, left)

        local single = ClientsideModel("models/props_lab/lockerdoorsingle.mdl", RENDERGROUP_OPAQUE)
        single:SetParent(self)
        single:SetLocalPos(Vector(10, 16, 38))
        single:SetLocalAngles(Angle(0, 0, 0))
        table.insert(self.LeftRightSingle, single)

        local right = ClientsideModel("models/props_lab/lockerdoorright.mdl", RENDERGROUP_OPAQUE)
        right:SetParent(self)
        right:SetLocalPos(Vector(10, 0, 38))
        right:SetLocalAngles(Angle(0, 0, 0))
        table.insert(self.LeftRightSingle, right)
    end

    function ENT:OnRemove()
        if self.LeftRightSingle then
            for _, model in pairs(self.LeftRightSingle) do
                if IsValid(model) then
                    model:Remove()
                end
            end
        end
    end
end
