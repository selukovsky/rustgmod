AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

DEFINE_BASECLASS("rust_storage")

function ENT:Initialize()
    if CLIENT then return end

    self:SetModel("models/environment/crates/elite_crate.mdl")
    self:SetSolid(SOLID_VPHYSICS)

    if self.Deploy then
        self:PhysicsInitStatic(SOLID_VPHYSICS)
    else
        self:PhysicsInit(SOLID_VPHYSICS)
        local phys = self:GetPhysicsObject()
        if IsValid(phys) then
            phys:EnableMotion(false)
            phys:Sleep()
        end
    end

    self:CreateInventory(12)
    self:SetInteractable(true)
    self:SetOpenSoundType("elite")
    self:SetDamageable(false)

    timer.Simple(0.1, function()
        if IsValid(self) then
            self.SpawnPosition = self:GetPos()
            self.SpawnAngles = self:GetAngles()
            self:PopulateWithItems()
        end
    end)

    timer.Create("CheckEmpty_" .. self:EntIndex(), 2, 0, function()
        if IsValid(self) then
            self:CheckIfEmptyAndScheduleRespawn()
        else
            timer.Remove("CheckEmpty_" .. self:EntIndex())
        end
    end)
end

function ENT:PopulateWithItems()
    local eliteCrateLootItems = {
         -- Очень частые предметы (17%)
        {
            itemid = "smgbody",
            amount = {1, 3},
            chance = 0.39,
        },
        {
            itemid = "techparts",
            amount = {4, 6},
            chance = 0.35,
        },
        {
            itemid = "metalpipe",
            amount = {2, 5},
            chance = 0.60,
        },
        {
            itemid = "coal",
            amount = {2, 3},
            chance = 0.15,
        },
        {
            itemid = "metal.refined",
            amount = {24, 48},
            chance = 0.43,
        },
        
        -- Частые предметы (16%)
        {
            itemid = "riflebody",
            amount = {1, 2},
            chance = 0.20,
        },
        
        -- Необычные предметы (9%)
        {
            itemid = "computer", -- targeting_computer
            amount = {1, 2},
            chance = 0.19,
        },
        {
            itemid = "camera", -- targeting_computer
            amount = {1, 2},
            chance = 0.21,
        },
        {
            itemid = "book", -- targeting_computer
            amount = {1, 1},
            chance = 0.14,
        },
        
        -- Очень редкие предметы (1%)
        {
            itemid = "supply.signal",
            amount = {1, 1},
            chance = 0.09,
        },
        {
            itemid = "pistol.semiauto",
            amount = {1, 1},
            chance = 0.10,
        },
        {
            itemid = "bluefrag", -- muzzle_boost
            amount = {25, 50},
            chance = 0.07,
        },
        {
            itemid = "grenade.beancan", -- f1_grenade
            amount = {1, 1},
            chance = 0.01,
        },
        {
            itemid = "rifle.semiauto",
            amount = {1, 2},
            chance = 0.15,
        },
        
        -- Легендарные предметы (0.5%)
        {
            itemid = "rocket.launcher",
            amount = {1, 1},
            chance = 0.05,
        },
        {
            itemid = "shotgun.pump",
            amount = {1, 1},
            chance = 0.21,
        },
        {
            itemid = "usp",
            amount = {1, 1},
            chance = 0.24,
        },
        {
            itemid = "smg.thompson",
            amount = {1, 1},
            chance = 0.15,
        },
        {
            itemid = "rifle.ak",
            amount = {1, 1},
            chance = 0.09,
        },
        {
            itemid = "rifle.bolt",
            amount = {1, 1},
            chance = 0.05,
        },
        {
            itemid = "rifle.l96",
            amount = {1, 1},
            chance = 0.10,
        },
        {
            itemid = "rifle.lr300",
            amount = {1, 1},
            chance = 0.12,
        },
        {
            itemid = "shotgun.spas12",
            amount = {1, 1},
            chance = 0.25,
        },
        {
            itemid = "shotgun.double",
            amount = {1, 1},
            chance = 0.52,
        },
        {
            itemid = "smg.2", -- custom_smg
            amount = {1, 1},
            chance = 0.20,
        },
        {
            itemid = "smg.mp5",
            amount = {1, 1},
            chance = 0.10,
        },
        {
            itemid = "pistol.revolver",
            amount = {1, 1},
            chance = 0.15,
        },
        {
            itemid = "pistol.m92",
            amount = {1, 1},
            chance = 0.10,
        },
        {
            itemid = "pistol.nailgun",
            amount = {1, 1},
            chance = 0.42,
        },
        {
            itemid = "crossbow",
            amount = {1, 1},
            chance = 0.50,
        },
        {
            itemid = "lmg.m249",
            amount = {1, 1},
            chance = 0.005,
        },
        {
            itemid = "explosive.satchel",
            amount = {1, 1},
            chance = 0.005,
        },
        {
            itemid = "explosive.timed",
            amount = {1, 1},
            chance = 0.10,
        },
        {
            itemid = "ammo.mgl.basic",
            amount = {2, 4},
            chance = 0.10,
        },
        {
            itemid = "weapon.mod.silencer",
            amount = {1, 1},
            chance = 0.35,
        },
        {
            itemid = "weapon.mod.8x.scope",
            amount = {1, 1},
            chance = 0.35,
        },
        {
            itemid = "scrap",
            amount = {25, 25},
            chance = 100.0,
        },
        
        -- Дополнительные компоненты (с низкими шансами)
        {
            itemid = "roadsigns",
            amount = {5, 10},
            chance = 0.60,
        },
        {
            itemid = "metalspring",
            amount = {1, 2},
            chance = 0.55,
        },
        {
            itemid = "sheetmetal",
            amount = {1, 4},
            chance = 0.52,
        },
        {
            itemid = "semibody",
            amount = {1, 3},
            chance = 0.38,
        },
        {
            itemid = "explosives",
            amount = {1, 1},
            chance = 0.15,
        },
    }

    local availableItems = {}
    for _, itemData in ipairs(eliteCrateLootItems) do
        local itemDef = gRust.Items[itemData.itemid]
        if itemDef then
            table.insert(availableItems, itemData)
        end
    end

    if #availableItems == 0 then return end

    if self.Inventory then
        for i = 1, self.InventorySlots do
            if self.Inventory[i] then
                self:RemoveSlot(i)
            end
        end
    end

    local itemCount = math.random(3, 8)
    local shuffledItems = {}
    
    for i = 1, #availableItems do
        table.insert(shuffledItems, availableItems[i])
    end
    for i = #shuffledItems, 2, -1 do
        local j = math.random(i)
        shuffledItems[i], shuffledItems[j] = shuffledItems[j], shuffledItems[i]
    end

    local currentSlot = 1
    local addedItems = 0

    for _, itemData in ipairs(shuffledItems) do
        if addedItems >= itemCount or currentSlot > self.InventorySlots then
            break
        end

        local randomChance = math.random()
        if randomChance <= itemData.chance then
            local amount = 1
            if type(itemData.amount) == "table" then
                amount = math.random(itemData.amount[1], itemData.amount[2])
            else
                amount = itemData.amount
            end

            local item = gRust.CreateItem(itemData.itemid, amount)
            if item then
                self:SetSlot(item, currentSlot)
                currentSlot = currentSlot + 1
                addedItems = addedItems + 1
            end
        end
    end
end

function ENT:RemoveSlot(slot)
    BaseClass.RemoveSlot(self, slot)

    timer.Simple(0.1, function()
        if IsValid(self) then
            self:CheckIfEmptyAndScheduleRespawn()
        end
    end)
end

function ENT:IsInventoryEmpty()
    if not self.Inventory then return true end
    
    for i = 1, self.InventorySlots do
        if self.Inventory[i] then
            return false
        end
    end
    
    return true
end

function ENT:CheckIfEmptyAndScheduleRespawn()
    if self:IsInventoryEmpty() then
        self:ScheduleRespawn()
    end
end

function ENT:ScheduleRespawn()
    local pos = self.SpawnPosition or self:GetPos()
    local ang = self.SpawnAngles or self:GetAngles()
    local respawnTime = 600 -- 5m

    timer.Remove("CheckEmpty_" .. self:EntIndex())
    
    self:Remove()

    local timerName = "EliteCrateRespawn_" .. tostring(pos.x) .. "_" .. tostring(pos.y) .. "_" .. tostring(pos.z)
    timer.Create(timerName, respawnTime, 1, function()
        local newCrate = ents.Create("rust_elitecrate")
        if IsValid(newCrate) then
            newCrate:SetPos(pos)
            newCrate:SetAngles(ang)
            newCrate:Spawn()
            newCrate:Activate()
            newCrate.SpawnPosition = pos
            newCrate.SpawnAngles = ang
        end
    end)
end

function ENT:Use(activator, caller)
    BaseClass.Use(self, activator, caller)
end

function ENT:OnDestroyed(dmg)
    if self.SpawnPosition then
        self:ScheduleRespawn()
    end
end

function ENT:OnRemove()
    timer.Remove("CheckEmpty_" .. self:EntIndex())
end
