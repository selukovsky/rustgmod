AddCSLuaFile()
ENT.Base = "rust_doubledoor"
ENT.Model = "models/deployable/metal_double_door.mdl"
ENT.MaxHealth = 500
ENT.Health = 500
ENT.DoorSound = "metal"
ENT.Deploy = {}
ENT.Deploy.Model = "models/deployable/metal_double_door.mdl"
ENT.Deploy.Sound = "deploy/metal_door_deploy.wav"
ENT.Deploy.Socket = "double"
ENT.metalupkeep = 150
ENT.Pickup = "door.hinged.metal"

-- Параметры для двойных дверей
ENT.DoorSpacing = 50.7
ENT.LeftDoorModel = "models/darky_m/rust/metal_door_l.mdl"
ENT.RightDoorModel = "models/deployable/metal_door.mdl"


-- Звуки для металлических дверей
function ENT:GetOpenSound()
    return "doors/door_metal_open.wav"
end

function ENT:GetCloseSound()
    return "doors/door_metal_close.wav"
end

function ENT:GetShutSound()
    return "doors/door_metal_shut.wav"
end