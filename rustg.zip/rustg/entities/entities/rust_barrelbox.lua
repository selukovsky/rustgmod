AddCSLuaFile()



ENT.Base = "rust_storage"



ENT.InventorySlots = 5

ENT.InventoryName   = "Ржавая бочка для хранения"



ENT.Deploy = {}

ENT.Deploy.Model = "models/props_c17/oildrum001.mdl"



ENT.Pickup			= "large_wood_box"

ENT.DisplayIcon 	= gRust.GetIcon("open")

ENT.ShowHealth	= true



function ENT:Initialize()

    if (CLIENT) then return end



    self:SetModel("models/props_c17/oildrum001.mdl")

    self:PhysicsInitStatic(SOLID_VPHYSICS)

    self:SetMoveType(MOVETYPE_NONE)

    self:SetSolid(SOLID_VPHYSICS)

    self:CreateInventory(48)

    self:SetSaveItems(true)



    self:SetInteractable(true)

    

    self:SetDamageable(true)

    self:SetHealth(200)

    self:SetMaxHealth(200)



    self:SetMeleeDamage(0.2)

    self:SetBulletDamage(0.05)

    self:SetExplosiveDamage(0.4)



    self:SetDisplayName("OPEN")

end