AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "Fire Zone"
ENT.Author = "Darky"
ENT.Category = "gRust"

function ENT:Initialize()
    self:SetModel("models/hunter/blocks/cube05x05x05.mdl")
    self:SetMaterial("models/debug/debugwhite")
    self:SetColor(Color(255, 100, 0, 100))
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_BBOX)
    self:SetCollisionBounds(Vector(-128, -128, 0), Vector(128, 128, 64))
    self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
    self:SetTrigger(true)
    
    -- Эффект огня
    ParticleEffectAttach("env_fire_large", PATTACH_ABSORIGIN_FOLLOW, self, 0)
    
    -- Звук горения огня
    self.FireSound = CreateSound(self, "ambient/fire/fire_small_loop1.wav")
    if self.FireSound then
        self.FireSound:Play()
        self.FireSound:ChangeVolume(0.8, 0)
    end
    
    -- Начинаем наносить урон
    self.NextDamageTick = CurTime()
    self.LifeTime = CurTime() + 10
    
    if CLIENT then
        -- Клиентские эффекты
        self:EmitSound("ambient/fire/fire_small_loop1.wav")
    end
end

function ENT:Think()
    -- Наносим урон каждую секунду
    if CurTime() >= self.NextDamageTick then
        self:DamageEntitiesInRadius()
        self.NextDamageTick = CurTime() + 1
    end
    
    -- Удаляем по истечении времени
    if CurTime() >= self.LifeTime then
        self:StopFireSound()
        if CLIENT then
            self:StopSound("ambient/fire/fire_small_loop1.wav")
        end
        self:Remove()
        return
    end
    
    self:NextThink(CurTime() + 0.1)
    return true
end

function ENT:StopFireSound()
    if self.FireSound then
        self.FireSound:Stop()
        self.FireSound = nil
    end
end

function ENT:DamageEntitiesInRadius()
    local pos = self:GetPos()
    local radius = 128
    
    for _, ent in pairs(ents.FindInSphere(pos, radius)) do
        if ent:IsPlayer() or ent:IsNPC() then
            -- Проверяем, чтобы не наносить урон владельцу (опционально)
            if ent == self:GetOwner() then continue end
            
            local dmginfo = DamageInfo()
            dmginfo:SetDamage(15)
            dmginfo:SetAttacker(self:GetOwner() or self)
            dmginfo:SetInflictor(self)
            dmginfo:SetDamageType(DMG_BURN)
            dmginfo:SetDamagePosition(pos)
            
            ent:TakeDamageInfo(dmginfo)
            
            -- Визуальный эффект при получении урона
            if ent:IsPlayer() then
                ent:ScreenFade(SCREENFADE.IN, Color(255, 100, 0, 50), 0.5, 0)
            end
        end
    end
end

function ENT:StartTouch(ent)
    -- Можно добавить дополнительную логику при входе в зону
end

function ENT:EndTouch(ent)
    -- Можно добавить логику при выходе из зоны
end

function ENT:OnRemove()
    self:StopFireSound()
    
    if CLIENT then
        self:StopSound("ambient/fire/fire_small_loop1.wav")
        -- Эффект затухания огня
        local effect = EffectData()
        effect:SetOrigin(self:GetPos())
        util.Effect("extinguish_fire", effect, true, true)
    else
        -- Серверный эффект дыма при затухании
        local smokeEffect = EffectData()
        smokeEffect:SetOrigin(self:GetPos())
        smokeEffect:SetMagnitude(2)
        smokeEffect:SetScale(1)
        util.Effect("extinguish_fire", smokeEffect, true, true)
    end
end

-- Убедимся что звук останавливается при удалении
function ENT:OnDestroy()
    self:StopFireSound()
end