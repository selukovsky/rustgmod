include("shared.lua")

function ENT:Initialize()
    -- Инициализация моделей поворота
    self.YawEntity = ClientsideModel(self.YawModel)
    self.YawEntity:SetParent(self)
    self.YawEntity:SetLocalPos(self.YawPos)
    self.YawEntity:SetLocalAngles(Angle(0, 0, 0))

    self.PitchEntity = ClientsideModel(self.PitchModel)
    self.PitchEntity:SetParent(self.YawEntity)
    self.PitchEntity:SetLocalPos(self.PitchPos)
    self.PitchEntity:SetLocalAngles(Angle(0, 0, 0))

    -- ВАЖНО: Инициализируем переменные поворота
    self.IdleOffset = self:EntIndex()
    self.CurrentRotation = Angle(0, 0, 0)
    self.TargetRotation = Angle(0, 0, 0)
    self.LastWeaponID = 0
end

function ENT:OnRemove()
    if (IsValid(self.YawEntity)) then
        self.YawEntity:Remove()
    end

    if (IsValid(self.PitchEntity)) then
        self.PitchEntity:Remove()
    end

    if (IsValid(self.WeaponEntity)) then
        self.WeaponEntity:Remove()
    end
end

function ENT:Think()
    if (!IsValid(self.YawEntity) or !IsValid(self.PitchEntity)) then return end

    -- Обновление модели оружия
    if (!self.NextEntitiesUpdate or self.NextEntitiesUpdate < CurTime()) then
        self:UpdateEntities()
        self.NextEntitiesUpdate = CurTime() + 5
    end

    -- Обновление поворота
    self:UpdateRotation()

    -- Применяем поворот к моделям
    self.YawEntity:SetLocalAngles(Angle(0, self.CurrentRotation.y, 0))
    self.PitchEntity:SetLocalAngles(Angle(self.CurrentRotation.p, 0, 0))

    self:SetNextClientThink(CurTime())
    return true
end

function ENT:UpdateRotation()
    -- Получаем цель с сервера
    local target = self:GetTarget()
    
    -- ВАЖНО: Гарантируем что переменные инициализированы
    if not self.TargetRotation then
        self.TargetRotation = Angle(0, 0, 0)
    end
    if not self.CurrentRotation then
        self.CurrentRotation = Angle(0, 0, 0)
    end
    
    if IsValid(target) then
        -- Поворот к цели
        local targetPos = target:GetPos() + target:OBBCenter()
        local direction = (targetPos - self:GetPos()):Angle()
        self.TargetRotation = direction - self:GetAngles()
    else
        -- Поворот бездействия
        local idleYaw = math.max(math.min(2 * math.sin(0.2 * (CurTime() + self.IdleOffset) * math.pi), 1), -1) * 45
        self.TargetRotation = Angle(0, idleYaw, 0)
    end
    
    -- Плавный поворот
    local rotateSpeed = IsValid(target) and 10 or 1
    self.CurrentRotation = LerpAngle(FrameTime() * rotateSpeed, self.CurrentRotation, self.TargetRotation)
end

function ENT:UpdateEntities()
    local weaponID = self:GetWeaponID()
    
    if (weaponID != 0) then
        local weapon = gRust.GetItemRegisterFromIndex(weaponID)
        if (weapon) then
            if (!IsValid(self.WeaponEntity)) then
                self.WeaponEntity = ClientsideModel(weapon:GetModel())
                self.WeaponEntity:SetParent(self.PitchEntity)
                self.WeaponEntity:SetLocalPos(self.GunPos)
                self.WeaponEntity:SetLocalAngles(Angle(0, 0, 0))
                self.WeaponData = weapons.GetStored(weapon:GetWeapon())
            elseif (self.LastWeaponID != weaponID) then
                self.WeaponEntity:SetModel(weapon:GetModel())                
                self.WeaponData = weapons.GetStored(weapon:GetWeapon())
            end
        end
    else
        if (IsValid(self.WeaponEntity)) then
            self.WeaponEntity:Remove()
            self.WeaponEntity = nil
            self.WeaponData = nil
        end
    end

    if (IsValid(self.WeaponEntity)) then
        self.WeaponEntity:SetParent(self.PitchEntity)
        self.WeaponEntity:SetLocalPos(self.GunPos)
        self.WeaponEntity:SetLocalAngles(Angle(0, 0, 0))
    end

    if (!IsValid(self.YawEntity)) then
        self.YawEntity = ClientsideModel(self.YawModel)
        self.YawEntity:SetParent(self)
        self.YawEntity:SetLocalPos(self.YawPos)
        self.YawEntity:SetLocalAngles(Angle(0, 0, 0))
    end

    if (!IsValid(self.PitchEntity)) then
        self.PitchEntity = ClientsideModel(self.PitchModel)
        self.PitchEntity:SetParent(self.YawEntity)
        self.PitchEntity:SetLocalPos(self.PitchPos)
        self.PitchEntity:SetLocalAngles(Angle(0, 0, 0))
    end
    
    self.LastWeaponID = weaponID
end

-- Обработчик эффектов выстрела
net.Receive("gRust.AutoTurret.ShootEffects", function(len)
    local turret = net.ReadEntity()
    if (!IsValid(turret) or turret:GetClass() != "rust_turret") then return end

    local ent = turret.WeaponEntity
    if (!IsValid(ent)) then return end

    local effect = turret.WeaponData and turret.WeaponData.MuzzleEffect or "CS_MuzzleFlash"
    if (effect and effect != "") then
        local attachment = ent:GetAttachment(1)
        if (!attachment) then return end

        local fx = EffectData()
        fx:SetOrigin(attachment.Pos)
        fx:SetEntity(ent)
        fx:SetAngles(attachment.Ang)
        fx:SetScale(2)
        fx:SetAttachment(1)
        util.Effect(effect, fx)
    end
end)