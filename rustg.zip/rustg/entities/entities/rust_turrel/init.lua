AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

DEFINE_BASECLASS("rust_storage")

-- Звуки
local ShootSound = Sound("Weapon_AR2.Single")
local TargetAcquired = Sound("npc/turret_floor/ping.wav")

function ENT:Initialize()
    
    -- Базовая инициализация как у ящика
    self:SetModel(self.BaseModel)
    self:PhysicsInitStatic(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)
    
    -- Создаем инвентарь как в ящике
    self:CreateInventory(self.InventorySlots)
    self:SetInteractable(true)
    self:SetOpenSoundType("largewoodbox")
    
    -- Настройки турели
    self:SetDamageable(true)
    self:SetHealth(500)
    self:SetMaxHealth(500)
    self:SetMeleeDamage(0.2)
    self:SetBulletDamage(0.2)
    self:SetExplosiveDamage(0.4)
    
    -- Переменные для логики
    self:SetWeaponID(0)
    self:SetAmmoCount(0)
    self:SetIsActive(false)
    self:SetTarget(nil)
    
    self.NextShot = 0
    self.FireRate = 0.1
    self.LastTargetCheck = 0
    self.TargetCheckInterval = 0.2
    
    -- Владелец и список друзей
    self.Owner = nil
    self.FriendlyPlayers = {}
    
    -- Инициализируем переменные поворота
    self.IdleOffset = math.random(0, 100)
    self.TargetRotation = Angle(0, 0, 0)
    self.CurrentRotation = Angle(0, 0, 0)
    
    print("[Turret] Turret initialized with " .. self.InventorySlots .. " slots")
    
    -- Принудительная проверка инвентаря после инициализации
    timer.Simple(2.0, function()
        if IsValid(self) then
            print("[Turret] Initial inventory check...")
            self:ForceInventoryCheck()
        end
    end)
end

-- ПРИНУДИТЕЛЬНАЯ ПРОВЕРКА ИНВЕНТАРЯ
function ENT:ForceInventoryCheck()
    print("[Turret] === FORCE INVENTORY CHECK ===")
    
    if not self.Inventory then
        print("[Turret] ❌ ERROR: No inventory table!")
        return
    end
    
    -- Проверяем структуру инвентаря
    print("[Turret] Inventory slots: " .. tostring(self.InventorySlots))
    print("[Turret] Inventory table type: " .. type(self.Inventory))
    
    local itemCount = 0
    for i = 1, self.InventorySlots do
        if self.Inventory[i] then
            itemCount = itemCount + 1
            local item = self.Inventory[i]
            print(string.format("[Turret] Slot %d: %s x%d", i, item:GetItem(), item:GetQuantity()))
        end
    end
    
    print("[Turret] Total items found: " .. itemCount)
    self:OnInventoryUpdated()
end

-- Функции для работы с инвентарем
function ENT:Use(activator, caller)
    if not self:GetInteractable() then return end
    if not IsValid(activator) or not activator:IsPlayer() then return end
    
    print("[Turret] Player using turret: " .. activator:Nick())
    
    -- Принудительно проверяем инвентарь перед открытием
    self:ForceInventoryCheck()
    
    -- Открываем инвентарь
    self:OpenInventory(activator)
end

function ENT:OpenInventory(ply)
    if not IsValid(ply) then return end
    
    net.Start("gRust.OpenStorage")
    net.WriteEntity(self)
    net.WriteString(self.InventoryName or "Auto Turret")
    net.WriteUInt(self.InventorySlots or 6, 8)
    net.Send(ply)
    
    -- Синхронизируем слоты
    timer.Simple(0.2, function()
        if IsValid(self) and IsValid(ply) then
            for i = 1, self.InventorySlots do
                self:SyncSlot(i, ply)
            end
            -- После синхронизации снова проверяем инвентарь
            timer.Simple(0.5, function()
                if IsValid(self) then
                    self:ForceInventoryCheck()
                end
            end)
        end
    end)
end

function ENT:SyncSlot(slot, ply)
    if not self.Inventory then 
        print("[Turret] ❌ No inventory in SyncSlot")
        return 
    end
    
    local item = self.Inventory[slot]
    
    if ply then
        if item then
            net.Start("gRust.Inventory.SyncSlot")
            net.WriteEntity(self)
            net.WriteUInt(slot, 6)
            net.WriteItem(item)
            net.Send(ply)
        else
            net.Start("gRust.Inventory.Remove")
            net.WriteEntity(self)
            net.WriteUInt(slot, 6)
            net.Send(ply)
        end
    else
        local recipients = {}
        for _, pl in pairs(player.GetAll()) do
            if IsValid(pl) and pl:GetPos():Distance(self:GetPos()) <= 200 then 
                table.insert(recipients, pl) 
            end
        end
        
        if #recipients > 0 then
            if item then
                net.Start("gRust.Inventory.SyncSlot")
                net.WriteEntity(self)
                net.WriteUInt(slot, 6)
                net.WriteItem(item)
                net.Send(recipients)
            else
                net.Start("gRust.Inventory.Remove")
                net.WriteEntity(self)
                net.WriteUInt(slot, 6)
                net.Send(recipients)
            end
        end
    end
end

function ENT:RemoveSlot(slot)
    if not self.Inventory or not slot then return end
    self.Inventory[slot] = nil
    self:SyncSlot(slot)
    
    timer.Simple(0.1, function()
        if IsValid(self) then
            self:ForceInventoryCheck()
        end
    end)
end

-- ОСНОВНАЯ ФУНКЦИЯ ПРОВЕРКИ ИНВЕНТАРЯ (ИСПРАВЛЕННАЯ)
function ENT:OnInventoryUpdated()
    print("[Turret] === INVENTORY UPDATE START ===")
    
    if not self.Inventory then
        print("[Turret] ❌ ERROR: No inventory table!")
        self:SetIsActive(false)
        self:SetWeaponID(0)
        self:SetAmmoCount(0)
        return
    end
    
    local hasWeapon = false
    local hasAmmo = false
    local totalAmmo = 0
    local weaponID = 0
    local weaponClass = ""
    
    -- Проверяем слот 1 на оружие (ИСПРАВЛЕННАЯ ПРОВЕРКА)
    if self.Inventory[1] then
        local item = self.Inventory[1]
        local itemClass = item:GetItem()
        local itemData = gRust.Items[itemClass]
        
        if itemData then
            -- Проверяем, является ли предмет оружием (более надежный способ)
            local weaponClass = itemData:GetWeapon()
            if weaponClass and weaponClass ~= "" then
                hasWeapon = true
                weaponClass = itemClass
                -- Используем индекс предмета вместо индекса оружия
                weaponID = gRust.GetItemIndex(itemClass) or 1
                print("[Turret] ✅ WEAPON FOUND: " .. weaponClass .. " (ID: " .. weaponID .. ")")
            else
                print("[Turret] ❌ Slot 1 is not a weapon: " .. itemClass)
            end
        else
            print("[Turret] ❌ Invalid item data for: " .. itemClass)
        end
    else
        print("[Turret] ❌ Slot 1 is empty")
    end
    
    -- Проверяем слоты 2-6 на патроны (ИСПРАВЛЕННАЯ ПРОВЕРКА)
    for i = 2, 6 do
        if self.Inventory[i] then
            local item = self.Inventory[i]
            local itemClass = item:GetItem()
            local itemData = gRust.Items[itemClass]
            
            if itemData then
                -- Проверяем категорию предмета
                local category = itemData:GetCategory() or ""
                if string.lower(category) == "ammo" then
                    totalAmmo = totalAmmo + item:GetQuantity()
                    hasAmmo = true
                    print("[Turret] ✅ AMMO FOUND: " .. itemClass .. " x" .. item:GetQuantity() .. " in slot " .. i)
                else
                    print("[Turret] ❌ Slot " .. i .. " is not ammo (category: " .. category .. "): " .. itemClass)
                end
            else
                print("[Turret] ❌ Invalid item data for: " .. itemClass)
            end
        else
            print("[Turret] ❌ Slot " .. i .. " is empty")
        end
    end
    
    self:SetWeaponID(weaponID)
    self:SetAmmoCount(totalAmmo)
    
    local isReady = (hasWeapon and totalAmmo > 0)
    self:SetIsActive(isReady)
    
    print("[Turret] SUMMARY:")
    print("[Turret] - Weapon: " .. tostring(hasWeapon) .. " (" .. weaponClass .. ")")
    print("[Turret] - Ammo: " .. totalAmmo)
    print("[Turret] - Ready: " .. tostring(isReady))
    print("[Turret] - WeaponID: " .. weaponID)
    
    if isReady then
        print("[Turret] ✅ TURRET READY FOR COMBAT!")
    else
        print("[Turret] ❌ TURRET NOT READY")
        if not hasWeapon then print("[Turret]   - Reason: No weapon in slot 1") end
        if totalAmmo <= 0 then print("[Turret]   - Reason: No ammo in slots 2-6") end
    end
    
    print("[Turret] === INVENTORY UPDATE END ===")
end

-- Основной логический цикл
function ENT:Think()
    if (CLIENT) then return end
    
    -- Периодическая проверка инвентаря (каждые 10 секунд)
    if CurTime() > (self.LastInventoryCheck or 0) + 10 then
        self:ForceInventoryCheck()
        self.LastInventoryCheck = CurTime()
    end
    
    -- Отладочная информация
    if CurTime() > (self.LastDebug or 0) + 3 then
        local targetInfo = "none"
        if IsValid(self:GetTarget()) then
            targetInfo = self:GetTarget():Nick() or "unknown"
        end
        
        print(string.format("[Turret] STATUS - Active: %s, Ammo: %d, WeaponID: %d, Target: %s", 
              tostring(self:GetIsActive()), self:GetAmmoCount(), self:GetWeaponID(), targetInfo))
        self.LastDebug = CurTime()
    end
    
    -- Обновляем поворот турели
    self:UpdateRotation()
    
    -- Проверяем цель
    if CurTime() > self.LastTargetCheck + self.TargetCheckInterval then
        self:FindTarget()
        self.LastTargetCheck = CurTime()
    end
    
    -- Стрельба по цели
    if self:GetIsActive() and IsValid(self:GetTarget()) then
        if CurTime() > (self.LastShotDebug or 0) + 1 then
            print(string.format("[Turret] 🔫 SHOOTING at %s! Ammo: %d", 
                  self:GetTarget():Nick(), self:GetAmmoCount()))
            self.LastShotDebug = CurTime()
        end
        self:ShootAtTarget()
    end
    
    self:NextThink(CurTime())
    return true
end

-- Остальные функции без изменений...
function ENT:FindTarget()
    local currentTarget = self:GetTarget()
    
    if IsValid(currentTarget) and self:IsTargetValid(currentTarget) then
        return
    end
    
    local bestTarget = nil
    local bestDistance = self.DetectionRange
    
    for _, ply in pairs(player.GetAll()) do
        if self:IsTargetValid(ply) then
            local distance = self:GetPos():Distance(ply:GetPos())
            if distance < bestDistance then
                bestTarget = ply
                bestDistance = distance
            end
        end
    end
    
    self:SetTarget(bestTarget)
    
    if IsValid(bestTarget) and not IsValid(currentTarget) then
        self:EmitSound(TargetAcquired)
        print(string.format("[Turret] 🎯 TARGET ACQUIRED: %s", bestTarget:Nick()))
    end
end

function ENT:IsTargetValid(target)
    if not IsValid(target) or not target:IsPlayer() or not target:Alive() then
        return false
    end
    
    if self:IsFriendly(target) then
        return false
    end
    
    local distance = self:GetPos():Distance(target:GetPos())
    if distance > self.DetectionRange then
        return false
    end
    
    local direction = (target:GetPos() - self:GetPos()):GetNormalized()
    local forward = self:GetAngles():Forward()
    local dot = direction:Dot(forward)
    local angle = math.deg(math.acos(dot))
    
    if angle > (self.FieldOfView / 2) then
        return false
    end
    
    local trace = util.TraceLine({
        start = self:GetMuzzlePos(),
        endpos = target:GetPos() + Vector(0, 0, 50),
        filter = {self, self.Owner}
    })
    
    return trace.Entity == target
end

function ENT:IsFriendly(ply)
    if ply == self.Owner then return true end
    if self.FriendlyPlayers[ply:SteamID()] then return true end
    return false
end

function ENT:ShootAtTarget()
    if CurTime() < self.NextShot then return end
    if self:GetAmmoCount() <= 0 then 
        print("[Turret] ❌ OUT OF AMMO!")
        self:SetIsActive(false)
        self:SetTarget(nil)
        return 
    end
    
    local target = self:GetTarget()
    if not IsValid(target) then return end
    
    local trace = util.TraceLine({
        start = self:GetMuzzlePos(),
        endpos = target:GetPos() + Vector(0, 0, 50),
        filter = {self, self.Owner}
    })
    
    if trace.Entity != target then
        self:SetTarget(nil)
        return
    end
    
    self:ConsumeAmmo(1)
    self:EmitSound(ShootSound)
    
    net.Start("gRust.AutoTurret.ShootEffects")
    net.WriteEntity(self)
    net.Broadcast()
    
    local bullet = {}
    bullet.Num = 1
    bullet.Src = self:GetMuzzlePos()
    bullet.Dir = (target:GetPos() + Vector(0, 0, 50) - self:GetMuzzlePos()):GetNormalized()
    bullet.Spread = Vector(0.01, 0.01, 0)
    bullet.Tracer = 1
    bullet.TracerName = "Tracer"
    bullet.Force = 5
    bullet.Damage = 25
    bullet.Attacker = IsValid(self.Owner) and self.Owner or self
    bullet.Inflictor = self
    
    self:FireBullets(bullet)
    
    self.NextShot = CurTime() + (1 / self.FireRate)
end

function ENT:ConsumeAmmo(amount)
    if not self.Inventory then
        self:SetAmmoCount(0)
        self:SetIsActive(false)
        return
    end
    
    local remaining = amount
    
    for slot = 2, 6 do
        if remaining <= 0 then break end
        
        local item = self.Inventory[slot]
        if item then
            local itemClass = item:GetItem()
            local itemData = gRust.Items[itemClass]
            
            if itemData then
                local category = itemData:GetCategory() or ""
                if string.lower(category) == "ammo" then
                    local takeAmount = math.min(remaining, item:GetQuantity())
                    item:RemoveQuantity(takeAmount)
                    remaining = remaining - takeAmount
                    
                    if item:GetQuantity() <= 0 then
                        self:RemoveSlot(slot)
                    else
                        self:SyncSlot(slot)
                    end
                end
            end
        end
    end
    
    local newAmmoCount = math.max(0, self:GetAmmoCount() - amount)
    self:SetAmmoCount(newAmmoCount)
    
    if newAmmoCount <= 0 then
        self:SetIsActive(false)
        self:SetTarget(nil)
    end
end

function ENT:UpdateRotation()
    local target = self:GetTarget()
    
    if not self.TargetRotation then self.TargetRotation = Angle(0, 0, 0) end
    if not self.CurrentRotation then self.CurrentRotation = Angle(0, 0, 0) end
    
    if IsValid(target) then
        local targetPos = target:GetPos() + target:OBBCenter()
        local direction = (targetPos - self:GetPos()):Angle()
        self.TargetRotation = direction - self:GetAngles()
    else
        local idleYaw = math.max(math.min(2 * math.sin(0.2 * (CurTime() + self.IdleOffset) * math.pi), 1), -1) * 45
        self.TargetRotation = Angle(0, idleYaw, 0)
    end
    
    local rotateSpeed = IsValid(target) and 10 or 1
    self.CurrentRotation = LerpAngle(FrameTime() * rotateSpeed, self.CurrentRotation, self.TargetRotation)
end

function ENT:GetMuzzlePos()
    return self:LocalToWorld(self.YawPos + self.PitchPos + self.GunPos + Vector(0, 0, 5))
end

function ENT:SetTurretOwner(ply)
    if IsValid(ply) and ply:IsPlayer() then
        self.Owner = ply
        self.FriendlyPlayers[ply:SteamID()] = true
    end
end

-- Хук для обновления при перемещении предметов
hook.Add("gRust.ItemMoved", "TurretInventoryUpdate", function(ply, fromEnt, toEnt, oldSlot, newSlot)
    if IsValid(toEnt) and toEnt:GetClass() == "rust_turret" then
        timer.Simple(0.5, function()
            if IsValid(toEnt) then
                print("[Turret] Item moved TO turret, updating inventory...")
                toEnt:ForceInventoryCheck()
            end
        end)
    end
    
    if IsValid(fromEnt) and fromEnt:GetClass() == "rust_turret" then
        timer.Simple(0.5, function()
            if IsValid(fromEnt) then
                print("[Turret] Item moved FROM turret, updating inventory...")
                fromEnt:ForceInventoryCheck()
            end
        end)
    end
end)