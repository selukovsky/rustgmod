ENT.Base = "rust_storage"

ENT.Deploy = {}
ENT.Deploy.Model = "models/environment/misc/recycler.mdl"

-- Модели для частей турели (как у вашего друга)
ENT.BaseModel = "models/deployable/turret_base.mdl"
ENT.PitchModel = "models/deployable/turret_pitch.mdl"
ENT.YawModel = "models/deployable/turret_yaw.mdl"
ENT.PitchPos = Vector(0, 0, 5)
ENT.YawPos = Vector(0, 0, 30)
ENT.GunPos = Vector(0, 0, -5)

-- Настройки турели
ENT.DetectionRange = 3900 -- 100 метров
ENT.FieldOfView = 120 -- Угол обзора

-- Инвентарь: 6 слотов (1 для оружия, 5 для патронов)
ENT.InventorySlots = 6
ENT.InventoryName = "Auto Turret"

function ENT:SetupDataTables()
    self:NetworkVar("Int", 0, "WeaponID") -- ID оружия для отрисовки модели
    self:NetworkVar("Entity", 0, "Target") -- Текущая цель (для поворота на клиенте)
    self:NetworkVar("Bool", 0, "IsActive") -- Активна ли турель
    self:NetworkVar("Float", 0, "AmmoCount") -- Количество патронов
    
    -- Добавляем NetworkVar от rust_storage
    self:NetworkVar("Bool", 1, "Interactable")
    self:NetworkVar("String", 0, "OpenSoundType")
end

if SERVER then
    util.AddNetworkString("gRust.OpenStorage")
    util.AddNetworkString("gRust.StorageSlot")
    util.AddNetworkString("gRust.AutoTurret.ShootEffects")
end