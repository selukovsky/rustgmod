DEFINE_BASECLASS("rust_storage")
include("shared.lua")

ENT.InventorySlots = 30
ENT.InventoryName  = "VENDING MACHINE"
ENT.DisplayIcon    = gRust.GetIcon("open")

local PosOffset = Vector(15, -3, 80)
local AngOffset = Angle(0, 90, 90)
local ScreenWidth, ScreenHeight = 210, 195
local ScreenMaterial = Material("ui/vending_machine_screen.png")
local IconSize = 100
local TEXT_COLOR = Color(150, 220, 120)

function ENT:Initialize()
    self.SellOrders = {}
    self.GetDisplayName = self.Ov_GetDisplayName
    self.HasBuiltInterface = false
    self.OrderQuantities = {}
end

function ENT:Draw()
    self:DrawModel()

    cam.Start3D2D(self:LocalToWorld(PosOffset), self:LocalToWorldAngles(AngOffset), 0.1)
        surface.SetDrawColor(255, 255, 255)
        if ScreenMaterial then
            surface.SetMaterial(ScreenMaterial)
            surface.DrawTexturedRect(0, 0, ScreenWidth, ScreenHeight)
        else
            surface.SetDrawColor(10, 50, 10)
            surface.DrawRect(0, 0, ScreenWidth, ScreenHeight)
        end

        if self:GetVending() then
            local vendIcon = gRust.GetIcon("vending")
            if vendIcon then
                surface.SetDrawColor(150, 220, 120)
                surface.SetMaterial(vendIcon)
                surface.DrawTexturedRectRotated(ScreenWidth / 2, ScreenHeight / 2, IconSize, IconSize, CurTime() * 180)
            end
        elseif #self.SellOrders == 0 then
            draw.SimpleText("NO ITEMS", "gRust.32px", ScreenWidth / 2, ScreenHeight / 2, Color(150, 220, 120), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        else
            local index = math.floor((CurTime() * 0.2) % #self.SellOrders + 1)
            local order = self.SellOrders[index]
            local register = gRust.Items[order.SellItem]
            if register then
                local iconMat = Material(register.Icon or "vgui/white", "smooth")
                surface.SetDrawColor(255, 255, 255)
                surface.SetMaterial(iconMat)
                surface.DrawTexturedRectRotated(ScreenWidth / 2, ScreenHeight / 2, IconSize, IconSize, math.sin(CurTime()) * 5)
                draw.SimpleText(register.Name or order.SellItem, "gRust.24px", ScreenWidth / 2, ScreenHeight / 2 - IconSize * 0.7, TEXT_COLOR, TEXT_ALIGN_CENTER)
                draw.SimpleText("x" .. tostring(order.SellAmount), "gRust.32px", ScreenWidth / 2, ScreenHeight / 2 + IconSize * 0.5, TEXT_COLOR, TEXT_ALIGN_CENTER)
            end
        end
    cam.End3D2D()
end

function ENT:Ov_GetDisplayName()
    local dot = self:GetForward():Dot(self:GetPos() - LocalPlayer():GetPos())
    if dot > 0 then
        self.DisplayIcon = gRust.GetIcon("open")
        return "OPEN"
    end
    self.DisplayIcon = gRust.GetIcon("store")
    return "SHOP"
end

function ENT:Interact(pl)
    pl:RequestInventory(self)
    pl:EmitSound("vending_machine.open")
    gRust.OpenInventory(self)
    local dot = self:GetForward():Dot(self:GetPos() - pl:GetPos())
    if dot < 0 then
        self:ConstructInventory(gRust.Inventory.RightPanel)
    end
end

function ENT:ConstructInventory(pnl, data, rows)
    if self:GetForward():Dot(self:GetPos() - LocalPlayer():GetPos()) > 0 then
        BaseClass.ConstructInventory(self, pnl, data, rows)
        return
    end

    if not self.HasRequestedOrders then
        self:RequestVendingOrders()
        self.HasRequestedOrders = true
    end

    local scaling = gRust.Hud.Scaling or 1
    local scrw, scrh = ScrW(), ScrH()

    if not IsValid(self.Container) then
        self.Container = pnl:Add("Panel")
        self.Container:Dock(FILL)
        self.Container:DockMargin(scrh * 0.01, scrh * 0.1, 0, 0)

        self:BuildVendingInterface()
    end
end

function ENT:BuildVendingInterface()
    if not IsValid(self.Container) then return end

    if not self.OrderQuantities then
        self.OrderQuantities = {}
    end

    local scaling = gRust.Hud.Scaling or 1
    local scrw, scrh = ScrW(), ScrH()
    local Container = self.Container

    for k, v in ipairs(Container:GetChildren()) do
        v:Remove()
    end

    if self:GetVending() then
        local VendingContainer = Container:Add("Panel")
        VendingContainer:Dock(FILL)
        VendingContainer.Paint = function(me, w, h)
            local size = 256 * scaling
            surface.SetDrawColor(255, 255, 255)
            surface.SetMaterial(gRust.GetIcon("vending"))
            surface.DrawTexturedRectRotated(w * 0.5, h * 0.5 - 40 * scaling, size, size, CurTime() * 220)
            draw.SimpleText("VENDING", "gRust.48px", w * 0.5, h * 0.5 + size * 0.5 + 16 * scaling, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        end
    else
        local leftMargin = 32 * scaling
        local padding = 12 * scaling

        local Header = Container:Add("Panel")
        Header:Dock(TOP)
        Header:SetTall(42 * scaling)
        Header:DockMargin(0, 0, 0, 8 * scaling)
        Header.Paint = function(me, w, h)
            surface.SetDrawColor(gRust.Colors.Surface)
            surface.DrawRect(0, 0, w, h)
            draw.SimpleText("FOR SALE", "gRust.30px", leftMargin, h * 0.5, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText("COST", "gRust.30px", leftMargin + 300 * scaling, h * 0.5, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        local ScrollPanel = Container:Add("DScrollPanel")
        ScrollPanel:Dock(FILL)
        ScrollPanel:DockMargin(0, 0, 10 * scaling, 0)

        for k, v in ipairs(self.SellOrders) do
            if not self.OrderQuantities[k] then
                self.OrderQuantities[k] = 1
            end

            local ItemPanel = ScrollPanel:Add("Panel")
            ItemPanel:Dock(TOP)
            ItemPanel:SetTall(144 * scaling)
            ItemPanel:DockMargin(0, 0, 0, 8 * scaling)

            ItemPanel.Paint = function(me, w, h)
                surface.SetDrawColor(126, 126, 126, 39)
                surface.DrawRect(0, 0, w, h)
            end

            local SellPanel = ItemPanel:Add("Panel")
            SellPanel:Dock(LEFT)
            SellPanel:SetWide(300 * scaling)
            SellPanel:DockMargin(leftMargin, padding, 0, padding)

            -- Функция для обновления отображения продаваемого товара
            local function UpdateSellDisplay()
                local quantity = self.OrderQuantities[k] or 1
                local totalSellAmount = v.SellAmount * quantity
                
                SellPanel.Paint = function(me, w, h)
                    local size = h
                    local iconMargin = 8 * scaling
                    local register = gRust.Items[v.SellItem]

                    if register then
                        surface.SetDrawColor(126, 126, 126, 39)
                        surface.DrawRect(0, 0, size, size)
                        surface.SetDrawColor(245, 245, 245)
                        surface.SetMaterial(Material(register.Icon or "vgui/white", "smooth"))
                        surface.DrawTexturedRect(iconMargin, iconMargin, size - iconMargin * 2, size - iconMargin * 2)

                        -- Отображаем общее количество продаваемого товара с учетом множителя
                        draw.SimpleText("x"..string.Comma(totalSellAmount), "gRust.30px", size - iconMargin, size - iconMargin, Color(255, 255, 255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
                    end
                end
                
                -- Перерисовываем панель
                if IsValid(SellPanel) then
                    SellPanel:PaintManual()
                end
            end

            local CostPanel = ItemPanel:Add("Panel")
            CostPanel:Dock(LEFT)
            CostPanel:SetWide(300 * scaling)
            CostPanel:DockMargin(50 * scaling, padding, 0, padding)

            -- Функция для обновления отображения стоимости
            local function UpdateCostDisplay()
                local quantity = self.OrderQuantities[k] or 1
                local totalCost = v.ForAmount * quantity
                
                CostPanel.Paint = function(me, w, h)
                    local size = h
                    local iconMargin = 8 * scaling
                    local register = gRust.Items[v.ForItem]

                    if register then
                        surface.SetDrawColor(126, 126, 126, 39)
                        surface.DrawRect(0, 0, size, size)
                        surface.SetDrawColor(245, 245, 245)
                        surface.SetMaterial(Material(register.Icon or "vgui/white", "smooth"))
                        surface.DrawTexturedRect(iconMargin, iconMargin, size - iconMargin * 2, size - iconMargin * 2)

                        -- Отображаем общее количество с учетом множителя
                        draw.SimpleText("x"..string.Comma(totalCost), "gRust.30px", size - iconMargin, size - iconMargin, Color(255, 255, 255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
                    end
                end
                
                -- Перерисовываем панель
                if IsValid(CostPanel) then
                    CostPanel:PaintManual()
                end
            end

            -- Инициализируем отображение продаваемого товара и стоимости
            UpdateSellDisplay()
            UpdateCostDisplay()

            local BuyPanel = ItemPanel:Add("Panel")
            BuyPanel:Dock(RIGHT)
            BuyPanel:SetWide(150 * scaling)
            BuyPanel:DockMargin(0, padding, 20 * scaling, padding)

            local BuyButton = BuyPanel:Add("gRust.Button")
            BuyButton:Dock(TOP)
            BuyButton:SetTall(60 * scaling)
            BuyButton:SetText("")
            BuyButton:SetFont("gRust.32px")

            local inStock = v.AlwaysInStock or true

            BuyButton.Paint = function(me, w, h)
                if me:IsEnabled() then
                    if inStock then
                        surface.SetDrawColor(me:IsHovered() and Color(122, 151, 76) or Color(99, 122, 61))
                        surface.DrawRect(0, 0, w, h)
                        draw.SimpleText("BUY", "gRust.32px", w/2, h/2, Color(153, 197, 61), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    else
                        surface.SetDrawColor(146, 62, 48)
                        surface.DrawRect(0, 0, w, h)
                        draw.SimpleText("NO STOCK", "gRust.32px", w/2, h/2, Color(238, 106, 106), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    end
                else
                    surface.SetDrawColor(100, 100, 100)
                    surface.DrawRect(0, 0, w, h)
                    draw.SimpleText("BUY", "gRust.32px", w/2, h/2, Color(150, 150, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
            end

            local sending = false
            BuyButton.DoClick = function()
                if sending or not inStock then return end
                sending = true
                
                net.Start("gRust.VendingBuy")
                net.WriteEntity(self)
                net.WriteUInt(k, 12)
                net.WriteUInt(self.OrderQuantities[k] or 1, 10)
                net.SendToServer()
                
                timer.Simple(0.5, function() 
                    sending = false 
                end)
            end

            BuyButton:SetEnabled(inStock)

            local QuantityContainer = BuyPanel:Add("Panel")
            QuantityContainer:Dock(TOP)
            QuantityContainer:SetTall(40 * scaling)
            QuantityContainer:DockMargin(0, 5 * scaling, 0, 0)

            local MinusButton = QuantityContainer:Add("gRust.Button")
            MinusButton:Dock(LEFT)
            MinusButton:SetWide(40 * scaling)
            MinusButton:SetText("-")
            MinusButton:SetFont("gRust.24px")
            MinusButton.Paint = function(me, w, h)
                surface.SetDrawColor(me:IsHovered() and Color(70, 70, 70) or Color(50, 50, 50))
                surface.DrawRect(0, 0, w, h)
            end

            local QuantityDisplay = QuantityContainer:Add("Panel")
            QuantityDisplay:Dock(FILL)
            QuantityDisplay:DockMargin(2 * scaling, 0, 2 * scaling, 0)
            QuantityDisplay.Paint = function(me, w, h)
                surface.SetDrawColor(Color(42, 42, 34, 200))
                surface.DrawRect(0, 0, w, h)
                draw.SimpleText(tostring(self.OrderQuantities[k] or 1), "gRust.24px", w/2, h/2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end

            local PlusButton = QuantityContainer:Add("gRust.Button")
            PlusButton:Dock(RIGHT)
            PlusButton:SetWide(40 * scaling)
            PlusButton:SetText("+")
            PlusButton:SetFont("gRust.24px")
            PlusButton.Paint = function(me, w, h)
                surface.SetDrawColor(me:IsHovered() and Color(70, 70, 70) or Color(50, 50, 50))
                surface.DrawRect(0, 0, w, h)
            end

            MinusButton.DoClick = function()
                if (self.OrderQuantities[k] or 1) > 1 then
                    self.OrderQuantities[k] = (self.OrderQuantities[k] or 1) - 1
                    QuantityDisplay:PaintManual()
                    UpdateSellDisplay() -- Обновляем отображение продаваемого товара
                    UpdateCostDisplay() -- Обновляем отображение стоимости
                end
            end

            PlusButton.DoClick = function()
                if (self.OrderQuantities[k] or 1) < 100 then
                    self.OrderQuantities[k] = (self.OrderQuantities[k] or 1) + 1
                    QuantityDisplay:PaintManual()
                    UpdateSellDisplay() -- Обновляем отображение продаваемого товара
                    UpdateCostDisplay() -- Обновляем отображение стоимости
                end
            end
        end

        local BottomSpacer = ScrollPanel:Add("Panel")
        BottomSpacer:Dock(TOP)
        BottomSpacer:SetTall(10 * scaling)
    end

    self.HasBuiltInterface = true
end

function ENT:RequestVendingOrders()
    net.Start("gRust.RequestVendingOrders")
    net.WriteEntity(self)
    net.SendToServer()
end

net.Receive("gRust.SendSellOrders", function()
    local ent = net.ReadEntity()
    if not IsValid(ent) then return end

    local count = net.ReadUInt(12)
    ent.SellOrders = {}

    for i = 1, count do
        local SellItem = net.ReadString()
        local SellAmount = net.ReadUInt(16)
        local ForItem = net.ReadString()
        local ForAmount = net.ReadUInt(16)
        local AlwaysInStock = net.ReadBool()

        table.insert(ent.SellOrders, {
            SellItem = SellItem,
            SellAmount = SellAmount,
            ForItem = ForItem,
            ForAmount = ForAmount,
            AlwaysInStock = AlwaysInStock
        })
    end

    if IsValid(ent.Container) then
        ent:BuildVendingInterface()
    end
end)

function ENT:OnStartLooting(pl)
    gRust.PlaySound("vendingmachine.open")
    BaseClass.OnStartLooting(self, pl)
end

function ENT:OnStopLooting(pl)
    gRust.PlaySound("toolbox.close")
    BaseClass.OnStopLooting(self, pl)
end