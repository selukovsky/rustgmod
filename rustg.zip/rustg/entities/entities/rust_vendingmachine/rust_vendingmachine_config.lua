
VENDING_MACHINE_ITEMS = {
    {
        SellItem = "stone",
        SellAmount = 1000,
        ForItem = "scrap",
        ForAmount = 50,
        AlwaysInStock = true
    },
    {
        SellItem = "wood",
        SellAmount = 1000,
        ForItem = "scrap",
        ForAmount = 20,
        AlwaysInStock = true
    },
    {
        SellItem = "lowgradefuel",
        SellAmount = 20,
        ForItem = "scrap",
        ForAmount = 10,
        AlwaysInStock = true
    },
    {
        SellItem = "stone",
        SellAmount = 150,
        ForItem = "wood",
        ForAmount = 500,
        AlwaysInStock = true
    },
    {
        SellItem = "wood",
        SellAmount = 500,
        ForItem = "stone",
        ForAmount = 150,
        AlwaysInStock = true
    },
    {
        SellItem = "metal.fragments",
        SellAmount = 250,
        ForItem = "scrap",
        ForAmount = 25,
        AlwaysInStock = true
    },
    {
        SellItem = "scrap",
        SellAmount = 4,
        ForItem = "fertilizer",
        ForAmount = 2,
        AlwaysInStock = true
    }
}

-- Автоматическое создание предметов при инициализации
VENDING_AUTO_STOCK_ITEMS = {
    "bluefrag",
    "stone", 
    "metal.fragments",
    "metal.refined",
    "navoz",
    "wood",
    "scrap"
}