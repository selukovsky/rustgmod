AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
AddCSLuaFile("rust_vendingmachine_config.lua")
include("shared.lua")

util.AddNetworkString("gRust.RequestVendingOrders")
util.AddNetworkString("gRust.SendSellOrders")
util.AddNetworkString("gRust.AddSellOrder")
util.AddNetworkString("gRust.RemoveSellOrder")
util.AddNetworkString("gRust.VendingBuy")
util.AddNetworkString("gRust.ToggleBroadcasting")

function ENT:Initialize()
    self:SetModel(self.Deploy.Model or "models/deployable/vending_machine.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:EnableMotion(false)
        phys:Wake()
    end

    self:SetDamageable(false)
    self:SetHealth(9999)
    self:SetMaxHealth(9999)

    self.Inventory = self.Inventory or {}
    self.InventorySlots = 30
    self.SellOrders = table.Copy(VENDING_MACHINE_ITEMS or {})
    self.EmptyVending = true -- Режим бесконечных товаров

    self:InitializeAutoStock()
end

function ENT:InitializeAutoStock()
    for _, itemClass in ipairs(VENDING_AUTO_STOCK_ITEMS or {}) do
        local amount = 1000
        local success = self:GiveItem(itemClass, amount)
        if not success then
            print("Failed to give auto stock item: " .. tostring(itemClass))
        end
    end
end

function ENT:ReloadConfig()
    self.SellOrders = table.Copy(VENDING_MACHINE_ITEMS or {})
    self:InitializeAutoStock()

    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) then
            self:SendSellOrders(ply)
        end
    end
end

function ENT:GiveItem(itemOrClass, amount, slot, wear, clip)
    if not self.Inventory or not itemOrClass then return false end

    if type(itemOrClass) == "table" and itemOrClass.GetItem then
        local item = itemOrClass
        local targetSlot = slot

        if targetSlot then
            if targetSlot < 1 or targetSlot > self.InventorySlots then return false end

            local existingItem = self.Inventory[targetSlot]
            if existingItem then
                if existingItem:CanStack(item) then
                    local success, overflow = existingItem:Merge(item)
                    if success then
                        self:SyncSlot(targetSlot)
                        return true
                    end
                end
                return false
            else
                self:SetSlot(item:Copy(), targetSlot)
                return true
            end
        else
            for i = 1, self.InventorySlots do
                local existingItem = self.Inventory[i]
                if existingItem and existingItem:CanStack(item) then
                    local success, overflow = existingItem:Merge(item)
                    if success then
                        self:SyncSlot(i)
                        return true
                    end
                end
            end

            local targetSlot = self:FindEmptySlot(1, self.InventorySlots, item)
            if targetSlot then
                self:SetSlot(item:Copy(), targetSlot)
                return true
            end
        end

        return false
    end

    local itemClass = itemOrClass
    if not gRust.Items[itemClass] then return false end

    amount = amount or 1
    local remaining = amount
    local ItemData = gRust.Items[itemClass]
    local maxStack = ItemData:GetStack()

    if slot then
        if slot < 1 or slot > self.InventorySlots then return false end

        local existingItem = self.Inventory[slot]
        if existingItem then
            if existingItem:GetItem() == itemClass and existingItem:CanAddQuantity(remaining) then
                existingItem:AddQuantity(remaining)
                if wear and existingItem.SetWear then existingItem:SetWear(wear) end
                if clip and existingItem.SetClip then existingItem:SetClip(clip) end
                self:SyncSlot(slot)
                return true
            end
            return false
        else
            local newItem = gRust.CreateItem(itemClass, remaining, wear)
            if clip and newItem.SetClip then newItem:SetClip(clip) end
            self:SetSlot(newItem, slot)
            return true
        end
    end

    while remaining > 0 do
        local targetSlot = nil

        for i = 1, self.InventorySlots do
            local existingItem = self.Inventory[i]
            if existingItem and existingItem:GetItem() == itemClass and existingItem:CanAddQuantity(1) then
                targetSlot = i
                break
            end
        end

        if not targetSlot then
            targetSlot = self:FindEmptySlot(1, self.InventorySlots, gRust.CreateItem(itemClass, 1))
        end

        if not targetSlot then break end

        local existingItem = self.Inventory[targetSlot]
        if existingItem then
            local maxAddable = existingItem:GetMaxAddable()
            local toAdd = math.min(remaining, maxAddable)
            existingItem:AddQuantity(toAdd)
            remaining = remaining - toAdd
            self:SyncSlot(targetSlot)
        else
            local toAdd = math.min(remaining, maxStack)
            local newItem = gRust.CreateItem(itemClass, toAdd, wear)
            if clip and newItem.SetClip then newItem:SetClip(clip) end
            if newItem then
                self:SetSlot(newItem, targetSlot)
                remaining = remaining - toAdd
            else
                break
            end
        end
    end

    return remaining == 0
end

function ENT:SendSellOrders(recipient)
    net.Start("gRust.SendSellOrders")
    net.WriteEntity(self)
    net.WriteUInt(#self.SellOrders, 12)

    for i, order in ipairs(self.SellOrders) do
        net.WriteString(order.SellItem or "")
        net.WriteUInt(order.SellAmount or 1, 16)
        net.WriteString(order.ForItem or "")
        net.WriteUInt(order.ForAmount or 1, 16)
        local inStock = order.AlwaysInStock or self.EmptyVending or true
        net.WriteBool(inStock)
    end

    if recipient then
        net.Send(recipient)
    else
        net.Broadcast()
    end
end

net.Receive("gRust.RequestVendingOrders", function(len, ply)
    local ent = net.ReadEntity()
    if IsValid(ent) and ent:GetClass() == "rust_vendingmachine" then
        ent:SendSellOrders(ply)
    end
end)

net.Receive("gRust.VendingBuy", function(len, ply)
    local ent = net.ReadEntity()
    local index = net.ReadUInt(12)
    local quantity = net.ReadUInt(10)

    if not IsValid(ent) or ent:GetClass() ~= "rust_vendingmachine" then return end
    if not ent.SellOrders or not ent.SellOrders[index] then 
        print("Invalid order index: " .. tostring(index))
        return 
    end

    local order = ent.SellOrders[index]
    local totalSellAmount = order.SellAmount * quantity
    local totalForAmount = order.ForAmount * quantity

    print("Attempting to buy: " .. tostring(order.SellItem) .. " x" .. totalSellAmount .. " for " .. tostring(order.ForItem) .. " x" .. totalForAmount)

    if not ply:HasItem(order.ForItem, totalForAmount) then 
        print("Player doesn't have required items")
        return 
    end

    local canAccept = false
    local testItem = gRust.CreateItem(order.SellItem, totalSellAmount)

    if testItem then
        for i = 1, ply.InventorySlots do
            local existingItem = ply.Inventory[i]
            if existingItem and existingItem:GetItem() == order.SellItem then
                local maxStack = gRust.Items[order.SellItem]:GetStack()
                if existingItem:GetQuantity() + totalSellAmount <= maxStack then
                    canAccept = true
                    break
                end
            end
        end

        if not canAccept then
            for i = 1, ply.InventorySlots do
                if not ply.Inventory[i] then
                    canAccept = true
                    break
                end
            end
        end
    end

    if not canAccept then 
        print("Player doesn't have space for items")
        return 
    end

    if not ent.EmptyVending then
        local hasItem = ent:HasItem(order.SellItem, totalSellAmount)
        if not hasItem then 
            print("Vending machine doesn't have items in stock")
            return 
        end

        local removed = ent:RemoveItem(order.SellItem, totalSellAmount)
        if not removed then 
            print("Failed to remove items from vending machine")
            return 
        end
    end

    local removed = ply:RemoveItem(order.ForItem, totalForAmount)
    if not removed then 
        print("Failed to remove payment items from player")
        return 
    end

    local given = ply:GiveItem(order.SellItem, totalSellAmount)
    if not given then
        print("Failed to give items to player, refunding...")
        ply:GiveItem(order.ForItem, totalForAmount)
        return
    end

    print("Purchase successful!")
    ply:EmitSound("rust/vending-machine-purchase.wav")
end)

concommand.Add("rust_reload_vending_configs", function(ply, cmd, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    for _, ent in ipairs(ents.FindByClass("rust_vendingmachine")) do
        ent:ReloadConfig()
    end
end)