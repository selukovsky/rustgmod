DEFINE_BASECLASS("rust_storage")
ENT.Base = "rust_storage"

-- Добавляем сетевые строки
if SERVER then
    util.AddNetworkString("gRust.RequestVendingOrders")
    util.AddNetworkString("gRust.SendSellOrders")
    util.AddNetworkString("gRust.AddSellOrder")
    util.AddNetworkString("gRust.RemoveSellOrder")
    util.AddNetworkString("gRust.VendingBuy")
    util.AddNetworkString("gRust.ToggleBroadcasting")
end

-- Загружаем конфиг
if SERVER then
    include("rust_vendingmachine_config.lua")
else
    VENDING_MACHINE_ITEMS = VENDING_MACHINE_ITEMS or {}
    VENDING_AUTO_STOCK_ITEMS = VENDING_AUTO_STOCK_ITEMS or {}
end

ENT.Deploy = {}
ENT.Deploy.Model = "models/deployable/vending_machine.mdl"

ENT.Options =
{
    {
        Name    = "Toggle Broadcasting",
        Desc    = "",
        Icon    = gRust.GetIcon("power"),
        Func    = function(ent)
			net.Start("gRust.ToggleBroadcasting")
				net.WriteEntity(ent)
			net.SendToServer()
        end
    },
    {
        Name    = "Open",
        Desc    = "",
        Icon    = gRust.GetIcon("open"),
        Func    = function(ent)
            ent:Interact(LocalPlayer())
        end
    }
}

function ENT:SetupDataTables()
    BaseClass.SetupDataTables(self)
    self:NetworkVar("Bool", 1, "Vending")
end