DEFINE_BASECLASS("rust_base")

AddCSLuaFile()

ENT.Base = "rust_base"

ENT.Deploy          = {}
ENT.Deploy.Model    = "models/deployable/sleeping_bag.mdl"

ENT.DisplayIcon 	= gRust.GetIcon("sleepingbag")
ENT.ShowHealth      = true

ENT.RespawnDelay = 300

ENT.Pickup          = "sleeping_bag"

if (SERVER) then
    util.AddNetworkString("gRust.AddSleepingBag")
    util.AddNetworkString("gRust.RemoveSleepingBag")
    util.AddNetworkString("gRust.UpdateSleepingBagMap")
    
    gRust.SleepingBags = gRust.SleepingBags or {}
    gRust.SleepingBagCache = gRust.SleepingBagCache or {}
    
    ENT.Deploy.OnDeploy = function(pl, ent, tr)
        net.Start("gRust.AddSleepingBag")
        net.WriteUInt(ent:EntIndex(), 13)
        net.WriteString(ent:GetBagName() or "Unnamed Bag")
        net.WriteVector(ent:GetPos())
        net.Send(pl)

        ent.Owner = pl
        ent.OwnerSteamID = pl:SteamID()
        
        -- Добавляем мешок в систему смерти
        AddSleepingBagToPlayer(pl, ent)
        
        -- Обновляем карту для всех мешков игрока
        UpdatePlayerSleepingBagsMap(pl)
        
        print("[SleepingBag] Bag deployed by " .. pl:Nick() .. ", added to death system")
    end
else
    net.Receive("gRust.AddSleepingBag", function()
        local pl = LocalPlayer()
        local entid = net.ReadUInt(13)
        local name = net.ReadString()
        local pos = net.ReadVector()

        pl.SleepingBags = pl.SleepingBags or {}
        pl.SleepingBags[entid] = {
            name = name,
            pos = pos
        }
        
        -- Обновляем карту
        if IsValid(gRust.MapMenu) then
            gRust.MapMenu:UpdateSleepingBags()
        end
    end)
    
    net.Receive("gRust.RemoveSleepingBag", function()
        local pl = LocalPlayer()
        local entid = net.ReadUInt(13)
        
        if pl.SleepingBags then
            pl.SleepingBags[entid] = nil
        end
        
        -- Обновляем карту
        if IsValid(gRust.MapMenu) then
            gRust.MapMenu:UpdateSleepingBags()
        end
    end)
    
    net.Receive("gRust.UpdateSleepingBagMap", function()
        local pl = LocalPlayer()
        local count = net.ReadUInt(8)
        
        pl.SleepingBags = {}
        for i = 1, count do
            local entid = net.ReadUInt(13)
            local name = net.ReadString()
            local pos = net.ReadVector()
            
            pl.SleepingBags[entid] = {
                name = name,
                pos = pos
            }
        end
        
        -- Обновляем карту
        if IsValid(gRust.MapMenu) then
            gRust.MapMenu:UpdateSleepingBags()
        end
    end)
end

function ENT:SetupDataTables()
    BaseClass.SetupDataTables(self)
    self:NetworkVar("String", 1, "BagName")
    self:SetBagName("Unnamed Bag")
    self:NetworkVar("Int", 1, "LastRespawn")
    self:SetLastRespawn(0)
end

function ENT:Initialize()
    self:SetInteractable(true)
    self:SetModel("models/deployable/sleeping_bag.mdl")

    if (CLIENT) then return end

    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetDisplayName("Rename Sleeping Bag")

    self:SetDamageable(true)
    self:SetHealth(200)
    self:SetMaxHealth(200)

    self:SetMeleeDamage(0.2)
    self:SetBulletDamage(0.05)
    self:SetExplosiveDamage(0.4)

    if (!self.BagIndex) then
        self.BagIndex = self:EntIndex()
    end
    
    -- Устанавливаем задержку респавна
    self:SetLastRespawn(0)
    
    -- Если мешок загружается из сохранения, добавляем его в систему
    timer.Simple(1.0, function()
        if IsValid(self) and self.OwnerSteamID then
            local owner = player.GetBySteamID(self.OwnerSteamID)
            if IsValid(owner) then
                self.Owner = owner
                AddSleepingBagToPlayer(owner, self)
                UpdatePlayerSleepingBagsMap(owner)
                print("[SleepingBag] Loaded bag for " .. owner:Nick())
            end
        end
    end)
end

function ENT:Interact(pl)
    if (SERVER) then return end

    gRust.StringQuery("RENAME SLEEPING BAG", "CANCEL", "Change Name", function(txt)
        if (!IsValid(self)) then return end

        net.Start("gRust.RenameBag")
        net.WriteString(txt)
        net.WriteEntity(self)
        net.SendToServer()
    end)
end

if (SERVER) then
    util.AddNetworkString("gRust.RenameBag")
    net.Receive("gRust.RenameBag", function(len, pl)
        local Text = net.ReadString()
        local ent = net.ReadEntity()

        if (ent:GetClass() ~= "rust_sleepingbag") then
            return
        end

        if (string.match(Text, "%W")) then
            pl:ChatPrint("Sleeping bag names should only contain alphanumeric characters")
            return
        end

        if (string.len(Text) < 3) then
            pl:ChatPrint("Bag name must be more than 2 characters")
            return
        end

        if (string.len(Text) > 20) then
            pl:ChatPrint("Bag name must be 20 characters or less")
            return
        end

        if (pl:GetPos():DistToSqr(ent:GetPos()) > 25000) then return end
        
        local tr = {}
        tr.start = pl:EyePos()
        tr.endpos = ent:GetPos() + ent:OBBCenter()
        tr.filter = {pl, ent}
        tr = util.TraceLine(tr)

        if (tr.Hit) then
            pl:ChatPrint("You must be looking at this sleeping bag")
            return
        end
        
        ent:SetBagName(Text)
        
        -- Обновляем карту после переименования
        UpdatePlayerSleepingBagsMap(pl)
    end)
end

function ENT:Save(data)
	data.pos 	= self:GetPos()
	data.ang 	= self:GetAngles()
    
    data.owner  = self.OwnerSteamID or (IsValid(self.Owner) and self.Owner:SteamID() or nil)
    data.bagindex = self.BagIndex

    data.name   = self:GetBagName()
    data.last_respawn = self:GetLastRespawn()
end

function ENT:Load(data)
	self:SetPos(data.pos)
	self:SetAngles(data.ang)
    
    self.OwnerSteamID = data.owner
    self.BagIndex = data.bagindex

    self:SetBagName(data.name)
    self:SetLastRespawn(data.last_respawn or 0)
    
    -- Восстанавливаем владельца при загрузке
    if data.owner then
        timer.Simple(2.0, function()
            if IsValid(self) then
                local owner = player.GetBySteamID(data.owner)
                if IsValid(owner) then
                    self.Owner = owner
                    UpdatePlayerSleepingBagsMap(owner)
                    print("[SleepingBag] Restored owner: " .. owner:Nick())
                end
            end
        end)
    end
end

-- Методы для работы с системой смерти
function ENT:GetLastRespawn()
    return self:GetNWFloat("LastRespawn", 0)
end

function ENT:SetLastRespawn(time)
    self:SetNWFloat("LastRespawn", time)
end

function ENT:OnRemove()
    if SERVER then
        if IsValid(self.Owner) then
            RemoveSleepingBagFromPlayer(self.Owner, self)
            UpdatePlayerSleepingBagsMap(self.Owner)
            print("[SleepingBag] Removed bag from death system")
        end
        
        -- Уведомляем всех клиентов об удалении мешка
        net.Start("gRust.RemoveSleepingBag")
        net.WriteUInt(self:EntIndex(), 13)
        net.Broadcast()
    end
end

-- Серверная функция для обновления карты спальных мешков
if SERVER then
    function UpdatePlayerSleepingBagsMap(pl)
        if not IsValid(pl) then return end
        
        local bags = {}
        local count = 0
        
        -- Ищем все спальные мешки игрока
        for _, ent in pairs(ents.FindByClass("rust_sleepingbag")) do
            if IsValid(ent) and ent.Owner == pl then
                bags[ent:EntIndex()] = {
                    name = ent:GetBagName() or "Unnamed Bag",
                    pos = ent:GetPos()
                }
                count = count + 1
            end
        end
        
        -- Отправляем обновление игроку
        net.Start("gRust.UpdateSleepingBagMap")
        net.WriteUInt(count, 8)
        
        for entid, bag in pairs(bags) do
            net.WriteUInt(entid, 13)
            net.WriteString(bag.name)
            net.WriteVector(bag.pos)
        end
        
        net.Send(pl)
    end
    
    -- Обновляем карту при подключении игрока
    hook.Add("PlayerInitialSpawn", "UpdateSleepingBagsOnSpawn", function(pl)
        timer.Simple(3, function()
            if IsValid(pl) then
                UpdatePlayerSleepingBagsMap(pl)
            end
        end)
    end)
end