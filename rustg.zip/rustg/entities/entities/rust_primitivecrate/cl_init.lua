-- COPYRIGHT DOWN 2021, ALL RIGHTS RESERVED

include("shared.lua")

function ENT:Draw()
    self:DrawModel()
end