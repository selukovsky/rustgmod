AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

DEFINE_BASECLASS("base_gmodentity")

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Card Reader Door"
ENT.Spawnable = true

function ENT:Initialize()
    self:SetModel("models/darky_m/rust/puzzle/door.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(100)
        phys:EnableMotion(false)
    end

    self.OriginalAngles = self:GetAngles()
    self:SetNWBool("Opened", false)
    self.IsAnimating = false
end

function ENT:GetOpened()
    return self:GetNWBool("Opened", false)
end

function ENT:SetOpened(state)
    self:SetNWBool("Opened", state)
end

function ENT:OpenDoorForDuration(duration)
    if self.IsAnimating or self:GetOpened() then return end

    self:SetOpened(true)
    self.IsAnimating = true

    local targetAngle = self.OriginalAngles + Angle(0, 90, 0)
    self:AnimateRotation(targetAngle, 1.0)

    timer.Simple(duration, function()
        if not IsValid(self) then return end
        self:CloseDoor()
    end)
end

function ENT:CloseDoor()
    if self.IsAnimating or not self:GetOpened() then return end

    self:SetOpened(false)
    self.IsAnimating = true

    self:EmitSound("doors/door_metal_close.wav")

    timer.Simple(0.9, function()
        if IsValid(self) then
            self:EmitSound("doors/door_metal_shut.wav")
        end
    end)

    local targetAngle = self.OriginalAngles
    self:AnimateRotation(targetAngle, 1.0)
end

function ENT:AnimateRotation(targetAngle, duration)
    local startAngle = self:GetAngles()
    local startTime = CurTime()

    local function updateRotation()
        if not IsValid(self) then return end

        local progress = math.min((CurTime() - startTime) / duration, 1)
        self:SetAngles(LerpAngle(progress, startAngle, targetAngle))

        if progress >= 1 then
            self.IsAnimating = false
            return
        end

        timer.Simple(0.01, updateRotation)
    end

    updateRotation()
end