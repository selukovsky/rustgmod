AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

DEFINE_BASECLASS("base_gmodentity")

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Card "
ENT.Spawnable = true

function ENT:Initialize()
    self:SetModel("models/darky_m/rust/puzzle/door.mdl") -- замени на свою модель
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(100)
        phys:EnableMotion(false)
    end

    self.OriginalAngles = self:GetAngles()
    self:SetNWBool("Opened", false)
    self.IsAnimating = false
    self.OpenTimer = nil
    self.CorrectCardUsed = false
    self:SetUseType(SIMPLE_USE)
end

function ENT:GetOpened()
    return self:GetNWBool("Opened", false)
end

function ENT:SetOpened(state)
    self:SetNWBool("Opened", state)
end

function ENT:Use(activator, caller)
    if not IsValid(activator) or not activator:IsPlayer() then return end

    if self.LinkedDoor and IsValid(self.LinkedDoor) then
        self.LinkedDoor:AuthorizeCard()
        self.LinkedDoor:OpenDoorForDuration(180)
        activator:ChatPrint("Дверь открыта на 3 минуты.")
        self:EmitSound("buttons/button1.wav")
    else
        activator:ChatPrint("Дверь не привязана к кардридеру.")
    end
end

function ENT:AuthorizeCard()
    self.CorrectCardUsed = true
    print("[Door] AuthorizeCard вызван")
end

function ENT:OpenDoorForDuration(duration)
    if self.IsAnimating or self:GetOpened() then return end

    self:SetOpened(true)
    self.IsAnimating = true

    local targetAngle = self.OriginalAngles + Angle(0, 90, 0)
    self:AnimateRotation(targetAngle, 1.0)

    if self.OpenTimer then
        timer.Remove(self.OpenTimer)
    end

    self.OpenTimer = "CardDoorCloseTimer_" .. self:EntIndex()

    timer.Create(self.OpenTimer, duration, 1, function()
        if not IsValid(self) then return end
        self:CloseDoor()
    end)
end

function ENT:CloseDoor()
    if self.IsAnimating or not self:GetOpened() then return end

    self:SetOpened(false)
    self.IsAnimating = true

    local targetAngle = self.OriginalAngles
    self:AnimateRotation(targetAngle, 1.0)
end

function ENT:AnimateRotation(targetAngle, duration)
    local startAngle = self:GetAngles()
    local startTime = CurTime()

    local function updateRotation()
        if not IsValid(self) then return end

        local progress = math.min((CurTime() - startTime) / duration, 1)
        self:SetAngles(LerpAngle(progress, startAngle, targetAngle))

        if progress >= 1 then
            self.IsAnimating = false
            return
        end

        timer.Simple(0.01, updateRotation)
    end

    updateRotation()
end