DEFINE_BASECLASS("rust_base")
ENT.Base = "rust_base"

ENT.AutomaticFrameAdvance = true

ENT.DisplayIcon = gRust.GetIcon("lock")
ENT.DrawHalo    = true