

DEFINE_BASECLASS("rust_base")

ENT.Base = "rust_base"