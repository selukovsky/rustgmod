AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

DEFINE_BASECLASS("rust_base")

function ENT:Initialize()
    if CLIENT then return end

    self:SetModel("models/darky_m/rust/puzzle/card_reader.mdl")
    self:SetSolid(SOLID_VPHYSICS)
    if self.Deploy then
        self:PhysicsInitStatic(SOLID_VPHYSICS)
    else
        self:PhysicsInit(SOLID_VPHYSICS)
        local phys = self:GetPhysicsObject()
        if IsValid(phys) then
            phys:EnableMotion(false)
            phys:Sleep()
        end
    end
    BaseClass.Initialize(self)

    self.LinkedDoor = nil -- ссылка на ENT двери
    self:FindAndSetLinkedDoor()
end

function ENT:SetLinkedDoor(doorEntity)
    self.LinkedDoor = doorEntity
end

function ENT:FindAndSetLinkedDoor()
    local dist = 200
    for _, ent in pairs(ents.FindInSphere(self:GetPos(), dist)) do
        if IsValid(ent) and ent:GetClass() == "rust_puzzledoorblue" then
            self:SetLinkedDoor(ent)
            print("Linked door set to entity: ", ent)
            break
        end
    end
end

function ENT:Use(activator, caller)
    if not IsValid(activator) or not activator:IsPlayer() then return end

    -- Проверяем наличие задержки
    if self.LastUseTime and CurTime() - self.LastUseTime < 5 then
        activator:ChatPrint("Пожалуйста, подождите перед повторным использованием.")
        return
    end

    if activator.HasItem and activator:HasItem("keycard_blue", 1) then
        local door = nil
        local dist = 200
        for _, ent in pairs(ents.FindInSphere(self:GetPos(), dist)) do
            if IsValid(ent) and ent:GetClass() == "rust_puzzledoorblue" then
                door = ent
                break
            end
        end

        if door then
            door:AuthorizeCard()
            door:OpenDoorForDuration(180)
            activator:ChatPrint("Дверь открыта на 3 минуты.")

            if activator.RemoveItem then
                local removed = activator:RemoveItem("keycard_blue", 1)
                if removed then
                    activator:ChatPrint("Карта использована и удалена.")
                else
                    activator:ChatPrint("Не удалось удалить карту из инвентаря.")
                end
            else
                activator:ChatPrint("Функция удаления карты не найдена.")
            end

            self:EmitSound("buttons/button1.wav")
            self.LastUseTime = CurTime() -- Устанавливаем время последнего использования
        else
            activator:ChatPrint("Ближайшая дверь не найдена.")
        end
    else
        activator:ChatPrint("У вас нет необходимой карты для открытия двери.")
    end
end