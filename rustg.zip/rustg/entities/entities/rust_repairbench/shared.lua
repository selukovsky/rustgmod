ENT.Base = "rust_storage"

ENT.InventorySlots  = 5
ENT.InventoryName   = "REPAIR BENCH"

ENT.ShowHealth      = true

ENT.Deploy          = {}
ENT.Deploy.Model    = "models/deployable/repair_bench.mdl"

ENT.Pickup          = "repair_bench"