AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

DEFINE_BASECLASS("rust_storage")

util.AddNetworkString("gRust.Repair")

function ENT:Initialize()
    self:SetModel(self.Deploy.Model)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    self:CreateInventory(1)
    self:SetInteractable(true)
    
    local phys = self:GetPhysicsObject()
    if phys:IsValid() then
        phys:Wake()
    end
    
    self:InitInventory()
end

function ENT:Use(activator, caller)
    if not IsValid(activator) or not activator:IsPlayer() then return end
end

-- Инициализация инвентаря
function ENT:InitInventory()
    self.Inventory = {}
    self.InventorySlots = self.InventorySlots or 5
    
    for i = 1, self.InventorySlots do
        self.Inventory[i] = nil
    end
end

-- Получение инвентаря
function ENT:GetInventory()
    return self.Inventory
end

-- Установка предмета в слот
function ENT:SetSlot(item, slot)
    if not self.Inventory or not slot then return false end
    if slot > self.InventorySlots or slot < 1 then return false end
    
    self.Inventory[slot] = item
    self:SyncSlot(slot)
    return true
end

-- Удаление предмета из слота
function ENT:RemoveSlot(slot)
    if not self.Inventory or not slot then return end
    self.Inventory[slot] = nil
    self:SyncSlot(slot)
end

-- Синхронизация слота
function ENT:SyncSlot(slot)
    if not self.Inventory or not slot then return end
    local item = self.Inventory[slot]
    
    -- Находим всех игроков рядом с ремонтным столом
    local recipients = {}
    for _, pl in pairs(player.GetAll()) do
        if IsValid(pl) and pl:GetPos():Distance(self:GetPos()) <= 200 then 
            table.insert(recipients, pl) 
        end
    end

    if #recipients > 0 then
        if item then
            net.Start("gRust.Inventory.SyncSlot")
            net.WriteEntity(self)
            net.WriteUInt(slot, 6)
            net.WriteItem(item)
            net.Send(recipients)
        else
            net.Start("gRust.Inventory.Remove")
            net.WriteEntity(self)
            net.WriteUInt(slot, 6)
            net.Send(recipients)
        end
    end
end

-- Основная функция ремонта
function ENT:HasRepairResources(ply, repairCost)
    if not IsValid(ply) then return false end
    for _, cost in ipairs(repairCost) do
        local hasAmount = ply:HasItem(cost.Class, cost.Amount)
        if not hasAmount then
            return false
        end
    end
    return true
end

-- Снимает ресурсы из инвентаря игрока для починки
function ENT:TakeRepairResources(ply, repairCost)
    if not IsValid(ply) then return false end
    for _, cost in ipairs(repairCost) do
        local success = ply:RemoveItem(cost.Class, cost.Amount)
        if not success then
            return false
        end
    end
    return true
end

-- Повышает прочность предмета на фиксированное значение (например +0.2 по износу),
-- но не выше максимальной (wear = 1 - полная прочность)
function ENT:PerformRepair(itemToRepair)
    if not itemToRepair then return false end
    if not itemToRepair.GetWear or not itemToRepair.SetWear then return false end

    local wear = itemToRepair:GetWear() -- от 0 (новый) до 1 (сломанный)
    local repairAmount = 0.2 -- Уменьшить износ на этот коэффициент

    local newWear = wear - repairAmount
    if newWear < 0 then newWear = 0 end -- Не выше 100% прочности

    itemToRepair:SetWear(newWear)
    return true
end

-- Основная функция починки предмета из инвентаря (слот 1)
function ENT:RepairItem(ply)
    if not IsValid(ply) then return false, "Недопустимый игрок" end

    local itemToRepair = self.Inventory[1]
    if not itemToRepair then return false, "Нет предмета для починки" end

    local repairCost = itemToRepair.GetRepairCost and itemToRepair:GetRepairCost()
    if not repairCost then return false, "Этот предмет нельзя починить" end

    local wear = itemToRepair:GetWear()
    if wear <= 0 then return false, "Предмет не требует починки" end

    if not self:HasRepairResources(ply, repairCost) then
        return false, "Недостаточно ресурсов для починки"
    end

    if not self:TakeRepairResources(ply, repairCost) then
        return false, "Ошибка снятия ресурсов"
    end

    if not self:PerformRepair(itemToRepair) then
        return false, "Ошибка починки предмета"
    end

    self:SyncSlot(1) -- Обновляем слот инвентаря

    return true, "Предмет успешно починен"
end

net.Receive("gRust.RepairSuccess", function()
    if InputCost and InputCost.Update then
        InputCost:Update()
    end
    if Slot1 and Slot1.SetItem then
        Slot1:SetItem(LocalPlayer().Inventory[1])
    end
end)

-- Сетевая обработка починки
net.Receive("gRust.Repair", function(len, ply)
    local repairBench = net.ReadEntity()
    if not IsValid(repairBench) or not repairBench.RepairItem then return end
    if not IsValid(ply) then return end

    if ply:GetPos():Distance(repairBench:GetPos()) > 200 then
        ply:ChatPrint("Вы слишком далеко от верстака для починки.")
        return
    end

    local success, message = repairBench:RepairItem(ply)
    if success then
        ply:ChatPrint("Предмет починен успешно!")
    else
        ply:ChatPrint("Починка не удалась: "..message)
    end
end)

-- Сохранение и загрузка данных
function ENT:PostEntityPaste(ply, ent, createdEnts)
    if self.PreEntityPaste then
        self:PreEntityPaste(ply, ent, createdEnts)
    end
    
    self:InitInventory()
end

duplicator.RegisterEntityClass("repair_bench", function(ply, data)
    if not ply:CheckLimit("repair_bench") then return end
    
    local ent = duplicator.GenericDuplicatorFunction(ply, data)
    if IsValid(ent) then
        ply:AddCount("repair_bench", ent)
        ent:InitInventory()
    end
    
    return ent
end, "Data")