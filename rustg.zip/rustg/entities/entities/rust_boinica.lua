AddCSLuaFile()



ENT.Base = "rust_base"



ENT.Model    = "models/deployable/vertical_embrasure.mdl"

ENT.MaxHealth   = 500



ENT.MeleeDamage     = 0.0

ENT.BulletDamage    = 0.1

ENT.ExplosiveDamage = 0.3



ENT.Deploy          = {}

ENT.Deploy.Rotation = 0

ENT.Deploy.Model    = "models/deployable/vertical_embrasure.mdl"

ENT.Deploy.Socket   = "emb"

ENT.Deploy.Sound    = "deploy/metal_bars_deploy.wav"



ENT.woodupkeep = 50



ENT.Pickup = "reinforced_window"