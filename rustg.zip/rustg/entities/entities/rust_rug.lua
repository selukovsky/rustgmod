AddCSLuaFile()

ENT.Base = "rust_base"

ENT.Model    = "models/deployable/rug.mdl"
ENT.MaxHealth   = 250

ENT.MeleeDamage     = 0.1
ENT.BulletDamage    = 0.2
ENT.ExplosiveDamage = 0.3

ENT.Deploy          = {}
ENT.Deploy.Rotation = 0
ENT.Deploy.Model    = "models/deployable/rug.mdl"
ENT.Deploy.Sound	= "deploy/wood_bars_deploy.wav"

ENT.woodupkeep = 50

ENT.Pickup = "rug"