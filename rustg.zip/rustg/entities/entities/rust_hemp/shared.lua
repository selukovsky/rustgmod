ENT.Base = "rust_base"



ENT.DisplayIcon = gRust.GetIcon("give")



ENT.Deploy = {}

ENT.Deploy.Model = "models/environment/plants/hemp.mdl"

ENT.DrawHalo    = true
