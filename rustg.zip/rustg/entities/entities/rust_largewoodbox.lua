AddCSLuaFile()

ENT.Base = "rust_storage"

ENT.InventorySlots = 48
ENT.InventoryName = "Большой деревянный ящик"

ENT.Deploy = {}
ENT.Deploy.Model = "models/deployable/large_wooden_box.mdl"

ENT.Pickup = "box.wooden.large"
ENT.DisplayIcon = gRust.GetIcon("open")
ENT.ShowHealth = true

function ENT:Initialize()
    if (CLIENT) then return end

    self:SetModel("models/deployable/large_wooden_box.mdl")
    self:PhysicsInitStatic(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)
    self:CreateInventory(48)
    self:SetSaveItems(true)
    self:SetInteractable(true)
    
    self:SetDamageable(true)
    self:SetHealth(200)
    self:SetMaxHealth(200)

    self:SetMeleeDamage(0.2)
    self:SetBulletDamage(0.05)
    self:SetExplosiveDamage(0.4)

    self:SetDisplayName("OPEN")
    
    -- Устанавливаем тип звука открывания для этого контейнера
    self:SetOpenSoundType("largewoodbox") -- Можно использовать "wood", "metal" и т.д.
    
    -- Или добавим кастомные звуки для этого типа контейнера
    self:AddOpenSounds("wood", {
        "physics/wood/wood_crate_open1.wav",
        "physics/wood/wood_crate_open2.wav",
        "ambient/materials/door_hit_wood1.wav"
    })
end



function ENT:AddOpenSounds(soundType, sounds)
    if type(sounds) == "string" then
        sounds = {sounds}
    end

    self.OpenSounds = self.OpenSounds or {}
    if not self.OpenSounds[soundType] then
        self.OpenSounds[soundType] = {}
    end

    for _, sound in ipairs(sounds) do
        table.insert(self.OpenSounds[soundType], sound)
    end
end