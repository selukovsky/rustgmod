AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")
util.AddNetworkString("gRust.PickupLock")

-- Переносим функцию FindNearestTC в начало файла
local function FindNearestTC(pos, radius)
    local nearest, best = nil, math.huge
    for _, v in ipairs(ents.FindInSphere(pos, radius or 300)) do
        if IsValid(v) and v:GetClass() == "rust_toolcupboard" then
            local d = pos:Distance(v:GetPos())
            if d < best then
                best = d
                nearest = v
            end
        end
    end
    return nearest
end

function ENT:SetupDataTables()
    self:NetworkVar("Bool", 0, "Opened")
    self:NetworkVar("String", 0, "DoorCode")
end

function ENT:Initialize()
    self:SetModel(self.Model or "models/deployable/door_wood.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)
    
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(100)
        phys:EnableMotion(false)
    end

    self:SetOpened(false)
    self:SetBodygroup(2, 0)
    self.OriginalAngles = self:GetAngles()
    self.IsAnimating = false
    self.DoorCode = nil
    self:SetUseType(SIMPLE_USE)
end

function ENT:Use(activator, caller)
    if not IsValid(activator) or not activator:IsPlayer() then return end
    if self.IsAnimating then return end

    local tc = self:FindNearestTC(self:GetPos(), 300)

    -- Door unlocked, anyone can open/close
    if self:GetBodygroup(2) == 0 then
        self:ToggleDoor()
        return
    end

    -- Door locked, check TC authorization
    if tc then
        local hasAccess = tc:IsAuthorized(activator)
        if hasAccess then
            self:ToggleDoor()
        else
            activator:ChatPrint("You are not authorized on the nearby Tool Cupboard.")
        end
    else
        activator:ChatPrint("A Tool Cupboard is required nearby to unlock this door.")
    end
end

function ENT:FindNearestTC(pos, radius)
    local nearest, best = nil, math.huge
    for _, v in ipairs(ents.FindInSphere(pos, radius or 300)) do
        if IsValid(v) and v:GetClass() == "rust_toolcupboard" then
            local d = pos:Distance(v:GetPos())
            if d < best then
                best = d
                nearest = v
            end
        end
    end
    return nearest
end

function ENT:ToggleDoor()
    if self.IsAnimating then return end
    
    local isOpened = self:GetOpened()
    self:SetOpened(not isOpened)
    self.IsAnimating = true
    
    self:ToggleSingleDoor(not isOpened)
end

function ENT:ToggleSingleDoor(shouldOpen)
    local targetAngle
    
    if shouldOpen then
        targetAngle = self.OriginalAngles + Angle(0, 90, 0)
        self:EmitSound(self:GetOpenSound() or "doors/door_metal_open.wav")
    else
        targetAngle = self.OriginalAngles
        self:EmitSound(self:GetCloseSound() or "doors/door_metal_close.wav")
    end

    self:AnimateRotation(targetAngle, 1.0)
end

function ENT:AnimateRotation(targetAngle, duration)
    local startAngle = self:GetAngles()
    local startTime = CurTime()
    
    local function updateRotation()
        if not IsValid(self) then 
            self.IsAnimating = false
            return 
        end
        
        local progress = math.min((CurTime() - startTime) / duration, 1)
        local currentAngle = LerpAngle(progress, startAngle, targetAngle)
        self:SetAngles(currentAngle)
        
        if progress >= 1 then
            self.IsAnimating = false
            return
        end

        timer.Simple(0.01, updateRotation)
    end

    updateRotation()
end

function ENT:GetOpenSound()
    if self.DoorSound == "metal" then
        return "doors/door_metal_open.wav"
    else
        return "doors/door_wood_open1.wav"
    end
end

function ENT:GetCloseSound()
    if self.DoorSound == "metal" then
        return "doors/door_metal_close.wav"
    else
        return "doors/door_wood_close1.wav"
    end
end