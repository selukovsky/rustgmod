include("shared.lua")
ENT.ShowHealth = true

function ENT:Draw()
    self:DrawModel()
    
    -- Отрисовка двойных дверей если они есть
    if IsValid(self.LeftDoor) then
        self.LeftDoor:DrawModel()
    end
    if IsValid(self.RightDoor) then
        self.RightDoor:DrawModel()
    end
end

-- Убедиться что двери следуют за основной entity
function ENT:Think()
    if IsValid(self.LeftDoor) and IsValid(self.RightDoor) then
        local spacing = self.DoorSpacing or 50.7
        self.LeftDoor:SetPos(self:LocalToWorld(Vector(spacing, 0, 5)))
        self.RightDoor:SetPos(self:LocalToWorld(Vector(-spacing, 0, 5)))
    end
    self:NextThink(CurTime() + 0.1)
    return true
end