AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

DEFINE_BASECLASS("rust_storage")

util.AddNetworkString("gRust.Authorize")
util.AddNetworkString("gRust.ClearAuthlist")
util.AddNetworkString("gRust.Deauthorize")
util.AddNetworkString("gRust.BuildingStatus")

ENT.InventorySlots = 24
ENT.InventoryName = "TOOL CUPBOARD"
ENT.Base = "rust_storage"
ENT.ShowHealth = true

ENT.Deploy = {}
ENT.Deploy.Model = "models/deployable/tool_cupboard.mdl"
ENT.Deploy.Sound = "deploy/tool_cupboard_deploy.wav"
ENT.Deploy.OnDeploy = function(pl, ent, tr)
    ent:Authorize(pl)
    ent.TC_Owner = pl
end

ENT.Pickup = "tool_cupboard"

if not gRust then gRust = {} end
if not gRust.Building then gRust.Building = {} end

gRust.Building.PlayerCache = {}

function ENT:Initialize()
    BaseClass.Initialize(self)
    self:SetInteractable(true)
    self:SetOpenSoundType("cupbord")
    self:CreateInventory(24)

    self.AuthorizedPlayers = {}
    self.LastUpkeepTime = CurTime()
    self.UpkeepInterval = 60
    self.ProtectedUntil = CurTime() + (24 * 60 * 60)

    self:SetNW2Int("WoodUpkeep", 100)
    self:SetNW2Int("StoneUpkeep", 50)
    self:SetNW2Int("MetalUpkeep", 25)
    self:SetNW2Int("HQUpkeep", 5)
    self:SetNW2String("ProtectedFor", "24h")
    self:SetNW2Bool("IsProtected", true)

    if not timer.Exists("gRust.Building.GlobalUpdate") then
        timer.Create("gRust.Building.GlobalUpdate", 2, 0, function()
            gRust.Building.UpdateAllPlayers()
        end)
    end

    timer.Simple(0.1, function()
        if IsValid(self) then
            self:UpdateProtectionTime()
            self:CalculateUpkeep()
        end
    end)
end

function ENT:CreateInventory(slots)
    self.Inventory = {}
    self.InventorySlots = slots or 24
end

function ENT:Interact(ply)
    if not IsValid(ply) then return end

    if not self:IsAuthorized(ply) then
        if #self.AuthorizedPlayers == 0 then
            self:Authorize(ply)
            ply:ChatPrint("Автоматически авторизован как владелец Tool Cupboard!")
        else
            ply:ChatPrint("У вас нет доступа к этому Tool Cupboard!")
            ply:EmitSound("buttons/button2.wav")
            return false
        end
    end

    BaseClass.Interact(self, ply)
end

function ENT:Authorize(ply)
    if not IsValid(ply) then return end

    local sid = ply:SteamID64()
    if not table.HasValue(self.AuthorizedPlayers, sid) then
        table.insert(self.AuthorizedPlayers, sid)
        ply:ChatPrint("You are now authorized on this Tool Cupboard.")

        timer.Simple(0.1, function()
            if IsValid(ply) then
                gRust.Building.UpdatePlayer(ply)
            end
        end)
    end
end

function ENT:IsAuthorized(ply)
    if not IsValid(ply) then return false end
    return table.HasValue(self.AuthorizedPlayers, ply:SteamID64())
end

function gRust.Building.UpdateAllPlayers()
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and ply:Alive() then
            gRust.Building.UpdatePlayer(ply)
        end
    end
end

function gRust.Building.UpdatePlayer(ply)
    if not IsValid(ply) then return end

    local status = "none"

    if ply:IsInNoBuildZone() then
        status = "nobuild"
    else
        local radius = 450
        local hasPrivilege = false
        local hasBlocking = false

        for _, tc in ipairs(ents.FindByClass("rust_toolcupboard")) do
            if IsValid(tc) then
                local dist = ply:GetPos():Distance(tc:GetPos())
                if dist <= radius then
                    if tc:IsAuthorized(ply) then
                        hasPrivilege = true
                        break
                    else
                        hasBlocking = true
                    end
                end
            end
        end

        if hasPrivilege then
            status = "privilege"
        elseif hasBlocking then
            status = "blocked"
        end
    end

    local oldStatus = gRust.Building.PlayerCache[ply]
    if oldStatus ~= status then
        gRust.Building.PlayerCache[ply] = status
        net.Start("gRust.BuildingStatus")
        net.WriteString(status)
        net.Send(ply)
    end
end

function ENT:OnRemove()
    timer.Simple(0.1, function()
        gRust.Building.UpdateAllPlayers()
    end)

    if timer.Exists("DecayTimer_" .. self:EntIndex()) then
        timer.Remove("DecayTimer_" .. self:EntIndex())
    end
end

net.Receive("gRust.Authorize", function(len, ply)
    local ent = ply:GetEyeTrace().Entity
    if IsValid(ent) and ent:GetClass() == "rust_toolcupboard" then
        ent:Authorize(ply)
        ent:SetBodygroup(2, 1)
    end
end)

net.Receive("gRust.ClearAuthlist", function(len, ply)
    local ent = ply:GetEyeTraceNoCursor().Entity
    if IsValid(ent) and ent:GetClass() == "rust_toolcupboard" then
        if ent:IsAuthorized(ply) then
            ent.AuthorizedPlayers = {}
            ply:ChatPrint("Authorized list cleared.")
            timer.Simple(0.1, function()
                gRust.Building.UpdateAllPlayers()
            end)
        end
    end
end)

net.Receive("gRust.Deauthorize", function(len, ply)
    local ent = ply:GetEyeTraceNoCursor().Entity
    if IsValid(ent) and ent:GetClass() == "rust_toolcupboard" then
        local sid = ply:SteamID64()
        for i, v in ipairs(ent.AuthorizedPlayers) do
            if v == sid then
                table.remove(ent.AuthorizedPlayers, i)
                ply:ChatPrint("You have been deauthorized from this Tool Cupboard.")
                timer.Simple(0.1, function()
                    if IsValid(ply) then
                        gRust.Building.UpdatePlayer(ply)
                    end
                end)
                break
            end
        end
    end
end)

function ENT:Think()
    if not self.UpkeepInterval then
        self.UpkeepInterval = 60
    end

    if not self.NextUpkeepCheck or self.NextUpkeepCheck < CurTime() then
        self.NextUpkeepCheck = CurTime() + self.UpkeepInterval
        self:ProcessUpkeep()
    end

    self:UpdateProtectionTime()
    self:NextThink(CurTime() + 1)
    return true
end

function ENT:ProcessUpkeep()
    if not self.ProtectedUntil then
        self.ProtectedUntil = CurTime()
    end

    if self.ProtectedUntil <= CurTime() then
        self:SetNW2Bool("IsProtected", false)
        self:StartDecay()
        return
    end

    local requiredResources = {
        ["wood"] = self:GetNW2Int("WoodUpkeep"),
        ["stone"] = self:GetNW2Int("StoneUpkeep"),
        ["metal.fragments"] = self:GetNW2Int("MetalUpkeep"),
        ["metal.refined"] = self:GetNW2Int("HQUpkeep")
    }

    local canSustain = true

    if not self.Inventory then
        canSustain = false
    else
        for resource, amount in pairs(requiredResources) do
            if amount > 0 then
                local available = self:ItemCount(resource)
                if available < amount then
                    canSustain = false
                    break
                end
            end
        end
    end

    if canSustain then
        for resource, amount in pairs(requiredResources) do
            if amount > 0 then
                self:TakeItems(resource, amount)
            end
        end

        self.ProtectedUntil = self.ProtectedUntil + (24 * 60 * 60)
        self:SetNW2Bool("IsProtected", true)
    else
        local timeLeft = self.ProtectedUntil - CurTime()
        if timeLeft <= 0 then
            self:SetNW2Bool("IsProtected", false)
            self:StartDecay()
        end
    end
end

function ENT:TakeItems(itemClass, amount)
    if not self.Inventory or not itemClass or amount <= 0 then return false end

    local remaining = amount

    for slot = 1, self.InventorySlots do
        if remaining <= 0 then break end

        local item = self.Inventory[slot]
        if item and item:GetItem() == itemClass then
            local currentQty = item:GetQuantity()
            local takeAmount = math.min(remaining, currentQty)

            item:RemoveQuantity(takeAmount)
            remaining = remaining - takeAmount

            if item:GetQuantity() <= 0 then
                self:RemoveSlot(slot)
            else
                self:SyncSlot(slot)
            end
        end
    end

    return remaining == 0
end

function ENT:SyncSlot(slot)
    if not self.Inventory or not slot then return end

    local recipients = {}
    for _, pl in pairs(player.GetAll()) do
        if IsValid(pl) and pl:GetPos():Distance(self:GetPos()) <= 200 then
            table.insert(recipients, pl)
        end
    end

    if #recipients > 0 then
        local item = self.Inventory[slot]
        if item then
            net.Start("gRust.Inventory.SyncSlot")
            net.WriteEntity(self)
            net.WriteUInt(slot, 6)
            net.WriteItem(item)
            net.Send(recipients)
        else
            net.Start("gRust.Inventory.Remove")
            net.WriteEntity(self)
            net.WriteUInt(slot, 6)
            net.Send(recipients)
        end
    end
end

function ENT:RemoveSlot(slot)
    if not self.Inventory or not slot then return end

    self.Inventory[slot] = nil
    self:SyncSlot(slot)
end

function ENT:StartDecay()
    if not self.DecayStarted then
        self.DecayStarted = true

        local radius = 450
        local buildings = {}

        for _, ent in ipairs(ents.FindInSphere(self:GetPos(), radius)) do
            if IsValid(ent) and ent.IsBuilding and ent:IsBuilding() then
                table.insert(buildings, ent)
            end
        end

        timer.Create("DecayTimer_" .. self:EntIndex(), 30, 0, function()
            if not IsValid(self) then return end

            for _, building in ipairs(buildings) do
                if IsValid(building) and building.TakeDamage then
                    building:TakeDamage(building:Health() * 0.1)

                    if building:Health() <= 0 then
                        building:Remove()
                    end
                end
            end
        end)
    end
end

function ENT:UpdateProtectionTime()
    if not self.ProtectedUntil then return end

    local timeLeft = self.ProtectedUntil - CurTime()

    if timeLeft <= 0 then
        self:SetNW2String("ProtectedFor", "UNPROTECTED")
        self:SetNW2Bool("IsProtected", false)
    else
        local hours = math.floor(timeLeft / 3600)
        local minutes = math.floor((timeLeft % 3600) / 60)

        if hours > 0 then
            self:SetNW2String("ProtectedFor", string.format("%dh %dm", hours, minutes))
        else
            self:SetNW2String("ProtectedFor", string.format("%dm", minutes))
        end

        self:SetNW2Bool("IsProtected", true)
    end
end

function ENT:CalculateUpkeep()
    local radius = 450
    local buildingCount = 0

    for _, ent in ipairs(ents.FindInSphere(self:GetPos(), radius)) do
        if IsValid(ent) and ent.IsBuilding and ent:IsBuilding() then
            buildingCount = buildingCount + 1
        end
    end

    local multiplier = math.max(1, math.floor(buildingCount / 10))

    self:SetNW2Int("WoodUpkeep", 100 * multiplier)
    self:SetNW2Int("StoneUpkeep", 50 * multiplier)
    self:SetNW2Int("MetalUpkeep", 25 * multiplier)
    self:SetNW2Int("HQUpkeep", 5 * multiplier)
end

function ENT:OnTakeDamage(dmg)
    if self:GetNW2Bool("IsProtected") then
        return 0
    end

    BaseClass.OnTakeDamage(self, dmg)
end
