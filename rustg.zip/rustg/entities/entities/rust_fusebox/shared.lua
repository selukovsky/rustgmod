ENT.Base = "rust_storage"

ENT.InventorySlots = 1
ENT.InventoryName   = "FUSE BOX"
ENT.DisplayIcon = gRust.GetIcon("open")