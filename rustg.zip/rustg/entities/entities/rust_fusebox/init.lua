AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

DEFINE_BASECLASS("rust_storage")

function ENT:Initialize()
    if CLIENT then return end

    self:SetModel("models/darky_m/rust/puzzle/fusebox.mdl")
    self:SetSolid(SOLID_VPHYSICS)
    self:PhysicsInit(SOLID_VPHYSICS)
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:EnableMotion(false)
        phys:Sleep()
    end

    self:CreateInventory(1)
    self:SetInteractable(true)
    self:SetDamageable(false)

    self.HasPower = false
    self.WearRate = 4.0

    timer.Create("FuseWear_" .. self:EntIndex(), 1, 0, function()
        if not IsValid(self) then
            timer.Remove("FuseWear_" .. self:EntIndex())
            return
        end
        self:UpdateFuseWear()
    end)

    self:NextThink(CurTime())
    self:SetDisplayName("OPEN")
    self:SetSkin(0)
end

function ENT:Use(activator, caller)
    BaseClass.Use(self, activator, caller)
end

function ENT:Think()
    if self:HasFuse() then
        self.HasPower = true
        self:SetSkin(1)
    else
        self.HasPower = false
        self:SetSkin(0)
    end

    self:NextThink(CurTime() + 0.5)
    return true
end

function ENT:UpdateFuseWear()
    local fuse = self.Inventory[1]
    if fuse and fuse:GetItem() == "fuse" then
        local currentWear = fuse:GetWear()
        local newWear = currentWear - self.WearRate
        fuse:SetWear(newWear)

        if newWear <= 0 then
            self:RemoveFuse()
        else
            self:SyncSlot(1)
        end
    else
        self.HasPower = false
    end
end

function ENT:RemoveFuse()
    self.Inventory[1] = nil
    self.HasPower = false
    self:SyncSlot(1)
end

function ENT:HasFuse()
    local fuse = self.Inventory[1]
    return fuse and fuse:GetItem() == "fuse" and fuse:GetWear() > 0
end