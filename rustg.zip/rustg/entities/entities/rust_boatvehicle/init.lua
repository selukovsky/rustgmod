AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/zohart/vehicles/boat_medium.mdl")

    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(800)  -- Увеличена масса чтобы игрок не мог толкать
        phys:SetDragCoefficient(-0.05)  -- Отрицательное сопротивление для скорости
        phys:SetAngleDragCoefficient(0.8)
        phys:EnableMotion(true)
        phys:EnableDrag(true)
        phys:EnableGravity(true)
    end

    self:SetHealth(self.MaxHealth)
    self:SetMaxHealth(self.MaxHealth)

    self:SetNWBool("BoatActive", false)
    self:SetNWInt("BoatHealth", self.MaxHealth)
    self:SetNWEntity("BoatDriver", NULL)

    self.NextWaterCheck = 0
    self.IsInWater = false
    self.WaterSurfaceZ = 0

    -- Звуковые параметры
    self.EngineSound = "zohart/vehicles/boats/medium/loop.wav"
    self.EngineIdleSound = "zohart/vehicles/boats/medium/loop.wav" -- Звук холостого хода
    self.IsEngineRunning = false
    self.IsMoving = false
    self.CurrentSound = nil

    self.DriverSeats = {}

    self:CreateDriverSeats()
end

function ENT:CreateDriverSeats()
    local seatPositions = {
        {pos = Vector(-75, 0, 20), ang = Angle(0, -90, 0), isDriver = true},  -- Водитель
        {pos = Vector(-20, 0, 10), ang = Angle(0, -90, 0), isDriver = false}, -- Пассажир
    }

    for i, seatData in ipairs(seatPositions) do
        local seat = ents.Create("prop_vehicle_prisoner_pod")
        if IsValid(seat) then
            seat:SetModel("models/nova/airboat_seat.mdl")
            seat:SetKeyValue("vehiclescript", "scripts/vehicles/prisoner_pod.txt")

            local pos = self:LocalToWorld(seatData.pos)
            local ang = self:GetAngles() + seatData.ang

            seat:SetPos(pos)
            seat:SetAngles(ang)
            seat:Spawn()
            seat:Activate()

            seat:SetNoDraw(true)
            seat:SetNotSolid(true)

            seat:SetParent(self)

            seat:Fire("Unlock", "", 0)

            seat.BoatEntity = self
            seat.SeatIndex = i
            seat.IsDriverSeat = seatData.isDriver

            table.insert(self.DriverSeats, seat)
        end
    end
end

function ENT:Think()
    if not self.DriverSeats then
        self.DriverSeats = {}
        return
    end

    for _, seat in pairs(self.DriverSeats) do
        if IsValid(seat) then
            local driver = seat:GetDriver()

            if IsValid(driver) then
                if seat.IsDriverSeat then
                    if self:GetNWEntity("BoatDriver") != driver then
                        self:PlayerEnterBoat(driver)
                    end
                    self:HandleBoatMovement(driver)
                    self:UpdateEngineSound(driver)
                end
            else
                if seat.IsDriverSeat and IsValid(self:GetNWEntity("BoatDriver")) then
                    self:PlayerExitBoat(self:GetNWEntity("BoatDriver"))
                end
            end

            if CurTime() % 1 < 0.1 then
                seat:Fire("Unlock", "", 0)
            end
        end
    end

    if CurTime() > self.NextWaterCheck then
        self:CheckWater()
        self.NextWaterCheck = CurTime() + 0.1
    end

    self:ApplyWaterPhysics()

    self:NextThink(CurTime())
    return true
end

function ENT:CheckWater()
    local pos = self:GetPos()
    if not pos then return end

    local waterLevel = self:WaterLevel()

    if waterLevel > 0 then
        local tr = util.TraceLine({
            start = pos + Vector(0, 0, 200),
            endpos = pos + Vector(0, 0, -200),
            mask = MASK_WATER,
            filter = self
        })

        if tr and tr.Hit and tr.HitPos then
            self.WaterSurfaceZ = tr.HitPos.z
        else
            self.WaterSurfaceZ = pos.z
        end
        self.IsInWater = true
    else
        self.IsInWater = false
        self.WaterSurfaceZ = 0
    end
end

function ENT:ApplyWaterPhysics()
    local phys = self:GetPhysicsObject()
    if not IsValid(phys) then return end

    if self.IsInWater and self.WaterSurfaceZ > 0 then
        local pos = self:GetPos()
        local waterDepth = self.WaterSurfaceZ - (pos.z - 20)

        if waterDepth > 0 then
            local buoyancyForce = math.min(waterDepth * 25, 400)
            phys:ApplyForceCenter(Vector(0, 0, buoyancyForce))
        end

        local vel = phys:GetVelocity()
        local waterDrag = Vector(vel.x * -0.08, vel.y * -0.08, vel.z * -0.04)  -- Уменьшено водное сопротивление
        phys:ApplyForceCenter(waterDrag)

        local angles = self:GetAngles()
        local angVel = phys:GetAngleVelocity()

        local pitchDeadzone = 10.0
        local rollDeadzone = 10.0

        local stabilizationForce = 200
        local dampingForce = 15

        local pitchStabilize = 0
        local rollStabilize = 0

        if math.abs(angles.p) > pitchDeadzone then
            local pitchDifference = math.abs(angles.p) - pitchDeadzone
            pitchStabilize = -math.Sign(angles.p) * pitchDifference * stabilizationForce - angVel.y * dampingForce
        end

        if math.abs(angles.r) > rollDeadzone then
            local rollDifference = math.abs(angles.r) - rollDeadzone
            rollStabilize = -math.Sign(angles.r) * rollDifference * stabilizationForce - angVel.x * dampingForce
        end

        if pitchStabilize != 0 or rollStabilize != 0 then
            phys:ApplyTorqueCenter(Vector(rollStabilize, pitchStabilize, 0))
        end

        if angVel:Length() > 20 then
            local microDamping = Vector(angVel.x * -3, angVel.y * -3, 0)
            phys:ApplyTorqueCenter(microDamping)
        end
    end
end

function ENT:UpdateEngineSound(ply)
    if not IsValid(ply) then
        self:StopAllSounds()
        return
    end

    local keys = {
        forward = ply:KeyDown(IN_FORWARD),
        back = ply:KeyDown(IN_BACK),
        left = ply:KeyDown(IN_MOVELEFT),
        right = ply:KeyDown(IN_MOVERIGHT)
    }

    local isMoving = keys.forward or keys.back or keys.left or keys.right

    if isMoving and not self.IsMoving then
        -- Начинаем движение - переключаем на звук с оборотами
        self:StopAllSounds()
        self:EmitSound(self.EngineSound, 90, 120, 1.0, CHAN_AUTO)
        self.IsMoving = true
        self.CurrentSound = self.EngineSound
    elseif not isMoving and self.IsMoving then
        -- Останавливаемся - переключаем на звук холостого хода
        self:StopAllSounds()
        self:EmitSound(self.EngineIdleSound, 85, 80, 0.8, CHAN_AUTO)
        self.IsMoving = false
        self.CurrentSound = self.EngineIdleSound
    end
end

function ENT:StopAllSounds()
    if self.IsEngineRunning then
        self:StopSound(self.EngineSound)
        self:StopSound(self.EngineIdleSound)
        self.IsMoving = false
        self.CurrentSound = nil
    end
end

function ENT:PlayerEnterBoat(ply)
    if not IsValid(ply) then return end

    self:SetNWEntity("BoatDriver", ply)
    self:SetNWBool("BoatActive", true)

    ply:SetNWEntity("CurrentBoat", self)

    ply:PrintMessage(HUD_PRINTCENTER, "Используйте WASD для управления лодкой | E для выхода")

    -- При входе в лодку включаем звук холостого хода
    self:StopAllSounds()
    self:EmitSound(self.EngineIdleSound, 85, 80, 0.8, CHAN_AUTO)
    self.IsEngineRunning = true
    self.IsMoving = false
    self.CurrentSound = self.EngineIdleSound
end

function ENT:PlayerExitBoat(ply)
    if not IsValid(ply) then return end

    self:SetNWEntity("BoatDriver", NULL)
    self:SetNWBool("BoatActive", false)

    ply:SetNWEntity("CurrentBoat", NULL)

    -- При выходе из лодки останавливаем все звуки
    self:StopAllSounds()

    timer.Simple(0.1, function()
        if IsValid(ply) and IsValid(self) then
            local exitPos = self:GetPos() + self:GetRight() * 80
            exitPos = util.TraceHull({
                start = exitPos + Vector(0, 0, 50),
                endpos = exitPos - Vector(0, 0, 100),
                mins = ply:OBBMins(),
                maxs = ply:OBBMaxs(),
                filter = {self, ply}
            }).HitPos

            ply:SetPos(exitPos + Vector(0, 0, 10))
        end
    end)
end

function ENT:HandleBoatMovement(ply)
    if not IsValid(ply) then return end

    local phys = self:GetPhysicsObject()
    if not IsValid(phys) then return end

    local keys = {
        forward = ply:KeyDown(IN_FORWARD),
        back = ply:KeyDown(IN_BACK),
        left = ply:KeyDown(IN_MOVELEFT),
        right = ply:KeyDown(IN_MOVERIGHT)
    }

    local forward = self:GetForward()
    local right = self:GetRight()

    local forwardForce = 5000  -- Увеличена сила для компенсации большой массы
    local backwardForce = 1200
    local turnForce = 1200

    if keys.forward then
        phys:ApplyForceCenter(forward * forwardForce)
    elseif keys.back then
        phys:ApplyForceCenter(-forward * backwardForce)
    end

    if keys.left then
        phys:ApplyTorqueCenter(Vector(0, 0, -turnForce))
    elseif keys.right then
        phys:ApplyTorqueCenter(Vector(0, 0, turnForce))
    end

    local vel = phys:GetVelocity()
    if vel:Length() > 1200 then
        phys:SetVelocity(vel:GetNormalized() * 1200)
    end
end

function ENT:Use(activator, caller)
    if not IsValid(activator) or not activator:IsPlayer() then return end

    if not self.DriverSeats or #self.DriverSeats == 0 then
        return
    end

    local closestSeat = nil
    local closestDistance = math.huge

    for _, seat in pairs(self.DriverSeats) do
        if IsValid(seat) then
            local distance = activator:GetPos():Distance(seat:GetPos())
            if distance < closestDistance then
                closestDistance = distance
                closestSeat = seat
            end
        end
    end

    if IsValid(closestSeat) then
        local currentDriver = closestSeat:GetDriver()

        if IsValid(currentDriver) and currentDriver == activator then
            closestSeat:Fire("Unlock", "", 0)
            activator:ExitVehicle()
        elseif not IsValid(currentDriver) then
            closestSeat:Fire("Unlock", "", 0)
            activator:EnterVehicle(closestSeat)
        end
    end
end

function ENT:OnTakeDamage(dmg)
    local health = self:Health() - dmg:GetDamage()
    self:SetHealth(math.max(0, health))
    self:SetNWInt("BoatHealth", self:Health())

    if self:Health() <= 0 then
        self:Explode()
    end
end

function ENT:Explode()
    self:StopAllSounds()

    local effectdata = EffectData()
    effectdata:SetOrigin(self:GetPos())
    effectdata:SetMagnitude(1)
    effectdata:SetScale(2)
    util.Effect("Explosion", effectdata)

    for _, seat in pairs(self.DriverSeats) do
        if IsValid(seat) then
            local driver = seat:GetDriver()
            if IsValid(driver) then
                driver:ExitVehicle()
            end
            seat:Remove()
        end
    end

    self:Remove()
end

function ENT:OnRemove()
    self:StopAllSounds()

    for _, seat in pairs(self.DriverSeats) do
        if IsValid(seat) then
            seat:Remove()
        end
    end
end
