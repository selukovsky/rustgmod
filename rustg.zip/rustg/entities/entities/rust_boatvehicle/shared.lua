ENT.Type = "anim"
ENT.Base = "base_anim"

ENT.MaxHealth = 500
ENT.MaxSpeed = 1200
ENT.Acceleration = 1500
ENT.TurnSpeed = 3.0
ENT.BuoyancyForce = 2000
ENT.WaterLevel = 0
