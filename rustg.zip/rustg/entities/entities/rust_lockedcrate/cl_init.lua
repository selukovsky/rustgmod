include("shared.lua")

local function formatTime(time)
    if(time < 1)then return "00:00" end

    local minutes = math.floor(time / 60)
    local seconds = math.floor(time - minutes * 60)

    if(minutes < 10)then minutes = "0" .. minutes end
    if(seconds < 10)then seconds = "0" .. seconds end

    return minutes .. ":" .. seconds
end

local color, color_otl, angg = Color(165, 255, 154), Color(48, 136, 40, 20), Angle(0, 77.8, 90)
function ENT:Draw()
    self:DrawModel()

    if(!self:GetNWBool("opening") && !self:GetNWBool("hacked"))then return end

    local ang = self:GetAngles()
    local pos, time = self:GetPos() + ang:Up() * 75.7 + ang:Forward() * -11 + ang:Right() * 0.1, self:GetNWInt("opentime") - CurTime()

    cam.Start3D2D(pos, ang + angg, .1)
        draw.SimpleTextOutlined("c:\\system\\notporn>cd..", "DermaDefaultBold", 0, 0, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 2, color_otl)
        draw.SimpleTextOutlined("c:\\system>cd tools", "DermaDefaultBold", 0, 14, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 2, color_otl)
        draw.SimpleTextOutlined("c:\\system\\tools>hack.exe", "DermaDefaultBold", 0, 28, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 2, color_otl)
        draw.SimpleTextOutlined(">Bruteforce attack initiated...", "DermaDefaultBold", 0, 56, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 2, color_otl)
        draw.SimpleTextOutlined(formatTime(time), "DermaLarge", 0, 68, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 2, color_otl)
    cam.End3D2D()
end

function ENT:Think()
    if self.LastHacked ~= self:GetNWBool("hacked") then
        self.LastHacked = self:GetNWBool("hacked")

        if self.LastHacked then
            self.DisplayIcon = gRust.GetIcon("open")
        else
            self.DisplayIcon = gRust.GetIcon("boosts")
        end
    end
end