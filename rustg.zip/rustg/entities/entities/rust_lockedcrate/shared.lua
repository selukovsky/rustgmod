ENT.Base = "rust_storage"

ENT.InventorySlots = 5
ENT.InventoryName = "Locked Crate"