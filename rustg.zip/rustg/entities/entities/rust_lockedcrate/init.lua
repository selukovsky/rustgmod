AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

DEFINE_BASECLASS("rust_storage")

function ENT:Initialize()
    if CLIENT then return end

    self:SetModel("models/environment/crates/locked_crate.mdl")
    self:SetSolid(SOLID_VPHYSICS)

    if self.Deploy then
        self:PhysicsInitStatic(SOLID_VPHYSICS)
    else
        self:PhysicsInit(SOLID_VPHYSICS)
        local phys = self:GetPhysicsObject()
        if IsValid(phys) then
            phys:EnableMotion(false)
            phys:Sleep()
        end
    end

    self:CreateInventory(26)
    self:SetInteractable(true)
    self:SetDamageable(false)
    self:SetDisplayName("START HACKING")

    self:SetNWBool("hacked", false)
    self:SetNWBool("opening", false)
    self:SetNWInt("opentime", 0)

    self.SpawnPosition = self:GetPos()
    self.SpawnAngles = self:GetAngles()
    self:PopulateWithItems()

    timer.Create("CheckEmpty_" .. self:EntIndex(), 2, 0, function()
        if IsValid(self) then
            self:CheckAndRespawnIfEmpty()
        else
            timer.Remove("CheckEmpty_" .. self:EntIndex())
        end
    end)
end

function ENT:PopulateWithItems()
    local lockedCrateLootItems = {
        {
            itemid = "rifle.ak",
            amount = {1, 2},
            chance = 0.25,
        },
        {
            itemid = "hmlmg",
            amount = {1, 1},
            chance = 0.30,
        },
        {
            itemid = "rifle.bolt",
            amount = {1, 1},
            chance = 0.10,
        },
        {
            itemid = "coal",
            amount = {3, 3},
            chance = 0.12,
        },
        {
            itemid = "rifle.l96",
            amount = {1, 5},
            chance = 0.20,
        },
        {
            itemid = "rifle.lr300",
            amount = {1, 2},
            chance = 0.19,
        },
        {
            itemid = "metalpipe",
            amount = {5, 15},
            chance = 0.75,
        },
        {
            itemid = "roadsigns",
            amount = {5, 15},
            chance = 0.79,
        },
        {
            itemid = "metal.refined",
            amount = {45, 65},
            chance = 0.79,
        },
        {
            itemid = "smg.mp5",
            amount = {1, 2},
            chance = 0.15,
        },
        {
            itemid = "metalspring",
            amount = {1, 3},
            chance = 0.50,
        },
        {
            itemid = "scrap",
            amount = {50, 50},
            chance = 100.0,
        },
        {
            itemid = "pistol.m92",
            amount = {1, 1},
            chance = 0.40,
        },
        {
            itemid = "rifle.sks",
            amount = {1, 1},
            chance = 0.30,
        },
        {
            itemid = "revolver.hc",
            amount = {1, 1},
            chance = 0.45,
        },
        {
            itemid = "shotgun.m4",
            amount = {1, 1},
            chance = 0.25,
        },
        {
            itemid = "ammo.rocket.basic",
            amount = {1, 2},
            chance = 0.10,
        },
        {
            itemid = "ammo.mgl.basic",
            amount = {4, 6},
            chance = 0.10,
        },
        {
            itemid = "rocket.launcher",
            amount = {1, 1},
            chance = 0.10,
        },
        {
            itemid = "lmg.m249",
            amount = {1, 1},
            chance = 0.09,
        },
        {
            itemid = "smg.2",
            amount = {1, 1},
            chance = 0.21,
        },
        {
            itemid = "riflebody",
            amount = {1, 2},
            chance = 0.10,
        },
        {
            itemid = "ammo.rifle",
            amount = {20, 30},
            chance = 0.15,
        },
        {
            itemid = "ammo.pistol",
            amount = {20, 30},
            chance = 0.18,
        },
        {
            itemid = "computer",
            amount = {1, 1},
            chance = 0.10,
        },
        {
            itemid = "door.hinged.toptier",
            amount = {1, 1},
            chance = 0.21,
        },
        {
            itemid = "wall.window.glass.reinforced",
            amount = {1, 1},
            chance = 0.14,
        },
        {
            itemid = "smgbody",
            amount = {1, 2},
            chance = 0.10,
        },
        {
            itemid = "techparts",
            amount = {2, 10},
            chance = 0.60,
        },
        {
            itemid = "explosives",
            amount = {5, 10},
            chance = 0.03,
        },
        {
            itemid = "explosive.timed",
            amount = {1, 1},
            chance = 0.03,
        },
        {
            itemid = "gears",
            amount = {2, 10},
            chance = 0.70,
        }
    }

    local availableItems = {}
    for _, itemData in ipairs(lockedCrateLootItems) do
        local itemDef = gRust.Items[itemData.itemid]
        if itemDef then
            table.insert(availableItems, itemData)
        end
    end

    if #availableItems == 0 then return end

    if self.Inventory then
        for i = 1, self.InventorySlots do
            if self.Inventory[i] then
                self:RemoveSlot(i)
            end
        end
    end

    local itemCount = math.random(5, 6)
    local shuffledItems = {}
    
    for i = 1, #availableItems do
        table.insert(shuffledItems, availableItems[i])
    end
    for i = #shuffledItems, 2, -1 do
        local j = math.random(i)
        shuffledItems[i], shuffledItems[j] = shuffledItems[j], shuffledItems[i]
    end

    local currentSlot = 1
    local addedItems = 0

    for _, itemData in ipairs(shuffledItems) do
        if addedItems >= itemCount or currentSlot > self.InventorySlots then
            break
        end

        local randomChance = math.random()
        if randomChance <= itemData.chance then
            local amount = 1
            if type(itemData.amount) == "table" then
                amount = math.random(itemData.amount[1], itemData.amount[2])
            else
                amount = itemData.amount
            end

            local item = gRust.CreateItem(itemData.itemid, amount)
            if item then
                self:SetSlot(item, currentSlot)
                currentSlot = currentSlot + 1
                addedItems = addedItems + 1
            end
        end
    end
end

function ENT:RemoveSlot(slot)
    BaseClass.RemoveSlot(self, slot)
    
    self:CheckAndRespawnIfEmpty()
end

function ENT:CheckAndRespawnIfEmpty()
    if not self.Inventory then
        self:ScheduleRespawn()
        return
    end

    local hasItems = false
    for i = 1, self.InventorySlots do
        if self.Inventory[i] then
            hasItems = true
            break
        end
    end

    if not hasItems then
        self:ScheduleRespawn()
    end
end

function ENT:ScheduleRespawn()
    local pos = self.SpawnPosition or self:GetPos()
    local ang = self.SpawnAngles or self:GetAngles()
    
    timer.Remove("CheckEmpty_" .. self:EntIndex())
    
    self:Remove()
    
    timer.Create("LockedCrateRespawn_" .. tostring(pos), 900, 1, function()
        local newCrate = ents.Create("rust_lockedcrate")
        if IsValid(newCrate) then
            newCrate:SetPos(pos)
            newCrate:SetAngles(ang)
            newCrate:Spawn()
            newCrate:Activate()
        end
    end)
end

function ENT:OnRemove()
    timer.Remove("CheckEmpty_" .. self:EntIndex())
end

function ENT:Use(activator, caller)
    if self:GetNWBool("opening") then return end
    
    if self:GetNWBool("hacked") then
        BaseClass.Use(self, activator, caller)
    elseif not self:GetNWBool("opening") then
        self:StartHacking(caller)
    end
end

function ENT:StartHacking(player)
    if self:GetNWBool("hacked") or self:GetNWBool("opening") then return end
    
    self:SetNWBool("opening", true)
    self:SetNWInt("opentime", CurTime() + 300)
    self:SetInteractable(false)
    self:SetDisplayName("")

    self:EmitSound("entity/locked_crate/beep.wav")
    
    timer.Create("HackingTimer_" .. self:EntIndex(), 1, 300, function()
        if IsValid(self) then
            if CurTime() >= self:GetNWInt("opentime") then
                self:CompleteHacking()
            end
        else
            timer.Remove("HackingTimer_" .. self:EntIndex())
        end
    end)
end

function ENT:CompleteHacking()
    if IsValid(self) then
        self:SetNWBool("opening", false)
        self:SetNWBool("hacked", true)
        self:SetNWInt("opentime", 0)
        
        timer.Simple(0.1, function()
            if IsValid(self) then
                self:SetInteractable(true)
                self:SetDisplayName("OPEN")
            end
        end)
        
        timer.Remove("HackingTimer_" .. self:EntIndex())
    end
end

function ENT:Think()
    if self:GetNWBool("opening") then
        self:SetInteractable(false)
    elseif self:GetNWBool("hacked") then
        self:SetInteractable(true)
    end
    
    self:NextThink(CurTime() + 0.1)
    return true
end


RUST_LOCKEDCRATE_SPAWNS = {
    {
        pos = Vector(14116.809570, 13413.786133, -5004.968750),   -- Позиция X, Y, Z
        ang = Angle(0.000, 129.011, 0.000)           -- Угол Pitch, Yaw, Roll
    }
    -- Добавьте больше спавнпоинтов по необходимости
}

hook.Add("InitPostEntity", "SpawnRustLockedCrates", function()
    timer.Simple(5, function()
        if not SERVER then return end
        
        for _, spawnData in ipairs(RUST_LOCKEDCRATE_SPAWNS) do
            -- Проверяем, нет ли ентити в этой позиции
            local nearbyEnts = ents.FindInSphere(spawnData.pos, 50)
            local crateExists = false
            
            for _, ent in ipairs(nearbyEnts) do
                if ent:GetClass() == "rust_lockedcrate" then
                    crateExists = true
                    break
                end
            end
            
            if not crateExists then
                local crate = ents.Create("rust_lockedcrate")
                if IsValid(crate) then
                    crate:SetPos(spawnData.pos)
                    crate:SetAngles(spawnData.ang)
                    crate:Spawn()
                    crate:Activate()
                    
                    print("Spawned rust_lockedcrate at: " .. tostring(spawnData.pos))
                end
            end
        end
    end)
end)