AddCSLuaFile()

ENT.Base = "rust_storage"

ENT.InventorySlots  = 2
ENT.InventoryName   = "Компостер"

ENT.Deploy = {}
ENT.Deploy.Model = "models/deployable/wooden_box.mdl"
ENT.Deploy.Sound	= "deploy/small_wooden_box_deploy.wav"

ENT.Pickup			= "wood_box"
ENT.DisplayIcon 	= gRust.GetIcon("open")
ENT.ShowHealth	= true

function ENT:Initialize()
    if (CLIENT) then return end

    self:SetModel("models/deployable/wooden_box.mdl")
    self:PhysicsInitStatic(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)
    self:CreateInventory(18)
    
    self:SetInteractable(true)
    
    self:SetDamageable(true)
    self:SetHealth(150)
    self:SetMaxHealth(150)

    self:SetMeleeDamage(0.2)
    self:SetBulletDamage(0.2)
    self:SetExplosiveDamage(0.4)

    -- Таймер для компостирования
    self.m_tNextCompostCheck = CurTime() + 1
end

-- Функция для поиска навоза в инвентаре
function ENT:FindNavozSlot()
    for i = 1, self.InventorySlots do
        local item = self.Inventory[i]
        if item and item:GetItem() == "navoz" then
            return i
        end
    end
    return nil
end

-- Функция для добавления удобрения
function ENT:AddFertilizer()
    local fertilizerItem = gRust.CreateItem("fertilizer", 30)
    
    -- Пытаемся найти существующий стак удобрения
    for i = 1, self.InventorySlots do
        local item = self.Inventory[i]
        if item and item:GetItem() == "fertilizer" then
            local maxStack = gRust.Items["fertilizer"]:GetStack()
            if item:GetQuantity() < maxStack then
                local availableSpace = maxStack - item:GetQuantity()
                local toAdd = math.min(30, availableSpace)
                item:AddQuantity(toAdd)
                self:SyncSlot(i)
                return toAdd
            end
        end
    end
    
    -- Ищем пустой слот для нового удобрения
    for i = 1, self.InventorySlots do
        if not self.Inventory[i] then
            self.Inventory[i] = fertilizerItem
            self:SyncSlot(i)
            return 30
        end
    end
    
    return 0
end

-- Основная функция компостирования
function ENT:CompostThink()
    if CurTime() < self.m_tNextCompostCheck then return end
    self.m_tNextCompostCheck = CurTime() + 1 -- Проверяем каждую секунду
    
    -- Ищем навоз в инвентаре
    local navozSlot = self:FindNavozSlot()
    if not navozSlot then return end
    
    local navozItem = self.Inventory[navozSlot]
    if not navozItem or navozItem:GetItem() ~= "navoz" then return end
    
    -- Уменьшаем количество навоза на 1
    navozItem:RemoveQuantity(1)
    
    if navozItem:GetQuantity() <= 0 then
        self:RemoveSlot(navozSlot)
    else
        self:SyncSlot(navozSlot)
    end
    
    -- Добавляем 30 удобрения
    local added = self:AddFertilizer()
    if added > 0 then
        print(string.format("[Компостер] Преобразовано 1 навоз в %d удобрения", added))
    else
        print("[Компостер] Не удалось добавить удобрение - нет места в инвентаре")
    end
    
    -- Устанавливаем следующий цикл через 3 минуты
    self.m_tNextCompostCheck = CurTime() + 60
end

function ENT:Think()
    if SERVER then
        self:CompostThink()
    end
    self:NextThink(CurTime() + 1)
    return true
end