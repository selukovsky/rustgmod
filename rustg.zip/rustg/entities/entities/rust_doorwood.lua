AddCSLuaFile()
ENT.Base = "rust_door"
ENT.Model = "models/deployable/wooden_door.mdl"
ENT.MaxHealth = 200
ENT.DoorSound = "wood"
ENT.Deploy = {}
ENT.Deploy.Rotation = -10
ENT.Deploy.Model = "models/deployable/wooden_door.mdl"
ENT.Deploy.Sound = "deploy/wood_door_deploy.wav"
ENT.Deploy.Socket = "door"
ENT.woodupkeep = 100
ENT.Pickup = "door.hinged.wood"