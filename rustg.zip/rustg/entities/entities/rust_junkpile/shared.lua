ENT.Base = "base_anim"
ENT.Type = "anim"