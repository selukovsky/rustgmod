ENT.Base = "rust_storage"



ENT.InventoryName   = "Shotgun Trap"



ENT.Deploy          = {}

ENT.Deploy.Model    = "models/traps/shotgun_trap.mdl"

ENT.Deploy.Sound    = "deploy/shop_front_deploy.wav"



ENT.Pickup = "shotgun_trap"