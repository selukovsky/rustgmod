ENT.Base = "rust_base"

ENT.DisplayIcon = gRust.GetIcon("open")

ENT.InventorySlots = 12
