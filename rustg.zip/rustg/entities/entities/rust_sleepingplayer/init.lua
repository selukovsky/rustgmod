AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

DEFINE_BASECLASS("rust_storage")

function ENT:Initialize()
    self.InventoryName = "SLEEPING PLAYER"
    self:SetModel("models/zohart/loot/backpack.mdl")
    
    -- Делаем ентити физичным
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetCollisionGroup(COLLISION_GROUP_WEAPON)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:EnableMotion(true)
        phys:SetMass(50) -- Устанавливаем разумную массу
    end

    self:CreateInventory(36)
    self:SetInteractable(true)
    self:SetOpenSoundType("stash")
    self:SetDamageable(false)
    
    self.OwnerSteamID = nil
    self.OwnerName = nil
    self.OwnerLastPos = nil
    
    -- Таймер для проверки пустоты инвентаря
    self:StartEmptyCheckTimer()
end

function ENT:StartEmptyCheckTimer()
    timer.Create("EmptyCheck_" .. self:EntIndex(), 5, 0, function()
        if not IsValid(self) then return end
        self:CheckAndRemoveIfEmpty()
    end)
end

function ENT:OnRemove()
    timer.Remove("EmptyCheck_" .. self:EntIndex())
end

function ENT:SetOwner(player)
    if not IsValid(player) then return end
    
    self.OwnerSteamID = player:SteamID()
    self.OwnerName = player:Nick()
    self.InventoryName = string.upper(player:Nick() .. "'S LOOT")
    self.OwnerLastPos = player:GetPos()

    self:SetNWString("OwnerSteamID", self.OwnerSteamID)
    self:SetNWString("OwnerName", self.OwnerName)
    self:SetNWString("InventoryName", self.InventoryName)
end

function ENT:IsOwner(player)
    if not IsValid(player) then return false end
    return player:SteamID() == self.OwnerSteamID
end

function ENT:IsInventoryEmpty()
    if not self.Inventory then return true end

    for i = 1, self.InventorySlots do
        if self.Inventory[i] then
            return false
        end
    end
    return true
end

function ENT:CheckAndRemoveIfEmpty()
    if self:IsInventoryEmpty() then
        self:Remove()
    end
end

function ENT:RemoveSlot(slot)
    self.BaseClass.RemoveSlot(self, slot)
    
    -- Проверяем пустоту после удаления предмета
    timer.Simple(0.1, function()
        if IsValid(self) then
            self:CheckAndRemoveIfEmpty()
        end
    end)
end

function ENT:GetOwnerName()
    return self.OwnerName or "Unknown"
end

function ENT:GetOwnerSteamID()
    return self.OwnerSteamID
end

function ENT:GetOwnerLastPos()
    return self.OwnerLastPos
end

function ENT:TransferInventoryToPlayer(player)
    if not IsValid(player) or not self.Inventory then return end
    
    for i = 1, self.InventorySlots do
        local item = self.Inventory[i]
        if item then
            if player.GiveItem then
                player:GiveItem(item)
            end
        end
    end
    
    self.Inventory = {}
    self:Remove()
end

function ENT:CreateStashOnDestroy()
    return
end

function ENT:Use(activator, caller)
    if not self.Interactable then return end 
    if not IsValid(activator) or not activator:IsPlayer() then return end
    if IsValid(gRust.Inventory) then return end
    
    local distance = self:GetPos():Distance(activator:GetPos())
    if distance > 200 then 
        gRust.CloseInventory()
        return 
    end

    activator:RequestInventory(self)
end

-- Добавляем физическое взаимодействие
function ENT:PhysicsCollide(data, phys)
    -- Небольшое гашение энергии при столкновении
    phys:SetVelocity(phys:GetVelocity() * 0.8)
end

  local i = 1
    local function CreateRow(name)
        local Grid = Container:Add("gRust.Inventory.SlotGrid")
        Grid:Dock(BOTTOM)
        Grid:SetCols(6)
        Grid:SetRows(1)
        Grid:SetInventoryOffset((i - 1) * 6)
        Grid:SetEntity(self)
        Grid:SetMargin(data.margin)
        Grid:DockMargin(LeftMargin, 0, RightMargin, ScrH() * 0.01)
        Grid:SetTall((data.wide / 8) + data.margin)
        local Name = Container:Add("Panel")
        Name:Dock(BOTTOM)
        Name:SetTall(ScrH() * 0.03)
        Name:DockMargin(LeftMargin - ScrW() * 0.005, 0, RightMargin, ScrH() * 0.008)
        Name.Paint = function(me, w, h)
            surface.SetDrawColor(80, 76, 70, 100)
            surface.DrawRect(0, 0, w, h)
            draw.SimpleText(name, "gRust.38px", w * 0.01, h * 0.5, Color(255, 255, 255, 200), 0, 1)
        end

        i = i + 1
    end

    CreateRow("Attire")
    CreateRow("Belt")