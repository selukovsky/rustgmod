ENT.Base = "rust_storage"

ENT.InventorySlots = 37

ENT.InventoryName   = "Sleeping Player"

ENT.DisplayIcon = gRust.GetIcon("open")


