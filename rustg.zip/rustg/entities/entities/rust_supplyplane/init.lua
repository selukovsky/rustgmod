AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")

include("shared.lua")

function ENT:Initialize()
    self:SetModel(self.Model)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_FLY)
    self:SetSolid(SOLID_BBOX)

    local backward = -self:GetForward()
    self.Velocity = backward * 250

    timer.Simple(25, function()
        if IsValid(self) then
            self:Remove()
        end
    end)

    timer.Simple(math.random(7, 15), function()
        if not IsValid(self) then return end

        local dropPos = self:GetPos() + Vector(0, 0, -200)
        local dropEnt = ents.Create("rust_supplydrop")

        dropEnt:SetPos(dropPos)
        dropEnt:Spawn()
        dropEnt:Activate()
    end)
end

function ENT:Think()
    if IsValid(self) and self.Velocity then
        self:SetLocalVelocity(self.Velocity)
    end
    self:NextThink(CurTime())
    return true
end