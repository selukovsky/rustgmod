include("shared.lua")

local FALLOFF_DISTANCE = 9024

function ENT:Initialize()
    self:SetModel(self.Model)

    self.Sound = CreateSound(LocalPlayer(), "rust/airdrop-plane-loop.mp3")
    if self.Sound then
        self.Sound:Play()
    end
end

function ENT:Think()
    if not self.Sound then return end

    local pos = self:GetPos()
    local ply = LocalPlayer()

    local relativePos = pos - ply:GetPos()
    relativePos.z = 0
    local distance = relativePos:Length()

    local volume = math.Clamp(1 - (distance / FALLOFF_DISTANCE), 0, 1)
    self.Sound:ChangeVolume(volume, 0.1)
end