ENT.Base = "base_anim"
ENT.Type = "anim"

ENT.Model = "models/darky_m/rust/supply_plane.mdl"