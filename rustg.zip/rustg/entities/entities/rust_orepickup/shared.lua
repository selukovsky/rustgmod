ENT.Base = "rust_base"

ENT.DisplayIcon = gRust.GetIcon("give")

ENT.DrawHalo = true
