ENT.Base = "rust_base"

ENT.DisplayIcon = gRust.GetIcon("circle")
ENT.AutomaticFrameAdvance = true