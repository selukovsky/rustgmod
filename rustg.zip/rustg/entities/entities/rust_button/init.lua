AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/darky_m/rust/puzzle/button.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:EnableMotion(false)
    end

    self:SetUseType(SIMPLE_USE)
    self.Door = nil
    self:FindDoor()
    self:SetDisplayName("PRESS")
end

function ENT:FindDoor()
    local dist = 100
    for _, ent in pairs(ents.FindInSphere(self:GetPos(), dist)) do
        if ent:GetClass() == "rust_puzzledoor" then
            self.Door = ent
            break
        end
    end
end

function ENT:Use(activator, caller)
    if not IsValid(self.Door) then return end
    if self.Door:GetOpened() or self.Door.IsAnimating then return end

    self.Door:EmitSound("doors/door_metal_open.wav")
    self.Door:OpenDoorForDuration(5)
end