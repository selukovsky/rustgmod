ENT.Base = "rust_storage"
ENT.Type = "anim"

ENT.InventorySlots = 2
ENT.InventoryName = "RESEARCH TABLE"

ENT.Deploy = {}
ENT.Deploy.Model = "models/deployable/research_table.mdl"

ENT.ProcessTime = 10.0
ENT.DisplayIcon = gRust.GetIcon("open")

function ENT:CanResearch()
    local inputItem = self.Inventory[1]
    local scrapItem = self.Inventory[2]

    if not inputItem or not scrapItem then return false end

    local itemClass = inputItem:GetItem()
    local itemData = gRust.Items[itemClass]
    if not itemData then return false end

    local blueprintCost = itemData:GetBlueprint()
    if not blueprintCost or not isnumber(blueprintCost) then return false end

    if scrapItem:GetItem() ~= "scrap" then return false end
    if scrapItem:GetQuantity() < blueprintCost then return false end
    
    if inputItem:GetQuantity() > 1 then return false end

    return true
end