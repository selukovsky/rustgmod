include("shared.lua")

surface.CreateFont("gRust.Research.Text", {
    font = "Roboto Condensed",
    size = 23,
    weight = 500,
    antialias = true
})

function ENT:Draw()
    self:DrawModel()
end

function ENT:Initialize()
    if not IsValid(gRust.Inventory) then return end
    gRust.Inventory.Container = nil
end

function ENT:Use(activator, caller)
    if not IsValid(caller) or not caller:IsPlayer() then return end
    caller:RequestInventory(self)
end

local Container
local ResearchButton
local TimerLabel

function ENT:ConstructInventory(panel, data, rows)
	local scrw, scrh = ScrW(), ScrH()

	if (IsValid(Container)) then
		Slot1:SetItem(self.Inventory[1])
		Slot2:SetItem(self.Inventory[2])
		self:UpdateResearchButton()
		self:UpdateTimerDisplay()
		if (table.IsEmpty(data)) then
			Container:Remove()
		end
		return
	end

	Container = panel:Add("Panel")
	Container:Dock(FILL)
	Container:DockMargin(0, 0, 0, ScrH() * 0.165)

	local Container = Container:Add("Panel")
	Container:Dock(BOTTOM)
	Container:SetTall(ScrH() * 0.75)
	Container:DockMargin(scrw * 0.02, 0, scrw * 0.0335, scrh * 0.005)

	local ButtonContainer = Container:Add("DPanel")
	ButtonContainer:Dock(BOTTOM)
	ButtonContainer:SetTall(scrh * 0.065)
	ButtonContainer:DockMargin(0, scrh * 0.005, 0, 0)
	ButtonContainer:DockPadding(scrh * 0.0075, scrh * 0.0075, scrh * 0.0075, scrh * 0.0075)
	ButtonContainer.Paint = function(me, w, h)
		surface.SetDrawColor(126, 126, 126, 39)
		surface.DrawRect(0, 0, w, h)
	end

	ResearchButton = ButtonContainer:Add("gRust.Button")
	ResearchButton:Dock(RIGHT)
	ResearchButton:SetWide(scrw * 0.095)
	ResearchButton:SetDefaultColor(Color(115, 141, 69))
	ResearchButton:SetHoveredColor(Color(105, 141, 42))
	ResearchButton:SetActiveColor(Color(134, 180, 55))
	ResearchButton:SetText("BEGIN RESEARCH")
	ResearchButton.DoClick = function()
		net.Start("gRust.Research")
		net.WriteEntity(self)
		net.SendToServer()
	end
	ResearchButton:SetVisible(false)

	TimerLabel = ButtonContainer:Add("DLabel")
	TimerLabel:Dock(RIGHT)
	TimerLabel:SetWide(scrw * 0.075)
	TimerLabel:SetContentAlignment(4)
	TimerLabel:SetFont("gRust.68px")
	TimerLabel:SetVisible(false)
	TimerLabel:SetText("0.00")

	local CTall = scrh * 0.175
	local ScrapContainer = Container:Add("Panel")
	ScrapContainer:Dock(BOTTOM)
	ScrapContainer:SetTall(CTall)

	local ScrapInfo = ScrapContainer:Add("DPanel")
	ScrapInfo:Dock(FILL)
	ScrapInfo:DockMargin(scrh * 0.005, 0, 0, 0)
	ScrapInfo.Paint = function(me, w, h)
		surface.SetDrawColor(126, 126, 126, 39)
		surface.DrawRect(0, 0, w, h)
	end

	local Scrap = ScrapContainer:Add("gRust.Inventory.Slot")
	Scrap:Dock(LEFT)
	Scrap:SetWide(CTall)
	Scrap:SetItem(self.Inventory[2])
	Scrap:SetEntity(self)
	Scrap:SetID(2)
	Scrap.OnItemChanged = function()
		self:UpdateResearchButton()
	end
	Slot2 = Scrap

	local ScrapTitle = ScrapContainer:Add("DLabel")
	ScrapTitle:Dock(FILL)
	ScrapTitle:DockMargin(scrw * 0.01, scrh * -0.120, 0, 0)
	ScrapTitle:SetColor(color_grey)
	ScrapTitle:SetFont("gRust.48px")
	ScrapTitle:SetContentAlignment(4)
	ScrapTitle:SetText("Scrap To Use")

	local ScrapInfo = ScrapContainer:Add("DLabel")
	ScrapInfo:Dock(FILL)
	ScrapInfo:DockMargin(scrw * 0.01, 0, 0, scrh * 0.015)
	ScrapInfo:SetColor(color_grey)
	ScrapInfo:SetFont("gRust.Research.Text")
	ScrapInfo:SetContentAlignment(4)
	ScrapInfo:SetText("Scrap is required to produce an item\nblueprint, insert it here.")

	local ResearchContainer = Container:Add("Panel")
	ResearchContainer:Dock(BOTTOM)
	ResearchContainer:SetTall(scrh * 0.11)
	ResearchContainer:DockMargin(0, scrh * 0.005, 0, scrh * 0.005)

	local ResearchInfo = ResearchContainer:Add("Panel")
	ResearchInfo:Dock(FILL)
	ResearchInfo:DockMargin(0, 0, scrh * 0.005, 0)
	ResearchInfo.Paint = function(me, w, h)
		surface.SetDrawColor(126, 126, 126, 39)
		surface.DrawRect(0, 0, w, h)
	end

	local ResearchCost = ResearchContainer:Add("Panel")
	ResearchCost:Dock(RIGHT)
	ResearchCost:SetWide(scrw * 0.1)
	ResearchCost.Paint = function(me, w, h)
		surface.SetDrawColor(126, 126, 126, 39)
		surface.DrawRect(0, 0, w, h)

		local Slot = self.Inventory[1]
		local Cost = (Slot and gRust.Items[Slot:GetItem()].Blueprint) or "N/A"
		if (!isnumber(Cost)) then Cost = "N/A" end

		draw.SimpleText(Cost, "gRust.120px", w * 0.5, h * 0.5, Color(225, 225, 225), 1, 1)
	end

	local ResearchCostTitle = ResearchContainer:Add("DLabel")
	ResearchCostTitle:Dock(FILL)
	ResearchCostTitle:DockMargin(scrw * 0.01, scrh * -0.057, 0, 0)
	ResearchCostTitle:SetColor(color_grey)
	ResearchCostTitle:SetFont("gRust.48px")
	ResearchCostTitle:SetContentAlignment(4)
	ResearchCostTitle:SetText("Research Cost")

	local ResearchCostInfo = ResearchContainer:Add("DLabel")
	ResearchCostInfo:Dock(FILL)
	ResearchCostInfo:DockMargin(scrw * 0.01, 0, 0, scrh * -0.023)
	ResearchCostInfo:SetColor(color_grey)
	ResearchCostInfo:SetFont("gRust.Research.Text")
	ResearchCostInfo:SetContentAlignment(4)
	ResearchCostInfo:SetText("How much scrap you require to produce a\nblueprint of this item")

	local InputContainer = Container:Add("Panel")
	InputContainer:Dock(BOTTOM)
	InputContainer:SetTall(CTall)

	local Input = InputContainer:Add("gRust.Inventory.Slot")
	Input:Dock(LEFT)
	Input:SetWide(CTall)
	Input:SetEntity(self)
	Input:SetID(1)
	Input:SetItem(self.Inventory[1])
	Input.OnItemChanged = function()
		self:UpdateResearchButton()
	end
	Slot1 = Input

	local InputInfo = InputContainer:Add("Panel")
	InputInfo:Dock(FILL)
	InputInfo:DockMargin(scrw * 0.0025, 0, 0, 0)
	InputInfo.Paint = function(me, w, h)
		surface.SetDrawColor(126, 126, 126, 39)
		surface.DrawRect(0, 0, w, h)
	end

	local ItemToResearchTitle = InputContainer:Add("DLabel")
	ItemToResearchTitle:Dock(FILL)
	ItemToResearchTitle:DockMargin(scrw * 0.01, scrh * -0.120, 0, 0)
	ItemToResearchTitle:SetColor(color_grey)
	ItemToResearchTitle:SetFont("gRust.48px")
	ItemToResearchTitle:SetContentAlignment(4)
	ItemToResearchTitle:SetText("Item to research")

	local ItemToResearchInfo = InputContainer:Add("DLabel")
	ItemToResearchInfo:Dock(FILL)
	ItemToResearchInfo:DockMargin(scrw * 0.01, 0, 0, scrh * 0.015)
	ItemToResearchInfo:SetColor(color_grey)
	ItemToResearchInfo:SetFont("gRust.Research.Text")
	ItemToResearchInfo:SetContentAlignment(4)
	ItemToResearchInfo:SetText("Drag the item you want to research into\nthe box on the left. This item might get\ndestroyed during the research process.")

	local Info = Container:Add("Panel")
	Info:Dock(BOTTOM)
	Info:SetTall(scrh * 0.08)
	Info:DockMargin(0, scrh * 0.005, 0, scrh * 0.005)
	Info:DockPadding(scrh * 0.01, scrh * 0.01, scrh * 0.01, scrh * 0.01)
	Info.Paint = function(me, w, h)
		surface.SetDrawColor(126, 126, 126, 39)
		surface.DrawRect(0, 0, w, h)
	end

	local InfoIcon = Info:Add("DImage")
	InfoIcon:Dock(LEFT)
	InfoIcon:SetWide(scrh * 0.06)
	InfoIcon:SetImageColor(Color(200, 200, 200))
	InfoIcon:SetMaterial(Material("icons/info.png"))

	local Info = Info:Add("DLabel")
	Info:Dock(FILL)
	Info:DockMargin(scrw * 0.01, 0, 0, 0)
	Info:SetColor(color_grey)
	Info:SetWrap(true)
	Info:SetFont("gRust.28px")
	Info:SetContentAlignment(4)
	Info:SetText("Use the research table to learn how to craft new items using scrap")

	local Name = Container:Add("Panel")
	Name:Dock(BOTTOM)
	Name:SetTall(ScrH() * 0.04)
	Name.Paint = function(me, w, h)
		draw.SimpleText("RESEARCH TABLE", "gRust.48px", w * 0.00, h * 0.5, Color(255, 255, 255, 200), 0, 1)
	end

	self:UpdateResearchButton()
	self:UpdateTimerDisplay()
end

function ENT:UpdateResearchButton()
	if not IsValid(ResearchButton) then return end
	ResearchButton:SetVisible(self:CanResearch() and not self.IsProcessing)
end

function ENT:UpdateTimerDisplay()
	if not IsValid(TimerLabel) then return end
	if self.IsProcessing and self.ProcessStartTime and self.ProcessDuration then
		local elapsed = CurTime() - self.ProcessStartTime
		local remaining = math.max(0, self.ProcessDuration - elapsed)
		local seconds = math.floor(remaining)
		local milliseconds = math.floor((remaining - seconds) * 100)
		TimerLabel:SetText(string.format("%d.%02d", seconds, milliseconds))
		TimerLabel:SetVisible(true)
	else
		TimerLabel:SetVisible(false)
		TimerLabel:SetText("0.00")
	end
end

function ENT:UpdateTimer(duration, elapsed)
	if not IsValid(TimerLabel) then return end
	local remaining = math.max(0, duration - elapsed)
	local seconds = math.floor(remaining)
	local milliseconds = math.floor((remaining - seconds) * 100)
	TimerLabel:SetText(string.format("%d.%02d", seconds, milliseconds))
end

net.Receive("gRust.ResearchTable.UpdateProgress", function()
    local ent = net.ReadEntity()
    local active = net.ReadBool()
    local duration = net.ReadFloat()

	if not IsValid(ent) then return end

	if active then
		ent.IsProcessing = true
		ent.ProcessStartTime = CurTime()
		ent.ProcessDuration = duration
		
		if IsValid(ResearchButton) then
			ResearchButton:SetVisible(false)
		end
		
		if IsValid(TimerLabel) then
			TimerLabel:SetVisible(true)
			local startTime = CurTime()
			timer.Create("ResearchTimer_" .. ent:EntIndex(), 0.01, 0, function()
				if not IsValid(ent) or not ent.IsProcessing then
					timer.Remove("ResearchTimer_" .. ent:EntIndex())
					return
				end
				ent:UpdateTimer(duration, CurTime() - startTime)
			end)
		end
	else
		ent.IsProcessing = false
		ent.ProcessStartTime = nil
		ent.ProcessDuration = nil
		
		if IsValid(TimerLabel) then
			TimerLabel:SetVisible(false)
			TimerLabel:SetText("0.00")
		end
		
		timer.Remove("ResearchTimer_" .. ent:EntIndex())
		ent:UpdateResearchButton()
	end
end)