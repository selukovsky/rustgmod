AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

util.AddNetworkString("gRust.Research")
util.AddNetworkString("gRust.ResearchTable.Open")
util.AddNetworkString("gRust.ResearchTable.UpdateProgress")

function ENT:Initialize()
    self:SetUseType(SIMPLE_USE)
    self:SetModel(self.Deploy.Model)
    self:PhysicsInitStatic(SOLID_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:CreateInventory(2)
    self:SetInteractable(true)
    self:SetDamageable(true)
    self:SetHealth(200)
    self:SetMaxHealth(200)
    self:SetDisplayName("OPEN")

    self:SetNW2Bool("gRust.Processing", false)
    self:SetNW2Float("gRust.ProcessStart", 0)
    self:SetNW2Float("gRust.ProcessTime", self.ProcessTime)
    self:SetNW2Float("gRust.Progress", 0)

    self.LastUser = nil
end

function ENT:Use(activator, caller)
    if not IsValid(caller) or not caller:IsPlayer() then return end
    caller:RequestInventory(self)
    self.LastUser = caller
end

function ENT:StartProcessing()
    if self:GetNW2Bool("gRust.Processing") then return end
    if not self:CanResearch() then return end

    local inputItem = self.Inventory[1]
    local scrapItem = self.Inventory[2]
    local itemClass = inputItem:GetItem()
    local itemData = gRust.Items[itemClass]
    local blueprintCost = itemData:GetBlueprint()

    scrapItem:RemoveQuantity(blueprintCost)
    if scrapItem:GetQuantity() <= 0 then
        self:RemoveSlot(2)
    else
        self:SyncSlot(2)
    end

    self:SetNW2Bool("gRust.Processing", true)
    self:SetNW2Float("gRust.ProcessStart", CurTime())
    self:SetNW2Float("gRust.ProcessTime", self.ProcessTime)

    net.Start("gRust.ResearchTable.UpdateProgress")
    net.WriteEntity(self)
    net.WriteBool(true)
    net.WriteFloat(self.ProcessTime)
    net.Broadcast()

    timer.Create("ResearchTable_" .. self:EntIndex(), self.ProcessTime, 1, function()
        if IsValid(self) then
            self:CompleteResearch()
        end
    end)
end

function ENT:CompleteResearch()
    local inputItem = self.Inventory[1]
    if not inputItem then
        self:StopProcessing()
        return
    end

    local itemClass = inputItem:GetItem()
    local itemData = gRust.Items[itemClass]
    if not itemData then
        self:StopProcessing()
        return
    end

    local blueprintCost = itemData:GetBlueprint()
    if not blueprintCost then
        self:StopProcessing()
        return
    end

    local blueprintClass = itemClass .. ".Blueprint"
    
    if not gRust.Items[blueprintClass] then
        blueprintClass = "blueprint_" .. itemClass
        if not gRust.Items[blueprintClass] then
            self:StopProcessing()
            return
        end
    end

    local blueprintItem = gRust.CreateItem(blueprintClass, 1)
    self:SetSlot(blueprintItem, 1)

    self:EmitSound("farming/research_success.wav")
    self:StopProcessing()
end

function ENT:StopProcessing()
    self:SetNW2Bool("gRust.Processing", false)
    self:SetNW2Float("gRust.Progress", 0)

    net.Start("gRust.ResearchTable.UpdateProgress")
    net.WriteEntity(self)
    net.WriteBool(false)
    net.Broadcast()

    timer.Remove("ResearchTable_" .. self:EntIndex())
end

net.Receive("gRust.Research", function(len, ply)
    local ent = net.ReadEntity()
    if not IsValid(ent) or ent:GetClass() ~= "rust_researchtable" then return end
    if ent.LastUser ~= ply then return end

    local inputItem = ent.Inventory[1]
    if inputItem then
        local itemData = gRust.Items[inputItem:GetItem()]
        if itemData and itemData:GetWeapon() then
            local clip = inputItem:GetClip() or 0
            if clip > 0 then
                local ammoType = weapons.Get(itemData:GetWeapon()) and weapons.Get(itemData:GetWeapon()).Ammo
                if ammoType then
                    ply:GiveItem(ammoType, clip)
                    inputItem:SetClip(0)
                    ent:SyncSlot(1)
                    
                    local wep = ply:GetActiveWeapon()
                    if IsValid(wep) and wep:GetClass() == itemData:GetWeapon() then
                        wep:SetClip1(0)
                    end
                end
            end
        end
    end
    
    if ent:CanResearch() then
        ent:StartProcessing()
        ent:EmitSound("farming/research_item.wav")
    end
end)

function ENT:OnRemove()
    timer.Remove("ResearchTable_" .. self:EntIndex())
end