AddCSLuaFile()

ENT.Base = "rust_tier1"

ENT.Deploy = {}

ENT.Deploy.Model = "models/deployable/workbench_tier3.mdl"

ENT.Deploy.Sound = "deploy/workbench_tier_3_deploy.wav"

ENT.MaxHealth = 750

ENT.Pickup = "tier3"

ENT.TechTree = {
    {
        Item = "rifle.sks",
        Direction = 1,
        Scrap = 150,
        Branch = {
            {
                Item = "smg.mp5",
                Scrap = 500,
                Branch = {
                    {
                        Item = "rifle.ak",
                        Scrap = 500,
                        Direction = 1,
                        Branch = {
                            {
                                Item = "rifle.bolt",
                                Scrap = 500,
                                Direction = 1,
                                Branch = {
                                    {
                                        Item = "hmlmg",
                                        Scrap = 500
                                    }
                                }
                            }
                        }
                    },
                    {
                        Item = "explosives",
                        Scrap = 500,
                        Direction = 2,
                        Branch = {
                            {
                                Item = "explosive.timed",
                                Scrap = 500
                            }
                        }
                    }
                }
            }
        }
    }
}