AddCSLuaFile()
ENT.Base = "rust_process"

ENT.Deploy = {}
ENT.Deploy.Model = "models/zohart/deployables/furnace_large.mdl"
ENT.ProcessTime = 0.5
ENT.StopOnEmpty = true
ENT.Pickup = "furnace"
ENT.OpenSoundType = "largefurnace"
ENT.ShowHealth = true

ENT.Ores = {
    ["sulfur.ore"] = {
        processTime = 1.2,
        woodConsumption = 1,
        charcoalProduction = 1,
        output = { item = "sulfur", amount = 1 }
    },
    ["metal.ore"] = {
        processTime = 1.0,
        woodConsumption = 2,
        charcoalProduction = 2,
        output = { item = "metal.fragments", amount = 1 }
    },
    ["hq.metal.ore"] = {
        processTime = 3.20,
        woodConsumption = 3,
        charcoalProduction = 3,
        output = { item = "metal.refined", amount = 1 }
    },
    ["wood"] = {
        processTime = 0.3,
        woodConsumption = 0,
        charcoalProduction = 1,
        output = { item = "charcoal", amount = 2 }
    },
}

function ENT:GetOreData(itemType)
    return self.Ores[itemType]
end

-- возвращает время переплавки
function ENT:GetProcessTimeForItem(itemType)
    local ore = self:GetOreData(itemType)
    return ore and ore.processTime or self.ProcessTime
end

-- сколько надо дерева
function ENT:GetWoodConsumptionForItem(itemType)
    local ore = self:GetOreData(itemType)
    return ore and ore.woodConsumption or 1
end

-- сколько угля сделает
function ENT:GetCharcoalProductionForItem(itemType)
    local ore = self:GetOreData(itemType)
    return ore and ore.charcoalProduction or 1
end

ENT.DisplayIcon = gRust.GetIcon("open")
function ENT:Initialize()
    self.Fire = false
    if CLIENT then return end

    self:SetModel("models/zohart/deployables/furnace_large.mdl")
    self:PhysicsInitStatic(SOLID_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetInteractable(true)
    self:CreateInventory(18)
    self:SetSaveItems(true)
    self:SetDamageable(true)
    self:SetHealth(500)
    self:SetMaxHealth(500)
    self:SetMeleeDamage(0.2)
    self:SetBulletDamage(0.05)
    self:SetExplosiveDamage(0.4)
    self:SetInteractable(true)
    self:SetDisplayName("OPEN")

    self.CurrentProcessingItems = {}
    self.ProcessWoodConsumed = false
    self:SetNW2Bool("gRust.Enabled", false)
    self:SetNW2Bool("gRust.Processing", false)

    self.LFurnaceSound = nil

    self:EmitSound("farming/furnace_deploy.wav", 100, 100)
end

function ENT:SyncSlot(i)
    local item = self.Inventory[i]
    if item then
        self:SetNW2String("Slot_" .. i .. "_Class", item:GetItem())
        self:SetNW2Int("Slot_" .. i .. "_Quantity", item:GetQuantity())
    else
        self:SetNW2String("Slot_" .. i .. "_Class", "")
        self:SetNW2Int("Slot_" .. i .. "_Quantity", 0)
    end
end

function ENT:SyncAllSlots()
    if not self.Inventory then return end
    for i = 1, #self.Inventory do
        self:SyncSlot(i)
    end
end

function ENT:Toggle()
    local enabled = self:GetNW2Bool("gRust.Enabled", false)
    if not enabled then
        if self:CanProcess() then
            self:SetNW2Bool("gRust.Enabled", true)
            self:StartProcessing()
        end
    else
        self:SetNW2Bool("gRust.Enabled", false)
        self:StopProcessing()
        if self.LFurnaceSound then
            self.LFurnaceSound:Stop()
            self.LFurnaceSound = nil
        end
        self:EmitSound("farming/furnace_extinguish.wav", 75, 100)
    end
    return true
end

function ENT:Use(activator, caller)
    if not caller:IsPlayer() then return end
    if self.LastUse and CurTime() - self.LastUse < 0.5 then
        return
    end
    self.LastUse = CurTime()
    self.LastUser = caller
end

net.Receive("gRust.LargeFurnaceToggle", function(len, ply)
    local ent = net.ReadEntity()
    if IsValid(ent) and ent:GetClass() == "rust_largefurnace" and ent.LastUser == ply then ent:Toggle() end
end)

function ENT:CanProcess()
    local itemsToProcess = {}
    local totalWoodNeeded = 0
    for i = 1, 18 do
        local item = self.Inventory[i]
        if item and self.Ores[item:GetItem()] then
            table.insert(itemsToProcess, { slot = i, type = item:GetItem() })
            totalWoodNeeded = totalWoodNeeded + self:GetWoodConsumptionForItem(item:GetItem())
        end
    end

    if #itemsToProcess == 0 then return false end
    local woodCount = 0
    for i = 1, 18 do
        local item = self.Inventory[i]
        if item and item:GetItem() == "wood" then woodCount = woodCount + item:GetQuantity() end
    end
    return woodCount >= totalWoodNeeded and #itemsToProcess > 0
end

function ENT:StartProcessing()
    if self:GetNW2Bool("gRust.Processing", false) then return end
    if not self:CanProcess() then
        self:SetNW2Bool("gRust.Enabled", false)
        return
    end
    self.CurrentProcessingItems = {}
    for i = 1, 18 do
        local item = self.Inventory[i]
        if item and self.Ores[item:GetItem()] then
            table.insert(self.CurrentProcessingItems, { slot = i, type = item:GetItem() })
        end
    end
    if #self.CurrentProcessingItems > 0 then
        local maxTime = 0
        for _, itemData in pairs(self.CurrentProcessingItems) do
            local time = self:GetProcessTimeForItem(itemData.type)
            if time > maxTime then maxTime = time end
        end
        self.ProcessTime = maxTime
        self.ProcessWoodConsumed = false
    end

    self:SetNW2Bool("gRust.Processing", true)
    self:SetNW2Float("gRust.ProcessStart", CurTime())
    self:SetNW2Float("gRust.ProcessTime", self.ProcessTime)

    if not self.LFurnaceSound then
        self.LFurnaceSound = CreateSound(self, "farming/furnace_loop.wav")
        self.LFurnaceSound:Play()
    end

    timer.Create("ProcessTimer_" .. self:EntIndex(), self.ProcessTime, 1, function()
        if IsValid(self) then self:CompleteProcess() end
    end)
end

function ENT:AddItem(itemClass, amount, data, startSlot, endSlot)
    startSlot = startSlot or 1
    endSlot = endSlot or 18

    local itemData = gRust.Items[itemClass]
    if not itemData then 
        return false 
    end

    local maxStack = itemData:GetStack() or 1
    local remainingAmount = amount

    -- Функция для создания нового предмета
    local function CreateNewItem(qty)
        local newItem = gRust.CreateItem(itemClass, qty, data)
        if not newItem then
            return nil
        end
        return newItem
    end

    -- Шаг 1: Попытка добавить к существующим стакам
    for i = startSlot, endSlot do
        if remainingAmount <= 0 then break end
        
        local slotItem = self.Inventory[i]
        if slotItem and slotItem:GetItem() == itemClass then
            local currentQty = slotItem:GetQuantity()
            if currentQty < maxStack then
                local canAdd = math.min(remainingAmount, maxStack - currentQty)
                
                if canAdd > 0 then
                    if slotItem.AddQuantity then
                        slotItem:AddQuantity(canAdd)
                    elseif slotItem.SetQuantity then
                        slotItem:SetQuantity(currentQty + canAdd)
                    else
                        local newItem = CreateNewItem(currentQty + canAdd)
                        if newItem then
                            self.Inventory[i] = newItem
                        end
                    end
                    
                    remainingAmount = remainingAmount - canAdd
                    self:SyncSlot(i)
                end
            end
        end
    end

    -- Шаг 2: Создание новых стаков в пустых слотах
    if remainingAmount > 0 then
        for i = startSlot, endSlot do
            if remainingAmount <= 0 then break end
            
            if not self.Inventory[i] then
                local createAmount = math.min(remainingAmount, maxStack)
                local newItem = CreateNewItem(createAmount)
                
                if newItem then
                    self.Inventory[i] = newItem
                    remainingAmount = remainingAmount - createAmount
                    self:SyncSlot(i)
                end
            end
        end
    end

    -- Шаг 3: Дополнительное добавление к существующим стакам
    if remainingAmount > 0 then
        for i = startSlot, endSlot do
            if remainingAmount <= 0 then break end
            
            local slotItem = self.Inventory[i]
            if slotItem and slotItem:GetItem() == itemClass then
                local currentQty = slotItem:GetQuantity()
                if currentQty < maxStack then
                    local canAdd = math.min(remainingAmount, maxStack - currentQty)
                    
                    if canAdd > 0 then
                        if slotItem.AddQuantity then
                            slotItem:AddQuantity(canAdd)
                        elseif slotItem.SetQuantity then
                            slotItem:SetQuantity(currentQty + canAdd)
                        end
                        
                        remainingAmount = remainingAmount - canAdd
                        self:SyncSlot(i)
                    end
                end
            end
        end
    end

    self:SyncAllSlots()
    return remainingAmount <= 0
end

function ENT:CompleteProcess()
    if not self.ProcessWoodConsumed then
        local totalWoodNeeded = 0
        for _, itemData in pairs(self.CurrentProcessingItems) do
            totalWoodNeeded = totalWoodNeeded + self:GetWoodConsumptionForItem(itemData.type)
        end
        local woodConsumed = 0
        for i = 1, 18 do
            local item = self.Inventory[i]
            if item and item:GetItem() == "wood" and item:GetQuantity() > 0 then
                local toConsume = math.min(item:GetQuantity(), totalWoodNeeded - woodConsumed)
                item:RemoveQuantity(toConsume)
                woodConsumed = woodConsumed + toConsume
                if item:GetQuantity() <= 0 then
                    self:RemoveSlot(i)
                else
                    self:SyncSlot(i)
                end
                if woodConsumed >= totalWoodNeeded then break end
            end
        end
        self.ProcessWoodConsumed = true
    end

    for _, itemData in pairs(self.CurrentProcessingItems) do
        local item = self.Inventory[itemData.slot]
        if item and item:GetItem() == itemData.type then
            local ore = self:GetOreData(item:GetItem())
            if ore and ore.output then
                local canAddResult = self:FindEmptySlot(1, 18, gRust.CreateItem(ore.output.item, ore.output.amount)) ~= nil
                local canAddCharcoal = self:FindEmptySlot(1, 18, gRust.CreateItem("charcoal", ore.charcoalProduction)) ~= nil
                if canAddResult and canAddCharcoal then
                    item:RemoveQuantity(1)
                    if item:GetQuantity() <= 0 then
                        self:RemoveSlot(itemData.slot)
                    else
                        self:SyncSlot(itemData.slot)
                    end
                    self:AddItem(ore.output.item, ore.output.amount, nil, 1, 18)
                    self:AddItem("charcoal", ore.charcoalProduction, nil, 1, 18)
                end
            end
        end
    end

    self:StopProcessing()
    self.CurrentProcessingItems = {}

    if self:GetNW2Bool("gRust.Enabled", false) then
        if self:CanProcess() then
            timer.Simple(0.1, function()
                if IsValid(self) then
                    self:StartProcessing()
                end
            end)
        else
            self:SetNW2Bool("gRust.Enabled", false)
            if self.LFurnaceSound then
                self.LFurnaceSound:Stop()
                self.LFurnaceSound = nil
            end
            self:EmitSound("farming/furnace_extinguish.wav", 75, 100)
        end
    end
end

function ENT:StopProcessing()
    self:SetNW2Bool("gRust.Processing", false)
    timer.Remove("ProcessTimer_" .. self:EntIndex())
    self.ProcessWoodConsumed = false
end

function ENT:OnRemove()
    timer.Remove("ProcessTimer_" .. self:EntIndex())
    self:StopParticles()
    if self.LFurnaceSound then
        self.LFurnaceSound:Stop()
        self.LFurnaceSound = nil
    end
end

function ENT:Draw()
    self:DrawModel()
    local enabled = self:GetNW2Bool("gRust.Enabled")
    if enabled and not self.Fire then
        ParticleEffectAttach("rust_fire", PATTACH_POINT_FOLLOW, self, 1)
        self.Fire = true
    elseif not enabled and self.Fire then
        self:StopParticles()
        self.Fire = false
    end
end

function ENT:Togglez()
    net.Start("gRust.LargeFurnaceToggle")
    net.WriteEntity(self)
    net.SendToServer()
end

-- ОДНА СТРОКА НА 6 СЛОТОВ
function ENT:ConstructInventory(panel, data, rows)
    if IsValid(Container) then Container:Remove() end
    Container = panel:Add("Panel")
    Container:Dock(FILL)
    local LeftMargin = ScrW() * 0.02
    local RightMargin = ScrW() * 0.05
    local Margin = ScrH() * 0.01

    ------------------------------------------------------------------------
    -- ПАНЕЛЬ УПРАВЛЕНИЯ ДЛЯ БОЛЬШОЙ ПЕЧКИ
    ------------------------------------------------------------------------
    local ControlPanel = Container:Add("Panel")
    ControlPanel:Dock(BOTTOM)
    ControlPanel:DockMargin(LeftMargin, 20 * gRust.Scaling, RightMargin, ScrH() * 0.15)
    ControlPanel:SetTall(184 * gRust.Scaling)
    ControlPanel.Paint = PaintBackground

    -- Заголовок панели управления
    local Title = ControlPanel:Add("Panel")
    Title:Dock(TOP)
    Title:SetTall(30 * gRust.Scaling)
    Title:DockMargin(0, 0, 0, 2 * gRust.Scaling)
    Title.Paint = function(me, w, h)
        surface.SetDrawColor(80, 76, 70, 100)
        surface.DrawRect(0, 0, w, h)
        draw.SimpleText("CONTROLS", "gRust.28px", 8 * gRust.Scaling, h / 2, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    local ContentPanel = ControlPanel:Add("Panel")
    ContentPanel:Dock(FILL)
    ContentPanel:DockPadding(10 * gRust.Scaling, 10 * gRust.Scaling, 10 * gRust.Scaling, 10 * gRust.Scaling)

    local ToggleButton = ContentPanel:Add("gRust.ToggleButton")
    ToggleButton:Dock(LEFT)
    ToggleButton:SetWide(256 * gRust.Scaling)
    ToggleButton:SetToggled(self:GetNW2Bool("gRust.Enabled", false))

    local Info = ContentPanel:Add("DLabel")
    Info:Dock(FILL)
    Info:SetWrap(true)
    Info:SetFont("gRust.28px")
    Info:SetTextColor(Color(255, 255, 255))
    Info:DockMargin(20 * gRust.Scaling, 0, 0, 0)
    Info:SetContentAlignment(7)
    
    -- Тексты подсказок для большой печки (такие же как у обычной)
    local TOGGLE_ON_TEXT = [[The furnace is on. Wait for the smelting process to complete.]]
    local TOGGLE_OFF_TEXT = [[The furnace is off. Add wood and ore.]]

    -- Устанавливаем начальный текст
    Info:SetText(self:GetNW2Bool("gRust.Enabled", false) and TOGGLE_ON_TEXT or TOGGLE_OFF_TEXT)

    -- Обработка переключения
    ToggleButton.OnToggle = function(me, toggled)
        net.Start("gRust.LargeFurnaceToggle")
        net.WriteEntity(self)
        net.SendToServer()
    end

    -- Обновление состояния
    ToggleButton.Think = function(me)
        local toggled = self:GetNW2Bool("gRust.Enabled", false)
        if toggled then
            Info:SetText(TOGGLE_ON_TEXT)
            ToggleButton:SetToggled(true)
        else
            Info:SetText(TOGGLE_OFF_TEXT)
            ToggleButton:SetToggled(false)
        end
    end

    ------------------------------------------------------------------------
    -- СЛОТЫ ИНВЕНТАРЯ БОЛЬШОЙ ПЕЧКИ
    ------------------------------------------------------------------------
    local slotSize = 128
    local cols = 6
    local rows = 3

    local Grid = Container:Add("gRust.Inventory.SlotGrid")
    Grid:Dock(BOTTOM)
    Grid:SetCols(cols)
    Grid:SetRows(rows)
    Grid:SetInventoryOffset(0)
    Grid:SetEntity(self)
    Grid:SetMargin(data.margin)
    Grid:DockMargin(LeftMargin, 0, RightMargin, ScrH() * 0.01)
    Grid:SetWide(slotSize * cols + data.margin * (cols - 5))
    Grid:SetTall(slotSize * rows + data.margin * (rows - 5))
    Grid.InvType = "ALL"

    local Name = Container:Add("Panel")
    Name:Dock(BOTTOM)
    Name:SetTall(ScrH() * 0.03)
    Name:DockMargin(LeftMargin - ScrW() * 0.005, 0, RightMargin, ScrH() * 0.008)
    Name.Paint = function(me, w, h)
        surface.SetDrawColor(80, 76, 70, 100)
        surface.DrawRect(0, 0, w, h)
        draw.SimpleText("LARGE FURNACE", "gRust.38px", w * 0.01, h * 0.5, Color(255, 255, 255, 200), 0, 1)
    end

    local distance = LocalPlayer():GetPos():Distance(self:GetPos())
    if distance > 200 then
        gRust.CloseInventory()
        return
    end
end