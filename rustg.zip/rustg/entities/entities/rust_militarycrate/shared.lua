ENT.Base = "rust_storage"

ENT.Deploy = {}
ENT.Deploy.Model = "models/environment/misc/recycler.mdl"


ENT.InventorySlots = 5

ENT.InventoryName   = "Military Crate"
