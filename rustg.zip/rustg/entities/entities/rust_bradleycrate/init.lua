AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

DEFINE_BASECLASS("rust_storage")

-- Настройки вариантов лута
ENT.LootVariants = {
    {
        name = "Вариант 1 - Пулемётный",
        chance = 0.17, -- Шанс выпадения этого варианта
        items = {
            {
                itemid = "lmg.m249",
                amount = {1, 1},
            },
            {
                itemid = "ammo.rifle",
                amount = {128, 256},
            },
            {
                itemid = "ammo.pistol",
                amount = {60, 60},
            },
            {
                itemid = "ammo.rifle.incendiary",
                amount = {60, 60},
            },
            {
                itemid = "door.hinged.toptier",
                amount = {1, 1},
            },
            {
                itemid = "ammo.rocket.basic",
                amount = {1, 1},
            },
            {
                itemid = "techparts",
                amount = {12, 24},
            }, -- Добавлена недостающая запятая
            {
                itemid = "computer",
                amount = {1, 1},
            }
        }
    },
    {
        name = "Вариант 2 - Штурмовой",
        chance = 0.25,
        items = {
            {
                itemid = "rifle.ak",
                amount = {1, 1},
            },
            {
                itemid = "ammo.rifle",
                amount = {90, 128},
            },
            {
                itemid = "explosive.timed",
                amount = {1, 1},
            }
        }
    },
    {
        name = "Вариант 3 - SMG",
        chance = 0.34,
        items = {
            {
                itemid = "smg.thompson",
                amount = {1, 1},
            },
            {
                itemid = "ammo.rifle",
                amount = {64, 128},
            }
        }
    },
    {
        name = "Вариант 4 - Снайперский L96", -- Исправлено имя (было дублирование "Вариант 1")
        chance = 0.22,
        items = {
            {
                itemid = "rifle.l96",
                amount = {1, 1},
            },
            {
                itemid = "ammo.rifle",
                amount = {128, 256},
            },
            {
                itemid = "ammo.pistol",
                amount = {60, 60},
            },
            {
                itemid = "ammo.rifle.incendiary",
                amount = {60, 60},
            },
            {
                itemid = "door.hinged.toptier",
                amount = {1, 1},
            },
            {
                itemid = "ammo.rocket.basic",
                amount = {1, 1},
            },
            {
                itemid = "techparts",
                amount = {12, 24},
            }
        }
    },
    {
        name = "Вариант 5 - Дробовик", -- Исправлено имя
        chance = 0.24,
        items = {
            {
                itemid = "shotgun.m4",
                amount = {1, 1},
            },
            {
                itemid = "ammo.shotgun",
                amount = {32, 32},
            },
            {
                itemid = "ammo.pistol",
                amount = {60, 60},
            },
            {
                itemid = "door.hinged.toptier",
                amount = {1, 1},
            },
            {
                itemid = "techparts",
                amount = {12, 24},
            }
        }
    },
    {
        name = "Вариант 6 - Пистолет", -- Исправлено имя
        chance = 0.36,
        items = {
            {
                itemid = "pistol.m92",
                amount = {1, 1},
            },
            {
                itemid = "ammo.pistol",
                amount = {60, 60},
            },
            {
                itemid = "techparts",
                amount = {12, 24},
            }
        }
    },
    {
        name = "Вариант 7 - Строительный", -- Исправлено имя
        chance = 0.45,
        items = {
            {
                itemid = "door.hinged.toptier",
                amount = {1, 1},
            },
            {
                itemid = "wall.window.glass.reinforced",
                amount = {1, 1},
            },
            {
                itemid = "computer",
                amount = {1, 2},
            },
            {
                itemid = "camera",
                amount = {1, 1},
            },
            {
                itemid = "techparts",
                amount = {12, 24},
            }
        }
    },
    {
        name = "Вариант 8 - Снайперский Болтовой", -- Исправлено имя
        chance = 0.20,
        items = {
            {
                itemid = "rifle.bolt",
                amount = {1, 1},
            },
            {
                itemid = "ammo.rifle",
                amount = {32, 64},
            },
            {
                itemid = "weapon.mod.silencer",
                amount = {1, 1},
            }
        }
    }
}

function ENT:Initialize()
    if CLIENT then return end

    self:SetModel("models/environment/crates/elite_crate.mdl")
    self:SetSolid(SOLID_VPHYSICS)

    if self.Deploy then
        self:PhysicsInitStatic(SOLID_VPHYSICS)
    else
        self:PhysicsInit(SOLID_VPHYSICS)
        local phys = self:GetPhysicsObject()
        if IsValid(phys) then
            phys:EnableMotion(false)
            phys:Sleep()
        end
    end

    self:CreateInventory(12)
    self:SetInteractable(true)
    self:SetOpenSoundType("elite")
    self:SetDamageable(false)

    timer.Simple(0.1, function()
        if IsValid(self) then
            self.SpawnPosition = self:GetPos()
            self.SpawnAngles = self:GetAngles()
            self:PopulateWithItems()
        end
    end)

    timer.Create("CheckEmpty_" .. self:EntIndex(), 2, 0, function()
        if IsValid(self) then
            self:CheckAndRespawnIfEmpty()
        else
            timer.Remove("CheckEmpty_" .. self:EntIndex())
        end
    end)
end

function ENT:PopulateWithItems()
    -- Выбираем случайный вариант лута на основе шансов
    local selectedVariant = self:SelectLootVariant()
    
    if not selectedVariant then
        print("[BradleyCrate] Не удалось выбрать вариант лута!")
        return
    end
    
    print("[BradleyCrate] Выбран вариант: " .. selectedVariant.name)
    
    -- Очищаем инвентарь
    if self.Inventory then
        for i = 1, self.InventorySlots do
            if self.Inventory[i] then
                self:RemoveSlot(i)
            end
        end
    end

    -- Заполняем ящик предметами из выбранного варианта
    local currentSlot = 1
    
    for _, itemData in ipairs(selectedVariant.items) do
        if currentSlot > self.InventorySlots then break end
        
        local itemDef = gRust.Items[itemData.itemid]
        if itemDef then
            local amount = 1
            if type(itemData.amount) == "table" then
                amount = math.random(itemData.amount[1], itemData.amount[2])
            else
                amount = itemData.amount
            end
            
            local item = gRust.CreateItem(itemData.itemid, amount)
            if item then
                self:SetSlot(item, currentSlot)
                currentSlot = currentSlot + 1
                print(string.format("[BradleyCrate] Добавлен предмет: %s x%d", itemData.itemid, amount))
            end
        else
            print("[BradleyCrate] Предмет не найден: " .. itemData.itemid)
        end
    end
end

function ENT:SelectLootVariant()
    -- Нормализуем шансы (на случай если сумма не равна 1)
    local totalChance = 0
    for _, variant in ipairs(self.LootVariants) do
        totalChance = totalChance + (variant.chance or 0)
    end
    
    -- Выбираем вариант на основе шансов
    local randomValue = math.random() * totalChance
    local cumulativeChance = 0
    
    for _, variant in ipairs(self.LootVariants) do
        cumulativeChance = cumulativeChance + (variant.chance or 0)
        if randomValue <= cumulativeChance then
            return variant
        end
    end
    
    -- Если по какой-то причине не выбрали, возвращаем первый вариант
    return self.LootVariants[1]
end

function ENT:RemoveSlot(slot)
    BaseClass.RemoveSlot(self, slot)
    
    timer.Simple(0.1, function()
        if IsValid(self) then
            self:CheckAndRespawnIfEmpty()
        end
    end)
end

function ENT:CheckAndRespawnIfEmpty()
    if not self.Inventory then
        self:ScheduleRespawn()
        return
    end

    local hasItems = false
    for i = 1, self.InventorySlots do
        if self.Inventory[i] then
            hasItems = true
            break
        end
    end

    if not hasItems then
        self:ScheduleRespawn()
    end
end

function ENT:ScheduleRespawn()
    local pos = self.SpawnPosition or self:GetPos()
    local ang = self.SpawnAngles or self:GetAngles()
    
    timer.Remove("CheckEmpty_" .. self:EntIndex())
    
    self:Remove()
    
    timer.Create("BradleyCrateRespawn_" .. tostring(pos), 900, 1, function()
        local newCrate = ents.Create("rust_bradleycrate")
        if IsValid(newCrate) then
            newCrate:SetPos(pos)
            newCrate:SetAngles(ang)
            newCrate:Spawn()
            newCrate:Activate()
        end
    end)
end

function ENT:OnRemove()
    timer.Remove("CheckEmpty_" .. self:EntIndex())
end

function ENT:Use(activator, caller)
    BaseClass.Use(self, activator, caller)
end