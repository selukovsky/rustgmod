ENT.Base = "rust_storage"

ENT.InventoryName   = "Metal Shop Front"

ENT.Deploy          = {}
ENT.Deploy.Model    = "models/darky_m/rust/shopfront.mdl"
ENT.Deploy.Sound    = "deploy/shop_front_deploy.wav"
ENT.Deploy.Socket   = "base"

ENT.Pickup = "metal_shop_front"